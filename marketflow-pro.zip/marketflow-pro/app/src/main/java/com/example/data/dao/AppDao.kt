package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Account
import com.example.data.model.Customer
import com.example.data.model.Expense
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItem
import com.example.data.model.InvoiceType
import com.example.data.model.JournalEntry
import com.example.data.model.JournalLine
import com.example.data.model.PaymentTransaction
import com.example.data.model.Product
import com.example.data.model.StockAudit
import com.example.data.model.StockAuditItem
import com.example.data.model.Supplier
import com.example.data.model.TransactionType
import com.example.data.model.Employee
import com.example.data.model.DelegateSyncLog
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
  // Products
  @Query("SELECT * FROM products ORDER BY name ASC")
  fun getAllProducts(): Flow<List<Product>>

  @Query("SELECT * FROM products")
  suspend fun getAllProductsSync(): List<Product>

  @Query("SELECT * FROM products WHERE id = :id")
  suspend fun getProductById(id: Long): Product?

  @Query("SELECT * FROM products WHERE barcode = :barcode LIMIT 1")
  suspend fun getProductByBarcode(barcode: String): Product?

  @Query("SELECT COUNT(*) FROM products")
  suspend fun getProductCount(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProduct(product: Product): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProducts(products: List<Product>)

  @Update
  suspend fun updateProduct(product: Product)

  @Delete
  suspend fun deleteProduct(product: Product)

  @Query("UPDATE products SET totalPiecesInStock = totalPiecesInStock + :piecesDelta WHERE id = :productId")
  suspend fun adjustProductStock(productId: Long, piecesDelta: Int)

  @Query("UPDATE products SET totalPiecesInStock = :newStock WHERE id = :productId")
  suspend fun setProductStock(productId: Long, newStock: Int)

  @Query("UPDATE products SET cartonCostPrice = :cartonCost WHERE id = :productId")
  suspend fun updateProductCost(productId: Long, cartonCost: Double)

  // Customers
  @Query("SELECT * FROM customers ORDER BY name ASC")
  fun getAllCustomers(): Flow<List<Customer>>

  @Query("SELECT * FROM customers WHERE id = :id")
  suspend fun getCustomerById(id: Long): Customer?

  @Query("SELECT COUNT(*) FROM customers")
  suspend fun getCustomerCount(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCustomer(customer: Customer): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCustomers(customers: List<Customer>)

  @Update
  suspend fun updateCustomer(customer: Customer)

  @Delete
  suspend fun deleteCustomer(customer: Customer)

  @Query("UPDATE customers SET currentBalance = currentBalance + :balanceDelta WHERE id = :customerId")
  suspend fun updateCustomerBalance(customerId: Long, balanceDelta: Double)

  // Suppliers
  @Query("SELECT * FROM suppliers ORDER BY name ASC")
  fun getAllSuppliers(): Flow<List<Supplier>>

  @Query("SELECT * FROM suppliers WHERE id = :id")
  suspend fun getSupplierById(id: Long): Supplier?

  @Query("SELECT COUNT(*) FROM suppliers")
  suspend fun getSupplierCount(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSupplier(supplier: Supplier): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSuppliers(suppliers: List<Supplier>)

  @Update
  suspend fun updateSupplier(supplier: Supplier)

  @Delete
  suspend fun deleteSupplier(supplier: Supplier)

  @Query("UPDATE suppliers SET currentBalance = currentBalance + :balanceDelta WHERE id = :supplierId")
  suspend fun updateSupplierBalance(supplierId: Long, balanceDelta: Double)

  // Invoices
  @Query("SELECT * FROM invoices ORDER BY timestamp DESC")
  fun getAllInvoices(): Flow<List<Invoice>>

  @Query("SELECT * FROM invoices")
  suspend fun getAllInvoicesSync(): List<Invoice>

  @Query("SELECT * FROM invoices WHERE type = :type ORDER BY timestamp DESC")
  fun getInvoicesByType(type: InvoiceType): Flow<List<Invoice>>

  @Query("SELECT * FROM invoices WHERE partyId = :partyId AND type = :type ORDER BY timestamp DESC")
  fun getInvoicesByParty(partyId: Long, type: InvoiceType): Flow<List<Invoice>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertInvoice(invoice: Invoice): Long

  @Update
  suspend fun updateInvoice(invoice: Invoice)

  @Delete
  suspend fun deleteInvoice(invoice: Invoice)

  // Invoice Items
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertInvoiceItems(items: List<InvoiceItem>)

  @Query("SELECT * FROM invoice_items WHERE invoiceId = :invoiceId")
  fun getInvoiceItems(invoiceId: Long): Flow<List<InvoiceItem>>

  @Query("SELECT * FROM invoice_items WHERE invoiceId = :invoiceId")
  suspend fun getInvoiceItemsSync(invoiceId: Long): List<InvoiceItem>

  @Query("DELETE FROM invoice_items WHERE invoiceId = :invoiceId")
  suspend fun deleteInvoiceItemsByInvoiceId(invoiceId: Long)

  @Query("DELETE FROM journal_entries WHERE referenceId = :refId AND referenceType = :refType")
  suspend fun deleteJournalEntriesByReference(refId: Long, refType: String)

  @Query("SELECT * FROM invoice_items")
  fun getAllInvoiceItems(): Flow<List<InvoiceItem>>

  @Query("SELECT * FROM invoice_items")
  suspend fun getAllInvoiceItemsSync(): List<InvoiceItem>

  // Transactions (سندات القبض والصرف)
  @Query("SELECT * FROM payment_transactions ORDER BY timestamp DESC")
  fun getAllTransactions(): Flow<List<PaymentTransaction>>

  @Query("SELECT * FROM payment_transactions WHERE partyId = :partyId AND type = :type ORDER BY timestamp DESC")
  fun getTransactionsByParty(partyId: Long, type: TransactionType): Flow<List<PaymentTransaction>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTransaction(tx: PaymentTransaction): Long

  // Expenses (المصروفات)
  @Query("SELECT * FROM expenses ORDER BY timestamp DESC")
  fun getAllExpenses(): Flow<List<Expense>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertExpense(expense: Expense): Long

  @Delete
  suspend fun deleteExpense(expense: Expense)

  // Stock Audits (الجرد المخزني)
  @Query("SELECT * FROM stock_audits ORDER BY auditDate DESC")
  fun getAllStockAudits(): Flow<List<StockAudit>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertStockAudit(audit: StockAudit): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertStockAuditItems(items: List<StockAuditItem>)

  @Query("SELECT * FROM stock_audit_items WHERE auditId = :auditId")
  fun getStockAuditItems(auditId: Long): Flow<List<StockAuditItem>>

  // --- Double-Entry Accounting (دليل الحسابات وقيود اليومية) ---
  @Query("SELECT * FROM accounts ORDER BY code ASC")
  fun getAllAccounts(): Flow<List<Account>>

  @Query("SELECT * FROM accounts WHERE code = :code LIMIT 1")
  suspend fun getAccountByCode(code: String): Account?

  @Query("SELECT COUNT(*) FROM accounts")
  suspend fun getAccountsCount(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAccount(account: Account)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAccounts(accounts: List<Account>)

  // Journal Entries
  @Query("SELECT * FROM journal_entries ORDER BY timestamp DESC")
  fun getAllJournalEntries(): Flow<List<JournalEntry>>

  @Query("SELECT * FROM journal_entries WHERE id = :id")
  suspend fun getJournalEntryById(id: Long): JournalEntry?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertJournalEntry(entry: JournalEntry): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertJournalLines(lines: List<JournalLine>)

  @Query("SELECT * FROM journal_lines WHERE entryId = :entryId")
  fun getJournalLinesForEntry(entryId: Long): Flow<List<JournalLine>>

  @Query("SELECT * FROM journal_lines")
  fun getAllJournalLines(): Flow<List<JournalLine>>

  @Query("SELECT * FROM journal_lines WHERE accountCode = :code ORDER BY id ASC")
  fun getJournalLinesForAccount(code: String): Flow<List<JournalLine>>

  // --- Full Database Backup & Restore Helpers ---
  @Query("SELECT * FROM customers")
  suspend fun getAllCustomersSync(): List<Customer>

  @Query("SELECT * FROM suppliers")
  suspend fun getAllSuppliersSync(): List<Supplier>

  @Query("SELECT * FROM payment_transactions")
  suspend fun getAllTransactionsSync(): List<PaymentTransaction>

  @Query("SELECT * FROM expenses")
  suspend fun getAllExpensesSync(): List<Expense>

  @Query("SELECT * FROM stock_audits")
  suspend fun getAllStockAuditsSync(): List<StockAudit>

  @Query("SELECT * FROM stock_audit_items")
  suspend fun getAllStockAuditItemsSync(): List<StockAuditItem>

  @Query("SELECT * FROM accounts")
  suspend fun getAllAccountsSync(): List<Account>

  @Query("SELECT * FROM journal_entries")
  suspend fun getAllJournalEntriesSync(): List<JournalEntry>

  @Query("SELECT * FROM journal_lines")
  suspend fun getAllJournalLinesSync(): List<JournalLine>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertInvoices(invoices: List<Invoice>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTransactions(transactions: List<PaymentTransaction>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertExpenses(expenses: List<Expense>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertStockAudits(audits: List<StockAudit>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertJournalEntries(entries: List<JournalEntry>)

  @Query("DELETE FROM invoice_items")
  suspend fun deleteAllInvoiceItems()

  @Query("DELETE FROM invoices")
  suspend fun deleteAllInvoices()

  @Query("DELETE FROM payment_transactions")
  suspend fun deleteAllTransactions()

  @Query("DELETE FROM expenses")
  suspend fun deleteAllExpenses()

  @Query("DELETE FROM stock_audit_items")
  suspend fun deleteAllStockAuditItems()

  @Query("DELETE FROM stock_audits")
  suspend fun deleteAllStockAudits()

  @Query("DELETE FROM journal_lines")
  suspend fun deleteAllJournalLines()

  @Query("DELETE FROM journal_entries")
  suspend fun deleteAllJournalEntries()

  @Query("DELETE FROM products")
  suspend fun deleteAllProducts()

  @Query("DELETE FROM customers")
  suspend fun deleteAllCustomers()

  @Query("DELETE FROM suppliers")
  suspend fun deleteAllSuppliers()

  @Query("DELETE FROM accounts")
  suspend fun deleteAllAccounts()

  @androidx.room.Transaction
  suspend fun clearAllDataToFreshState() {
    deleteAllInvoiceItems()
    deleteAllInvoices()
    deleteAllTransactions()
    deleteAllExpenses()
    deleteAllStockAuditItems()
    deleteAllStockAudits()
    deleteAllJournalLines()
    deleteAllJournalEntries()
    deleteAllProducts()
    deleteAllCustomers()
    deleteAllSuppliers()
  }

  @androidx.room.Transaction
  suspend fun restoreDatabaseAll(
    products: List<Product>,
    customers: List<Customer>,
    suppliers: List<Supplier>,
    invoices: List<Invoice>,
    invoiceItems: List<InvoiceItem>,
    transactions: List<PaymentTransaction>,
    expenses: List<Expense>,
    stockAudits: List<StockAudit>,
    stockAuditItems: List<StockAuditItem>,
    accounts: List<Account>,
    journalEntries: List<JournalEntry>,
    journalLines: List<JournalLine>
  ) {
    deleteAllInvoiceItems()
    deleteAllInvoices()
    deleteAllTransactions()
    deleteAllExpenses()
    deleteAllStockAuditItems()
    deleteAllStockAudits()
    deleteAllJournalLines()
    deleteAllJournalEntries()
    deleteAllProducts()
    deleteAllCustomers()
    deleteAllSuppliers()
    deleteAllAccounts()

    if (products.isNotEmpty()) insertProducts(products)
    if (customers.isNotEmpty()) insertCustomers(customers)
    if (suppliers.isNotEmpty()) insertSuppliers(suppliers)
    if (invoices.isNotEmpty()) insertInvoices(invoices)
    if (invoiceItems.isNotEmpty()) insertInvoiceItems(invoiceItems)
    if (transactions.isNotEmpty()) insertTransactions(transactions)
    if (expenses.isNotEmpty()) insertExpenses(expenses)
    if (stockAudits.isNotEmpty()) insertStockAudits(stockAudits)
    if (stockAuditItems.isNotEmpty()) insertStockAuditItems(stockAuditItems)
    if (accounts.isNotEmpty()) insertAccounts(accounts)
    if (journalEntries.isNotEmpty()) insertJournalEntries(journalEntries)
    if (journalLines.isNotEmpty()) insertJournalLines(journalLines)
  }

  // ==========================================
  // Multi-Employee & Delegate Queries
  // ==========================================

  @Query("SELECT * FROM employees ORDER BY id ASC")
  fun getAllEmployees(): Flow<List<Employee>>

  @Query("SELECT * FROM employees")
  suspend fun getAllEmployeesSync(): List<Employee>

  @Query("SELECT * FROM employees WHERE id = :id")
  suspend fun getEmployeeById(id: Long): Employee?

  @Query("SELECT * FROM employees WHERE isDelegate = 1 AND isActive = 1 ORDER BY name ASC")
  fun getActiveDelegates(): Flow<List<Employee>>

  @Query("SELECT COUNT(*) FROM employees")
  suspend fun getEmployeeCount(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertEmployee(employee: Employee): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertEmployees(employees: List<Employee>)

  @Update
  suspend fun updateEmployee(employee: Employee)

  @Delete
  suspend fun deleteEmployee(employee: Employee)

  @Query("DELETE FROM employees")
  suspend fun deleteAllEmployees()

  // Delegate Sync Logs
  @Query("SELECT * FROM delegate_sync_logs ORDER BY timestamp DESC")
  fun getAllSyncLogs(): Flow<List<DelegateSyncLog>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSyncLog(log: DelegateSyncLog): Long

  // Delegate Pending / Synced Invoices
  @Query("SELECT * FROM invoices WHERE syncStatus = 'PENDING_SYNC' ORDER BY timestamp ASC")
  fun getPendingSyncInvoices(): Flow<List<Invoice>>

  @Query("SELECT * FROM invoices WHERE syncStatus = 'PENDING_SYNC'")
  suspend fun getPendingSyncInvoicesSync(): List<Invoice>

  @Query("UPDATE invoices SET syncStatus = :newStatus WHERE id = :invoiceId")
  suspend fun updateInvoiceSyncStatus(invoiceId: Long, newStatus: String)

  @Query("UPDATE invoices SET syncStatus = 'SYNCED' WHERE id IN (:ids)")
  suspend fun markInvoicesAsSynced(ids: List<Long>)
}
