package com.example.ui.components

import android.app.DatePickerDialog
import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.ReportPeriod
import com.example.ui.WholesaleViewModel
import com.example.ui.theme.EmeraldPrimary
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * دالة مساعدة لفتح نافذة اختيار التاريخ القياسية
 */
fun showAndroidDatePicker(
  context: Context,
  initialTimestamp: Long,
  onDateSelected: (Long) -> Unit
) {
  val cal = Calendar.getInstance()
  cal.timeInMillis = initialTimestamp
  val year = cal.get(Calendar.YEAR)
  val month = cal.get(Calendar.MONTH)
  val day = cal.get(Calendar.DAY_OF_MONTH)

  val datePickerDialog = DatePickerDialog(
    context,
    { _, selectedYear, selectedMonth, selectedDay ->
      val resCal = Calendar.getInstance()
      resCal.set(Calendar.YEAR, selectedYear)
      resCal.set(Calendar.MONTH, selectedMonth)
      resCal.set(Calendar.DAY_OF_MONTH, selectedDay)
      resCal.set(Calendar.HOUR_OF_DAY, 0)
      resCal.set(Calendar.MINUTE, 0)
      resCal.set(Calendar.SECOND, 0)
      resCal.set(Calendar.MILLISECOND, 0)
      onDateSelected(resCal.timeInMillis)
    },
    year,
    month,
    day
  )
  datePickerDialog.show()
}

/**
 * شريط تصفية واختيار الفترة الزمنية واليوم المخصص والمدة المحددة
 */
@Composable
fun ReportPeriodSelectorBar(
  viewModel: WholesaleViewModel,
  modifier: Modifier = Modifier,
  showLabel: Boolean = true
) {
  val context = LocalContext.current
  val selectedPeriod by viewModel.selectedReportPeriod.collectAsStateWithLifecycle()
  val customDayTimestamp by viewModel.customDayTimestamp.collectAsStateWithLifecycle()
  val customDateRange by viewModel.customDateRange.collectAsStateWithLifecycle()

  var showCustomRangeDialog by remember { mutableStateOf(false) }

  val arabicDayFormat = remember { SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar")) }
  val shortDateFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale("ar")) }

  Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
    // 1. فلاتر الفترات المجهزة مسبقاً
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.fillMaxWidth()
    ) {
      if (showLabel) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 6.dp)) {
          Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(15.dp), tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "الفترة:",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items(ReportPeriod.values()) { period ->
          val isSelected = selectedPeriod == period
          FilterChip(
            selected = isSelected,
            onClick = {
              if (period == ReportPeriod.CUSTOM_DAY) {
                if (selectedPeriod == ReportPeriod.CUSTOM_DAY) {
                  // الضغط مرة ثانية يفتح التقويم لتغيير اليوم
                  showAndroidDatePicker(context, customDayTimestamp) { newDate ->
                    viewModel.setCustomDay(newDate)
                  }
                } else {
                  viewModel.setReportPeriod(ReportPeriod.CUSTOM_DAY)
                }
              } else if (period == ReportPeriod.CUSTOM_RANGE) {
                showCustomRangeDialog = true
              } else {
                viewModel.setReportPeriod(period)
              }
            },
            leadingIcon = {
              when (period) {
                ReportPeriod.CUSTOM_DAY -> Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(14.dp))
                ReportPeriod.CUSTOM_RANGE -> Icon(Icons.Default.EditCalendar, contentDescription = null, modifier = Modifier.size(14.dp))
                else -> null
              }
            },
            label = {
              Text(
                text = period.label,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = MaterialTheme.colorScheme.primary,
              selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
              selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
            )
          )
        }
      }
    }

    // 2. شريط التنقل والتحكم التفاعلي باليوم المخصص
    if (selectedPeriod == ReportPeriod.CUSTOM_DAY) {
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // زر اليوم السابق
          IconButton(
            onClick = {
              val cal = Calendar.getInstance()
              cal.timeInMillis = customDayTimestamp
              cal.add(Calendar.DAY_OF_YEAR, -1)
              viewModel.setCustomDay(cal.timeInMillis)
            },
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              Icons.AutoMirrored.Filled.ArrowForward,
              contentDescription = "اليوم السابق",
              modifier = Modifier.size(16.dp),
              tint = MaterialTheme.colorScheme.primary
            )
          }

          // عرض اليوم المختار مع زر فتح التقويم
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .clickable {
                showAndroidDatePicker(context, customDayTimestamp) { newDate ->
                  viewModel.setCustomDay(newDate)
                }
              }
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(6.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = arabicDayFormat.format(Date(customDayTimestamp)),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
              Text("اضغط لتغيير اليوم من التقويم 📅", fontSize = 9.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }

          // زر اليوم التالي
          IconButton(
            onClick = {
              val cal = Calendar.getInstance()
              cal.timeInMillis = customDayTimestamp
              cal.add(Calendar.DAY_OF_YEAR, 1)
              viewModel.setCustomDay(cal.timeInMillis)
            },
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "اليوم التالي",
              modifier = Modifier.size(16.dp),
              tint = MaterialTheme.colorScheme.primary
            )
          }
        }
      }
    }

    // 3. شريط عرض الفترة المخصصة المختارة
    if (selectedPeriod == ReportPeriod.CUSTOM_RANGE) {
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = EmeraldPrimary.copy(alpha = 0.12f),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { showCustomRangeDialog = true }
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(16.dp), tint = EmeraldPrimary)
            Spacer(modifier = Modifier.width(6.dp))
            val startStr = shortDateFormat.format(Date(customDateRange.first))
            val endStr = shortDateFormat.format(Date(customDateRange.second))
            Text(
              text = "الفترة المحددة: من $startStr إلى $endStr",
              fontSize = 11.5.sp,
              fontWeight = FontWeight.Bold,
              color = EmeraldPrimary
            )
          }

          Surface(
            shape = RoundedCornerShape(6.dp),
            color = EmeraldPrimary
          ) {
            Text(
              text = "تعديل الفترة ✎",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }
      }
    }
  }

  // نافذة تحديد المدة المخصصة
  if (showCustomRangeDialog) {
    CustomDateRangePickerDialog(
      initialStart = customDateRange.first,
      initialEnd = customDateRange.second,
      onDismiss = { showCustomRangeDialog = false },
      onApply = { start, end ->
        viewModel.setCustomDateRange(start, end)
        showCustomRangeDialog = false
      }
    )
  }
}

/**
 * نافذة حوارية أنيقة لتحديد نطاق زمني مخصص (من تاريخ - إلى تاريخ) مع خيارات سريعة
 */
@Composable
fun CustomDateRangePickerDialog(
  initialStart: Long,
  initialEnd: Long,
  onDismiss: () -> Unit,
  onApply: (startTimestamp: Long, endTimestamp: Long) -> Unit
) {
  val context = LocalContext.current
  var startTimestamp by remember { mutableLongStateOf(initialStart) }
  var endTimestamp by remember { mutableLongStateOf(initialEnd) }

  val dateFormat = remember { SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar")) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.95f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("تحديد فترة مخصصة", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        HorizontalDivider()

        Text("اختر بداية ونهاية الفترة المطلوبة لحساب التقارير والأرباح:", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        // بطاقة تحديد تاريخ البداية
        Card(
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              showAndroidDatePicker(context, startTimestamp) { newStart ->
                startTimestamp = newStart
                if (startTimestamp > endTimestamp) {
                  endTimestamp = startTimestamp
                }
              }
            }
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("من تاريخ (بداية الفترة):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = dateFormat.format(Date(startTimestamp)),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
            }
            Icon(Icons.Default.CalendarToday, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
          }
        }

        // بطاقة تحديد تاريخ النهاية
        Card(
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              showAndroidDatePicker(context, endTimestamp) { newEnd ->
                endTimestamp = newEnd
                if (endTimestamp < startTimestamp) {
                  startTimestamp = endTimestamp
                }
              }
            }
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("إلى تاريخ (نهاية الفترة):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = dateFormat.format(Date(endTimestamp)),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
            }
            Icon(Icons.Default.CalendarToday, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
          }
        }

        // خيارات وفترات سريعة
        Text("خيارات سريعة:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          OutlinedButton(
            onClick = {
              val cal = Calendar.getInstance()
              endTimestamp = cal.timeInMillis
              cal.add(Calendar.DAY_OF_YEAR, -6)
              startTimestamp = cal.timeInMillis
            },
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(4.dp)
          ) {
            Text("آخر 7 أيام", fontSize = 10.5.sp)
          }

          OutlinedButton(
            onClick = {
              val cal = Calendar.getInstance()
              endTimestamp = cal.timeInMillis
              cal.add(Calendar.DAY_OF_YEAR, -29)
              startTimestamp = cal.timeInMillis
            },
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(4.dp)
          ) {
            Text("آخر 30 يوم", fontSize = 10.5.sp)
          }

          OutlinedButton(
            onClick = {
              val cal = Calendar.getInstance()
              cal.set(Calendar.DAY_OF_MONTH, 1)
              startTimestamp = cal.timeInMillis
              cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
              endTimestamp = cal.timeInMillis
            },
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(4.dp)
          ) {
            Text("هذا الشهر", fontSize = 10.5.sp)
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val actualStart = minOf(startTimestamp, endTimestamp)
              val actualEnd = maxOf(startTimestamp, endTimestamp)
              onApply(actualStart, actualEnd)
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            modifier = Modifier.weight(1f)
          ) {
            Text("تطبيق وتحديث التقارير", fontWeight = FontWeight.Bold)
          }

          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}
