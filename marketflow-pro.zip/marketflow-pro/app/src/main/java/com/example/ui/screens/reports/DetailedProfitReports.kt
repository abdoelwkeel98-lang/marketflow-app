package com.example.ui.screens.reports

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Customer
import com.example.data.model.Expense
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItem
import com.example.data.model.InvoiceType
import com.example.data.model.PaymentType
import com.example.data.model.Product
import com.example.ui.ExpenseCategoryStat
import com.example.ui.ProfitReportData
import com.example.ui.ReportPeriod
import com.example.ui.TopProductStat
import com.example.ui.WholesaleViewModel
import com.example.ui.components.ReportPeriodSelectorBar
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import com.example.utils.ReportExportHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ProfitDimensionItem(
  val id: Int,
  val title: String,
  val subtitle: String,
  val icon: ImageVector,
  val iconColor: Color
)

@Composable
fun DetailedProfitReportsView(
  viewModel: WholesaleViewModel,
  report: ProfitReportData,
  salesInvoices: List<Invoice>,
  invoiceItems: List<InvoiceItem>,
  products: List<Product>,
  customers: List<Customer>,
  expenses: List<Expense>,
  expensesByCategory: List<ExpenseCategoryStat>,
  topProducts: List<TopProductStat>,
  currency: String,
  onAddExpense: () -> Unit
) {
  val context = LocalContext.current
  var selectedDimension by remember { mutableIntStateOf(0) }
  var searchQuery by remember { mutableStateOf("") }
  var sortOrder by remember { mutableIntStateOf(0) } // 0: الأعلى ربحاً, 1: الأعلى مبيعات, 2: أعلى هامش %
  var isDimensionListExpanded by remember { mutableStateOf(false) }

  val businessProfile by viewModel.businessProfile.collectAsStateWithLifecycle()
  val selectedPeriod by viewModel.selectedReportPeriod.collectAsStateWithLifecycle()
  val customDayTimestamp by viewModel.customDayTimestamp.collectAsStateWithLifecycle()
  val customDateRange by viewModel.customDateRange.collectAsStateWithLifecycle()

  val (startTimestamp, endTimestamp) = remember(selectedPeriod, customDayTimestamp, customDateRange) {
    viewModel.getPeriodDateRange(selectedPeriod, customDayTimestamp, customDateRange)
  }

  // تصفية الفواتير بالفترة المحددة
  val filteredInvoices = remember(salesInvoices, startTimestamp, endTimestamp) {
    salesInvoices.filter { it.type == InvoiceType.SALE && it.timestamp in startTimestamp..endTimestamp }
  }

  val validInvoiceIds = remember(filteredInvoices) {
    filteredInvoices.map { it.id }.toSet()
  }

  val filteredItems = remember(invoiceItems, validInvoiceIds) {
    invoiceItems.filter { it.invoiceId in validInvoiceIds }
  }

  val filteredExpenses = remember(expenses, startTimestamp, endTimestamp) {
    expenses.filter { it.timestamp in startTimestamp..endTimestamp }
  }

  val totalSalesRevenue = remember(filteredInvoices) { filteredInvoices.sumOf { it.totalAmount } }
  val totalSalesCost = remember(filteredInvoices) { filteredInvoices.sumOf { it.totalCost } }
  val totalGrossProfit = remember(filteredInvoices) { filteredInvoices.sumOf { it.totalProfit } }
  val totalExpensesAmount = remember(filteredExpenses) { filteredExpenses.sumOf { it.amount } }
  val netProfit = totalGrossProfit - totalExpensesAmount + report.totalAuditDiscrepancy
  val profitMarginPercent = if (totalSalesRevenue > 0) (netProfit / totalSalesRevenue) * 100.0 else 0.0

  val dimensions = remember {
    listOf(
      ProfitDimensionItem(0, "📊 قائمة الدخل الشاملة (P&L)", "بيان الإيرادات والتكلفة والمصروفات وصافي الأرباح", Icons.Default.AttachMoney, EmeraldPrimary),
      ProfitDimensionItem(1, "👥 الأرباح حسب العميل", "أرباح كل عميل وهامش الربح وإجمالي المشتريات", Icons.Default.Person, Color(0xFF2563EB)),
      ProfitDimensionItem(2, "📅 الأرباح حسب اليوم والتاريخ", "حركة الأرباح الصافية يوماً بيوم خلال الفترة", Icons.Default.CalendarToday, Color(0xFFD97706)),
      ProfitDimensionItem(3, "🗂️ الأرباح حسب التصنيف والقسم", "تحليل ربحية كل قسم ومساهمته في أرباح المتجر", Icons.Default.Category, Color(0xFF059669)),
      ProfitDimensionItem(4, "🏷️ الأرباح حسب المنتج والأصناف", "هامش وربحية كل صنف مباع وتكلفة WAC والربح للقطعة", Icons.Default.ShoppingBag, Color(0xFF7C3AED)),
      ProfitDimensionItem(5, "👤 الأرباح حسب الموظف والكاشير", "إنتاجية وأرباح المبيعات المحققة بواسطة كل بائع", Icons.Default.Receipt, Color(0xFF0284C7)),
      ProfitDimensionItem(6, "🧾 الأرباح حسب الفاتورة", "كشف تفصيلي بربحية وتكلفة وهوامش كل فاتورة بيع", Icons.Default.Description, Color(0xFFE11D48))
    )
  }

  Column(modifier = Modifier.fillMaxSize()) {
    // 1. شريط فلترة الفترة الزمنية
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 4.dp),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
      Column(modifier = Modifier.padding(10.dp)) {
        ReportPeriodSelectorBar(
          viewModel = viewModel,
          showLabel = true
        )
      }
    }

    // 2. بطاقة مؤشرات الأرباح وصافي الدخل السريعة
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 4.dp),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("صافي الأرباح للفترة", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
              text = String.format(Locale.ENGLISH, "%.2f %s", netProfit, currency),
              fontSize = 20.sp,
              fontWeight = FontWeight.ExtraBold,
              color = if (netProfit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
            )
          }

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (netProfit >= 0) EmeraldPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = if (netProfit >= 0) Icons.AutoMirrored.Filled.TrendingUp else Icons.Default.TrendingDown,
                contentDescription = null,
                tint = if (netProfit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = String.format(Locale.ENGLISH, "هامش %.1f%%", profitMarginPercent),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = if (netProfit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column {
            Text("المبيعات", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
              text = String.format(Locale.ENGLISH, "%.1f %s", totalSalesRevenue, currency),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )
          }
          Column {
            Text("تكلفة WAC", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
              text = String.format(Locale.ENGLISH, "%.1f %s", totalSalesCost, currency),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          Column {
            Text("مجمل الربح", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
              text = String.format(Locale.ENGLISH, "%.1f %s", totalGrossProfit, currency),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = EmeraldPrimary
            )
          }
          Column {
            Text("المصروفات", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
              text = String.format(Locale.ENGLISH, "%.1f %s", totalExpensesAmount, currency),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.error
            )
          }
        }
      }
    }

    // 3. شريط أزرار الطباعة والتصدير الشامل (Print, PDF, Image, Share)
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 2.dp),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // طباعة مباشرة
        OutlinedButton(
          onClick = {
            ReportExportHelper.printReportViaSystem(
              context = context,
              report = report,
              period = selectedPeriod,
              businessName = businessProfile.businessName,
              phone = businessProfile.contactPhone,
              address = businessProfile.address,
              topProducts = topProducts,
              expensesByCategory = expensesByCategory,
              customTitle = "تقرير الأرباح والدخل - ${dimensions[selectedDimension].title}"
            )
          },
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(4.dp))
          Text("طباعة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        // مشاركة PDF
        Button(
          onClick = {
            val pdfFile = ReportExportHelper.generateFinancialReportPdf(
              context = context,
              report = report,
              period = selectedPeriod,
              businessName = businessProfile.businessName,
              phone = businessProfile.contactPhone,
              address = businessProfile.address,
              topProducts = topProducts,
              expensesByCategory = expensesByCategory,
              customTitle = "تقرير الأرباح والدخل - ${dimensions[selectedDimension].title}"
            )
            ReportExportHelper.shareFile(
              context = context,
              file = pdfFile,
              mimeType = "application/pdf",
              title = "مشاركة تقرير الأرباح والدخل PDF"
            )
          },
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        // مشاركة كصورة PNG
        Button(
          onClick = {
            val imgFile = ReportExportHelper.generateFinancialReportImage(
              context = context,
              report = report,
              period = selectedPeriod,
              businessName = businessProfile.businessName,
              topProducts = topProducts,
              customTitle = "تقرير الأرباح والدخل - ${dimensions[selectedDimension].title}"
            )
            ReportExportHelper.shareFile(
              context = context,
              file = imgFile,
              mimeType = "image/png",
              title = "مشاركة صورة تقرير الأرباح والدخل"
            )
          },
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("صورة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        // نسخ ملخص نصي
        IconButton(
          onClick = {
            val dateStr = SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH).format(Date())
            val txt = "📊 تقرير الأرباح والدخل (${businessProfile.businessName})\nالفترة: ${selectedPeriod.label} ($dateStr)\n• المبيعات: ${String.format(Locale.ENGLISH, "%.2f", totalSalesRevenue)} $currency\n• تكلفة البضاعة WAC: ${String.format(Locale.ENGLISH, "%.2f", totalSalesCost)} $currency\n• مجمل الربح: ${String.format(Locale.ENGLISH, "%.2f", totalGrossProfit)} $currency\n• المصروفات: ${String.format(Locale.ENGLISH, "%.2f", totalExpensesAmount)} $currency\n• صافي الأرباح: ${String.format(Locale.ENGLISH, "%.2f", netProfit)} $currency\n• هامش الربح: ${String.format(Locale.ENGLISH, "%.1f%%", profitMarginPercent)}"
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Profit Report", txt))
            Toast.makeText(context, "تم نسخ ملخص الأرباح للحافظة ✓", Toast.LENGTH_SHORT).show()
          },
          modifier = Modifier.size(32.dp)
        ) {
          Icon(Icons.Default.ContentCopy, contentDescription = "نسخ", modifier = Modifier.size(16.dp))
        }
      }
    }

    // 4. محدد أبعاد تقرير الأرباح (الأرباح حسب العميل، اليوم، التصنيف، المنتج، الموظف، الفاتورة)
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 4.dp),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
      Column(modifier = Modifier.padding(10.dp)) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { isDimensionListExpanded = !isDimensionListExpanded }
            .padding(vertical = 2.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = dimensions[selectedDimension].iconColor.copy(alpha = 0.15f),
              modifier = Modifier.size(32.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  dimensions[selectedDimension].icon,
                  contentDescription = null,
                  tint = dimensions[selectedDimension].iconColor,
                  modifier = Modifier.size(18.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = dimensions[selectedDimension].title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = dimensions[selectedDimension].subtitle,
                fontSize = 10.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
          }

          Icon(
            imageVector = if (isDimensionListExpanded) Icons.Default.Clear else Icons.Default.FilterList,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
          )
        }

        // القائمة المنسدلة للأبعاد
        AnimatedVisibility(visible = isDimensionListExpanded) {
          Column(modifier = Modifier.padding(top = 10.dp)) {
            HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(6.dp))

            dimensions.forEach { dim ->
              val isSelected = dim.id == selectedDimension
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .background(if (isSelected) dim.iconColor.copy(alpha = 0.12f) else Color.Transparent)
                  .clickable {
                    selectedDimension = dim.id
                    isDimensionListExpanded = false
                  }
                  .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = dim.icon,
                  contentDescription = null,
                  tint = if (isSelected) dim.iconColor else MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = dim.title,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 12.sp,
                    color = if (isSelected) dim.iconColor else MaterialTheme.colorScheme.onSurface
                  )
                  Text(
                    text = dim.subtitle,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
                if (isSelected) {
                  Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = dim.iconColor,
                    modifier = Modifier.size(16.dp)
                  )
                }
              }
            }
          }
        }
      }
    }

    // 5. شريط البحث والترتيب (للأبعاد التفصيلية 1 إلى 6)
    if (selectedDimension != 0) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text("بحث في نتائج التقرير...", fontSize = 11.5.sp) },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
          trailingIcon = {
            if (searchQuery.isNotBlank()) {
              IconButton(onClick = { searchQuery = "" }) {
                Icon(Icons.Default.Clear, contentDescription = "مسح", modifier = Modifier.size(14.dp))
              }
            }
          },
          singleLine = true,
          modifier = Modifier
            .weight(1f)
            .height(48.dp),
          shape = RoundedCornerShape(10.dp)
        )

        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          modifier = Modifier.clickable {
            sortOrder = (sortOrder + 1) % 3
          }
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = when (sortOrder) {
                0 -> "الأعلى ربحاً ⬇"
                1 -> "الأعلى مبيعات ⬇"
                else -> "أعلى هامش % ⬇"
              },
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }
      }
    }

    // 6. عرض محتوى البعد المختار
    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
      when (selectedDimension) {
        0 -> GeneralIncomeStatementSubReport(
          report = report,
          expensesByCategory = expensesByCategory,
          onAddExpense = onAddExpense,
          currency = currency
        )
        1 -> ProfitByCustomerSubReport(
          invoices = filteredInvoices,
          customers = customers,
          totalProfit = totalGrossProfit,
          searchQuery = searchQuery,
          sortOrder = sortOrder,
          currency = currency
        )
        2 -> ProfitByDaySubReport(
          invoices = filteredInvoices,
          expenses = filteredExpenses,
          searchQuery = searchQuery,
          currency = currency
        )
        3 -> ProfitByCategorySubReport(
          items = filteredItems,
          products = products,
          totalProfit = totalGrossProfit,
          searchQuery = searchQuery,
          sortOrder = sortOrder,
          currency = currency
        )
        4 -> ProfitByProductSubReport(
          items = filteredItems,
          products = products,
          totalProfit = totalGrossProfit,
          searchQuery = searchQuery,
          sortOrder = sortOrder,
          currency = currency
        )
        5 -> ProfitByEmployeeSubReport(
          invoices = filteredInvoices,
          totalProfit = totalGrossProfit,
          searchQuery = searchQuery,
          currency = currency
        )
        6 -> ProfitByInvoiceSubReport(
          invoices = filteredInvoices,
          searchQuery = searchQuery,
          sortOrder = sortOrder,
          currency = currency
        )
      }
    }
  }
}

// =============================================================================
// البعد 0: قائمة الدخل الشاملة P&L (Comprehensive Income Statement)
// =============================================================================
@Composable
fun GeneralIncomeStatementSubReport(
  report: ProfitReportData,
  expensesByCategory: List<ExpenseCategoryStat>,
  onAddExpense: () -> Unit,
  currency: String
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(14.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(
            text = "قائمة الأرباح والخسائر الشاملة (P&L)",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
          Text(
            text = "تدرج بنود الإيرادات والتكاليف والمصاريف وصافي الدخل",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(12.dp))
          HorizontalDivider()
          Spacer(modifier = Modifier.height(8.dp))

          ProfitStatementRow("1. إجمالي إيرادات المبيعات", report.totalSales + report.totalDiscount, currency, isHeader = true, isPositive = true)
          if (report.totalDiscount > 0) {
            ProfitStatementRow("   (-) خصومات مسموح بها للعملاء", -report.totalDiscount, currency, isNegative = true)
          }
          ProfitStatementRow("   (=) صافي إيرادات المبيعات الفعلية", report.totalSales, currency, isBold = true)

          Spacer(modifier = Modifier.height(6.dp))
          HorizontalDivider()
          Spacer(modifier = Modifier.height(6.dp))

          ProfitStatementRow("2. (-) تكلفة البضاعة المباعة (WAC COGS)", -report.totalSalesCost, currency, isNegative = true)

          Spacer(modifier = Modifier.height(6.dp))
          HorizontalDivider()
          Spacer(modifier = Modifier.height(6.dp))

          val grossMargin = if (report.totalSales > 0) (report.grossProfit / report.totalSales) * 100.0 else 0.0
          ProfitStatementRow("3. (=) مجمل أرباح النشاط التجاري", report.grossProfit, currency, isHeader = true, isBold = true, isPositive = true, margin = grossMargin)

          Spacer(modifier = Modifier.height(6.dp))
          HorizontalDivider()
          Spacer(modifier = Modifier.height(6.dp))

          ProfitStatementRow("4. (-) إجمالي المصروفات التشغيلية", -report.totalExpenses, currency, isNegative = true)
          expensesByCategory.forEach { cat ->
            ProfitStatementRow("     • ${cat.category}", -cat.totalAmount, currency, isSubItem = true)
          }

          if (report.totalAuditDiscrepancy != 0.0) {
            val isNeg = report.totalAuditDiscrepancy < 0
            val label = if (isNeg) "5. (-) تسويات عجز الجرد المخزني" else "5. (+) تسويات فائض الجرد المخزني"
            ProfitStatementRow(label, report.totalAuditDiscrepancy, currency, isNegative = isNeg, isPositive = !isNeg)
          }

          Spacer(modifier = Modifier.height(8.dp))
          HorizontalDivider(thickness = 2.dp, color = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.height(8.dp))

          ProfitStatementRow(
            label = "★ صافي الأرباح النهائية الصافية (Net Profit)",
            amount = report.netProfit,
            currency = currency,
            isTotal = true,
            isPositive = report.netProfit >= 0,
            margin = report.profitMarginPercent
          )
        }
      }
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
      ) {
        OutlinedButton(
          onClick = onAddExpense,
          shape = RoundedCornerShape(8.dp)
        ) {
          Text("+ إضافة مصروف تشغيلي جديد", fontSize = 11.5.sp)
        }
      }
    }
  }
}

@Composable
fun ProfitStatementRow(
  label: String,
  amount: Double,
  currency: String,
  isHeader: Boolean = false,
  isBold: Boolean = false,
  isTotal: Boolean = false,
  isSubItem: Boolean = false,
  isPositive: Boolean = false,
  isNegative: Boolean = false,
  margin: Double? = null
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = if (isTotal) 6.dp else 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = label,
      fontSize = if (isTotal) 13.5.sp else if (isHeader) 12.5.sp else if (isSubItem) 11.sp else 11.5.sp,
      fontWeight = if (isTotal || isHeader || isBold) FontWeight.Bold else FontWeight.Normal,
      color = if (isTotal && isPositive) EmeraldPrimary else if (isTotal) MaterialTheme.colorScheme.error else if (isSubItem) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
    )

    Row(verticalAlignment = Alignment.CenterVertically) {
      if (margin != null) {
        Text(
          text = String.format(Locale.ENGLISH, "(%.1f%%)", margin),
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = if (margin >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
        )
        Spacer(modifier = Modifier.width(6.dp))
      }
      Text(
        text = String.format(Locale.ENGLISH, "%.2f %s", amount, currency),
        fontSize = if (isTotal) 14.sp else if (isHeader || isBold) 12.5.sp else 11.5.sp,
        fontWeight = if (isTotal || isHeader || isBold) FontWeight.Bold else FontWeight.Normal,
        color = if (isNegative) MaterialTheme.colorScheme.error else if (isPositive) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
      )
    }
  }
}

// =============================================================================
// البعد 1: الأرباح حسب العميل (Profit by Customer)
// =============================================================================
data class CustomerProfitRow(
  val customerId: Long,
  val customerName: String,
  val invoiceCount: Int,
  val totalSales: Double,
  val totalCost: Double,
  val totalProfit: Double,
  val profitMarginPercent: Double,
  val profitSharePercent: Double
)

@Composable
fun ProfitByCustomerSubReport(
  invoices: List<Invoice>,
  customers: List<Customer>,
  totalProfit: Double,
  searchQuery: String,
  sortOrder: Int,
  currency: String
) {
  val rows = remember(invoices, customers, totalProfit) {
    val grouped = invoices.groupBy { it.partyId }
    val list = mutableListOf<CustomerProfitRow>()

    grouped.forEach { (partyId, custInvoices) ->
      val custName = if (partyId == 0L) "عميل نقدي (شباك/فوري)" else (customers.find { it.id == partyId }?.name ?: custInvoices.firstOrNull()?.partyName ?: "عميل #$partyId")
      val sales = custInvoices.sumOf { it.totalAmount }
      val cost = custInvoices.sumOf { it.totalCost }
      val profit = custInvoices.sumOf { it.totalProfit }
      val margin = if (sales > 0) (profit / sales) * 100.0 else 0.0
      val share = if (totalProfit > 0) (profit / totalProfit) * 100.0 else 0.0

      list.add(
        CustomerProfitRow(
          customerId = partyId,
          customerName = custName,
          invoiceCount = custInvoices.size,
          totalSales = sales,
          totalCost = cost,
          totalProfit = profit,
          profitMarginPercent = margin,
          profitSharePercent = share
        )
      )
    }
    list
  }

  val filteredRows = remember(rows, searchQuery, sortOrder) {
    rows.filter {
      searchQuery.isBlank() || it.customerName.contains(searchQuery, ignoreCase = true)
    }.let { list ->
      when (sortOrder) {
        0 -> list.sortedByDescending { it.totalProfit }
        1 -> list.sortedByDescending { it.totalSales }
        else -> list.sortedByDescending { it.profitMarginPercent }
      }
    }
  }

  if (filteredRows.isEmpty()) {
    EmptyReportState("لا توجد مبيعات أو أرباح للعملاء في هذه الفترة")
    return
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(14.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    items(filteredRows, key = { it.customerId }) { row ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = row.customerName,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "${row.invoiceCount} فاتورة بيع",
                fontSize = 10.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = String.format(Locale.ENGLISH, "%+.2f %s", row.totalProfit, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = if (row.totalProfit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
              )
              Text(
                text = String.format(Locale.ENGLISH, "هامش %.1f%%", row.profitMarginPercent),
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                color = if (row.profitMarginPercent >= 15) EmeraldPrimary else AmberPrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // شريط نسبة المساهمة من أرباح المتجر
          LinearProgressIndicator(
            progress = { (row.profitSharePercent / 100f).toFloat().coerceIn(0f, 1f) },
            modifier = Modifier
              .fillMaxWidth()
              .height(4.dp)
              .clip(RoundedCornerShape(2.dp)),
            color = EmeraldPrimary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
          )

          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "المبيعات: ${String.format(Locale.ENGLISH, "%.1f %s", row.totalSales, currency)}",
              fontSize = 10.5.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              text = "التكلفة: ${String.format(Locale.ENGLISH, "%.1f %s", row.totalCost, currency)}",
              fontSize = 10.5.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              text = "المساهمة بالأرباح: ${String.format(Locale.ENGLISH, "%.1f%%", row.profitSharePercent)}",
              fontSize = 10.5.sp,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }
      }
    }
  }
}

// =============================================================================
// البعد 2: الأرباح حسب اليوم والتاريخ (Profit by Day)
// =============================================================================
data class DayProfitRow(
  val dateStr: String,
  val timestamp: Long,
  val invoiceCount: Int,
  val salesAmount: Double,
  val costAmount: Double,
  val grossProfit: Double,
  val dayExpenses: Double,
  val netProfit: Double,
  val marginPercent: Double
)

@Composable
fun ProfitByDaySubReport(
  invoices: List<Invoice>,
  expenses: List<Expense>,
  searchQuery: String,
  currency: String
) {
  val dayFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH) }
  val dayNameFormat = remember { SimpleDateFormat("EEEE", Locale("ar")) }

  val rows = remember(invoices, expenses) {
    val dayInvoices = invoices.groupBy { dayFormat.format(Date(it.timestamp)) }
    val dayExpensesMap = expenses.groupBy { dayFormat.format(Date(it.timestamp)) }

    val allDates = (dayInvoices.keys + dayExpensesMap.keys).distinct().sortedDescending()

    allDates.map { dateKey ->
      val invs = dayInvoices[dateKey] ?: emptyList()
      val exps = dayExpensesMap[dateKey] ?: emptyList()

      val sales = invs.sumOf { it.totalAmount }
      val cost = invs.sumOf { it.totalCost }
      val gross = invs.sumOf { it.totalProfit }
      val expTotal = exps.sumOf { it.amount }
      val net = gross - expTotal
      val margin = if (sales > 0) (net / sales) * 100.0 else 0.0

      val ts = invs.firstOrNull()?.timestamp ?: exps.firstOrNull()?.timestamp ?: 0L

      DayProfitRow(
        dateStr = dateKey,
        timestamp = ts,
        invoiceCount = invs.size,
        salesAmount = sales,
        costAmount = cost,
        grossProfit = gross,
        dayExpenses = expTotal,
        netProfit = net,
        marginPercent = margin
      )
    }
  }

  val filteredRows = remember(rows, searchQuery) {
    rows.filter {
      searchQuery.isBlank() || it.dateStr.contains(searchQuery)
    }
  }

  if (filteredRows.isEmpty()) {
    EmptyReportState("لا توجد بيانات أرباح يومية خلال هذه الفترة")
    return
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(14.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    items(filteredRows, key = { it.dateStr }) { row ->
      val dayName = if (row.timestamp > 0) dayNameFormat.format(Date(row.timestamp)) else ""
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "${row.dateStr} ($dayName)",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "${row.invoiceCount} فاتورة بيع",
                fontSize = 10.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = String.format(Locale.ENGLISH, "صافي: %+.2f %s", row.netProfit, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.5.sp,
                color = if (row.netProfit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
              )
              Text(
                text = String.format(Locale.ENGLISH, "هامش %.1f%%", row.marginPercent),
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                color = if (row.marginPercent >= 15) EmeraldPrimary else AmberPrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))
          HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("مبيعات: ${String.format(Locale.ENGLISH, "%.1f", row.salesAmount)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.primary)
            Text("تكلفة: ${String.format(Locale.ENGLISH, "%.1f", row.costAmount)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("مجمل: ${String.format(Locale.ENGLISH, "%.1f", row.grossProfit)}", fontSize = 10.5.sp, color = EmeraldPrimary)
            Text("مصاريف: ${String.format(Locale.ENGLISH, "%.1f", row.dayExpenses)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.error)
          }
        }
      }
    }
  }
}

// =============================================================================
// البعد 3: الأرباح حسب التصنيف والقسم (Profit by Category)
// =============================================================================
data class CategoryProfitRow(
  val categoryName: String,
  val itemCount: Int,
  val totalSales: Double,
  val totalCost: Double,
  val totalProfit: Double,
  val marginPercent: Double,
  val sharePercent: Double
)

@Composable
fun ProfitByCategorySubReport(
  items: List<InvoiceItem>,
  products: List<Product>,
  totalProfit: Double,
  searchQuery: String,
  sortOrder: Int,
  currency: String
) {
  val prodMap = remember(products) { products.associateBy { it.id } }

  val rows = remember(items, prodMap, totalProfit) {
    val grouped = items.groupBy { item ->
      prodMap[item.productId]?.category ?: "بدون تصنيف"
    }

    grouped.map { (catName, catItems) ->
      val sales = catItems.sumOf { it.totalPrice }
      val cost = catItems.sumOf { it.unitCost * it.quantity }
      val profit = sales - cost
      val margin = if (sales > 0) (profit / sales) * 100.0 else 0.0
      val share = if (totalProfit > 0) (profit / totalProfit) * 100.0 else 0.0

      CategoryProfitRow(
        categoryName = catName,
        itemCount = catItems.size,
        totalSales = sales,
        totalCost = cost,
        totalProfit = profit,
        marginPercent = margin,
        sharePercent = share
      )
    }
  }

  val filteredRows = remember(rows, searchQuery, sortOrder) {
    rows.filter {
      searchQuery.isBlank() || it.categoryName.contains(searchQuery, ignoreCase = true)
    }.let { list ->
      when (sortOrder) {
        0 -> list.sortedByDescending { it.totalProfit }
        1 -> list.sortedByDescending { it.totalSales }
        else -> list.sortedByDescending { it.marginPercent }
      }
    }
  }

  if (filteredRows.isEmpty()) {
    EmptyReportState("لا توجد مبيعات في التصنيفات خلال هذه الفترة")
    return
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(14.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    items(filteredRows, key = { it.categoryName }) { row ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "قسم: ${row.categoryName}",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "${row.itemCount} صنف مباع",
                fontSize = 10.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = String.format(Locale.ENGLISH, "%+.2f %s", row.totalProfit, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.5.sp,
                color = if (row.totalProfit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
              )
              Text(
                text = String.format(Locale.ENGLISH, "هامش %.1f%%", row.marginPercent),
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                color = if (row.marginPercent >= 15) EmeraldPrimary else AmberPrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          LinearProgressIndicator(
            progress = { (row.sharePercent / 100f).toFloat().coerceIn(0f, 1f) },
            modifier = Modifier
              .fillMaxWidth()
              .height(4.dp)
              .clip(RoundedCornerShape(2.dp)),
            color = Color(0xFF059669),
            trackColor = MaterialTheme.colorScheme.surfaceVariant
          )

          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("مبيعات: ${String.format(Locale.ENGLISH, "%.1f %s", row.totalSales, currency)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("تكلفة: ${String.format(Locale.ENGLISH, "%.1f %s", row.totalCost, currency)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("مساهمة: ${String.format(Locale.ENGLISH, "%.1f%%", row.sharePercent)}", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
          }
        }
      }
    }
  }
}

// =============================================================================
// البعد 4: الأرباح حسب المنتج والأصناف (Profit by Product)
// =============================================================================
data class ProductProfitRow(
  val productId: Long,
  val productName: String,
  val category: String,
  val totalUnitsSold: Int,
  val revenue: Double,
  val cost: Double,
  val profit: Double,
  val marginPercent: Double,
  val profitPerUnit: Double
)

@Composable
fun ProfitByProductSubReport(
  items: List<InvoiceItem>,
  products: List<Product>,
  totalProfit: Double,
  searchQuery: String,
  sortOrder: Int,
  currency: String
) {
  val prodMap = remember(products) { products.associateBy { it.id } }

  val rows = remember(items, prodMap) {
    val grouped = items.groupBy { it.productId }

    grouped.map { (pId, pItems) ->
      val prod = prodMap[pId]
      val name = prod?.name ?: pItems.firstOrNull()?.productName ?: "صنف #$pId"
      val cat = prod?.category ?: "عام"
      val units = pItems.sumOf { it.quantity }
      val sales = pItems.sumOf { it.totalPrice }
      val cost = pItems.sumOf { it.unitCost * it.quantity }
      val profit = sales - cost
      val margin = if (sales > 0) (profit / sales) * 100.0 else 0.0
      val perUnit = if (units > 0) profit / units else 0.0

      ProductProfitRow(
        productId = pId,
        productName = name,
        category = cat,
        totalUnitsSold = units,
        revenue = sales,
        cost = cost,
        profit = profit,
        marginPercent = margin,
        profitPerUnit = perUnit
      )
    }
  }

  val filteredRows = remember(rows, searchQuery, sortOrder) {
    rows.filter {
      searchQuery.isBlank() || it.productName.contains(searchQuery, ignoreCase = true) || it.category.contains(searchQuery, ignoreCase = true)
    }.let { list ->
      when (sortOrder) {
        0 -> list.sortedByDescending { it.profit }
        1 -> list.sortedByDescending { it.revenue }
        else -> list.sortedByDescending { it.marginPercent }
      }
    }
  }

  if (filteredRows.isEmpty()) {
    EmptyReportState("لا توجد مبيعات أصناف خلال هذه الفترة")
    return
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(14.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    items(filteredRows, key = { it.productId }) { row ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = row.productName,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "${row.category} • مبيعات ${row.totalUnitsSold} وحدة",
                fontSize = 10.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = String.format(Locale.ENGLISH, "%+.2f %s", row.profit, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = if (row.profit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
              )
              Surface(
                shape = RoundedCornerShape(4.dp),
                color = when {
                  row.marginPercent >= 20 -> EmeraldPrimary.copy(alpha = 0.15f)
                  row.marginPercent >= 10 -> AmberPrimary.copy(alpha = 0.15f)
                  else -> MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
                }
              ) {
                Text(
                  text = String.format(Locale.ENGLISH, "هامش %.1f%%", row.marginPercent),
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = when {
                    row.marginPercent >= 20 -> EmeraldPrimary
                    row.marginPercent >= 10 -> AmberPrimary
                    else -> MaterialTheme.colorScheme.error
                  },
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(6.dp))
          HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("إيراد: ${String.format(Locale.ENGLISH, "%.1f", row.revenue)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.primary)
            Text("تكلفة WAC: ${String.format(Locale.ENGLISH, "%.1f", row.cost)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("ربح الوحدة: ${String.format(Locale.ENGLISH, "%.2f", row.profitPerUnit)}", fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, color = EmeraldPrimary)
          }
        }
      }
    }
  }
}

// =============================================================================
// البعد 5: الأرباح حسب الموظف والكاشير (Profit by Employee)
// =============================================================================
data class EmployeeProfitRow(
  val employeeName: String,
  val invoiceCount: Int,
  val totalSales: Double,
  val totalCost: Double,
  val totalProfit: Double,
  val marginPercent: Double
)

@Composable
fun ProfitByEmployeeSubReport(
  invoices: List<Invoice>,
  totalProfit: Double,
  searchQuery: String,
  currency: String
) {
  val rows = remember(invoices) {
    // تجميع الفواتير حسب كاشير النظام أو الموظف المسجل بالملاحظات
    val grouped = invoices.groupBy { inv ->
      val noteMatch = inv.notes.lines().find { it.contains("الموظف") || it.contains("كاشير") }
      noteMatch ?: "كاشير النظام الرئيسي"
    }

    grouped.map { (empName, empInvoices) ->
      val sales = empInvoices.sumOf { it.totalAmount }
      val cost = empInvoices.sumOf { it.totalCost }
      val profit = empInvoices.sumOf { it.totalProfit }
      val margin = if (sales > 0) (profit / sales) * 100.0 else 0.0

      EmployeeProfitRow(
        employeeName = empName,
        invoiceCount = empInvoices.size,
        totalSales = sales,
        totalCost = cost,
        totalProfit = profit,
        marginPercent = margin
      )
    }.sortedByDescending { it.totalProfit }
  }

  val filteredRows = remember(rows, searchQuery) {
    rows.filter {
      searchQuery.isBlank() || it.employeeName.contains(searchQuery, ignoreCase = true)
    }
  }

  if (filteredRows.isEmpty()) {
    EmptyReportState("لا توجد مبيعات موظفين خلال هذه الفترة")
    return
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(14.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    items(filteredRows, key = { it.employeeName }) { row ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = row.employeeName,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "${row.invoiceCount} فاتورة مسجلة",
                fontSize = 10.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = String.format(Locale.ENGLISH, "%+.2f %s", row.totalProfit, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.5.sp,
                color = if (row.totalProfit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
              )
              Text(
                text = String.format(Locale.ENGLISH, "هامش %.1f%%", row.marginPercent),
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                color = if (row.marginPercent >= 15) EmeraldPrimary else AmberPrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))
          HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("مبيعات: ${String.format(Locale.ENGLISH, "%.1f %s", row.totalSales, currency)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.primary)
            Text("تكلفة: ${String.format(Locale.ENGLISH, "%.1f %s", row.totalCost, currency)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            val avgPerInv = if (row.invoiceCount > 0) row.totalProfit / row.invoiceCount else 0.0
            Text("متوسط ربح/فاتورة: ${String.format(Locale.ENGLISH, "%.1f", avgPerInv)}", fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, color = EmeraldPrimary)
          }
        }
      }
    }
  }
}

// =============================================================================
// البعد 6: الأرباح حسب الفاتورة (Profit by Invoice)
// =============================================================================
@Composable
fun ProfitByInvoiceSubReport(
  invoices: List<Invoice>,
  searchQuery: String,
  sortOrder: Int,
  currency: String
) {
  val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.ENGLISH) }

  val filteredInvoices = remember(invoices, searchQuery, sortOrder) {
    invoices.filter {
      searchQuery.isBlank() || it.invoiceNumber.contains(searchQuery) || it.partyName.contains(searchQuery, ignoreCase = true)
    }.let { list ->
      when (sortOrder) {
        0 -> list.sortedByDescending { it.totalProfit }
        1 -> list.sortedByDescending { it.totalAmount }
        else -> list.sortedByDescending { if (it.totalAmount > 0) (it.totalProfit / it.totalAmount) * 100.0 else 0.0 }
      }
    }
  }

  if (filteredInvoices.isEmpty()) {
    EmptyReportState("لا توجد فواتير مبيعات مطابقة في هذه الفترة")
    return
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(14.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    items(filteredInvoices, key = { it.id }) { inv ->
      val margin = if (inv.totalAmount > 0) (inv.totalProfit / inv.totalAmount) * 100.0 else 0.0
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "فاتورة #${inv.invoiceNumber}",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = if (inv.paymentType == PaymentType.CASH) EmeraldPrimary.copy(alpha = 0.15f) else AmberPrimary.copy(alpha = 0.15f)
                ) {
                  Text(
                    text = if (inv.paymentType == PaymentType.CASH) "نقدي" else "آجل",
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (inv.paymentType == PaymentType.CASH) EmeraldPrimary else AmberPrimary,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                  )
                }
              }
              Text(
                text = "${inv.partyName} • ${dateFormat.format(Date(inv.timestamp))}",
                fontSize = 10.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = String.format(Locale.ENGLISH, "ربح: %+.2f %s", inv.totalProfit, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.5.sp,
                color = if (inv.totalProfit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
              )
              Text(
                text = String.format(Locale.ENGLISH, "هامش %.1f%%", margin),
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                color = if (margin >= 15) EmeraldPrimary else AmberPrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))
          HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("قيمة الفاتورة: ${String.format(Locale.ENGLISH, "%.2f", inv.totalAmount)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.primary)
            Text("تكلفة WAC: ${String.format(Locale.ENGLISH, "%.2f", inv.totalCost)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (inv.discount > 0) {
              Text("خصم: ${String.format(Locale.ENGLISH, "%.1f", inv.discount)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.error)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun EmptyReportState(message: String) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .padding(32.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Icon(
        imageVector = Icons.Default.Inventory2,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
        modifier = Modifier.size(48.dp)
      )
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = message,
        fontSize = 12.5.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
  }
}
