package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// =============================================================================
// الألوان الهيكلية الأساسية (Core UI Colors) - وفق دليل الهوية المحدد بدقة
// =============================================================================
// 1. اللون الأساسي / الهيدر العلوي (Primary Dark) - الكحلي الداكن / الأزرق الليلي
val NavyPrimaryDark = Color(0xFF2B3E55)       // #2B3E55 كحلي داكن راقي للشريط العلوي
val NavyPrimaryDeep = Color(0xFF2C3A4E)       // #2C3A4E أزرق ليلي بديل فخم
val NavyPrimaryContainer = Color(0xFF1E2B3C)  // كحلي عميق للحاويات
val NavyPrimaryOnContainer = Color(0xFFE2E8F0)// نص فاتح للحاويات

// 2. خلفية التطبيق العامة (Background) - رمادي أزرق فاتح جداً (Off-White Blue)
val BackgroundOffWhiteBlue = Color(0xFFF0F4F8) // #F0F4F8 خلفية هادئة مريحة وتباين ناعم
val BackgroundOffWhiteBlueAlt = Color(0xFFEBF0F5) // #EBF0F5

// 3. خلفية البطاقات والكروت (Card Background) - الأبيض النقي
val CardBackgroundPureWhite = Color(0xFFFFFFFF) // #FFFFFF نقي لكروت الأقسام والوصول السريع

// 4. لون النصوص الأساسية (Primary Text) - الأسود الداكن المائل للكحلي
val TextPrimaryDark = Color(0xFF1A202C)        // #1A202C أسود كحلي نقي لعناوين البطاقات
val TextPrimaryDarkAlt = Color(0xFF212121)     // #212121

// 5. لون النصوص الفرعية (Secondary Text) - رمادي أزرق متوسط
val TextSecondaryMuted = Color(0xFF8C9DAE)     // #8C9DAE رمادي أزرق متوسط للنصوص المساعدة
val TextSecondaryMutedAlt = Color(0xFFA0AEC0)  // #A0AEC0

// حدود البطاقات الناعمة
val CardBorderSubtle = Color(0xFFD9E2EC)

// ألوان متناسقة للوضع الداكن متوافقة تماماً مع الهوية الكحلية
val DarkAppBackground = Color(0xFF131A24)       // كحلي داكن عميق لخلفية الشاشة الكاملة
val DarkCardSurface = Color(0xFF1E2836)         // كحلي رمادي لكروت الوضع الداكن
val DarkCardBorder = Color(0xFF2D3C4E)          // حدود كروت الوضع الداكن

// Primary Warm Brand Colors: Orange & Warm Crimson Red
val OrangePrimary = Color(0xFFEA580C)      // Vibrant Orange
val OrangeLight = Color(0xFFFB923C)        // Soft Orange
val OrangeDark = Color(0xFFC2410C)         // Deep Amber Orange
val OrangeContainer = Color(0xFFFFEDD5)    // Creamy Peach Container

// Warm Red / Crimson Accent
val CrimsonRed = Color(0xFFE11D48)         // Vibrant Rose Crimson
val CoralRed = Color(0xFFDC2626)           // Alert / Debit Red
val CrimsonContainer = Color(0xFFFFE4E6)   // Soft Pink-Red Container

// Secondary Emerald Green (Cash In, Net Profit, Positive Status)
val EmeraldPrimary = Color(0xFF059669)
val EmeraldLight = Color(0xFF10B981)
val EmeraldContainer = Color(0xFFD1FAE5)

// Amber / Warning (Low Stock, Credit Alert)
val AmberPrimary = Color(0xFFD97706)
val AmberLight = Color(0xFFFBBF24)
val AmberContainer = Color(0xFFFEF3C7)

// Neutral Modern Slates (Clean & High Readability)
val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate300 = Color(0xFFCBD5E1)
val Slate400 = Color(0xFF94A3B8)
val Slate500 = Color(0xFF64748B)
val Slate600 = Color(0xFF475569)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
val Slate950 = Color(0xFF020617)

// Thermal Receipt Paper Background
val ThermalPaper = Color(0xFFFFFDF8)
val ThermalInk = Color(0xFF1C1917)

// Dark Dashboard Colors - Deep Slate & Navy for rich contrast
val DarkDashboardBg = Color(0xFF0A0F1D)
val DarkDashboardCard = Color(0xFF141C2E)
val DarkDashboardCardBorder = Color(0xFF243048)

// Tile Badges & Icon Accents (High Contrast in both Dark and Light)
val TileSalesBadge = Color(0xFF1E2B4D)
val TileSalesIcon = Color(0xFF818CF8)

val TilePurchasesBadge = Color(0xFF3E1624)
val TilePurchasesIcon = Color(0xFFF87171)

val TileCustomersBadge = Color(0xFF0B3340)
val TileCustomersIcon = Color(0xFF38BDF8)

val TileSuppliersBadge = Color(0xFF3B260A)
val TileSuppliersIcon = Color(0xFFFBBF24)

val TileCashboxBadge = Color(0xFF083526)
val TileCashboxIcon = Color(0xFF34D399)

val TileExpensesBadge = Color(0xFF2A1542)
val TileExpensesIcon = Color(0xFFC084FC)

val TileWarehouseBadge = Color(0xFF38133E)
val TileWarehouseIcon = Color(0xFFF472B6)

val TileReportsBadge = Color(0xFF1A2335)
val TileReportsIcon = Color(0xFF94A3B8)
