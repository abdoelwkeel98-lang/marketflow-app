package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.settings.BusinessProfile
import com.example.ui.WholesaleViewModel
import com.example.ui.components.BackupRestoreDialog
import com.example.ui.components.MultiEmployeeAndDelegateDialog
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(
  viewModel: WholesaleViewModel,
  onLogout: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val profile by viewModel.businessProfile.collectAsStateWithLifecycle()

  var selectedCategoryIndex by remember { mutableIntStateOf(0) }

  // نوافذ الحوار المتخصصة لكل قسم
  var showSalesSettingsDialog by remember { mutableStateOf(false) }
  var showPurchasesSettingsDialog by remember { mutableStateOf(false) }
  var showWarehouseSettingsDialog by remember { mutableStateOf(false) }
  var showFinanceTaxSettingsDialog by remember { mutableStateOf(false) }
  var showBusinessProfileDialog by remember { mutableStateOf(false) }
  var showPrinterSettingsDialog by remember { mutableStateOf(false) }
  var showSecurityUsersDialog by remember { mutableStateOf(false) }
  var showSystemBackupDialog by remember { mutableStateOf(false) }
  var showBackupRestorePopup by remember { mutableStateOf(false) }

  var isBackingUp by remember { mutableStateOf(false) }
  var isRestoring by remember { mutableStateOf(false) }

  val categories = listOf(
    "📋 جميع الإعدادات",
    "🛒 المبيعات والكاشير",
    "🚚 المشتريات والتوريد",
    "📦 المخزن والجرد",
    "💰 المالية والضرائب",
    "🏢 الملف والنشاط",
    "🖨️ الطابعة والفواتير",
    "👥 الصلاحيات والأمان",
    "☁️ النظام والنسخ"
  )

  val lastBackupDateStr = remember(profile.lastBackupTime) {
    if (profile.lastBackupTime > 0) {
      SimpleDateFormat("dd/MM/yyyy - hh:mm a", Locale("ar")).format(Date(profile.lastBackupTime))
    } else {
      "لم تتم مزامنة بعد"
    }
  }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. بطاقة المتجر والمستخدم النشط
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Surface(
                shape = CircleShape,
                color = OrangePrimary,
                modifier = Modifier.size(48.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(Icons.Default.Storefront, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp))
                }
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = profile.businessName,
                  fontWeight = FontWeight.ExtraBold,
                  fontSize = 17.sp,
                  color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                  text = "${profile.businessType} • العملة: ${profile.currency}",
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                )
              }
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = EmeraldPrimary.copy(alpha = 0.18f),
              border = BorderStroke(1.dp, EmeraldPrimary)
            ) {
              Text(
                text = profile.userRole,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldPrimary,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
          HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.15f))
          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "هاتف: ${profile.contactPhone} • العنوان: ${profile.address}",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
              maxLines = 1,
              modifier = Modifier.weight(1f)
            )

            Button(
              onClick = { showBusinessProfileDialog = true },
              shape = RoundedCornerShape(8.dp),
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
              Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(13.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("تعديل النشاط", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    // 2. شريط التنقل السريع بين أقسام الإعدادات
    item {
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
          text = "أقسام الإعدادات والتحكم بالمنظومة:",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(categories.size) { idx ->
            val isSelected = selectedCategoryIndex == idx
            FilterChip(
              selected = isSelected,
              onClick = { selectedCategoryIndex = idx },
              label = {
                Text(
                  text = categories[idx],
                  fontSize = 11.5.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                )
              },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
              )
            )
          }
        }
      }
    }

    // -------------------------------------------------------------------------
    // 3. إعدادات شاشة المبيعات والكاشير
    // -------------------------------------------------------------------------
    if (selectedCategoryIndex == 0 || selectedCategoryIndex == 1) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.5.dp, EmeraldPrimary.copy(alpha = 0.4f)),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = CircleShape,
                color = EmeraldPrimary.copy(alpha = 0.15f),
                modifier = Modifier.size(36.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(Icons.Default.Tune, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                }
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("إعدادات الوحدة الأساسية وتعديل سعر المبيعات", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("التحكم بوحدة البيع الافتراضية وصلاحية تعديل الأسعار يدوياً", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // الوحدة الأساسية في المبيعات
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text("الوحدة الأساسية في المبيعات:", fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                Text(
                  text = "الوحدة المعتمدة بالفاتورة (${profile.salesDefaultUnit})",
                  fontSize = 11.sp,
                  color = EmeraldPrimary,
                  fontWeight = FontWeight.Medium
                )
              }
              Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("علبة", "كرتونة").forEach { unit ->
                  FilterChip(
                    selected = profile.salesDefaultUnit == unit,
                    onClick = { viewModel.updateBusinessProfile(profile.copy(salesDefaultUnit = unit)) },
                    label = { Text(if (unit == "علبة") "🏷️ علبة (أساسية)" else "📦 كرتونة", fontSize = 11.sp, fontWeight = if (profile.salesDefaultUnit == unit) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.filterChipColors(
                      selectedContainerColor = EmeraldPrimary,
                      selectedLabelColor = Color.White
                    )
                  )
                }
              }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

            // تعديل السعر يدوياً في المبيعات
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text("إمكانية تعديل سعر المنتجات يدوياً:", fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                Text(
                  text = if (profile.salesAllowManualPriceOverride) "مفعل: يسمح للكاشير بتعديل سعر بيع الصنف" else "معطل: يلتزم الكاشير بأسعار بيع النظام المسجلة",
                  fontSize = 10.5.sp,
                  color = if (profile.salesAllowManualPriceOverride) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              Switch(
                checked = profile.salesAllowManualPriceOverride,
                onCheckedChange = { checked ->
                  viewModel.updateBusinessProfile(profile.copy(salesAllowManualPriceOverride = checked))
                }
              )
            }
          }
        }
      }

      item {
        ComprehensiveModuleSettingsCard(
          title = "إعدادات شاشة المبيعات والكاشير",
          description = "تخصيص طرق الدفع، البيع بأقل من القيمة والتكلفة، الخصومات نسبة ومبلغ، وتعديل التاريخ والطباعة",
          icon = Icons.Default.PointOfSale,
          iconTint = EmeraldPrimary,
          onOpenFullSettings = { showSalesSettingsDialog = true },
          badges = listOf(
            "الوحدة الأساسية: ${profile.salesDefaultUnit}",
            if (profile.salesAllowManualPriceOverride) "تعديل السعر يدوياً: مسموح ✏️" else "تعديل السعر يدوياً: مقيّد 🔒",
            if (profile.salesAllowSellingBelowInvoiceTotal) "البيع بأقل من القيمة: مسموح ✅" else "البيع بأقل من القيمة: مقيّد 🔒",
            if (profile.salesEnableDiscount) "الخصم: نسبة ومبلغ مفعّل (${profile.salesDefaultDiscountType})" else "الخصم: معطّل ❌",
            if (profile.salesAllowCustomInvoiceDate) "تعديل التاريخ: متاح 📅" else "تاريخ تلقائي ⏱️",
            if (profile.salesAllowSellingBelowCost) "البيع بأقل من التكلفة: مسموح ⚠️" else "حماية التكلفة: مفعلة 🛡️",
            "الدفع الافتراضي: ${profile.salesDefaultPaymentType}",
            if (profile.salesPreventNegativeStock) "منع السالب: مفعّل 🔒" else "البيع بالسالب: مسموح"
          ),
          quickToggles = listOf(
            QuickToggleItem(
              title = "إمكانية تعديل سعر المنتجات يدوياً في المبيعات",
              subtitle = "السماح للكاشير بتعديل سعر بيع الصنف مباشرة أثناء إنشاء الفاتورة",
              checked = profile.salesAllowManualPriceOverride,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(salesAllowManualPriceOverride = checked))
              }
            ),
            QuickToggleItem(
              title = "الوحدة الأساسية في المبيعات: ${profile.salesDefaultUnit}",
              subtitle = "التبديل بين كرتونة أو علبة (أساسية) كوحدة بيع افتراضية بالفاتورة",
              checked = profile.salesDefaultUnit == "كرتونة",
              onCheckedChange = { checked ->
                val newUnit = if (checked) "كرتونة" else "علبة"
                viewModel.updateBusinessProfile(profile.copy(salesDefaultUnit = newUnit))
              }
            ),
            QuickToggleItem(
              title = "السماح بالبيع بأقل من قيمة الفاتورة",
              subtitle = "قبول إتمام الفاتورة حتى لو سدد العميل مبلغاً أقل من الإجمالي أو دفع جزء",
              checked = profile.salesAllowSellingBelowInvoiceTotal,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(salesAllowSellingBelowInvoiceTotal = checked))
              }
            ),
            QuickToggleItem(
              title = "تفعيل خاصية الخصم (نسبة ومبلغ)",
              subtitle = "إتاحة تطبيق خصومات كنسبة مئوية أو مبلغ نقدي في الفاتورة والسلة",
              checked = profile.salesEnableDiscount,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(salesEnableDiscount = checked))
              }
            ),
            QuickToggleItem(
              title = "السماح بتعديل تاريخ ووقت الفاتورة",
              subtitle = "إمكانية اختيار تاريخ سابق أو لاحق للفاتورة مباشرة من شاشة البيع",
              checked = profile.salesAllowCustomInvoiceDate,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(salesAllowCustomInvoiceDate = checked))
              }
            ),
            QuickToggleItem(
              title = "السماح بالبيع بأقل من سعر التكلفة",
              subtitle = "تجاوز منع الخسارة وتمرير الفواتير للعروض الخاصة والتصفيات",
              checked = profile.salesAllowSellingBelowCost,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(salesAllowSellingBelowCost = checked))
              }
            ),
            QuickToggleItem(
              title = "منع البيع بالسالب عند نفاد المخزون",
              subtitle = "إيقاف إتمام الفاتورة إذا كانت كمية الصنف غير كافية بالمخزن",
              checked = profile.salesPreventNegativeStock,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(salesPreventNegativeStock = checked))
              }
            ),
            QuickToggleItem(
              title = "تحذير عند البيع بأقل من سعر التكلفة",
              subtitle = "تنبيه الكاشير لحماية هوامش الربح من الخسارة",
              checked = profile.salesWarnBelowCost,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(salesWarnBelowCost = checked))
              }
            ),
            QuickToggleItem(
              title = "طباعة الفاتورة تلقائياً بعد الحفظ",
              subtitle = "إرسال أمر الطباعة مباشرة دون الحاجة للضغط على زر طباعة",
              checked = profile.salesAutoPrintReceipt,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(salesAutoPrintReceipt = checked))
              }
            ),
            QuickToggleItem(
              title = "إضافة قطعة واحدة مباشرة عند مسح الباركود",
              subtitle = "تسريع حركة البيع في السوبرماركت دون فتح نوافذ منبثقة",
              checked = profile.salesBarcodeAddSinglePieceDirectly,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(salesBarcodeAddSinglePieceDirectly = checked))
              }
            )
          )
        )
      }
    }

    // -------------------------------------------------------------------------
    // 4. إعدادات شاشة المشتريات والتوريد
    // -------------------------------------------------------------------------
    if (selectedCategoryIndex == 0 || selectedCategoryIndex == 2) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.5.dp, Color(0xFF2563EB).copy(alpha = 0.4f)),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = CircleShape,
                color = Color(0xFF2563EB).copy(alpha = 0.15f),
                modifier = Modifier.size(36.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(Icons.Default.Tune, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(18.dp))
                }
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("إعدادات الوحدة الأساسية وتعديل سعر المشتريات", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("التحكم بوحدة التوريد الافتراضية وصلاحية تعديل تكاليف الشراء يدوياً", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // الوحدة الأساسية في التوريد
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text("الوحدة الأساسية في التوريد:", fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                Text(
                  text = "الوحدة المعتمدة عند التوريد (${profile.purchasesDefaultUnit})",
                  fontSize = 11.sp,
                  color = Color(0xFF2563EB),
                  fontWeight = FontWeight.Medium
                )
              }
              Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("كرتونة", "علبة").forEach { unit ->
                  FilterChip(
                    selected = profile.purchasesDefaultUnit == unit,
                    onClick = { viewModel.updateBusinessProfile(profile.copy(purchasesDefaultUnit = unit)) },
                    label = { Text(if (unit == "كرتونة") "📦 كرتونة (أساسية)" else "🏷️ علبة", fontSize = 11.sp, fontWeight = if (profile.purchasesDefaultUnit == unit) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.filterChipColors(
                      selectedContainerColor = Color(0xFF2563EB),
                      selectedLabelColor = Color.White
                    )
                  )
                }
              }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

            // تعديل سعر الشراء يدوياً في المشتريات
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text("إمكانية تعديل سعر المنتجات يدوياً:", fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                Text(
                  text = if (profile.purchasesAllowManualPriceOverride) "مفعل: يسمح بتعديل سعر شراء الصنف يدوياً أثناء التوريد" else "معطل: استخدام أسعار شراء الأصناف المسجلة فقط",
                  fontSize = 10.5.sp,
                  color = if (profile.purchasesAllowManualPriceOverride) Color(0xFF2563EB) else MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              Switch(
                checked = profile.purchasesAllowManualPriceOverride,
                onCheckedChange = { checked ->
                  viewModel.updateBusinessProfile(profile.copy(purchasesAllowManualPriceOverride = checked))
                }
              )
            }
          }
        }
      }

      item {
        ComprehensiveModuleSettingsCard(
          title = "إعدادات شاشة المشتريات والتوريد",
          description = "تحديث أسعار التكلفة تلقائياً، تنبيهات ارتفاع الأسعار، وطرق السداد الافتراضية للموردين",
          icon = Icons.Default.LocalShipping,
          iconTint = Color(0xFF2563EB),
          onOpenFullSettings = { showPurchasesSettingsDialog = true },
          badges = listOf(
            "الوحدة الأساسية: ${profile.purchasesDefaultUnit}",
            if (profile.purchasesAllowManualPriceOverride) "تعديل السعر يدوياً: مسموح ✏️" else "تعديل السعر يدوياً: مقيّد 🔒",
            "السداد الافتراضي: ${profile.purchasesDefaultPaymentType}",
            if (profile.purchasesUpdateCostAutomatically) "تحديث التكلفة التلقائي: مفعّل 🔄" else "تحديث يدوي",
            if (profile.purchasesWarnIfCostIncreased) "تنبيه ارتفاع الأسعار: مفعّل ⚠️" else "بدون تنبيه"
          ),
          quickToggles = listOf(
            QuickToggleItem(
              title = "إمكانية تعديل سعر المنتجات يدوياً في المشتريات",
              subtitle = "السماح بتعديل سعر شراء الصنف وتكلفته يدوياً أثناء إنشاء فاتورة المشتريات",
              checked = profile.purchasesAllowManualPriceOverride,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(purchasesAllowManualPriceOverride = checked))
              }
            ),
            QuickToggleItem(
              title = "الوحدة الأساسية في التوريد: ${profile.purchasesDefaultUnit}",
              subtitle = "التبديل بين كرتونة (أساسية) أو علبة/قطعة كوحدة توريد افتراضية",
              checked = profile.purchasesDefaultUnit == "كرتونة",
              onCheckedChange = { checked ->
                val newUnit = if (checked) "كرتونة" else "قطعة"
                viewModel.updateBusinessProfile(profile.copy(purchasesDefaultUnit = newUnit))
              }
            ),
            QuickToggleItem(
              title = "التحديث التلقائي لسعر تكلفة الصنف",
              subtitle = "تحديث سعر التكلفة تلقائياً عند التوريد بأسعار شراء جديدة",
              checked = profile.purchasesUpdateCostAutomatically,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(purchasesUpdateCostAutomatically = checked))
              }
            ),
            QuickToggleItem(
              title = "التنبيه عند ارتفاع سعر الشراء عن السابق",
              subtitle = "إظهار تحذير في شاشة المشتريات عند رفع المورد للسعر",
              checked = profile.purchasesWarnIfCostIncreased,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(purchasesWarnIfCostIncreased = checked))
              }
            ),
            QuickToggleItem(
              title = "اشتراط إدخال رقم فاتورة المورد اليدوية",
              subtitle = "منع حفظ فاتورة الشراء بدون إدخال رقم السند الورقي",
              checked = profile.purchasesRequireInvoiceNumber,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(purchasesRequireInvoiceNumber = checked))
              }
            )
          )
        )
      }
    }

    // -------------------------------------------------------------------------
    // 5. إعدادات المخازن والجرد والأصناف
    // -------------------------------------------------------------------------
    if (selectedCategoryIndex == 0 || selectedCategoryIndex == 3) {
      item {
        ComprehensiveModuleSettingsCard(
          title = "إعدادات المخزن والجرد والأصناف",
          description = "إدارة حد الطلب، تنبيهات النواقص، تسعير المخزون المالي، وسياسات تسوية الجرد",
          icon = Icons.Default.Inventory2,
          iconTint = Color(0xFF7C3AED),
          onOpenFullSettings = { showWarehouseSettingsDialog = true },
          badges = listOf(
            "حد النواقص: ${profile.warehouseLowStockThreshold} قطع",
            "طريقة التقييم: ${profile.warehouseValuationMethod}",
            if (profile.warehouseShowCartonsAndPieces) "عرض كرتونة وقطعة: مفعّل 📦" else "قطع فقط",
            if (profile.warehouseAutoReconciliationAudit) "سند تسوية تلقائي: مفعّل 📝" else "تسوية يدوية"
          ),
          quickToggles = listOf(
            QuickToggleItem(
              title = "تفعيل إشعارات وتنبيهات نواقص المخزون",
              subtitle = "إظهار شارة النواقص عند وصول كمية أي صنف لحد الطلب",
              checked = profile.warehouseEnableLowStockAlerts,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(warehouseEnableLowStockAlerts = checked))
              }
            ),
            QuickToggleItem(
              title = "عرض الرصيد بالكرتونة والقطعة معاً",
              subtitle = "تقسيم الكمية تلقائياً لكراتين وقطع لتسهيل الجرد والبيع",
              checked = profile.warehouseShowCartonsAndPieces,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(warehouseShowCartonsAndPieces = checked))
              }
            ),
            QuickToggleItem(
              title = "إنشاء سند تسوية مخزنية تلقائياً عند التعديل",
              subtitle = "تسجيل فروقات الجرد وحفظ تاريخ التعديل واسم القائم به",
              checked = profile.warehouseAutoReconciliationAudit,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(warehouseAutoReconciliationAudit = checked))
              }
            )
          )
        )
      }
    }

    // -------------------------------------------------------------------------
    // 6. إعدادات الخزينة والمالية والضرائب
    // -------------------------------------------------------------------------
    if (selectedCategoryIndex == 0 || selectedCategoryIndex == 4) {
      item {
        ComprehensiveModuleSettingsCard(
          title = "إعدادات الخزينة والمالية والضرائب",
          description = "الخزينة الافتراضية، ضريبة القيمة المضافة VAT، والحد الأقصى للنقدية في الدرج",
          icon = Icons.Default.AccountBalanceWallet,
          iconTint = Color(0xFF047857),
          onOpenFullSettings = { showFinanceTaxSettingsDialog = true },
          badges = listOf(
            "الخزينة: ${profile.selectedCashbox}",
            if (profile.vatTaxEnabled) "الضريبة: ${profile.vatTaxRatePercent}% مفعّلة" else "الضريبة: معطلة",
            "حد الدرج: ${String.format(Locale.ENGLISH, "%.0f %s", profile.treasuryMaxDrawerLimit, profile.currency)}"
          ),
          quickToggles = listOf(
            QuickToggleItem(
              title = "تفعيل ضريبة القيمة المضافة (VAT)",
              subtitle = "تطبيق نسبة ضريبة ${profile.vatTaxRatePercent}% تلقائياً على فواتير المبيعات والمشتريات",
              checked = profile.vatTaxEnabled,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(vatTaxEnabled = checked))
              }
            ),
            QuickToggleItem(
              title = "الأسعار المعروضة شاملة الضريبة",
              subtitle = "اعتبار سعر البيع للمستهلك متضمناً قيمة الضريبة",
              checked = profile.vatTaxIncludedInPrice,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(vatTaxIncludedInPrice = checked))
              }
            ),
            QuickToggleItem(
              title = "اشتراط موافقة المدير لإغلاق وردية الخزينة",
              subtitle = "منع إغلاق وتقفيل الدرج إلا بعد اعتماد مشرف الوردية",
              checked = profile.treasuryRequireShiftClosureApproval,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(treasuryRequireShiftClosureApproval = checked))
              }
            )
          )
        )
      }
    }

    // -------------------------------------------------------------------------
    // 7. إعدادات الطابعة وفواتير POS
    // -------------------------------------------------------------------------
    if (selectedCategoryIndex == 0 || selectedCategoryIndex == 6) {
      item {
        ComprehensiveModuleSettingsCard(
          title = "إعدادات الطابعة الحرارية وفواتير POS",
          description = "نوع ومقاس الطابعة، البلوتوث، طباعة رمز QR، وتذييل الفاتورة",
          icon = Icons.Default.Print,
          iconTint = OrangePrimary,
          onOpenFullSettings = { showPrinterSettingsDialog = true },
          badges = listOf(
            "المقاس: ${profile.printerType}",
            if (profile.bluetoothPrinterName.isBlank()) "غير مقترنة" else profile.bluetoothPrinterName,
            if (profile.receiptPrintQrCode) "رمز QR: مفعّل 📱" else "بدون QR",
            "عدد النسخ: ${profile.receiptCopiesCount}"
          ),
          quickToggles = listOf(
            QuickToggleItem(
              title = "طباعة رمز الاستجابة السريع (QR Code)",
              subtitle = "إضافة QR للفاتورة الإلكترونية المتوافق مع هيئة الزكاة والضرائب",
              checked = profile.receiptPrintQrCode,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(receiptPrintQrCode = checked))
              }
            ),
            QuickToggleItem(
              title = "طباعة الرصيد السابق والمتبقي على العميل",
              subtitle = "إظهار كشف حساب العميل أسفل الفاتورة الآجلة",
              checked = profile.receiptPrintCustomerBalance,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(receiptPrintCustomerBalance = checked))
              }
            )
          )
        )
      }
    }

    // -------------------------------------------------------------------------
    // 8. إعدادات الموظفين والصلاحيات وخاصية المناديب
    // -------------------------------------------------------------------------
    if (selectedCategoryIndex == 0 || selectedCategoryIndex == 7) {
      item {
        ComprehensiveModuleSettingsCard(
          title = "نظام تعدد الموظفين والصلاحيات وخاصية المناديب",
          description = "إدارة الموظفين والمناديب، صلاحيات دقيقة بطلب المدير، ربط الأجهزة ومزامنة الفواتير أوفلاين وسحابياً",
          icon = Icons.Default.Security,
          iconTint = Color(0xFFDC2626),
          onOpenFullSettings = { showSecurityUsersDialog = true },
          badges = listOf(
            "المستخدم الحالي: ${profile.activeEmployeeName} (${profile.activeEmployeeRole})",
            if (profile.deviceRole == "DELEGATE") "وضع الجهاز: مندوب مبيعات 🛵" else "وضع الجهاز: المدير الرئيسي 🏢",
            "رمز الربط: ${profile.companySyncKey}",
            if (profile.securityHideProfitsFromCashier) "حجب الأرباح: مفعّل 🛡️" else "أرباح ظاهرة",
            if (profile.salesAllowManualPriceOverride) "تعديل سعر يدوي: مسموح ✏️" else "تعديل سعر: ممنوع 🔒"
          ),
          quickToggles = listOf(
            QuickToggleItem(
              title = "طلب إذن المدير عند حذف أو إلغاء أي فاتورة",
              subtitle = "منع الموظفين من حذف الفواتير الصادرة بدون موافقة المشرف",
              checked = profile.securityRequireAdminPasswordForDelete,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(securityRequireAdminPasswordForDelete = checked))
              }
            ),
            QuickToggleItem(
              title = "حجب تقارير وهوامش الأرباح عن الكاشير والموظفين",
              subtitle = "إخفاء أسعار التكلفة وصافي الأرباح لحماية سرية العمل",
              checked = profile.securityHideProfitsFromCashier,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(securityHideProfitsFromCashier = checked))
              }
            ),
            QuickToggleItem(
              title = "قفل الفواتير بعد إصدارها ومنع التعديل المباشر",
              subtitle = "إلزام إجراء مرتجع رسمي بدلاً من تعديل الفاتورة المصدرة",
              checked = profile.securityLockInvoicesAfterIssue,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(securityLockInvoicesAfterIssue = checked))
              }
            ),
            QuickToggleItem(
              title = "المزامنة اللحظية التلقائية مع أجهزة المناديب بمجرد توفر الإنترنت",
              subtitle = "تنزيل فواتير بيع المناديب وتحديث الخزينة والديون تلقائياً فور الاتصال",
              checked = profile.autoSyncWhenOnline,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(autoSyncWhenOnline = checked))
              }
            ),
            QuickToggleItem(
              title = "قفل الشاشة الآن والعودة لشاشة بصمة/باسوورد الموظف",
              subtitle = "إلزام التحقق الأمني بالبصمة أو رمز PIN قبل فتح أي شاشة",
              checked = false,
              onCheckedChange = {
                viewModel.setScreenLocked(true)
              }
            )
          )
        )
      }
    }

    // -------------------------------------------------------------------------
    // 9. إعدادات النظام والمظهر والنسخ الاحتياطي
    // -------------------------------------------------------------------------
    if (selectedCategoryIndex == 0 || selectedCategoryIndex == 8) {
      item {
        ComprehensiveModuleSettingsCard(
          title = "إعدادات النظام والمظهر والنسخ الاحتياطي",
          description = "المظهر الليلي Dark Mode، المزامنة السحابية اليومية، وتنبيهات الباركود الصوتية",
          icon = Icons.Default.CloudUpload,
          iconTint = OrangePrimary,
          onOpenFullSettings = { showSystemBackupDialog = true },
          badges = listOf(
            if (profile.isDarkMode) "المظهر: ليلي 🌙" else "المظهر: فاتح ☀️",
            if (profile.autoBackupEnabled) "مزامنة سحابية: مفعّلة ☁️" else "مزامنة معطلة",
            "آخر نسخ: $lastBackupDateStr"
          ),
          quickToggles = listOf(
            QuickToggleItem(
              title = "المظهر الليلي (Dark Mode)",
              subtitle = "تقليل إجهاد العين وتوفير طاقة البطارية أثناء العمل",
              checked = profile.isDarkMode,
              onCheckedChange = { viewModel.toggleDarkMode(it) }
            ),
            QuickToggleItem(
              title = "المزامنة السحابية اليومية التلقائية",
              subtitle = "حفظ نسخة احتياطية مشفرة من قاعدة البيانات يومياً",
              checked = profile.autoBackupEnabled,
              onCheckedChange = { viewModel.toggleCloudSync(it) }
            ),
            QuickToggleItem(
              title = "نغمة صوتية عند مسح الباركود بنجاح",
              subtitle = "تشغيل صوت بيب Beep للتأكيد على التقاط الصنف",
              checked = profile.soundBeepOnScan,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(soundBeepOnScan = checked))
              }
            ),
            QuickToggleItem(
              title = "الاهتزاز عند مسح الباركود",
              subtitle = "تأكيد لمسي أثناء مسح الأصناف عبر الكاميرا",
              checked = profile.vibrateOnScan,
              onCheckedChange = { checked ->
                viewModel.updateBusinessProfile(profile.copy(vibrateOnScan = checked))
              }
            )
          )
        )
      }

      // أزرار النسخ والاسترجاع السريع
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { showBackupRestorePopup = true },
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                  shape = CircleShape,
                  color = OrangePrimary.copy(alpha = 0.15f),
                  modifier = Modifier.size(36.dp)
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.CloudSync, contentDescription = null, tint = OrangePrimary, modifier = Modifier.size(20.dp))
                  }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text("النسخ الاحتياطي واستعادة البيانات", fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
                  Text("حفظ واستبدال تلقائي بذاكرة الهاتف بنقرة واحدة", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }

              Surface(
                shape = RoundedCornerShape(6.dp),
                color = EmeraldPrimary.copy(alpha = 0.15f)
              ) {
                Text(
                  text = "نسخة واحدة نشطة ✓",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = EmeraldPrimary,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
              }
            }

            Text(
              text = "المجلد الحالي: ${profile.backupFolderDisplayName}",
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium,
              color = MaterialTheme.colorScheme.onSurface
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Button(
                onClick = { showBackupRestorePopup = true },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                modifier = Modifier.weight(1f)
              ) {
                Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("فتح نافذة النسخ والاستعادة ⚡", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }

  // =========================================================================
  // النوافذ الحوارية المتخصصة لتعديل إعدادات كل شاشة وقسم
  // =========================================================================

  // 1. نافذة إعدادات المبيعات والكاشير
  if (showSalesSettingsDialog) {
    SalesSettingsDialog(
      initial = profile,
      onDismiss = { showSalesSettingsDialog = false },
      onSave = { updated ->
        viewModel.updateBusinessProfile(updated)
        showSalesSettingsDialog = false
        Toast.makeText(context, "تم حفظ إعدادات شاشة المبيعات بنجاح", Toast.LENGTH_SHORT).show()
      }
    )
  }

  // 2. نافذة إعدادات المشتريات والتوريد
  if (showPurchasesSettingsDialog) {
    PurchasesSettingsDialog(
      initial = profile,
      onDismiss = { showPurchasesSettingsDialog = false },
      onSave = { updated ->
        viewModel.updateBusinessProfile(updated)
        showPurchasesSettingsDialog = false
        Toast.makeText(context, "تم حفظ إعدادات شاشة المشتريات بنجاح", Toast.LENGTH_SHORT).show()
      }
    )
  }

  // 3. نافذة إعدادات المخزن والجرد
  if (showWarehouseSettingsDialog) {
    WarehouseSettingsDialog(
      initial = profile,
      onDismiss = { showWarehouseSettingsDialog = false },
      onSave = { updated ->
        viewModel.updateBusinessProfile(updated)
        showWarehouseSettingsDialog = false
        Toast.makeText(context, "تم حفظ إعدادات المخازن والجرد بنجاح", Toast.LENGTH_SHORT).show()
      }
    )
  }

  // 4. نافذة إعدادات المالية والضرائب
  if (showFinanceTaxSettingsDialog) {
    FinanceTaxSettingsDialog(
      initial = profile,
      onDismiss = { showFinanceTaxSettingsDialog = false },
      onSave = { updated ->
        viewModel.updateBusinessProfile(updated)
        showFinanceTaxSettingsDialog = false
        Toast.makeText(context, "تم حفظ إعدادات الخزينة والضرائب بنجاح", Toast.LENGTH_SHORT).show()
      }
    )
  }

  // 5. نافذة تعديل بيانات النشاط التجاري
  if (showBusinessProfileDialog) {
    EditBusinessProfileDialog(
      initial = profile,
      onDismiss = { showBusinessProfileDialog = false },
      onSave = { updated ->
        viewModel.updateBusinessProfile(updated)
        showBusinessProfileDialog = false
        Toast.makeText(context, "تم حفظ بيانات النشاط التجاري بنجاح", Toast.LENGTH_SHORT).show()
      }
    )
  }

  // 6. نافذة إعدادات الطابعة الحرارية
  if (showPrinterSettingsDialog) {
    PrinterSettingsDialog(
      initialProfile = profile,
      onDismiss = { showPrinterSettingsDialog = false },
      onSave = { updated ->
        viewModel.updateBusinessProfile(updated)
        showPrinterSettingsDialog = false
        Toast.makeText(context, "تم تحديث إعدادات الطابعة وفواتير POS", Toast.LENGTH_SHORT).show()
      }
    )
  }

  // 7. نافذة الموظفين والمناديب والصلاحيات والأمان
  if (showSecurityUsersDialog) {
    MultiEmployeeAndDelegateDialog(
      viewModel = viewModel,
      initial = profile,
      onDismiss = { showSecurityUsersDialog = false },
      onSaveProfile = { updated ->
        viewModel.updateBusinessProfile(updated)
        showSecurityUsersDialog = false
        Toast.makeText(context, "تم حفظ إعدادات الموظفين والمناديب بنجاح ✓", Toast.LENGTH_SHORT).show()
      }
    )
  }

  // 8. نافذة إعدادات النظام والنسخ الاحتياطي
  if (showSystemBackupDialog) {
    SystemAndBackupSettingsDialog(
      initial = profile,
      onDismiss = { showSystemBackupDialog = false },
      onOpenBackupDialog = {
        showSystemBackupDialog = false
        showBackupRestorePopup = true
      },
      onSave = { updated ->
        viewModel.updateBusinessProfile(updated)
        showSystemBackupDialog = false
        Toast.makeText(context, "تم حفظ إعدادات النظام بنجاح", Toast.LENGTH_SHORT).show()
      }
    )
  }

  // 9. القائمة المنبثقة لإدارة النسخ الاحتياطي والاستعادة الفورية
  if (showBackupRestorePopup) {
    BackupRestoreDialog(
      viewModel = viewModel,
      onDismiss = { showBackupRestorePopup = false }
    )
  }
}

// -----------------------------------------------------------------------------
// مكون بطاقة الإعدادات المتكاملة لكل شاشة
// -----------------------------------------------------------------------------
data class QuickToggleItem(
  val title: String,
  val subtitle: String,
  val checked: Boolean,
  val onCheckedChange: (Boolean) -> Unit
)

@Composable
fun ComprehensiveModuleSettingsCard(
  title: String,
  description: String,
  icon: ImageVector,
  iconTint: Color,
  onOpenFullSettings: () -> Unit,
  badges: List<String> = emptyList(),
  quickToggles: List<QuickToggleItem> = emptyList()
) {
  var isExpanded by remember { mutableStateOf(true) }

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      // شريط العنوان الرئيسي للقسم
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Surface(
            shape = CircleShape,
            color = iconTint.copy(alpha = 0.15f),
            modifier = Modifier.size(42.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(22.dp))
            }
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
            Text(description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
          }
        }

        Button(
          onClick = onOpenFullSettings,
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          colors = ButtonDefaults.buttonColors(containerColor = iconTint.copy(alpha = 0.9f))
        ) {
          Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(13.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("تخصيص", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }

      // شارات الحالة السريعة للإعدادات
      if (badges.isNotEmpty()) {
        Spacer(modifier = Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(badges) { badgeText ->
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
              Text(
                text = badgeText,
                fontSize = 10.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.5.dp)
              )
            }
          }
        }
      }

      // المفاتيح التفاعلية السريعة
      if (quickToggles.isNotEmpty()) {
        Spacer(modifier = Modifier.height(10.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded },
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (isExpanded) "إخفاء الخيارات السريعة ▲" else "الخيارات والتحكم المباشر (${quickToggles.size}) ▼",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = iconTint
          )
        }

        AnimatedVisibility(visible = isExpanded) {
          Column(modifier = Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            quickToggles.forEach { toggle ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                  .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                  Text(toggle.title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                  Text(toggle.subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                  checked = toggle.checked,
                  onCheckedChange = toggle.onCheckedChange,
                  modifier = Modifier.size(width = 38.dp, height = 24.dp)
                )
              }
            }
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 1. نافذة إعدادات شاشة المبيعات والكاشير
// -----------------------------------------------------------------------------
@Composable
fun SalesSettingsDialog(
  initial: BusinessProfile,
  onDismiss: () -> Unit,
  onSave: (BusinessProfile) -> Unit
) {
  var paymentType by remember { mutableStateOf(initial.salesDefaultPaymentType) }
  var pricingTier by remember { mutableStateOf(initial.salesDefaultPricingTier) }
  var defaultCust by remember { mutableStateOf(initial.salesDefaultCustomerName) }
  var defaultUnit by remember { mutableStateOf(initial.salesDefaultUnit) }
  
  // الإعدادات المطلوبة بشكل مباشر
  var allowBelowInvoiceTotal by remember { mutableStateOf(initial.salesAllowSellingBelowInvoiceTotal) }
  var enableDiscount by remember { mutableStateOf(initial.salesEnableDiscount) }
  var defaultDiscountType by remember { mutableStateOf(initial.salesDefaultDiscountType) }
  var maxDiscountPercent by remember { mutableStateOf(initial.salesMaxDiscountPercent.toString()) }
  var allowItemDiscount by remember { mutableStateOf(initial.salesAllowItemLevelDiscount) }
  var allowCustomInvoiceDate by remember { mutableStateOf(initial.salesAllowCustomInvoiceDate) }
  var allowSellingBelowCost by remember { mutableStateOf(initial.salesAllowSellingBelowCost) }
  
  // إعدادات إضافية ذكية وشاملة
  var warnBelowCost by remember { mutableStateOf(initial.salesWarnBelowCost) }
  var preventNegative by remember { mutableStateOf(initial.salesPreventNegativeStock) }
  var allowManualPrice by remember { mutableStateOf(initial.salesAllowManualPriceOverride) }
  var requireCustomer by remember { mutableStateOf(initial.salesRequireCustomerSelection) }
  var autoMergeDuplicates by remember { mutableStateOf(initial.salesAutoMergeDuplicateItems) }
  var enableInvoiceNotes by remember { mutableStateOf(initial.salesEnableInvoiceNotes) }
  var confirmClearCart by remember { mutableStateOf(initial.salesConfirmClearCart) }
  var quickPayButtons by remember { mutableStateOf(initial.salesEnableQuickPaymentButtons) }
  var checkCreditLimit by remember { mutableStateOf(initial.salesCheckCustomerCreditLimit) }
  var roundTotal by remember { mutableStateOf(initial.salesEnableRoundTotal) }
  var autoPrint by remember { mutableStateOf(initial.salesAutoPrintReceipt) }
  var showProfit by remember { mutableStateOf(initial.salesShowProfitToCashier) }
  var directBarcode by remember { mutableStateOf(initial.salesBarcodeAddSinglePieceDirectly) }

  val paymentOptions = listOf("نقدي", "آجل", "دفع جزئي")
  val pricingOptions = listOf("قطاعي (مستهلك)", "جملة", "جملة الجملة")
  val discountTypeOptions = listOf("مبلغ", "نسبة مئوية")

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.98f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = CircleShape,
            color = EmeraldPrimary.copy(alpha = 0.15f),
            modifier = Modifier.size(38.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Default.PointOfSale, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(22.dp))
            }
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text("إعدادات شاشة المبيعات والكاشير", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("التحكم الكامل في الخصومات، التواريخ، التسعير وحماية الأرباح", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }

        HorizontalDivider()

        // ================= القسم الأول: سياسات الدفع وسداد الفاتورة =================
        Text("💳 سياسات الدفع وسداد الفاتورة", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)

        SettingToggleRow(
          title = "السماح بالبيع بأقل من قيمة الفاتورة",
          subtitle = "قبول إتمام الفاتورة حتى لو سدد العميل مبلغاً أقل من الإجمالي أو دفع جزء دون قيود",
          checked = allowBelowInvoiceTotal,
          onCheckedChange = { allowBelowInvoiceTotal = it }
        )

        SettingToggleRow(
          title = "أزرار فئات النقدية السريعة وحساب الباقي",
          subtitle = "إظهار أزرار سريعة (50، 100، 200 ج.م) مع احتساب الفكة والمبلغ المتبقي للعميل فورياً",
          checked = quickPayButtons,
          onCheckedChange = { quickPayButtons = it }
        )

        SettingToggleRow(
          title = "تقريب كسور المبالغ تلقائياً",
          subtitle = "تقريب إجمالي الفاتورة والفكة لأقرب جنيه صحيح لتسهيل التعامل النقدي",
          checked = roundTotal,
          onCheckedChange = { roundTotal = it }
        )

        // طريقة الدفع الافتراضية
        Text("طريقة الدفع الافتراضية لفواتير البيع:", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          paymentOptions.forEach { opt ->
            FilterChip(
              selected = paymentType == opt,
              onClick = { paymentType = opt },
              label = { Text(opt, fontSize = 11.sp) }
            )
          }
        }

        // ================= القسم الثاني: الخصومات (نسبة ومبلغ) =================
        HorizontalDivider()
        Text("🏷️ خاصية الخصومات (نسبة مئوية ومبلغ)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)

        SettingToggleRow(
          title = "تفعيل خاصية الخصم في شاشة المبيعات",
          subtitle = "إتاحة تطبيق خصومات للعميل كنسبة مئوية (%) أو مبلغ مالي مباشر (ج.م)",
          checked = enableDiscount,
          onCheckedChange = { enableDiscount = it }
        )

        AnimatedVisibility(visible = enableDiscount) {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("نوع الخصم الافتراضي في شاشة البيع:", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              discountTypeOptions.forEach { dType ->
                FilterChip(
                  selected = defaultDiscountType == dType,
                  onClick = { defaultDiscountType = dType },
                  label = { Text(if (dType == "مبلغ") "مبلغ مالي (ج.م)" else "نسبة مئوية (%)", fontSize = 11.sp) }
                )
              }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
              OutlinedTextField(
                value = maxDiscountPercent,
                onValueChange = { maxDiscountPercent = it.filter { ch -> ch.isDigit() || ch == '.' } },
                label = { Text("أقصى نسبة خصم مسموح بها للكاشير (%)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.weight(1f)
              )
            }

            SettingToggleRow(
              title = "السماح بالخصم على مستوى الصنف الفردي",
              subtitle = "إمكانية إعطاء خصم على صنف محدد داخل السلة بالإضافة لخصم الفاتورة الإجمالي",
              checked = allowItemDiscount,
              onCheckedChange = { allowItemDiscount = it }
            )
          }
        }

        // ================= القسم الثالث: تاريخ وبيانات الفاتورة =================
        HorizontalDivider()
        Text("📅 تاريخ الفاتورة وبيانات العميل والملاحظات", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)

        SettingToggleRow(
          title = "السماح بتعديل تاريخ ووقت الفاتورة",
          subtitle = "إظهار منتقي التاريخ والوقت في شاشة البيع لتسجيل فواتير سابقة أو بتواريخ مخصصة",
          checked = allowCustomInvoiceDate,
          onCheckedChange = { allowCustomInvoiceDate = it }
        )

        SettingToggleRow(
          title = "تمكين حقل الملاحظات على الفاتورة",
          subtitle = "إتاحة كتابة شروط أو ملاحظات خاصة بكل فاتورة لطباعتها في الإيصال",
          checked = enableInvoiceNotes,
          onCheckedChange = { enableInvoiceNotes = it }
        )

        SettingToggleRow(
          title = "اشتراط اختيار عميل مسجل لكل فاتورة",
          subtitle = "إلزام الكاشير بتحديد عميل من القائمة ومنع البيع بدون تحديد هوية العميل",
          checked = requireCustomer,
          onCheckedChange = { requireCustomer = it }
        )

        OutlinedTextField(
          value = defaultCust,
          onValueChange = { defaultCust = it },
          label = { Text("اسم العميل الافتراضي للفواتير النقدية السريعة") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        // ================= القسم الرابع: حماية الأرباح ومستوى التسعير =================
        HorizontalDivider()
        Text("🛡️ حماية الأرباح والرقابة على الأسعار", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)

        // مستوى التسعير الافتراضي
        Text("مستوى التسعير الافتراضي:", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          pricingOptions.forEach { opt ->
            FilterChip(
              selected = pricingTier == opt,
              onClick = { pricingTier = opt },
              label = { Text(opt, fontSize = 11.sp) }
            )
          }
        }

        // الوحدة الأساسية الافتراضية
        Text("الوحدة الأساسية الافتراضية في المبيعات:", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("علبة", "قطعة", "كرتونة").forEach { opt ->
            FilterChip(
              selected = defaultUnit == opt,
              onClick = { defaultUnit = opt },
              label = { Text(if (opt == "علبة") "🏷️ علبة (أساسية)" else opt, fontSize = 11.sp) }
            )
          }
        }

        SettingToggleRow(
          title = "السماح بالبيع بأقل من سعر التكلفة",
          subtitle = "تجاوز منع الخسارة وتمرير الفواتير للعروض الخاصة والتصفيات الاستثنائية",
          checked = allowSellingBelowCost,
          onCheckedChange = { allowSellingBelowCost = it }
        )

        SettingToggleRow(
          title = "تحذير عند البيع بأقل من سعر التكلفة",
          subtitle = "تنبيه الكاشير لحماية الأرباح من الخسارة قبل الحفظ",
          checked = warnBelowCost,
          onCheckedChange = { warnBelowCost = it }
        )

        SettingToggleRow(
          title = "السماح بتعديل سعر بيع الصنف يدوياً",
          subtitle = "إمكانية قيام الكاشير بتعديل سعر الوحدة للصنف مباشرة أثناء الفاتورة",
          checked = allowManualPrice,
          onCheckedChange = { allowManualPrice = it }
        )

        SettingToggleRow(
          title = "منع البيع بالسالب عند نفاد المخزون",
          subtitle = "إيقاف الفاتورة تلقائياً إذا كان رصيد الصنف صفر أو غير كافٍ بالمخزن",
          checked = preventNegative,
          onCheckedChange = { preventNegative = it }
        )

        SettingToggleRow(
          title = "فحص الحد الائتماني للعميل عند البيع الآجل",
          subtitle = "تنبيه الكاشير إذا تجاوزت مديونية العميل السقف الائتماني المحدد له",
          checked = checkCreditLimit,
          onCheckedChange = { checkCreditLimit = it }
        )

        // ================= القسم الخامس: سرعة الكاشير والطباعة =================
        HorizontalDivider()
        Text("⚡ سرعة الكاشير وسلوك السلة والطباعة", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)

        SettingToggleRow(
          title = "إضافة قطعة مباشرة عند مسح الباركود",
          subtitle = "إدراج الصنف فورياً بالسلة دون فتح نافذة تعديل الكمية لتسريع البيع",
          checked = directBarcode,
          onCheckedChange = { directBarcode = it }
        )

        SettingToggleRow(
          title = "دمج كميات الأصناف المكررة في السلة",
          subtitle = "زيادة كمية الصنف تلقائياً عند مسحه مجدداً بدلاً من فتح سطر منفصل",
          checked = autoMergeDuplicates,
          onCheckedChange = { autoMergeDuplicates = it }
        )

        SettingToggleRow(
          title = "تأكيد قبل مسح وتفريغ السلة",
          subtitle = "عرض رسالة تأكيد عند الضغط على زر مسح السلة منعاً للأخطاء العفوية",
          checked = confirmClearCart,
          onCheckedChange = { confirmClearCart = it }
        )

        SettingToggleRow(
          title = "طباعة الفاتورة تلقائياً بعد الحفظ",
          subtitle = "إرسال أمر الطباعة مباشرة بعد إتمام الحفظ دون ضغط إضافي",
          checked = autoPrint,
          onCheckedChange = { autoPrint = it }
        )

        SettingToggleRow(
          title = "إظهار هامش ربح الفاتورة للكاشير",
          subtitle = "عرض نسبة ومبلغ الربح في أسفل شاشة البيع للمتابعة اللحظية",
          checked = showProfit,
          onCheckedChange = { showProfit = it }
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = {
              val parsedMaxDisc = maxDiscountPercent.toDoubleOrNull() ?: 30.0
              onSave(
                initial.copy(
                  salesDefaultPaymentType = paymentType,
                  salesDefaultPricingTier = pricingTier,
                  salesDefaultCustomerName = defaultCust.ifBlank { "عميل نقدي عام" },
                  salesAllowSellingBelowInvoiceTotal = allowBelowInvoiceTotal,
                  salesEnableDiscount = enableDiscount,
                  salesDefaultDiscountType = defaultDiscountType,
                  salesMaxDiscountPercent = parsedMaxDisc,
                  salesAllowItemLevelDiscount = allowItemDiscount,
                  salesAllowCustomInvoiceDate = allowCustomInvoiceDate,
                  salesAllowSellingBelowCost = allowSellingBelowCost,
                  salesWarnBelowCost = warnBelowCost,
                  salesPreventNegativeStock = preventNegative,
                  salesAllowManualPriceOverride = allowManualPrice,
                  salesDefaultUnit = defaultUnit,
                  salesRequireCustomerSelection = requireCustomer,
                  salesAutoMergeDuplicateItems = autoMergeDuplicates,
                  salesEnableInvoiceNotes = enableInvoiceNotes,
                  salesConfirmClearCart = confirmClearCart,
                  salesEnableQuickPaymentButtons = quickPayButtons,
                  salesCheckCustomerCreditLimit = checkCreditLimit,
                  salesEnableRoundTotal = roundTotal,
                  salesAutoPrintReceipt = autoPrint,
                  salesShowProfitToCashier = showProfit,
                  salesBarcodeAddSinglePieceDirectly = directBarcode
                )
              )
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("حفظ إعدادات المبيعات", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(0.4f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 2. نافذة إعدادات شاشة المشتريات والتوريد
// -----------------------------------------------------------------------------
@Composable
fun PurchasesSettingsDialog(
  initial: BusinessProfile,
  onDismiss: () -> Unit,
  onSave: (BusinessProfile) -> Unit
) {
  var paymentType by remember { mutableStateOf(initial.purchasesDefaultPaymentType) }
  var updateCostAuto by remember { mutableStateOf(initial.purchasesUpdateCostAutomatically) }
  var warnCostIncreased by remember { mutableStateOf(initial.purchasesWarnIfCostIncreased) }
  var defaultUnit by remember { mutableStateOf(initial.purchasesDefaultUnit) }
  var allowManualPrice by remember { mutableStateOf(initial.purchasesAllowManualPriceOverride) }
  var requireInvNum by remember { mutableStateOf(initial.purchasesRequireInvoiceNumber) }
  var defaultSupplier by remember { mutableStateOf(initial.purchasesDefaultSupplierName) }

  val paymentOptions = listOf("نقدي (من الخزينة)", "آجل للمورد")
  val unitOptions = listOf("كرتونة", "قطعة")

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.96f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.LocalShipping, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(24.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("إعدادات شاشة المشتريات والتوريد", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        HorizontalDivider()

        // السداد الافتراضي
        Text("طريقة السداد الافتراضية لفواتير الشراء:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          paymentOptions.forEach { opt ->
            FilterChip(
              selected = paymentType == opt,
              onClick = { paymentType = opt },
              label = { Text(opt, fontSize = 11.5.sp) }
            )
          }
        }

        // الوحدة الافتراضية
        Text("الوحدة الافتراضية لإدخال الكميات الموردة:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          unitOptions.forEach { opt ->
            FilterChip(
              selected = defaultUnit == opt,
              onClick = { defaultUnit = opt },
              label = { Text(opt, fontSize = 11.5.sp) }
            )
          }
        }

        OutlinedTextField(
          value = defaultSupplier,
          onValueChange = { defaultSupplier = it },
          label = { Text("المورد الافتراضي للتوريدات السريعة") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        HorizontalDivider()

        SettingToggleRow(
          title = "التحديث التلقائي لسعر تكلفة الصنف",
          subtitle = "تحديث سعر التكلفة فوراً بآخر سعر شراء عند اعتماد الفاتورة",
          checked = updateCostAuto,
          onCheckedChange = { updateCostAuto = it }
        )

        SettingToggleRow(
          title = "تنبيه عند ارتفاع سعر الشراء عن السعر السابق",
          subtitle = "تنبيه المستخدم عند قيام المورد برفع سعر الصنف",
          checked = warnCostIncreased,
          onCheckedChange = { warnCostIncreased = it }
        )

        SettingToggleRow(
          title = "اشتراط رقم فاتورة المورد الورقية",
          subtitle = "منع إتمام الفاتورة إلا بعد تدوين رقم الفاتورة الخارجية",
          checked = requireInvNum,
          onCheckedChange = { requireInvNum = it }
        )

        SettingToggleRow(
          title = "إمكانية تعديل سعر المنتجات يدوياً",
          subtitle = "السماح بتعديل سعر شراء الصنف يدوياً أثناء إنشاء فاتورة المشتريات",
          checked = allowManualPrice,
          onCheckedChange = { allowManualPrice = it }
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = {
              onSave(
                initial.copy(
                  purchasesDefaultPaymentType = paymentType,
                  purchasesDefaultUnit = defaultUnit,
                  purchasesAllowManualPriceOverride = allowManualPrice,
                  purchasesUpdateCostAutomatically = updateCostAuto,
                  purchasesWarnIfCostIncreased = warnCostIncreased,
                  purchasesRequireInvoiceNumber = requireInvNum,
                  purchasesDefaultSupplierName = defaultSupplier.ifBlank { "مورد عام نقدي" }
                )
              )
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ إعدادات المشتريات", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(0.5f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 3. نافذة إعدادات المخازن والجرد
// -----------------------------------------------------------------------------
@Composable
fun WarehouseSettingsDialog(
  initial: BusinessProfile,
  onDismiss: () -> Unit,
  onSave: (BusinessProfile) -> Unit
) {
  var thresholdText by remember { mutableStateOf(initial.warehouseLowStockThreshold.toString()) }
  var enableAlerts by remember { mutableStateOf(initial.warehouseEnableLowStockAlerts) }
  var valuationMethod by remember { mutableStateOf(initial.warehouseValuationMethod) }
  var showCartonPiece by remember { mutableStateOf(initial.warehouseShowCartonsAndPieces) }
  var autoReconcile by remember { mutableStateOf(initial.warehouseAutoReconciliationAudit) }

  val valuationOptions = listOf("متوسط التكلفة المرجح", "آخر سعر شراء")

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.96f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Inventory2, contentDescription = null, tint = Color(0xFF7C3AED), modifier = Modifier.size(24.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("إعدادات المخزن والجرد والأصناف", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        HorizontalDivider()

        OutlinedTextField(
          value = thresholdText,
          onValueChange = { thresholdText = it.filter { ch -> ch.isDigit() } },
          label = { Text("الحد الأدنى الافتراضي لتنبيه النواقص (قطع) *") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Text("طريقة تقييم المخزون المالي في التقارير:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          valuationOptions.forEach { opt ->
            FilterChip(
              selected = valuationMethod == opt,
              onClick = { valuationMethod = opt },
              label = { Text(opt, fontSize = 11.5.sp) }
            )
          }
        }

        HorizontalDivider()

        SettingToggleRow(
          title = "تفعيل إشعارات وتنبيهات نواقص المخزون",
          subtitle = "إبراز الأصناف الواصلة لحد الطلب في القوائم والتقارير",
          checked = enableAlerts,
          onCheckedChange = { enableAlerts = it }
        )

        SettingToggleRow(
          title = "عرض الرصيد بالكرتونة والقطعة معاً",
          subtitle = "حساب عدد الكراتين والقطع المتبقية آلياً في المخزن",
          checked = showCartonPiece,
          onCheckedChange = { showCartonPiece = it }
        )

        SettingToggleRow(
          title = "إنشاء قيد وسجل تسوية مخزنية تلقائياً",
          subtitle = "توثيق عمليات الجرد والتسوية لضمان تتبع الفروقات",
          checked = autoReconcile,
          onCheckedChange = { autoReconcile = it }
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = {
              val threshold = thresholdText.toIntOrNull() ?: 5
              onSave(
                initial.copy(
                  warehouseLowStockThreshold = threshold.coerceAtLeast(1),
                  warehouseEnableLowStockAlerts = enableAlerts,
                  warehouseValuationMethod = valuationMethod,
                  warehouseShowCartonsAndPieces = showCartonPiece,
                  warehouseAutoReconciliationAudit = autoReconcile
                )
              )
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ إعدادات المخزن", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(0.5f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 4. نافذة إعدادات المالية والضرائب
// -----------------------------------------------------------------------------
@Composable
fun FinanceTaxSettingsDialog(
  initial: BusinessProfile,
  onDismiss: () -> Unit,
  onSave: (BusinessProfile) -> Unit
) {
  var cashbox by remember { mutableStateOf(initial.selectedCashbox) }
  var vatEnabled by remember { mutableStateOf(initial.vatTaxEnabled) }
  var vatRateText by remember { mutableStateOf(initial.vatTaxRatePercent.toString()) }
  var vatIncluded by remember { mutableStateOf(initial.vatTaxIncludedInPrice) }
  var drawerLimitText by remember { mutableStateOf(initial.treasuryMaxDrawerLimit.toInt().toString()) }
  var shiftApproval by remember { mutableStateOf(initial.treasuryRequireShiftClosureApproval) }

  val cashboxes = listOf("الخزينة الرئيسية (درج النقدية)", "الخزينة الفرعية 2", "الحساب البنكي")

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.96f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = Color(0xFF047857), modifier = Modifier.size(24.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("إعدادات الخزينة والمالية والضرائب", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        HorizontalDivider()

        Text("الخزينة الافتراضية للعمليات النقدية:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        cashboxes.forEach { boxName ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { cashbox = boxName }
              .padding(vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            RadioButton(selected = cashbox == boxName, onClick = { cashbox = boxName })
            Spacer(modifier = Modifier.width(6.dp))
            Text(boxName, fontSize = 12.5.sp)
          }
        }

        HorizontalDivider()

        SettingToggleRow(
          title = "تفعيل ضريبة القيمة المضافة (VAT)",
          subtitle = "احتساب الضريبة آلياً في فواتير المبيعات والتوريد",
          checked = vatEnabled,
          onCheckedChange = { vatEnabled = it }
        )

        if (vatEnabled) {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = vatRateText,
              onValueChange = { vatRateText = it },
              label = { Text("نسبة الضريبة %") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )

            SettingToggleRow(
              title = "الأسعار شاملة الضريبة",
              subtitle = "احتساب الضريبة داخل سعر البيع",
              checked = vatIncluded,
              onCheckedChange = { vatIncluded = it },
              modifier = Modifier.weight(1.3f)
            )
          }
        }

        OutlinedTextField(
          value = drawerLimitText,
          onValueChange = { drawerLimitText = it.filter { ch -> ch.isDigit() } },
          label = { Text("الحد الأقصى للنقدية في الدرج (${initial.currency})") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        SettingToggleRow(
          title = "اشتراط موافقة المشرف لإغلاق وردية الدرج",
          subtitle = "منع إغلاق الوردية قبل مراجعة العجز أو الزيادة",
          checked = shiftApproval,
          onCheckedChange = { shiftApproval = it }
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = {
              val vatRate = vatRateText.toDoubleOrNull() ?: 14.0
              val limit = drawerLimitText.toDoubleOrNull() ?: 10000.0
              onSave(
                initial.copy(
                  selectedCashbox = cashbox,
                  vatTaxEnabled = vatEnabled,
                  vatTaxRatePercent = vatRate,
                  vatTaxIncludedInPrice = vatIncluded,
                  treasuryMaxDrawerLimit = limit,
                  treasuryRequireShiftClosureApproval = shiftApproval
                )
              )
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF047857)),
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ إعدادات المالية", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(0.5f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 5. نافذة تعديل بيانات النشاط التجاري
// -----------------------------------------------------------------------------
@Composable
fun EditBusinessProfileDialog(
  initial: BusinessProfile,
  onDismiss: () -> Unit,
  onSave: (BusinessProfile) -> Unit
) {
  var name by remember { mutableStateOf(initial.businessName) }
  var type by remember { mutableStateOf(initial.businessType) }
  var phone by remember { mutableStateOf(initial.contactPhone) }
  var address by remember { mutableStateOf(initial.address) }
  var currency by remember { mutableStateOf(initial.currency) }
  var taxNumber by remember { mutableStateOf(initial.taxNumber) }
  var commercialRecord by remember { mutableStateOf(initial.commercialRecord) }

  val currencies = listOf("ج.م", "SAR", "USD", "AED", "KWD")

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.96f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text("تعديل بيانات النشاط التجاري", fontWeight = FontWeight.Bold, fontSize = 16.sp)

        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("اسم النشاط التجاري / المحل *") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = type,
          onValueChange = { type = it },
          label = { Text("نوع النشاط (تجارة جملة، سوبرماركت..)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("رقم الهاتف") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = address,
            onValueChange = { address = it },
            label = { Text("العنوان") },
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = taxNumber,
            onValueChange = { taxNumber = it },
            label = { Text("الرقم الضريبي") },
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = commercialRecord,
            onValueChange = { commercialRecord = it },
            label = { Text("السجل التجاري") },
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
        }

        Text("العملة الافتراضية للتعاملات:", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          currencies.forEach { curr ->
            FilterChip(
              selected = currency == curr,
              onClick = { currency = curr },
              label = { Text(curr, fontSize = 11.5.sp) }
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              if (name.isBlank()) return@Button
              onSave(
                initial.copy(
                  businessName = name.trim(),
                  businessType = type.trim(),
                  contactPhone = phone.trim(),
                  address = address.trim(),
                  currency = currency,
                  taxNumber = taxNumber.trim(),
                  commercialRecord = commercialRecord.trim()
                )
              )
            },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary)
          ) {
            Text("حفظ التغييرات", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(0.5f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 6. نافذة إعدادات الطابعة وفواتير POS
// -----------------------------------------------------------------------------
@Composable
fun PrinterSettingsDialog(
  initialProfile: BusinessProfile,
  onDismiss: () -> Unit,
  onSave: (BusinessProfile) -> Unit
) {
  var chosenType by remember { mutableStateOf(initialProfile.printerType) }
  var btName by remember { mutableStateOf(initialProfile.bluetoothPrinterName) }
  var headerTitle by remember { mutableStateOf(initialProfile.receiptHeaderTitle) }
  var footerNote by remember { mutableStateOf(initialProfile.receiptFooterNote) }
  var printQr by remember { mutableStateOf(initialProfile.receiptPrintQrCode) }
  var printBalance by remember { mutableStateOf(initialProfile.receiptPrintCustomerBalance) }
  var copies by remember { mutableIntStateOf(initialProfile.receiptCopiesCount) }
  var isScanning by remember { mutableStateOf(false) }

  val printerTypes = listOf("حراري 80mm", "حراري 58mm", "A4")
  val context = LocalContext.current
  val scope = rememberCoroutineScope()

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.96f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Print, contentDescription = null, tint = OrangePrimary, modifier = Modifier.size(24.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("إعدادات الطابعة الحرارية وفواتير POS", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        HorizontalDivider()

        Text("اختر نوع ومقاس الطابعة:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          printerTypes.forEach { type ->
            FilterChip(
              selected = chosenType == type,
              onClick = { chosenType = type },
              label = { Text(type, fontSize = 11.5.sp) }
            )
          }
        }

        // اقتران البلوتوث
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = if (btName.isBlank()) Icons.Default.Bluetooth else Icons.Default.BluetoothConnected,
              contentDescription = null,
              tint = if (btName.isBlank()) MaterialTheme.colorScheme.outline else EmeraldPrimary
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (btName.isBlank()) "لا توجد طابعة متصلة" else "متصل: $btName",
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold
            )
          }

          OutlinedButton(
            onClick = {
              scope.launch {
                isScanning = true
                delay(1000)
                isScanning = false
                btName = "POS-80BT (متصل)"
                Toast.makeText(context, "تم العثور على طابعة POS-80 والاقتران بها", Toast.LENGTH_SHORT).show()
              }
            },
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(Icons.Default.BluetoothSearching, contentDescription = null, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(if (isScanning) "بحث..." else "اقتران", fontSize = 11.sp)
          }
        }

        OutlinedTextField(
          value = headerTitle,
          onValueChange = { headerTitle = it },
          label = { Text("عنوان رأس الفاتورة (Header)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = footerNote,
          onValueChange = { footerNote = it },
          label = { Text("تذييل الفاتورة الافتراضي (Footer)") },
          maxLines = 2,
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("عدد النسخ المطبوعة:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(1, 2).forEach { num ->
              FilterChip(
                selected = copies == num,
                onClick = { copies = num },
                label = { Text("$num نسخة", fontSize = 11.sp) }
              )
            }
          }
        }

        SettingToggleRow(
          title = "طباعة رمز الاستجابة السريع (QR Code)",
          subtitle = "إضافة QR للفاتورة الإلكترونية المتوافق ضريبياً",
          checked = printQr,
          onCheckedChange = { printQr = it }
        )

        SettingToggleRow(
          title = "طباعة رصيد العميل السابق والمتبقي",
          subtitle = "توضيح الحساب التراكمي في الفواتير الآجلة",
          checked = printBalance,
          onCheckedChange = { printBalance = it }
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              onSave(
                initialProfile.copy(
                  printerType = chosenType,
                  bluetoothPrinterName = btName,
                  receiptHeaderTitle = headerTitle.trim(),
                  receiptFooterNote = footerNote.trim(),
                  receiptPrintQrCode = printQr,
                  receiptPrintCustomerBalance = printBalance,
                  receiptCopiesCount = copies
                )
              )
            },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary)
          ) {
            Text("حفظ إعدادات الطابعة", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(0.5f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 7. نافذة الصلاحيات والمستخدمين
// -----------------------------------------------------------------------------
@Composable
fun UsersAndPermissionsDialog(
  initial: BusinessProfile,
  onDismiss: () -> Unit,
  onSave: (BusinessProfile) -> Unit
) {
  var currentRole by remember { mutableStateOf(initial.userRole) }
  var requirePwDelete by remember { mutableStateOf(initial.securityRequireAdminPasswordForDelete) }
  var hideProfits by remember { mutableStateOf(initial.securityHideProfitsFromCashier) }
  var lockInvoices by remember { mutableStateOf(initial.securityLockInvoicesAfterIssue) }

  val roles = listOf(
    Triple("أدمن (مدير عام)", "كامل الصلاحيات (البيع، الشراء، الأرباح، التعديل والحذف)", OrangePrimary),
    Triple("كاشير", "صلاحية إنشاء فواتير البيع فقط بدون إظهار التكلفة والربح", EmeraldPrimary),
    Triple("محاسب", "صلاحية إدارة الحسابات والتقارير المالية والمصروفات", Color(0xFF0284C7)),
    Triple("أمين مخزن", "صلاحية إدارة استلام البضائع وجرد المخزون والتحويلات", Color(0xFF7C3AED))
  )

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.96f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(24.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("إدارة الصلاحيات والمستخدمين والأمان", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        HorizontalDivider()

        Text("اختر الدور النشط لتحديد الصلاحيات:", fontSize = 12.sp, fontWeight = FontWeight.Bold)

        roles.forEach { (roleName, desc, color) ->
          val isSelected = currentRole.contains(roleName) || roleName.contains(currentRole)
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { currentRole = roleName },
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = if (isSelected) color.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
            border = if (isSelected) BorderStroke(1.5.dp, color) else null
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              RadioButton(selected = isSelected, onClick = { currentRole = roleName })
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(roleName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = if (isSelected) color else MaterialTheme.colorScheme.onSurface)
                Text(desc, fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }

        HorizontalDivider()

        SettingToggleRow(
          title = "طلب إذن المدير عند حذف الفواتير",
          subtitle = "حماية السجلات من الحذف العشوائي بدون إشراف",
          checked = requirePwDelete,
          onCheckedChange = { requirePwDelete = it }
        )

        SettingToggleRow(
          title = "حجب تقارير وهوامش الأرباح عن الكاشير",
          subtitle = "إخفاء أسعار التكلفة وصافي الأرباح",
          checked = hideProfits,
          onCheckedChange = { hideProfits = it }
        )

        SettingToggleRow(
          title = "قفل الفواتير بعد إصدارها",
          subtitle = "إلزام عمل مرتجع رسمي بدلاً من التعديل المباشر",
          checked = lockInvoices,
          onCheckedChange = { lockInvoices = it }
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = {
              onSave(
                initial.copy(
                  userRole = currentRole,
                  securityRequireAdminPasswordForDelete = requirePwDelete,
                  securityHideProfitsFromCashier = hideProfits,
                  securityLockInvoicesAfterIssue = lockInvoices
                )
              )
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ الصلاحيات", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(0.5f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 8. نافذة إعدادات النظام والنسخ الاحتياطي
// -----------------------------------------------------------------------------
@Composable
fun SystemAndBackupSettingsDialog(
  initial: BusinessProfile,
  onDismiss: () -> Unit,
  onOpenBackupDialog: () -> Unit = {},
  onSave: (BusinessProfile) -> Unit
) {
  var darkMode by remember { mutableStateOf(initial.isDarkMode) }
  var autoBackup by remember { mutableStateOf(initial.autoBackupEnabled) }
  var soundBeep by remember { mutableStateOf(initial.soundBeepOnScan) }
  var vibrateScan by remember { mutableStateOf(initial.vibrateOnScan) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.96f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.CloudUpload, contentDescription = null, tint = OrangePrimary, modifier = Modifier.size(24.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("إعدادات النظام والنسخ الاحتياطي", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        HorizontalDivider()

        Button(
          onClick = onOpenBackupDialog,
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("إدارة النسخ الاحتياطي واستعادة البيانات ⚡", fontWeight = FontWeight.Bold)
        }

        SettingToggleRow(
          title = "المظهر الليلي (Dark Mode)",
          subtitle = "تقليل إجهاد العين وتوفير البطارية في فترات العمل المسائية",
          checked = darkMode,
          onCheckedChange = { darkMode = it }
        )

        SettingToggleRow(
          title = "النسخ الاحتياطي اليومي التلقائي",
          subtitle = "حفظ نسخة احتياطية مشفرة يومياً بذاكرة الهاتف واستبدال القديمة",
          checked = autoBackup,
          onCheckedChange = { autoBackup = it }
        )

        SettingToggleRow(
          title = "نغمة صوتية عند مسح الباركود بنجاح",
          subtitle = "تأكيد صوتي على التقاط الصنف في شاشة المبيعات",
          checked = soundBeep,
          onCheckedChange = { soundBeep = it }
        )

        SettingToggleRow(
          title = "الاهتزاز عند مسح الباركود",
          subtitle = "إعطاء هزة خفيفة عند التعرف على الباركود",
          checked = vibrateScan,
          onCheckedChange = { vibrateScan = it }
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = {
              onSave(
                initial.copy(
                  isDarkMode = darkMode,
                  autoBackupEnabled = autoBackup,
                  soundBeepOnScan = soundBeep,
                  vibrateOnScan = vibrateScan
                )
              )
            },
            colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ إعدادات النظام", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(0.5f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// عنصر التبديل المساعد SettingToggleRow
// -----------------------------------------------------------------------------
@Composable
fun SettingToggleRow(
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
      .padding(horizontal = 12.dp, vertical = 8.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
      Text(title, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
      Text(subtitle, fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      colors = SwitchDefaults.colors(
        checkedThumbColor = Color.White,
        checkedTrackColor = MaterialTheme.colorScheme.primary
      )
    )
  }
}
