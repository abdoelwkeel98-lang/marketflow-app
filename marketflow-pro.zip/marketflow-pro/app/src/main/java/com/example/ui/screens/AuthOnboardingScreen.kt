package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.settings.BusinessProfile
import com.example.ui.WholesaleViewModel
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary

@Composable
fun AuthOnboardingScreen(
  viewModel: WholesaleViewModel,
  currentProfile: BusinessProfile,
  onComplete: () -> Unit
) {
  var selectedTab by remember { mutableIntStateOf(0) } // 0 = تسجيل الدخول, 1 = إعداد النشاط التجاري
  var phone by remember { mutableStateOf(currentProfile.phoneNumber) }
  var password by remember { mutableStateOf("123456") }
  var passwordVisible by remember { mutableStateOf(false) }

  // Business profile fields
  var businessName by remember { mutableStateOf(currentProfile.businessName) }
  var businessType by remember { mutableStateOf(currentProfile.businessType) }
  var currency by remember { mutableStateOf(currentProfile.currency) }
  var contactPhone by remember { mutableStateOf(currentProfile.contactPhone) }
  var address by remember { mutableStateOf(currentProfile.address) }
  var taxNumber by remember { mutableStateOf(currentProfile.taxNumber) }
  var commercialRecord by remember { mutableStateOf(currentProfile.commercialRecord) }
  var selectedRole by remember { mutableStateOf(currentProfile.userRole) }

  var showForgotPasswordDialog by remember { mutableStateOf(false) }
  var showOtpDialog by remember { mutableStateOf(false) }
  var statusMessage by remember { mutableStateOf<String?>(null) }

  val businessTypes = listOf(
    "سوبر ماركت ومخزن جملة",
    "تجارة جملة مواد غذائية",
    "تجزئة وبقالة ماركت",
    "مستودع توزيع وبضائع"
  )

  val currencies = listOf("ج.م", "ريال سعودي", "درهم إماراتي", "دينار كويتي", "$ USD")

  val roles = listOf("أدمن (مدير عام)", "كاشير", "محاسب")

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(
            OrangePrimary.copy(alpha = 0.08f),
            MaterialTheme.colorScheme.background
          )
        )
      )
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp, vertical = 24.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Spacer(modifier = Modifier.height(16.dp))

      // App Logo & Title
      Surface(
        shape = CircleShape,
        color = OrangePrimary,
        modifier = Modifier.size(76.dp),
        shadowElevation = 6.dp
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = Icons.Default.Storefront,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(44.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = "الوكيل لتجارة المواد الغذائية",
        fontSize = 22.sp,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.onBackground
      )
      Text(
        text = "إدارة المخازن، الفواتير، ديون العملاء والموردين",
        fontSize = 13.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(20.dp))

      // Tab switcher
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
      ) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text("تسجيل الدخول", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text("إعداد النشاط التجاري", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        )
      }

      Spacer(modifier = Modifier.height(20.dp))

      if (selectedTab == 0) {
        // ================= AUTH / LOGIN TAB =================
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Text(
              text = "تسجيل الدخول للنظام",
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "أدخل رقم الهاتف وكلمة السر أو استخدم الدخول السريع برمز التحقق OTP",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
              value = phone,
              onValueChange = { phone = it },
              label = { Text("رقم الهاتف") },
              leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
              value = password,
              onValueChange = { password = it },
              label = { Text("كلمة السر") },
              leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
              trailingIcon = {
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                  Icon(
                    imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                    contentDescription = null
                  )
                }
              },
              visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp)
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.End
            ) {
              TextButton(onClick = { showForgotPasswordDialog = true }) {
                Text("نسيت كلمة السر؟", fontSize = 12.sp, color = OrangePrimary)
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
              onClick = {
                viewModel.setLoggedIn(true)
                onComplete()
              },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary)
            ) {
              Text("دخول للنظام", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
              onClick = { showOtpDialog = true },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp)
            ) {
              Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("تسجيل سريع برقم الهاتف وتأكيد OTP", fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
              text = "حساب تجريبي نشط: اضغط مباشرة على 'دخول للنظام'",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.align(Alignment.CenterHorizontally)
            )
          }
        }
      } else {
        // ================= BUSINESS PROFILE SETUP TAB =================
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Text(
              text = "إعداد وتخصيص النشاط التجاري",
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "هذه البيانات ستظهر تلقائياً في رأس وتذييل فواتير البيع والإيصالات",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
              value = businessName,
              onValueChange = { businessName = it },
              label = { Text("اسم النشاط التجاري / المحل") },
              leadingIcon = { Icon(Icons.Default.Storefront, contentDescription = null) },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text("نوع النشاط التجاري:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
              businessTypes.forEach { type ->
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                      if (businessType == type) OrangePrimary.copy(alpha = 0.12f) else Color.Transparent
                    )
                    .clickable { businessType = type }
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(
                    imageVector = if (businessType == type) Icons.Default.CheckCircle else Icons.Default.Business,
                    contentDescription = null,
                    tint = if (businessType == type) OrangePrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(type, fontSize = 13.sp)
                }
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text("العملة الافتراضية:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              currencies.forEach { cur ->
                FilterChip(
                  selected = currency == cur,
                  onClick = { currency = cur },
                  label = { Text(cur, fontSize = 11.sp) }
                )
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
              value = contactPhone,
              onValueChange = { contactPhone = it },
              label = { Text("رقم هاتف التواصل (للفاتورة والواتساب)") },
              leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
              value = address,
              onValueChange = { address = it },
              label = { Text("عنوان المقر بالتفصيل") },
              leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(
                value = taxNumber,
                onValueChange = { taxNumber = it },
                label = { Text("الرقم الضريبي") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
              )
              OutlinedTextField(
                value = commercialRecord,
                onValueChange = { commercialRecord = it },
                label = { Text("السجل التجاري") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text("صلاحية المستخدم الحالي:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              roles.forEach { role ->
                FilterChip(
                  selected = selectedRole == role,
                  onClick = { selectedRole = role },
                  label = { Text(role, fontSize = 11.sp) }
                )
              }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Button(
              onClick = {
                val updated = currentProfile.copy(
                  isLoggedIn = true,
                  businessName = businessName.ifBlank { "الوكيل لتجارة المواد الغذائية" },
                  businessType = businessType,
                  currency = currency,
                  contactPhone = contactPhone,
                  address = address,
                  taxNumber = taxNumber,
                  commercialRecord = commercialRecord,
                  userRole = selectedRole
                )
                viewModel.updateBusinessProfile(updated)
                onComplete()
              },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
              Icon(Icons.Default.Check, contentDescription = null)
              Spacer(modifier = Modifier.width(8.dp))
              Text("حفظ وبدء العمل فوراً", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }

  // Forgot password dialog
  if (showForgotPasswordDialog) {
    Dialog(onDismissRequest = { showForgotPasswordDialog = false }) {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth(0.92f)
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Text("استعادة كلمة السر", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            "سيتم إرسال رمز التحقق وإعادة تعيين كلمة السر إلى رقم الهاتف المسجل: $phone",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(14.dp))
          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("رقم الهاتف") },
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(16.dp))
          Button(
            onClick = {
              showForgotPasswordDialog = false
              showOtpDialog = true
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary)
          ) {
            Text("إرسال رمز التحقق SMS")
          }
        }
      }
    }
  }

  // Quick OTP Dialog
  if (showOtpDialog) {
    var otpCode by remember { mutableStateOf("4829") }
    Dialog(onDismissRequest = { showOtpDialog = false }) {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth(0.92f)
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Text("تأكيد رمز الدخول السريع (OTP)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            "تم إرسال كود التحقق بنجاح إلى $phone. تم إدخال الكود الافتراضي (4829).",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(14.dp))
          OutlinedTextField(
            value = otpCode,
            onValueChange = { otpCode = it },
            label = { Text("رمز التحقق (4 أرقام)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(16.dp))
          Button(
            onClick = {
              showOtpDialog = false
              viewModel.setLoggedIn(true)
              onComplete()
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
          ) {
            Text("تأكيد والدخول للنظام", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}
