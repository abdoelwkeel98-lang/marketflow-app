package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = Color(0xFF93C5FD), // أزرق سماوي مضيء عالي التباين على الخلفيات الداكنة
  onPrimary = Color(0xFF0F172A),
  primaryContainer = Color(0xFF1E2B3C), // كحلي عميق للحاويات
  onPrimaryContainer = Color(0xFFF1F5F9), // نصوص بيضاء نقية واضحة
  secondary = EmeraldLight,
  onSecondary = Color(0xFF022C22),
  secondaryContainer = Color(0xFF064E3B),
  onSecondaryContainer = Color(0xFFD1FAE5),
  tertiary = AmberLight,
  onTertiary = Color(0xFF451A03),
  tertiaryContainer = Color(0xFF78350F),
  onTertiaryContainer = Color(0xFFFEF3C7),
  background = DarkAppBackground, // كحلي داكن عميق 0xFF131A24
  surface = DarkCardSurface,      // كروت الوضع الداكن 0xFF1E2836
  surfaceVariant = Color(0xFF263345),
  onBackground = Color(0xFFF8FAFC), // نصوص واضحة ومقروءة تماماً
  onSurface = Color(0xFFF8FAFC),    // نصوص البطاقات عالية الوضوح
  onSurfaceVariant = Color(0xFF94A3B8), // رمادي أزرق فاتح للنصوص الفرعية
  outline = DarkCardBorder,        // حدود البطاقات 0xFF2D3C4E
  outlineVariant = Color(0xFF253346),
  error = Color(0xFFF87171),
  onError = Color(0xFF450A0A),
  errorContainer = Color(0xFF7F1D1D),
  onErrorContainer = Color(0xFFFEE2E2)
)

private val LightColorScheme = lightColorScheme(
  primary = NavyPrimaryDark, // #2B3E55 الكحلي الداكن / الأزرق الليلي للشريط العلوي والعناوين الهامة
  onPrimary = Color.White,
  primaryContainer = Color(0xFFE2EBF5), // حاويات ثلجية كحلية ناعمة وعالية الوضوح
  onPrimaryContainer = Color(0xFF1B2A3E), // نصوص كحلية واضحة على الحاويات
  secondary = EmeraldPrimary,
  onSecondary = Color.White,
  secondaryContainer = EmeraldContainer,
  onSecondaryContainer = Color(0xFF064E3B),
  tertiary = OrangePrimary,
  onTertiary = Color.White,
  tertiaryContainer = OrangeContainer,
  onTertiaryContainer = OrangeDark,
  background = BackgroundOffWhiteBlue, // #F0F4F8 رمادي أزرق فاتح جداً لخلفية الشاشة الكاملة
  surface = CardBackgroundPureWhite,  // #FFFFFF الأبيض النقي لخلفية البطاقات والكروت
  onBackground = TextPrimaryDark,     // #1A202C الأسود الداكن المائل للكحلي
  onSurface = TextPrimaryDark,        // #1A202C عناوين البطاقات
  surfaceVariant = Color(0xFFE8EEF5), // رمادي أزرق فاتح للحاويات
  onSurfaceVariant = Color(0xFF475569), // رمادي حجري داكن فائق الوضوح للنصوص الفرعية والمساعدة
  outline = Color(0xFFCBD5E1),         // حدود ناعمة واضحة
  outlineVariant = Color(0xFFE2E8F0),
  error = CoralRed,
  onError = Color.White,
  errorContainer = CrimsonContainer,
  onErrorContainer = Color(0xFF7F1D1D)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Preserve brand identity with high contrast
  content: @Composable () -> Unit
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
