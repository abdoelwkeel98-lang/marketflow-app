package com.example.utils

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItem
import com.example.data.model.InvoiceType
import com.example.data.model.PaymentType
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object InvoiceExportHelper {

  /**
   * Generates a formal, beautiful PDF file for the invoice.
   */
  fun generateInvoicePdf(
    context: Context,
    invoice: Invoice,
    items: List<InvoiceItem>,
    businessName: String = "الوكيل لتجارة المواد الغذائية",
    phone: String = "",
    address: String = ""
  ): File {
    val dir = File(context.cacheDir, "invoices").apply { mkdirs() }
    val file = File(dir, "INV_${invoice.invoiceNumber}.pdf")

    val pdfDocument = PdfDocument()
    // Standard A4 dimensions in points: 595 x 842
    val pageWidth = 595
    val pageHeight = 842
    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas

    val paint = Paint().apply { isAntiAlias = true }

    // Top Header Banner
    paint.color = Color.rgb(16, 120, 80) // Deep Emerald Green
    canvas.drawRect(0f, 0f, pageWidth.toFloat(), 90f, paint)

    // Header Title
    paint.color = Color.WHITE
    paint.textSize = 20f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText(businessName, (pageWidth - 30).toFloat(), 40f, paint)

    paint.textSize = 11f
    paint.typeface = Typeface.DEFAULT
    val subtitle = if (invoice.type == InvoiceType.SALE) "فاتورة مبيعات تجارية رسمية" else "فاتورة توريد مشتريات مخزن"
    canvas.drawText(subtitle, (pageWidth - 30).toFloat(), 62f, paint)
    if (phone.isNotBlank() || address.isNotBlank()) {
      canvas.drawText("$phone  $address", (pageWidth - 30).toFloat(), 78f, paint)
    }

    // Left Header (Invoice Number & Date)
    paint.textAlign = Paint.Align.LEFT
    paint.textSize = 12f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("رقم الفاتورة: ${invoice.invoiceNumber}", 30f, 40f, paint)
    val dateStr = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")).format(Date(invoice.timestamp))
    paint.textSize = 10f
    paint.typeface = Typeface.DEFAULT
    canvas.drawText("التاريخ: $dateStr", 30f, 62f, paint)

    // Party Information Box
    var currentY = 115f
    paint.color = Color.rgb(245, 247, 246)
    canvas.drawRoundRect(25f, currentY, (pageWidth - 25).toFloat(), currentY + 50f, 8f, 8f, paint)

    paint.color = Color.rgb(30, 41, 59)
    paint.textAlign = Paint.Align.RIGHT
    paint.textSize = 12f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    val partyLabel = if (invoice.type == InvoiceType.SALE) "العميل: ${invoice.partyName}" else "المورد: ${invoice.partyName}"
    canvas.drawText(partyLabel, (pageWidth - 40).toFloat(), currentY + 28f, paint)

    paint.textAlign = Paint.Align.LEFT
    val paymentLabel = when (invoice.paymentType) {
      PaymentType.CASH -> "طريقة الدفع: نقداً (كاش)"
      PaymentType.CREDIT -> "طريقة الدفع: آجل بالكامل (على الحساب)"
      PaymentType.PARTIAL -> "طريقة الدفع: دفع جزئي نقدي + متبقي آجل"
    }
    paint.textSize = 11f
    paint.typeface = Typeface.DEFAULT
    canvas.drawText(paymentLabel, 40f, currentY + 28f, paint)

    currentY += 70f

    // Items Table Header
    paint.color = Color.rgb(226, 232, 240)
    canvas.drawRect(25f, currentY, (pageWidth - 25).toFloat(), currentY + 26f, paint)

    paint.color = Color.rgb(15, 23, 42)
    paint.textSize = 11f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText("م", (pageWidth - 35).toFloat(), currentY + 18f, paint)
    canvas.drawText("اسم الصنف والبيان", (pageWidth - 65).toFloat(), currentY + 18f, paint)

    paint.textAlign = Paint.Align.CENTER
    canvas.drawText("الكمية", 260f, currentY + 18f, paint)
    canvas.drawText("سعر الوحدة", 170f, currentY + 18f, paint)

    paint.textAlign = Paint.Align.LEFT
    canvas.drawText("الإجمالي (ج.م)", 40f, currentY + 18f, paint)

    currentY += 28f

    // Items Rows
    paint.typeface = Typeface.DEFAULT
    items.forEachIndexed { idx, itm ->
      if (idx % 2 == 1) {
        paint.color = Color.rgb(248, 250, 252)
        canvas.drawRect(25f, currentY - 4f, (pageWidth - 25).toFloat(), currentY + 20f, paint)
      }

      paint.color = Color.rgb(30, 41, 59)
      paint.textSize = 10.5f

      paint.textAlign = Paint.Align.RIGHT
      canvas.drawText("${idx + 1}", (pageWidth - 35).toFloat(), currentY + 13f, paint)
      val nameText = if (itm.productName.length > 32) itm.productName.take(30) + ".." else itm.productName
      canvas.drawText(nameText, (pageWidth - 65).toFloat(), currentY + 13f, paint)

      paint.textAlign = Paint.Align.CENTER
      canvas.drawText("${itm.quantity} ${itm.unitType}", 260f, currentY + 13f, paint)
      canvas.drawText(String.format(Locale.ENGLISH, "%.2f", itm.unitPrice), 170f, currentY + 13f, paint)

      paint.textAlign = Paint.Align.LEFT
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      canvas.drawText(String.format(Locale.ENGLISH, "%.2f", itm.totalPrice), 40f, currentY + 13f, paint)
      paint.typeface = Typeface.DEFAULT

      currentY += 24f
    }

    // Divider Line
    paint.color = Color.rgb(203, 213, 225)
    canvas.drawLine(25f, currentY, (pageWidth - 25).toFloat(), currentY, paint)
    currentY += 16f

    // Financial Summary Block (Right & Left Aligned)
    val summaryBoxTop = currentY
    paint.color = Color.rgb(241, 245, 249)
    canvas.drawRoundRect(25f, summaryBoxTop, (pageWidth - 25).toFloat(), summaryBoxTop + 140f, 10f, 10f, paint)

    val rowHeight = 20f
    var sy = summaryBoxTop + 24f

    fun drawSummaryLine(label: String, value: String, isHighlight: Boolean = false, isAlert: Boolean = false) {
      paint.textAlign = Paint.Align.RIGHT
      paint.textSize = if (isHighlight) 12f else 11f
      paint.color = if (isAlert) Color.rgb(185, 28, 28) else if (isHighlight) Color.rgb(16, 120, 80) else Color.rgb(51, 65, 85)
      paint.typeface = if (isHighlight) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
      canvas.drawText(label, (pageWidth - 45).toFloat(), sy, paint)

      paint.textAlign = Paint.Align.LEFT
      canvas.drawText(value, 45f, sy, paint)
      sy += rowHeight
    }

    drawSummaryLine("إجمالي الأصناف:", String.format(Locale.ENGLISH, "%.2f ج.م", invoice.subtotal))
    if (invoice.discount > 0) {
      drawSummaryLine("الخصم التجاري الممنوح:", String.format(Locale.ENGLISH, "- %.2f ج.م", invoice.discount), isAlert = true)
    }
    drawSummaryLine("صافي الفاتورة الحالية:", String.format(Locale.ENGLISH, "%.2f ج.م", invoice.totalAmount), isHighlight = true)
    drawSummaryLine("المدفوع نقداً كاش:", String.format(Locale.ENGLISH, "%.2f ج.م", invoice.paidAmount))
    if (invoice.remainingAmount > 0) {
      drawSummaryLine("المتبقي من الفاتورة الحالية:", String.format(Locale.ENGLISH, "%.2f ج.م", invoice.remainingAmount), isAlert = true)
    }

    // Previous Balance and Grand Total (جمع الرصيد السابق على المبيعات / المشتريات)
    val prevLabel = if (invoice.type == InvoiceType.SALE) "الرصيد السابق للعميل:" else "الرصيد السابق للمورد:"
    drawSummaryLine(prevLabel, String.format(Locale.ENGLISH, "%.2f ج.م", invoice.previousBalance))

    val grandDue = if (invoice.grandTotalDue > 0) invoice.grandTotalDue else (invoice.previousBalance + invoice.remainingAmount)
    val grandLabel = if (invoice.type == InvoiceType.SALE) "إجمالي الحساب المستحق بعد هذه الفاتورة:" else "إجمالي المستحق للمورد بعد هذه الفاتورة:"
    drawSummaryLine(grandLabel, String.format(Locale.ENGLISH, "%.2f ج.م", grandDue), isHighlight = true, isAlert = invoice.type == InvoiceType.SALE)

    // Footer Bar
    paint.color = Color.rgb(100, 116, 139)
    paint.textSize = 10f
    paint.textAlign = Paint.Align.CENTER
    paint.typeface = Typeface.DEFAULT
    canvas.drawText("شكراً لتعاملكم معنا • نظام الوكيل لتجارة المواد الغذائية لإدارة المبيعات والمخازن", (pageWidth / 2).toFloat(), 800f, paint)

    pdfDocument.finishPage(page)
    val fos = FileOutputStream(file)
    pdfDocument.writeTo(fos)
    fos.close()
    pdfDocument.close()

    return file
  }

  /**
   * Generates a high-quality Bitmap/Image of the invoice.
   */
  fun generateInvoiceImage(
    context: Context,
    invoice: Invoice,
    items: List<InvoiceItem>,
    businessName: String = "الوكيل لتجارة المواد الغذائية",
    phone: String = "",
    isThermalFormat: Boolean = false
  ): File {
    val dir = File(context.cacheDir, "invoices").apply { mkdirs() }
    val file = File(dir, "INV_${invoice.invoiceNumber}.png")

    val width = if (isThermalFormat) 600 else 720
    val dynamicHeight = 500 + (items.size * 34) + 240
    val bitmap = Bitmap.createBitmap(width, dynamicHeight, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    val paint = Paint().apply { isAntiAlias = true }

    // Background
    paint.color = if (isThermalFormat) Color.rgb(255, 255, 250) else Color.WHITE
    canvas.drawRect(0f, 0f, width.toFloat(), dynamicHeight.toFloat(), paint)

    var y = 40f

    // Header
    paint.textAlign = Paint.Align.CENTER
    paint.color = if (isThermalFormat) Color.BLACK else Color.rgb(16, 120, 80)
    paint.textSize = 24f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText(businessName, (width / 2).toFloat(), y, paint)
    y += 28f

    paint.textSize = 14f
    paint.color = Color.rgb(71, 85, 105)
    paint.typeface = Typeface.DEFAULT
    val subtitle = if (invoice.type == InvoiceType.SALE) "فاتورة مبيعات رسمية" else "فاتورة توريد مشتريات"
    canvas.drawText(subtitle, (width / 2).toFloat(), y, paint)
    y += 22f

    if (phone.isNotBlank()) {
      canvas.drawText("هاتف: $phone", (width / 2).toFloat(), y, paint)
      y += 20f
    }

    // Divider
    paint.color = Color.rgb(203, 213, 225)
    canvas.drawLine(20f, y, (width - 20).toFloat(), y, paint)
    y += 24f

    // Invoice Info
    paint.textSize = 13f
    paint.textAlign = Paint.Align.RIGHT
    paint.color = Color.rgb(30, 41, 59)
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    val partyText = if (invoice.type == InvoiceType.SALE) "العميل: ${invoice.partyName}" else "المورد: ${invoice.partyName}"
    canvas.drawText(partyText, (width - 30).toFloat(), y, paint)

    paint.textAlign = Paint.Align.LEFT
    paint.typeface = Typeface.DEFAULT
    canvas.drawText("فاتورة: #${invoice.invoiceNumber}", 30f, y, paint)
    y += 22f

    val dateStr = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")).format(Date(invoice.timestamp))
    canvas.drawText("التاريخ: $dateStr", 30f, y, paint)
    y += 26f

    // Table Header
    paint.color = Color.rgb(241, 245, 249)
    canvas.drawRoundRect(20f, y - 18f, (width - 20).toFloat(), y + 14f, 6f, 6f, paint)

    paint.color = Color.rgb(15, 23, 42)
    paint.textSize = 13f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText("الصنف", (width - 35).toFloat(), y, paint)

    paint.textAlign = Paint.Align.CENTER
    canvas.drawText("الكمية", (width * 0.52).toFloat(), y, paint)
    canvas.drawText("السعر", (width * 0.32).toFloat(), y, paint)

    paint.textAlign = Paint.Align.LEFT
    canvas.drawText("الإجمالي", 35f, y, paint)
    y += 30f

    // Items
    paint.typeface = Typeface.DEFAULT
    items.forEach { itm ->
      paint.color = Color.rgb(30, 41, 59)
      paint.textSize = 12.5f

      paint.textAlign = Paint.Align.RIGHT
      val name = if (itm.productName.length > 22) itm.productName.take(20) + ".." else itm.productName
      canvas.drawText(name, (width - 35).toFloat(), y, paint)

      paint.textAlign = Paint.Align.CENTER
      canvas.drawText("${itm.quantity} ${itm.unitType}", (width * 0.52).toFloat(), y, paint)
      canvas.drawText(String.format(Locale.ENGLISH, "%.1f", itm.unitPrice), (width * 0.32).toFloat(), y, paint)

      paint.textAlign = Paint.Align.LEFT
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      canvas.drawText(String.format(Locale.ENGLISH, "%.2f", itm.totalPrice), 35f, y, paint)
      paint.typeface = Typeface.DEFAULT

      y += 28f
    }

    paint.color = Color.rgb(203, 213, 225)
    canvas.drawLine(20f, y, (width - 20).toFloat(), y, paint)
    y += 24f

    // Summary Lines
    fun drawImgSummary(label: String, value: String, isHighlight: Boolean = false, isAlert: Boolean = false) {
      paint.textAlign = Paint.Align.RIGHT
      paint.textSize = if (isHighlight) 14f else 13f
      paint.color = if (isAlert) Color.rgb(220, 38, 38) else if (isHighlight) Color.rgb(16, 120, 80) else Color.rgb(51, 65, 85)
      paint.typeface = if (isHighlight) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
      canvas.drawText(label, (width - 35).toFloat(), y, paint)

      paint.textAlign = Paint.Align.LEFT
      canvas.drawText(value, 35f, y, paint)
      y += 24f
    }

    drawImgSummary("الإجمالي قبل الخصم:", String.format(Locale.ENGLISH, "%.2f ج.م", invoice.subtotal))
    if (invoice.discount > 0) {
      drawImgSummary("الخصم:", String.format(Locale.ENGLISH, "- %.2f ج.م", invoice.discount), isAlert = true)
    }
    drawImgSummary("صافي الفاتورة:", String.format(Locale.ENGLISH, "%.2f ج.م", invoice.totalAmount), isHighlight = true)
    drawImgSummary("المدفوع كاش:", String.format(Locale.ENGLISH, "%.2f ج.م", invoice.paidAmount))
    if (invoice.remainingAmount > 0) {
      drawImgSummary("المتبقي من الفاتورة:", String.format(Locale.ENGLISH, "%.2f ج.م", invoice.remainingAmount), isAlert = true)
    }

    val prevLabel = if (invoice.type == InvoiceType.SALE) "الرصيد السابق للعميل:" else "الرصيد السابق للمورد:"
    drawImgSummary(prevLabel, String.format(Locale.ENGLISH, "%.2f ج.م", invoice.previousBalance))

    val grandDue = if (invoice.grandTotalDue > 0) invoice.grandTotalDue else (invoice.previousBalance + invoice.remainingAmount)
    val grandLabel = if (invoice.type == InvoiceType.SALE) "إجمالي الحساب المستحق الكلي:" else "إجمالي المستحق الكلي للمورد:"
    drawImgSummary(grandLabel, String.format(Locale.ENGLISH, "%.2f ج.م", grandDue), isHighlight = true, isAlert = invoice.type == InvoiceType.SALE)

    y += 10f
    paint.textAlign = Paint.Align.CENTER
    paint.textSize = 12f
    paint.color = Color.rgb(100, 116, 139)
    paint.typeface = Typeface.DEFAULT
    canvas.drawText("شكراً لتعاملكم معنا 🙏", (width / 2).toFloat(), y, paint)

    val fos = FileOutputStream(file)
    bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
    fos.close()

    return file
  }

  /**
   * Native Android system printing via PrintManager (Supports ANY connected printer, WiFi, USB, Cloud, or Save to PDF).
   */
  fun printInvoiceViaSystem(
    context: Context,
    invoice: Invoice,
    items: List<InvoiceItem>,
    businessName: String = "الوكيل لتجارة المواد الغذائية",
    phone: String = "",
    address: String = ""
  ) {
    try {
      val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
      if (printManager == null) {
        Toast.makeText(context, "خدمة الطباعة غير متوفرة على هذا الجهاز", Toast.LENGTH_SHORT).show()
        return
      }

      val pdfFile = generateInvoicePdf(context, invoice, items, businessName, phone, address)

      val adapter = object : PrintDocumentAdapter() {
        override fun onLayout(
          oldAttributes: PrintAttributes?,
          newAttributes: PrintAttributes?,
          cancellationSignal: CancellationSignal?,
          callback: LayoutResultCallback?,
          extras: Bundle?
        ) {
          if (cancellationSignal?.isCanceled == true) {
            callback?.onLayoutCancelled()
            return
          }
          val info = PrintDocumentInfo.Builder("فاتورة_${invoice.invoiceNumber}.pdf")
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(1)
            .build()
          callback?.onLayoutFinished(info, true)
        }

        override fun onWrite(
          pages: Array<out PageRange>?,
          destination: ParcelFileDescriptor?,
          cancellationSignal: CancellationSignal?,
          callback: WriteResultCallback?
        ) {
          try {
            val input = FileInputStream(pdfFile)
            val output = FileOutputStream(destination?.fileDescriptor)
            input.copyTo(output)
            callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            input.close()
            output.close()
          } catch (e: Exception) {
            callback?.onWriteFailed(e.message)
          }
        }
      }

      printManager.print("فاتورة_${invoice.invoiceNumber}", adapter, PrintAttributes.Builder().build())
    } catch (e: Exception) {
      Toast.makeText(context, "فشل بدء الطباعة: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
  }

  /**
   * Shares a file (PDF or Image) using FileProvider.
   */
  fun shareFile(
    context: Context,
    file: File,
    mimeType: String,
    title: String,
    specificPackage: String? = null
  ) {
    try {
      val uri: Uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        file
      )

      val intent = Intent(Intent.ACTION_SEND).apply {
        type = mimeType
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, title)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }

      if (specificPackage != null) {
        val testIntent = Intent(intent).apply { setPackage(specificPackage) }
        val resolveInfos = context.packageManager.queryIntentActivities(testIntent, 0)
        if (resolveInfos.isNotEmpty()) {
          context.startActivity(testIntent)
          return
        }
      }

      val chooser = Intent.createChooser(intent, title).apply {
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
      context.startActivity(chooser)
    } catch (e: Exception) {
      Toast.makeText(context, "تعذر مشاركة الملف: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
  }

  /**
   * Formats rich WhatsApp text message with items and grand total breakdown.
   */
  fun formatWhatsAppText(
    invoice: Invoice,
    items: List<InvoiceItem>,
    businessName: String = "الوكيل لتجارة المواد الغذائية"
  ): String {
    val dateStr = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")).format(Date(invoice.timestamp))
    val sb = StringBuilder()
    sb.appendLine("🧾 *${businessName}*")
    sb.appendLine(if (invoice.type == InvoiceType.SALE) "📦 *فاتورة مبيعات رسمية*" else "🚚 *فاتورة توريد مشتريات*")
    sb.appendLine("رقم الفاتورة: #${invoice.invoiceNumber}")
    sb.appendLine("التاريخ: $dateStr")
    sb.appendLine("الطرف: ${invoice.partyName}")
    sb.appendLine("══════════════════════")
    items.forEach { item ->
      sb.appendLine("▪️ ${item.productName}")
      sb.appendLine("   ${item.quantity} ${item.unitType} × ${String.format(Locale.ENGLISH, "%.2f", item.unitPrice)} ج.م = *${String.format(Locale.ENGLISH, "%.2f", item.totalPrice)} ج.م*")
    }
    sb.appendLine("══════════════════════")
    sb.appendLine("مجموع البضاعة: ${String.format(Locale.ENGLISH, "%.2f", invoice.subtotal)} ج.م")
    if (invoice.discount > 0) {
      sb.appendLine("الخصم: - ${String.format(Locale.ENGLISH, "%.2f", invoice.discount)} ج.م")
    }
    sb.appendLine("صافي الفاتورة: *${String.format(Locale.ENGLISH, "%.2f", invoice.totalAmount)} ج.م*")
    sb.appendLine("المدفوع نقداً: ${String.format(Locale.ENGLISH, "%.2f", invoice.paidAmount)} ج.م")
    if (invoice.remainingAmount > 0) {
      sb.appendLine("المتبقي من الفاتورة: *${String.format(Locale.ENGLISH, "%.2f", invoice.remainingAmount)} ج.م*")
    }
    val prevLabel = if (invoice.type == InvoiceType.SALE) "الرصيد السابق للعميل:" else "الرصيد السابق للمورد:"
    sb.appendLine("$prevLabel ${String.format(Locale.ENGLISH, "%.2f", invoice.previousBalance)} ج.م")

    val grandDue = if (invoice.grandTotalDue > 0) invoice.grandTotalDue else (invoice.previousBalance + invoice.remainingAmount)
    val grandLabel = if (invoice.type == InvoiceType.SALE) "🔔 *إجمالي الحساب المستحق الكلي:*" else "🔔 *إجمالي المستحق الكلي للمورد:*"
    sb.appendLine("$grandLabel *${String.format(Locale.ENGLISH, "%.2f", grandDue)} ج.م*")

    sb.appendLine("══════════════════════")
    sb.appendLine("نسعد دائماً بخدمتكم وتلبية طلباتكم 🙏")
    return sb.toString()
  }
}
