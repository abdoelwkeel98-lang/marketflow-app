package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Customer
import com.example.data.model.Expense
import com.example.data.model.Product
import com.example.data.model.Supplier
import com.example.ui.theme.EmeraldPrimary

/**
 * Universal Dialog for Adding or Editing Products.
 * Can be launched anywhere (Home, Sales, Purchases, Warehouse).
 */
@Composable
fun AddEditProductDialog(
  initialProduct: Product = Product(name = ""),
  showUnitTypeSelection: Boolean = false,
  onDismiss: () -> Unit,
  onSave: (Product) -> Unit
) {
  var name by remember { mutableStateOf(initialProduct.name) }
  var category by remember { mutableStateOf(initialProduct.category.ifBlank { "عام" }) }
  var barcode by remember { mutableStateOf(initialProduct.barcode) }
  var cartonName by remember { mutableStateOf(initialProduct.cartonName.ifBlank { "كرتونة" }) }
  var unitName by remember { mutableStateOf(initialProduct.unitName.ifBlank { "قطعة" }) }
  var piecesPerCarton by remember { mutableStateOf(initialProduct.piecesPerCarton.toString()) }
  var cartonCostPrice by remember { mutableStateOf(if (initialProduct.cartonCostPrice > 0) initialProduct.cartonCostPrice.toString() else "") }
  var cartonWholesalePrice by remember { mutableStateOf(if (initialProduct.cartonWholesalePrice > 0) initialProduct.cartonWholesalePrice.toString() else "") }
  var cartonSemiWholesalePrice by remember { mutableStateOf(if (initialProduct.cartonSemiWholesalePrice > 0) initialProduct.cartonSemiWholesalePrice.toString() else "") }
  var pieceRetailPrice by remember { mutableStateOf(if (initialProduct.pieceRetailPrice > 0) initialProduct.pieceRetailPrice.toString() else "") }
  var totalCartonsInStock by remember {
    val ppc = initialProduct.piecesPerCarton.coerceAtLeast(1)
    mutableStateOf(if (initialProduct.totalPiecesInStock > 0) (initialProduct.totalPiecesInStock / ppc).toString() else "0")
  }
  var minStockAlert by remember { mutableStateOf(initialProduct.minStockAlert.toString()) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  val focusManager = LocalFocusManager.current
  val keyboardController = LocalSoftwareKeyboardController.current
  val safeDismiss = {
    keyboardController?.hide()
    focusManager.clearFocus()
    onDismiss()
  }

  Dialog(
    onDismissRequest = safeDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
  ) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 8.dp,
      modifier = Modifier
        .fillMaxWidth(0.96f)
        .imePadding()
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .background(EmeraldPrimary.copy(alpha = 0.12f), shape = RoundedCornerShape(8.dp))
                .padding(8.dp)
            ) {
              Icon(Icons.Default.Inventory2, contentDescription = null, tint = EmeraldPrimary)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (initialProduct.id == 0L) "إضافة صنف جديد" else "تعديل بيانات الصنف",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
              )
              Text(
                text = "بيانات السلعة وأسعار الجملة والتجزئة",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          IconButton(onClick = safeDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إلغاء")
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

        LazyColumn(
          modifier = Modifier
            .weight(1f, fill = false)
            .fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          item {
            OutlinedTextField(
              value = name,
              onValueChange = { name = it; errorMessage = null },
              label = { Text("اسم الصنف أو السلعة *") },
              placeholder = { Text("مثال: زيت عافية 1 لتر / مكرونة حواء") },
              singleLine = true,
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(10.dp)
            )
          }

          item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(
                value = category,
                onValueChange = { category = it },
                label = { Text("القسم / التصنيف") },
                placeholder = { Text("زيوت، معلبات..") },
                singleLine = true,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
              )
              OutlinedTextField(
                value = barcode,
                onValueChange = { barcode = it },
                label = { Text("الباركود (اختياري)") },
                singleLine = true,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
              )
            }
          }

          if (showUnitTypeSelection) {
            item {
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                  value = cartonName,
                  onValueChange = { cartonName = it },
                  label = { Text("اسم الكرتونة/البالتة") },
                  singleLine = true,
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(10.dp)
                )
                OutlinedTextField(
                  value = unitName,
                  onValueChange = { unitName = it },
                  label = { Text("اسم القطعة/العلبة") },
                  singleLine = true,
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(10.dp)
                )
              }
            }
          }

          item {
            OutlinedTextField(
              value = piecesPerCarton,
              onValueChange = { piecesPerCarton = it },
              label = { Text("عدد القطع داخل الكرتونة *") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(10.dp)
            )
          }

          item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(
                value = cartonCostPrice,
                onValueChange = { cartonCostPrice = it },
                label = { Text("شراء الكرتونة (التكلفة)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
              )
              OutlinedTextField(
                value = cartonWholesalePrice,
                onValueChange = { cartonWholesalePrice = it },
                label = { Text("بيع جملة الكرتونة *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
              )
            }
          }

          item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(
                value = cartonSemiWholesalePrice,
                onValueChange = { cartonSemiWholesalePrice = it },
                label = { Text("بيع نصف جملة") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
              )
              OutlinedTextField(
                value = pieceRetailPrice,
                onValueChange = { pieceRetailPrice = it },
                label = { Text("بيع قطاعي للقطعة") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
              )
            }
          }

          if (initialProduct.id == 0L) {
            item {
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                  value = totalCartonsInStock,
                  onValueChange = { totalCartonsInStock = it },
                  label = { Text("رصيد افتتاحي (بالكرتونة)") },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  singleLine = true,
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(10.dp)
                )
                OutlinedTextField(
                  value = minStockAlert,
                  onValueChange = { minStockAlert = it },
                  label = { Text("حد أمان النواقص (قطع)") },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  singleLine = true,
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(10.dp)
                )
              }
            }
          }

          errorMessage?.let { msg ->
            item {
              Text(msg, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          OutlinedButton(
            onClick = safeDismiss,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("إلغاء")
          }

          Button(
            onClick = {
              if (name.isBlank()) {
                errorMessage = "يرجى إدخال اسم الصنف أولاً"
                return@Button
              }
              val ppc = piecesPerCarton.toIntOrNull()?.coerceAtLeast(1) ?: 12
              val cost = cartonCostPrice.toDoubleOrNull() ?: 0.0
              val wholesale = cartonWholesalePrice.toDoubleOrNull() ?: (cost * 1.08)
              val semiWholesale = cartonSemiWholesalePrice.toDoubleOrNull() ?: (wholesale * 1.03)
              val retail = pieceRetailPrice.toDoubleOrNull() ?: if (ppc > 0) (wholesale / ppc) * 1.15 else 0.0
              val initialCartons = totalCartonsInStock.toIntOrNull() ?: 0
              val totalPieces = if (initialProduct.id == 0L) initialCartons * ppc else initialProduct.totalPiecesInStock

              val updated = initialProduct.copy(
                name = name.trim(),
                category = category.trim().ifBlank { "عام" },
                barcode = barcode.trim(),
                cartonName = cartonName.trim().ifBlank { "كرتونة" },
                unitName = unitName.trim().ifBlank { "قطعة" },
                piecesPerCarton = ppc,
                cartonCostPrice = cost,
                cartonWholesalePrice = wholesale,
                cartonSemiWholesalePrice = semiWholesale,
                pieceRetailPrice = retail,
                totalPiecesInStock = totalPieces,
                minStockAlert = minStockAlert.toIntOrNull() ?: 12
              )
              keyboardController?.hide()
              focusManager.clearFocus()
              onSave(updated)
            },
            modifier = Modifier.weight(1.5f),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("حفظ الصنف", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

/**
 * Universal Dialog for Adding or Editing Customers.
 * Accessible from Home, Sales POS checkout, Accounts.
 */
@Composable
fun AddEditCustomerDialog(
  initial: Customer = Customer(name = ""),
  onDismiss: () -> Unit,
  onSave: (Customer) -> Unit
) {
  var name by remember { mutableStateOf(initial.name) }
  var phone by remember { mutableStateOf(initial.phone) }
  var address by remember { mutableStateOf(initial.address) }
  var creditLimit by remember { mutableStateOf(if (initial.creditLimit > 0) initial.creditLimit.toString() else "") }
  var initialBalance by remember { mutableStateOf(if (initial.id == 0L && initial.currentBalance > 0) initial.currentBalance.toString() else "") }
  var notes by remember { mutableStateOf(initial.notes) }
  var error by remember { mutableStateOf<String?>(null) }
  var isSubmitting by remember { mutableStateOf(false) }
  val focusManager = LocalFocusManager.current
  val keyboardController = LocalSoftwareKeyboardController.current
  val safeDismiss = {
    keyboardController?.hide()
    focusManager.clearFocus()
    onDismiss()
  }

  Dialog(
    onDismissRequest = safeDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
  ) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 8.dp,
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .imePadding()
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .background(EmeraldPrimary.copy(alpha = 0.12f), shape = RoundedCornerShape(8.dp))
                .padding(8.dp)
            ) {
              Icon(Icons.Default.Person, contentDescription = null, tint = EmeraldPrimary)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (initial.id == 0L) "إضافة عميل جديد" else "تعديل بيانات العميل",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
              )
              Text("تسجيل بيانات المحل أو العميل بالآجل", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
          IconButton(onClick = safeDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

        OutlinedTextField(
          value = name,
          onValueChange = { name = it; error = null },
          label = { Text("اسم العميل أو اسم المحل *") },
          placeholder = { Text("مثال: سوبرماركت البركة / الحاج محمود") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it },
          label = { Text("رقم الهاتف للتواصل") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = address,
            onValueChange = { address = it },
            label = { Text("العنوان / المنطقة") },
            singleLine = true,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          )
          OutlinedTextField(
            value = creditLimit,
            onValueChange = { creditLimit = it },
            label = { Text("حد الائتمان (ج.م)") },
            placeholder = { Text("10000") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          )
        }

        if (initial.id == 0L) {
          OutlinedTextField(
            value = initialBalance,
            onValueChange = { initialBalance = it },
            label = { Text("مديونية سابقة / رصيد افتتاحي عليه (ج.م)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
          )
        }

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("ملاحظات") },
          maxLines = 2,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        error?.let {
          Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          OutlinedButton(
            onClick = safeDismiss,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("إلغاء")
          }

          Button(
            onClick = {
              if (isSubmitting) return@Button
              if (name.isBlank()) {
                error = "يرجى كتابة اسم العميل"
                return@Button
              }
              isSubmitting = true
              val initBal = initialBalance.toDoubleOrNull() ?: 0.0
              val saved = initial.copy(
                name = name.trim(),
                phone = phone.trim(),
                address = address.trim(),
                creditLimit = creditLimit.toDoubleOrNull() ?: 0.0,
                currentBalance = if (initial.id == 0L) initBal else initial.currentBalance,
                notes = notes.trim()
              )
              keyboardController?.hide()
              focusManager.clearFocus()
              onSave(saved)
            },
            enabled = !isSubmitting,
            modifier = Modifier.weight(1.5f),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("حفظ العميل", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

/**
 * Universal Dialog for Adding or Editing Suppliers.
 * Accessible from Home, Purchases Screen, Accounts.
 */
@Composable
fun AddEditSupplierDialog(
  initial: Supplier = Supplier(name = ""),
  onDismiss: () -> Unit,
  onSave: (Supplier) -> Unit
) {
  var name by remember { mutableStateOf(initial.name) }
  var company by remember { mutableStateOf(initial.company) }
  var phone by remember { mutableStateOf(initial.phone) }
  var address by remember { mutableStateOf("") }
  var initialBalance by remember { mutableStateOf(if (initial.id == 0L && initial.currentBalance > 0) initial.currentBalance.toString() else "") }
  var notes by remember { mutableStateOf(initial.notes) }
  var error by remember { mutableStateOf<String?>(null) }
  var isSubmitting by remember { mutableStateOf(false) }
  val focusManager = LocalFocusManager.current
  val keyboardController = LocalSoftwareKeyboardController.current
  val safeDismiss = {
    keyboardController?.hide()
    focusManager.clearFocus()
    onDismiss()
  }

  Dialog(
    onDismissRequest = safeDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
  ) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 8.dp,
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .imePadding()
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .background(EmeraldPrimary.copy(alpha = 0.12f), shape = RoundedCornerShape(8.dp))
                .padding(8.dp)
            ) {
              Icon(Icons.Default.Business, contentDescription = null, tint = EmeraldPrimary)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (initial.id == 0L) "إضافة مورد / شركة جديد" else "تعديل بيانات المورد",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
              )
              Text("تسجيل شركة التوريد أو مندوب البضاعة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
          IconButton(onClick = safeDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

        OutlinedTextField(
          value = name,
          onValueChange = { name = it; error = null },
          label = { Text("اسم المورد أو المندوب *") },
          placeholder = { Text("مثال: شركة شيبسي / مندوب جهينة") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = company,
            onValueChange = { company = it },
            label = { Text("الشركة التابع لها") },
            singleLine = true,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          )
          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("رقم الهاتف") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          )
        }

        OutlinedTextField(
          value = address,
          onValueChange = { address = it },
          label = { Text("العنوان أو المقر") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        if (initial.id == 0L) {
          OutlinedTextField(
            value = initialBalance,
            onValueChange = { initialBalance = it },
            label = { Text("مستحق سابق له / رصيد افتتاحي (ج.م)") },
            placeholder = { Text("0.0") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
          )
        }

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("ملاحظات") },
          maxLines = 2,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        error?.let {
          Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          OutlinedButton(
            onClick = safeDismiss,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("إلغاء")
          }

          Button(
            onClick = {
              if (isSubmitting) return@Button
              if (name.isBlank()) {
                error = "يرجى كتابة اسم المورد"
                return@Button
              }
              isSubmitting = true
              val initBal = initialBalance.toDoubleOrNull() ?: 0.0
              val combinedNotes = listOfNotNull(
                notes.trim().ifBlank { null },
                if (address.isNotBlank()) "العنوان: ${address.trim()}" else null
              ).joinToString(" | ")

              val saved = initial.copy(
                name = name.trim(),
                company = company.trim(),
                phone = phone.trim(),
                currentBalance = if (initial.id == 0L) initBal else initial.currentBalance,
                notes = combinedNotes
              )
              keyboardController?.hide()
              focusManager.clearFocus()
              onSave(saved)
            },
            enabled = !isSubmitting,
            modifier = Modifier.weight(1.5f),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("حفظ المورد", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

/**
 * Quick Expense Dialog.
 */
@Composable
fun AddExpenseQuickDialog(
  onDismiss: () -> Unit,
  onSave: (Expense) -> Unit
) {
  var category by remember { mutableStateOf("نثريات وتشغيل") }
  var recipient by remember { mutableStateOf("") }
  var amountText by remember { mutableStateOf("") }
  var notes by remember { mutableStateOf("") }
  var error by remember { mutableStateOf<String?>(null) }
  val focusManager = LocalFocusManager.current
  val keyboardController = LocalSoftwareKeyboardController.current
  val safeDismiss = {
    keyboardController?.hide()
    focusManager.clearFocus()
    onDismiss()
  }

  Dialog(
    onDismissRequest = safeDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
  ) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 8.dp,
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .imePadding()
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .background(Color(0xFFE53935).copy(alpha = 0.12f), shape = RoundedCornerShape(8.dp))
                .padding(8.dp)
            ) {
              Icon(Icons.Default.Receipt, contentDescription = null, tint = Color(0xFFE53935))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text("تسجيل مصروف تشغيلي / نثريات", fontWeight = FontWeight.Bold, fontSize = 16.sp)
              Text("خصم مباشر من رصيد الخزينة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
          IconButton(onClick = safeDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إلغاء")
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

        OutlinedTextField(
          value = category,
          onValueChange = { category = it; error = null },
          label = { Text("بند المصروف *") },
          placeholder = { Text("مثال: إيجار المحل / كهرباء وتبريد / عمالة") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        OutlinedTextField(
          value = amountText,
          onValueChange = { amountText = it; error = null },
          label = { Text("المبلغ المدفوع (ج.م) *") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        OutlinedTextField(
          value = recipient,
          onValueChange = { recipient = it },
          label = { Text("المستلم / المدفوع له") },
          placeholder = { Text("مثال: شركة الكهرباء / العامل فلان") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("ملاحظات إضافية") },
          maxLines = 2,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        error?.let {
          Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          OutlinedButton(
            onClick = safeDismiss,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("إلغاء")
          }

          Button(
            onClick = {
              val amt = amountText.toDoubleOrNull()
              if (category.isBlank()) {
                error = "يرجى كتابة بند المصروف"
                return@Button
              }
              if (amt == null || amt <= 0) {
                error = "يرجى كتابة مبلغ صحيح"
                return@Button
              }
              val exp = Expense(
                category = category.trim(),
                amount = amt,
                recipient = recipient.trim(),
                notes = notes.trim(),
                timestamp = System.currentTimeMillis()
              )
              keyboardController?.hide()
              focusManager.clearFocus()
              onSave(exp)
            },
            modifier = Modifier.weight(1.5f),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935)),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("صرف وتسجيل", fontWeight = FontWeight.Bold, color = Color.White)
          }
        }
      }
    }
  }
}

/**
 * Universal Dialog for Quick Debt Collection (Customer) or Debt Settlement (Supplier).
 */
@Composable
fun DebtSettlementQuickDialog(
  customers: List<Customer>,
  suppliers: List<Supplier>,
  onRecordCustomerPayment: (Customer, Double, String) -> Unit,
  onRecordSupplierPayment: (Supplier, Double, String) -> Unit,
  onDismiss: () -> Unit
) {
  var isCustomerTab by remember { mutableStateOf(true) }
  var selectedCustomer by remember { mutableStateOf<Customer?>(customers.firstOrNull { it.currentBalance > 0 } ?: customers.firstOrNull()) }
  var selectedSupplier by remember { mutableStateOf<Supplier?>(suppliers.firstOrNull { it.currentBalance > 0 } ?: suppliers.firstOrNull()) }
  var amountText by remember { mutableStateOf("") }
  var notes by remember { mutableStateOf("") }
  var error by remember { mutableStateOf<String?>(null) }
  var showPartyDropdown by remember { mutableStateOf(false) }
  val focusManager = LocalFocusManager.current
  val keyboardController = LocalSoftwareKeyboardController.current
  val safeDismiss = {
    keyboardController?.hide()
    focusManager.clearFocus()
    onDismiss()
  }

  Dialog(
    onDismissRequest = safeDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
  ) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth(0.96f)
        .imePadding()
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (isCustomerTab) "سند قبض تحصيل دين من عميل" else "سند صرف سداد دين لمورد",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = if (isCustomerTab) EmeraldPrimary else Color(0xFFEA580C)
          )
          IconButton(onClick = safeDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إلغاء")
          }
        }

        // Tab switcher
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
            .padding(4.dp)
        ) {
          Button(
            onClick = { isCustomerTab = true; error = null },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (isCustomerTab) EmeraldPrimary else Color.Transparent,
              contentColor = if (isCustomerTab) Color.White else MaterialTheme.colorScheme.onSurface
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1f)
          ) {
            Text("تحصيل من عميل (وارد)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = { isCustomerTab = false; error = null },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (!isCustomerTab) Color(0xFFEA580C) else Color.Transparent,
              contentColor = if (!isCustomerTab) Color.White else MaterialTheme.colorScheme.onSurface
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1f)
          ) {
            Text("سداد لمورد (منصرف)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }

        // Party Selector
        Box(modifier = Modifier.fillMaxWidth()) {
          OutlinedButton(
            onClick = { showPartyDropdown = true },
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              val name = if (isCustomerTab) selectedCustomer?.name ?: "اختر العميل" else selectedSupplier?.name ?: "اختر المورد"
              val balance = if (isCustomerTab) selectedCustomer?.currentBalance ?: 0.0 else selectedSupplier?.currentBalance ?: 0.0
              Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
              Text("الرصيد: %.1f ج.م".format(balance), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            }
          }

          androidx.compose.material3.DropdownMenu(
            expanded = showPartyDropdown,
            onDismissRequest = { showPartyDropdown = false }
          ) {
            if (isCustomerTab) {
              customers.forEach { c ->
                androidx.compose.material3.DropdownMenuItem(
                  text = {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                      Text(c.name, fontWeight = FontWeight.Bold)
                      Spacer(modifier = Modifier.width(16.dp))
                      Text("عليه: %.1f ج.م".format(c.currentBalance), color = if (c.currentBalance > 0) Color.Red else EmeraldPrimary)
                    }
                  },
                  onClick = {
                    selectedCustomer = c
                    showPartyDropdown = false
                  }
                )
              }
            } else {
              suppliers.forEach { s ->
                androidx.compose.material3.DropdownMenuItem(
                  text = {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                      Text(s.name, fontWeight = FontWeight.Bold)
                      Spacer(modifier = Modifier.width(16.dp))
                      Text("له: %.1f ج.م".format(s.currentBalance), color = if (s.currentBalance > 0) Color.Red else EmeraldPrimary)
                    }
                  },
                  onClick = {
                    selectedSupplier = s
                    showPartyDropdown = false
                  }
                )
              }
            }
          }
        }

        OutlinedTextField(
          value = amountText,
          onValueChange = { amountText = it; error = null },
          label = { Text("المبلغ المدفوع (ج.م) *") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("ملاحظات / رقم الإيصال / وسيلة الدفع") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        error?.let {
          Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val amt = amountText.toDoubleOrNull()
              if (amt == null || amt <= 0) {
                error = "يرجى إدخال مبلغ صحيح أكبر من الصفر"
                return@Button
              }
              if (isCustomerTab) {
                val cust = selectedCustomer
                if (cust == null) {
                  error = "يرجى اختيار العميل"
                  return@Button
                }
                onRecordCustomerPayment(cust, amt, notes)
              } else {
                val sup = selectedSupplier
                if (sup == null) {
                  error = "يرجى اختيار المورد"
                  return@Button
                }
                onRecordSupplierPayment(sup, amt, notes)
              }
              safeDismiss()
            },
            colors = ButtonDefaults.buttonColors(containerColor = if (isCustomerTab) EmeraldPrimary else Color(0xFFEA580C)),
            modifier = Modifier.weight(1f)
          ) {
            Text(if (isCustomerTab) "تأكيد القبض وإيداع بالخزينة" else "تأكيد الصرف وخصم من الخزينة", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = safeDismiss, modifier = Modifier.weight(0.5f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

