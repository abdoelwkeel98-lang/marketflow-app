package com.example.utils

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.ui.ExpenseCategoryStat
import com.example.ui.ProfitReportData
import com.example.ui.ReportPeriod
import com.example.ui.TopProductStat
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * محرك تصدير وطباعة التقارير المالية والإدارية الشاملة:
 * - إنشاء ملفات PDF رسمية عالية الدقة والوضوح قابلة للمشاركة والحفظ
 * - إنشاء صور PNG عالية الدقة لعرض ومشاركة التقرير عبر واتساب ومنصات التواصل
 * - الطباعة المباشرة عبر PrintManager لنظام أندرويد (طابعات A4 وطابعات الإيصالات)
 */
object ReportExportHelper {

  /**
   * توليد ملف PDF رسمي للتقرير المالي وقائمة الأرباح والدخل
   */
  fun generateFinancialReportPdf(
    context: Context,
    report: ProfitReportData,
    period: ReportPeriod,
    businessName: String = "الوكيل لتجارة المواد الغذائية",
    phone: String = "",
    address: String = "",
    topProducts: List<TopProductStat> = emptyList(),
    expensesByCategory: List<ExpenseCategoryStat> = emptyList(),
    customTitle: String? = null
  ): File {
    val dir = File(context.cacheDir, "reports").apply { mkdirs() }
    val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(Date())
    val file = File(dir, "REPORT_${timeStamp}.pdf")

    val pdfDocument = PdfDocument()
    val pageWidth = 595 // A4 standard width
    val pageHeight = 842 // A4 standard height
    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas

    val paint = Paint().apply { isAntiAlias = true }

    // 1. ترويسة التقرير العلوية (Header Banner)
    paint.color = Color.rgb(5, 150, 105) // Emerald Deep
    canvas.drawRect(0f, 0f, pageWidth.toFloat(), 80f, paint)

    paint.color = Color.WHITE
    paint.textSize = 18f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText(businessName, (pageWidth - 25).toFloat(), 34f, paint)

    paint.textSize = 11f
    paint.typeface = Typeface.DEFAULT
    val mainTitle = customTitle ?: "التقرير المالي وقائمة الأرباح والدخل (P&L)"
    canvas.drawText(mainTitle, (pageWidth - 25).toFloat(), 54f, paint)
    if (phone.isNotBlank() || address.isNotBlank()) {
      canvas.drawText("$phone  $address", (pageWidth - 25).toFloat(), 70f, paint)
    }

    // التاريخ والوقت والفترة
    paint.textAlign = Paint.Align.LEFT
    paint.textSize = 10.5f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    val dateStr = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.ENGLISH).format(Date())
    canvas.drawText("الفترة: ${period.label}", 25f, 34f, paint)
    paint.typeface = Typeface.DEFAULT
    canvas.drawText("تاريخ الإصدار: $dateStr", 25f, 54f, paint)
    canvas.drawText("العملة: جنيه مصري (ج.م)", 25f, 70f, paint)

    var y = 102f

    // 2. بطاقات المؤشرات الرئيسية السريعة (KPIs Cards)
    val cardW = (pageWidth - 50 - 30) / 4f
    val cardH = 50f

    drawKpiCard(canvas, paint, 25f, y, cardW, cardH, "إجمالي المبيعات", String.format(Locale.ENGLISH, "%.2f", report.totalSales), Color.rgb(37, 99, 235))
    drawKpiCard(canvas, paint, 25f + cardW + 10, y, cardW, cardH, "تكلفة المبيعات", String.format(Locale.ENGLISH, "%.2f", report.totalSalesCost), Color.rgb(100, 116, 139))
    drawKpiCard(canvas, paint, 25f + (cardW + 10) * 2, y, cardW, cardH, "مجمل الربح", String.format(Locale.ENGLISH, "%.2f", report.grossProfit), Color.rgb(5, 150, 105))
    drawKpiCard(canvas, paint, 25f + (cardW + 10) * 3, y, cardW, cardH, "صافي الأرباح", String.format(Locale.ENGLISH, "%.2f", report.netProfit), if (report.netProfit >= 0) Color.rgb(16, 185, 129) else Color.rgb(220, 38, 38))

    y += cardH + 18f

    // 3. جدول قائمة الدخل المفصلة (Income Statement Detailed Table)
    drawSectionHeader(canvas, paint, y, "أولاً: قائمة الدخل والأرباح التشغيلية (Income Statement)")
    y += 24f

    val startX = 25f
    val endX = pageWidth - 25f
    val tableW = endX - startX

    drawTableRow(canvas, paint, startX, endX, y, "1. إجمالي إيرادات المبيعات المحققة", String.format(Locale.ENGLISH, "%.2f ج.م", report.totalSales + report.totalDiscount), isHeader = true, isPositive = true)
    y += 20f

    if (report.totalDiscount > 0) {
      drawTableRow(canvas, paint, startX, endX, y, "   (-) خصومات مسموح بها للعملاء", String.format(Locale.ENGLISH, "-%.2f ج.م", report.totalDiscount), isNegative = true)
      y += 20f
    }

    drawTableRow(canvas, paint, startX, endX, y, "   (=) صافي إيرادات المبيعات الفعلية", String.format(Locale.ENGLISH, "%.2f ج.م", report.totalSales), isBold = true)
    y += 20f

    drawTableRow(canvas, paint, startX, endX, y, "2. (-) تكلفة البضاعة المباعة حسب WAC (COGS)", String.format(Locale.ENGLISH, "-%.2f ج.م", report.totalSalesCost), isNegative = true)
    y += 20f

    drawTableRow(canvas, paint, startX, endX, y, "3. (=) مجمل أرباح النشاط التجاري (Gross Profit)", String.format(Locale.ENGLISH, "%.2f ج.م", report.grossProfit), isHeader = true, isPositive = true)
    y += 20f

    drawTableRow(canvas, paint, startX, endX, y, "4. (-) إجمالي المصروفات التشغيلية والنثرية", String.format(Locale.ENGLISH, "-%.2f ج.م", report.totalExpenses), isNegative = true)
    y += 20f

    expensesByCategory.take(4).forEach { cat ->
      drawTableRow(canvas, paint, startX, endX, y, "     • ${cat.category}", String.format(Locale.ENGLISH, "-%.2f ج.م", cat.totalAmount), isSubItem = true)
      y += 18f
    }

    if (report.totalAuditDiscrepancy != 0.0) {
      val isDiscNeg = report.totalAuditDiscrepancy < 0
      val discLabel = if (isDiscNeg) "5. (-) تسويات عجز الجرد المخزني" else "5. (+) تسويات فائض الجرد المخزني"
      drawTableRow(canvas, paint, startX, endX, y, discLabel, String.format(Locale.ENGLISH, "%+.2f ج.م", report.totalAuditDiscrepancy), isNegative = isDiscNeg, isPositive = !isDiscNeg)
      y += 20f
    }

    // خط فاصل عريض قبل الصافي
    paint.color = Color.rgb(5, 150, 105)
    paint.strokeWidth = 2f
    canvas.drawLine(startX, y, endX, y, paint)
    paint.strokeWidth = 1f
    y += 14f

    drawTableRow(
      canvas, paint, startX, endX, y,
      "★ صافي الأرباح النهائية الصافية (Net Profit):",
      String.format(Locale.ENGLISH, "%.2f ج.م (هامش %.1f%%)", report.netProfit, report.profitMarginPercent),
      isTotal = true,
      isPositive = report.netProfit >= 0
    )
    y += 28f

    // 4. قسم السيولة والخزينة والمخزون
    drawSectionHeader(canvas, paint, y, "ثانياً: حركة السيولة النقدية والموقف المالي للمخزن والديون")
    y += 24f

    drawTableRow(canvas, paint, startX, endX, y, "• رصيد الخزينة والصندوق الحالي:", String.format(Locale.ENGLISH, "%.2f ج.م", report.cashDrawerBalance), isBold = true)
    y += 20f
    drawTableRow(canvas, paint, startX, endX, y, "• إجمالي المقبوضات النقدية والتحصيلات:", String.format(Locale.ENGLISH, "%.2f ج.م", report.cashInSales + report.cashInCustomerPayments), isPositive = true)
    y += 20f
    drawTableRow(canvas, paint, startX, endX, y, "• إجمالي المدفوعات النقدية ومصروفات التشغيل:", String.format(Locale.ENGLISH, "%.2f ج.م", report.cashOutPurchases + report.cashOutSupplierPayments + report.totalExpenses), isNegative = true)
    y += 20f
    drawTableRow(canvas, paint, startX, endX, y, "• قيمة بضاعة المخزن بالتكلفة المرجحة (WAC):", String.format(Locale.ENGLISH, "%.2f ج.م", report.totalInventoryCostValue), isBold = true)
    y += 20f
    drawTableRow(canvas, paint, startX, endX, y, "• إجمالي مديونيات لنا عند العملاء:", String.format(Locale.ENGLISH, "%.2f ج.م", report.totalCustomerDebts), isPositive = true)
    y += 20f
    drawTableRow(canvas, paint, startX, endX, y, "• إجمالي ديون علينا للموردين والتجار:", String.format(Locale.ENGLISH, "%.2f ج.م", report.totalSupplierDebts), isNegative = true)
    y += 28f

    // 5. الأصناف الأكثر مساهمة وربحية
    if (topProducts.isNotEmpty()) {
      drawSectionHeader(canvas, paint, y, "ثالثاً: الأصناف الرائدة الأكثر مبيعاً وربحية")
      y += 22f

      topProducts.take(4).forEachIndexed { idx, prod ->
        drawTableRow(
          canvas, paint, startX, endX, y,
          "${idx + 1}. ${prod.productName}",
          String.format(Locale.ENGLISH, "إيراد: %.1f ج.م | ربح: %.1f ج.م", prod.totalRevenue, prod.totalProfit),
          isSubItem = true
        )
        y += 18f
      }
      y += 10f
    }

    // تذييل الصفحة
    paint.color = Color.rgb(148, 163, 184)
    paint.textSize = 9f
    paint.textAlign = Paint.Align.CENTER
    paint.typeface = Typeface.DEFAULT
    canvas.drawText("تم استخراج التقرير آلياً بواسطة نظام إدارة ومحاسبة المخازن والوكيل لتجارة المواد الغذائية ✓", (pageWidth / 2).toFloat(), (pageHeight - 20).toFloat(), paint)

    pdfDocument.finishPage(page)

    val fos = FileOutputStream(file)
    pdfDocument.writeTo(fos)
    pdfDocument.close()
    fos.close()

    return file
  }

  /**
   * توليد صورة عالية الدقة PNG للتقرير لمشاركتها عبر وسائل التواصل وواتساب
   */
  fun generateFinancialReportImage(
    context: Context,
    report: ProfitReportData,
    period: ReportPeriod,
    businessName: String = "الوكيل لتجارة المواد الغذائية",
    topProducts: List<TopProductStat> = emptyList(),
    customTitle: String? = null
  ): File {
    val dir = File(context.cacheDir, "reports").apply { mkdirs() }
    val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(Date())
    val file = File(dir, "REPORT_${timeStamp}.png")

    val width = 900
    val height = 1350
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    // خلفية الصفحة
    canvas.drawColor(Color.WHITE)

    val paint = Paint().apply { isAntiAlias = true }

    // الترويسة
    paint.color = Color.rgb(5, 150, 105)
    canvas.drawRect(0f, 0f, width.toFloat(), 130f, paint)

    paint.color = Color.WHITE
    paint.textSize = 28f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText(businessName, (width - 40).toFloat(), 55f, paint)

    paint.textSize = 16f
    paint.typeface = Typeface.DEFAULT
    val title = customTitle ?: "التقرير المالي وقائمة الأرباح والدخل (P&L)"
    canvas.drawText(title, (width - 40).toFloat(), 88f, paint)
    canvas.drawText("الفترة: ${period.label}", (width - 40).toFloat(), 114f, paint)

    paint.textAlign = Paint.Align.LEFT
    paint.textSize = 15f
    val dateStr = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.ENGLISH).format(Date())
    canvas.drawText("تاريخ التقرير: $dateStr", 40f, 55f, paint)
    canvas.drawText("العملة: جنيه مصري (ج.م)", 40f, 88f, paint)

    var y = 165f

    // مربعات إحصائية ملونة
    val boxW = (width - 80 - 30) / 4f
    val boxH = 95f
    drawKpiBoxImg(canvas, paint, 40f, y, boxW, boxH, "المبيعات", String.format(Locale.ENGLISH, "%.2f", report.totalSales), Color.rgb(37, 99, 235))
    drawKpiBoxImg(canvas, paint, 40f + boxW + 10, y, boxW, boxH, "تكلفة WAC", String.format(Locale.ENGLISH, "%.2f", report.totalSalesCost), Color.rgb(100, 116, 139))
    drawKpiBoxImg(canvas, paint, 40f + (boxW + 10) * 2, y, boxW, boxH, "مجمل الربح", String.format(Locale.ENGLISH, "%.2f", report.grossProfit), Color.rgb(5, 150, 105))
    drawKpiBoxImg(canvas, paint, 40f + (boxW + 10) * 3, y, boxW, boxH, "صافي الأرباح", String.format(Locale.ENGLISH, "%.2f", report.netProfit), if (report.netProfit >= 0) Color.rgb(16, 185, 129) else Color.rgb(220, 38, 38))

    y += boxH + 35f

    // بطاقة جدول الأرباح والدخل
    val cardPaint = Paint().apply {
      color = Color.rgb(248, 250, 252)
      style = Paint.Style.FILL
    }
    canvas.drawRoundRect(40f, y, (width - 40).toFloat(), y + 360f, 16f, 16f, cardPaint)

    paint.color = Color.rgb(15, 23, 42)
    paint.textSize = 20f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText("📊 تفاصيل قائمة الأرباح والدخل", (width - 65).toFloat(), y + 38f, paint)

    var lineY = y + 75f
    val leftX = 65f
    val rightX = (width - 65).toFloat()

    drawImgRow(canvas, paint, leftX, rightX, lineY, "إجمالي مبيعات الفترة:", String.format(Locale.ENGLISH, "%.2f ج.م", report.totalSales))
    lineY += 40f
    drawImgRow(canvas, paint, leftX, rightX, lineY, "تكلفة البضاعة المباعة (WAC):", String.format(Locale.ENGLISH, "-%.2f ج.م", report.totalSalesCost), isNegative = true)
    lineY += 40f
    drawImgRow(canvas, paint, leftX, rightX, lineY, "مجمل أرباح المبيعات:", String.format(Locale.ENGLISH, "%.2f ج.م", report.grossProfit), isPositive = true, isBold = true)
    lineY += 40f
    drawImgRow(canvas, paint, leftX, rightX, lineY, "المصروفات التشغيلية والنثرية:", String.format(Locale.ENGLISH, "-%.2f ج.م", report.totalExpenses), isNegative = true)
    lineY += 40f
    if (report.totalAuditDiscrepancy != 0.0) {
      drawImgRow(canvas, paint, leftX, rightX, lineY, "تسويات عجز/زيادة الجرد المخزني:", String.format(Locale.ENGLISH, "%+.2f ج.م", report.totalAuditDiscrepancy))
      lineY += 40f
    }

    paint.color = Color.rgb(203, 213, 225)
    canvas.drawLine(leftX, lineY - 10, rightX, lineY - 10, paint)

    drawImgRow(canvas, paint, leftX, rightX, lineY + 15, "صافي الأرباح المحققة (Net Profit):", String.format(Locale.ENGLISH, "%.2f ج.م (هامش %.1f%%)", report.netProfit, report.profitMarginPercent), isBold = true, isPositive = report.netProfit >= 0, isLarge = true)

    y += 400f

    // بطاقة السيولة والمخزن
    canvas.drawRoundRect(40f, y, (width - 40).toFloat(), y + 300f, 16f, 16f, cardPaint)
    paint.color = Color.rgb(15, 23, 42)
    paint.textSize = 20f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("💵 الخزينة والمخزن والموقف المالي", (width - 65).toFloat(), y + 38f, paint)

    lineY = y + 75f
    drawImgRow(canvas, paint, leftX, rightX, lineY, "رصيد الخزينة والدرج الحالي:", String.format(Locale.ENGLISH, "%.2f ج.م", report.cashDrawerBalance), isBold = true)
    lineY += 40f
    drawImgRow(canvas, paint, leftX, rightX, lineY, "المقبوضات النقدية الإجمالية:", String.format(Locale.ENGLISH, "%.2f ج.م", report.cashInSales + report.cashInCustomerPayments), isPositive = true)
    lineY += 40f
    drawImgRow(canvas, paint, leftX, rightX, lineY, "المدفوعات والمصاريف الإجمالية:", String.format(Locale.ENGLISH, "%.2f ج.م", report.cashOutPurchases + report.cashOutSupplierPayments + report.totalExpenses), isNegative = true)
    lineY += 40f
    drawImgRow(canvas, paint, leftX, rightX, lineY, "بضاعة المخزن بالتكلفة المرجحة (WAC):", String.format(Locale.ENGLISH, "%.2f ج.م", report.totalInventoryCostValue), isBold = true)
    lineY += 40f
    drawImgRow(canvas, paint, leftX, rightX, lineY, "ديون لنا عند العملاء:", String.format(Locale.ENGLISH, "%.2f ج.م", report.totalCustomerDebts))
    lineY += 40f
    drawImgRow(canvas, paint, leftX, rightX, lineY, "ديون علينا للموردين:", String.format(Locale.ENGLISH, "%.2f ج.م", report.totalSupplierDebts))

    // التذييل
    paint.color = Color.rgb(148, 163, 184)
    paint.textSize = 14f
    paint.textAlign = Paint.Align.CENTER
    canvas.drawText("نظام إدارة ومحاسبة المخازن والمبيعات بالجملة ✓", (width / 2).toFloat(), (height - 30).toFloat(), paint)

    val fos = FileOutputStream(file)
    bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
    fos.close()

    return file
  }

  /**
   * تشغيل الطباعة المباشرة عبر PrintManager لنظام أندرويد
   */
  fun printReportViaSystem(
    context: Context,
    report: ProfitReportData,
    period: ReportPeriod,
    businessName: String = "الوكيل لتجارة المواد الغذائية",
    phone: String = "",
    address: String = "",
    topProducts: List<TopProductStat> = emptyList(),
    expensesByCategory: List<ExpenseCategoryStat> = emptyList(),
    customTitle: String? = null
  ) {
    try {
      val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
      if (printManager == null) {
        Toast.makeText(context, "خدمة الطباعة غير متوفرة على هذا الجهاز", Toast.LENGTH_SHORT).show()
        return
      }

      val pdfFile = generateFinancialReportPdf(
        context = context,
        report = report,
        period = period,
        businessName = businessName,
        phone = phone,
        address = address,
        topProducts = topProducts,
        expensesByCategory = expensesByCategory,
        customTitle = customTitle
      )

      val docTitle = customTitle ?: "تقرير_الأرباح_والدخل_${period.name}"

      val adapter = object : PrintDocumentAdapter() {
        override fun onLayout(
          oldAttributes: PrintAttributes?,
          newAttributes: PrintAttributes?,
          cancellationSignal: CancellationSignal?,
          callback: LayoutResultCallback?,
          extras: Bundle?
        ) {
          if (cancellationSignal?.isCanceled == true) {
            callback?.onLayoutCancelled()
            return
          }
          val info = PrintDocumentInfo.Builder("$docTitle.pdf")
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(1)
            .build()
          callback?.onLayoutFinished(info, true)
        }

        override fun onWrite(
          pages: Array<out PageRange>?,
          destination: ParcelFileDescriptor?,
          cancellationSignal: CancellationSignal?,
          callback: WriteResultCallback?
        ) {
          try {
            val input = FileInputStream(pdfFile)
            val output = FileOutputStream(destination?.fileDescriptor)
            input.copyTo(output)
            callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            input.close()
            output.close()
          } catch (e: Exception) {
            callback?.onWriteFailed(e.message)
          }
        }
      }

      printManager.print(docTitle, adapter, PrintAttributes.Builder().build())
    } catch (e: Exception) {
      Toast.makeText(context, "فشل بدء الطباعة: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
  }

  /**
   * مشاركة أي ملف (PDF أو صورة) عبر FileProvider
   */
  fun shareFile(
    context: Context,
    file: File,
    mimeType: String,
    title: String
  ) {
    try {
      val uri: Uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        file
      )

      val intent = Intent(Intent.ACTION_SEND).apply {
        type = mimeType
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, title)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }

      val chooser = Intent.createChooser(intent, title).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(chooser)
    } catch (e: Exception) {
      Toast.makeText(context, "تعذر مشاركة الملف: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
  }

  // --- Helper drawing functions ---

  private fun drawKpiCard(
    canvas: Canvas,
    paint: Paint,
    x: Float,
    y: Float,
    w: Float,
    h: Float,
    title: String,
    value: String,
    accentColor: Int
  ) {
    paint.color = Color.rgb(248, 250, 252)
    paint.style = Paint.Style.FILL
    canvas.drawRoundRect(x, y, x + w, y + h, 6f, 6f, paint)

    paint.color = accentColor
    paint.strokeWidth = 2f
    paint.style = Paint.Style.STROKE
    canvas.drawRoundRect(x, y, x + w, y + h, 6f, 6f, paint)
    paint.style = Paint.Style.FILL

    paint.color = Color.rgb(71, 85, 105)
    paint.textSize = 8.5f
    paint.textAlign = Paint.Align.CENTER
    paint.typeface = Typeface.DEFAULT
    canvas.drawText(title, x + w / 2f, y + 16f, paint)

    paint.color = accentColor
    paint.textSize = 12f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText(value, x + w / 2f, y + 36f, paint)
  }

  private fun drawKpiBoxImg(
    canvas: Canvas,
    paint: Paint,
    x: Float,
    y: Float,
    w: Float,
    h: Float,
    title: String,
    value: String,
    accentColor: Int
  ) {
    paint.color = Color.rgb(248, 250, 252)
    paint.style = Paint.Style.FILL
    canvas.drawRoundRect(x, y, x + w, y + h, 10f, 10f, paint)

    paint.color = accentColor
    paint.strokeWidth = 3f
    paint.style = Paint.Style.STROKE
    canvas.drawRoundRect(x, y, x + w, y + h, 10f, 10f, paint)
    paint.style = Paint.Style.FILL

    paint.color = Color.rgb(71, 85, 105)
    paint.textSize = 14f
    paint.textAlign = Paint.Align.CENTER
    paint.typeface = Typeface.DEFAULT
    canvas.drawText(title, x + w / 2f, y + 32f, paint)

    paint.color = accentColor
    paint.textSize = 18f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText(value, x + w / 2f, y + 68f, paint)
  }

  private fun drawSectionHeader(canvas: Canvas, paint: Paint, y: Float, title: String) {
    paint.color = Color.rgb(15, 23, 42)
    paint.textSize = 11.5f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText(title, 570f, y, paint)

    paint.color = Color.rgb(226, 232, 240)
    paint.strokeWidth = 1f
    canvas.drawLine(25f, y + 6f, 570f, y + 6f, paint)
  }

  private fun drawTableRow(
    canvas: Canvas,
    paint: Paint,
    startX: Float,
    endX: Float,
    y: Float,
    label: String,
    value: String,
    isHeader: Boolean = false,
    isBold: Boolean = false,
    isTotal: Boolean = false,
    isSubItem: Boolean = false,
    isPositive: Boolean = false,
    isNegative: Boolean = false
  ) {
    if (isTotal) {
      paint.color = if (isPositive) Color.rgb(5, 150, 105) else Color.rgb(220, 38, 38)
      paint.textSize = 12f
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    } else if (isHeader || isBold) {
      paint.color = Color.rgb(15, 23, 42)
      paint.textSize = 10f
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    } else if (isSubItem) {
      paint.color = Color.rgb(100, 116, 139)
      paint.textSize = 9f
      paint.typeface = Typeface.DEFAULT
    } else {
      paint.color = Color.rgb(51, 65, 85)
      paint.textSize = 9.5f
      paint.typeface = Typeface.DEFAULT
    }

    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText(label, endX, y, paint)

    if (isNegative) {
      paint.color = Color.rgb(220, 38, 38)
    } else if (isPositive) {
      paint.color = Color.rgb(5, 150, 105)
    }
    paint.textAlign = Paint.Align.LEFT
    canvas.drawText(value, startX, y, paint)
  }

  private fun drawImgRow(
    canvas: Canvas,
    paint: Paint,
    leftX: Float,
    rightX: Float,
    y: Float,
    label: String,
    value: String,
    isBold: Boolean = false,
    isPositive: Boolean = false,
    isNegative: Boolean = false,
    isLarge: Boolean = false
  ) {
    paint.color = if (isLarge && isPositive) Color.rgb(5, 150, 105) else Color.rgb(15, 23, 42)
    paint.textSize = if (isLarge) 18f else 15f
    paint.typeface = if (isBold || isLarge) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText(label, rightX, y, paint)

    if (isNegative) {
      paint.color = Color.rgb(220, 38, 38)
    } else if (isPositive) {
      paint.color = Color.rgb(5, 150, 105)
    }
    paint.textAlign = Paint.Align.LEFT
    canvas.drawText(value, leftX, y, paint)
  }
}
