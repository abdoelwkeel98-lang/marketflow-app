package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import com.example.data.model.PaymentTransaction
import com.example.ui.WholesaleViewModel
import com.example.ui.components.AddExpenseQuickDialog
import com.example.ui.components.BackupRestoreDialog
import com.example.ui.components.DebtSettlementQuickDialog
import com.example.ui.components.InvoiceReceiptDialog
import com.example.ui.components.QuickSanadVoucherDialog
import com.example.ui.components.VoiceToTransactionDialog
import com.example.ui.components.VoucherReceiptDialog
import com.example.ui.components.EmployeeGateLockScreen
import android.widget.Toast
import com.example.ui.screens.AccountsScreen
import com.example.ui.screens.AuthOnboardingScreen
import com.example.ui.screens.CashflowScreen
import com.example.ui.screens.HomeScreen
import java.util.Locale
import com.example.ui.screens.PurchasesScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SalesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.WarehouseScreen
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NavyPrimaryDark
import com.example.ui.theme.OrangePrimary

enum class WholesaleTab(val title: String, val icon: ImageVector) {
  HOME("الرئيسية", Icons.Default.Dashboard),
  SALES("المبيعات", Icons.Default.PointOfSale),
  PURCHASES("المشتريات", Icons.Default.LocalShipping),
  WAREHOUSE("المخزن", Icons.Default.Inventory2),
  ACCOUNTS("الحسابات", Icons.Default.People),
  CASHFLOW("الخزينة", Icons.Default.AccountBalanceWallet),
  REPORTS("التقارير", Icons.Default.Analytics),
  SETTINGS("الإعدادات", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

  private val viewModel: WholesaleViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val profile by viewModel.businessProfile.collectAsStateWithLifecycle()
      val isLocked by viewModel.isScreenLocked.collectAsStateWithLifecycle()

      MyApplicationTheme(darkTheme = profile.isDarkMode) {
        // Enforce RTL Layout Direction for Arabic Supermarket Accounting UI
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
          if (isLocked) {
            EmployeeGateLockScreen(
              viewModel = viewModel,
              onUnlockSuccess = {
                viewModel.setScreenLocked(false)
              }
            )
          } else {
            MainWholesaleApp(viewModel = viewModel)
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainWholesaleApp(viewModel: WholesaleViewModel) {
  var currentTab by remember { mutableIntStateOf(0) }
  val tabs = WholesaleTab.values()

  val businessProfile by viewModel.businessProfile.collectAsStateWithLifecycle()
  val lowStockList by viewModel.lowStockProducts.collectAsStateWithLifecycle()
  val salesCart by viewModel.salesCart.collectAsStateWithLifecycle()
  val lastCompletedInvoice by viewModel.lastCompletedInvoice.collectAsStateWithLifecycle()
  val products by viewModel.products.collectAsStateWithLifecycle()
  val customers by viewModel.customers.collectAsStateWithLifecycle()
  val suppliers by viewModel.suppliers.collectAsStateWithLifecycle()

  var showQuickActionSheet by remember { mutableStateOf(false) }
  var showVoiceDialog by remember { mutableStateOf(false) }
  var showDebtDialog by remember { mutableStateOf(false) }
  var showExpenseDialog by remember { mutableStateOf(false) }
  var showBackupRestoreDialog by remember { mutableStateOf(false) }
  var previewVoucher by remember { mutableStateOf<PaymentTransaction?>(null) }
  val sheetState = rememberModalBottomSheetState()
  val scope = rememberCoroutineScope()
  val focusManager = LocalFocusManager.current
  val keyboardController = LocalSoftwareKeyboardController.current
  val context = LocalContext.current

  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

  BackHandler(enabled = drawerState.isOpen) {
    scope.launch { drawerState.close() }
  }

  val openDialogFromSheet: (() -> Unit) -> Unit = { openAction ->
    keyboardController?.hide()
    focusManager.clearFocus()
    scope.launch {
      try {
        sheetState.hide()
      } catch (_: Exception) {}
      showQuickActionSheet = false
      openAction()
    }
  }

  ModalNavigationDrawer(
    drawerState = drawerState,
    drawerContent = {
      ModalDrawerSheet(
        modifier = Modifier.width(300.dp),
        drawerContainerColor = MaterialTheme.colorScheme.surface
      ) {
        // Drawer Header with Storefront & Info
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(NavyPrimaryDark)
            .padding(horizontal = 20.dp, vertical = 22.dp)
        ) {
          Column {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              Surface(
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.2f),
                modifier = Modifier.size(46.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.Storefront,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                  )
                }
              }
              Column {
                Text(
                  text = businessProfile.businessName.ifBlank { "الوكيل لتجارة المواد الغذائية" },
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                  fontSize = 16.sp,
                  maxLines = 1
                )
                Spacer(modifier = Modifier.height(2.dp))
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = Color.White.copy(alpha = 0.25f)
                ) {
                  Text(
                    text = businessProfile.userRole,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "الوكيل لتجارة المواد الغذائية | نظام إدارة المخازن والحسابات",
              color = Color(0xFFCBD5E1),
              fontSize = 10.sp,
              fontWeight = FontWeight.Medium
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = "أقسام وتطبيقات النظام",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
        )

        Column(
          modifier = Modifier
            .weight(1f)
            .verticalScroll(rememberScrollState())
        ) {
          tabs.forEachIndexed { index, tab ->
            val isSelected = currentTab == index
            val badgeCount = when (tab) {
              WholesaleTab.SALES -> salesCart.sumOf { it.quantity }
              WholesaleTab.WAREHOUSE -> lowStockList.size
              else -> 0
            }

            NavigationDrawerItem(
              label = {
                Text(
                  text = tab.title,
                  fontSize = 14.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                )
              },
              icon = {
                Icon(
                  imageVector = tab.icon,
                  contentDescription = tab.title,
                  tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
              },
              badge = if (badgeCount > 0) {
                {
                  Badge(
                    containerColor = if (tab == WholesaleTab.WAREHOUSE) MaterialTheme.colorScheme.error else EmeraldPrimary,
                    contentColor = Color.White
                  ) {
                    Text("$badgeCount")
                  }
                }
              } else null,
              selected = isSelected,
              onClick = {
                keyboardController?.hide()
                focusManager.clearFocus()
                currentTab = index
                scope.launch { drawerState.close() }
              },
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
              shape = RoundedCornerShape(12.dp),
              colors = NavigationDrawerItemDefaults.colors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                unselectedTextColor = MaterialTheme.colorScheme.onSurface
              )
            )
          }

          // زر إدارة النسخ الاحتياطي واستعادة البيانات
          NavigationDrawerItem(
            label = {
              Text(
                text = "النسخ الاحتياطي والاستعادة",
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold
              )
            },
            icon = {
              Icon(
                imageVector = Icons.Default.CloudSync,
                contentDescription = "النسخ الاحتياطي",
                tint = OrangePrimary
              )
            },
            selected = false,
            onClick = {
              keyboardController?.hide()
              focusManager.clearFocus()
              scope.launch { drawerState.close() }
              showBackupRestoreDialog = true
            },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
            shape = RoundedCornerShape(12.dp)
          )
        }

        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
        Text(
          text = "الوكيل لتجارة المواد الغذائية v2.0 • جاهز للعمل 100%",
          color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
          fontSize = 10.sp,
          modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
        )
      }
    }
  ) {
    Scaffold(
      topBar = {
        TopAppBar(
          navigationIcon = {
            IconButton(
              onClick = {
                keyboardController?.hide()
                focusManager.clearFocus()
                scope.launch {
                  if (drawerState.isClosed) drawerState.open() else drawerState.close()
                }
              }
            ) {
              Icon(
                imageVector = Icons.Default.Menu,
                contentDescription = "القائمة الجانبية (3 شروط)",
                tint = Color.White
              )
            }
          },
          title = {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.2f),
                modifier = Modifier.size(36.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.Storefront,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                  )
                }
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = businessProfile.businessName,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp,
                    color = Color.White
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Color.White.copy(alpha = 0.25f)
                  ) {
                    Text(
                      text = businessProfile.userRole.substringBefore(" "),
                      fontSize = 9.sp,
                      color = Color.White,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                  }
                }
                Text(
                  text = "الوكيل لتجارة المواد الغذائية | نظام إدارة الحسابات والمخازن",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Medium,
                  color = Color(0xFFCBD5E1)
                )
              }
            }
          }
        },
        actions = {
          if (lowStockList.isNotEmpty() && currentTab == WholesaleTab.WAREHOUSE.ordinal) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.error,
              modifier = Modifier
                .padding(end = 6.dp)
                .clickable { currentTab = WholesaleTab.WAREHOUSE.ordinal }
            ) {
              Text(
                text = "${lowStockList.size} نواقص",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          IconButton(onClick = {
            viewModel.setScreenLocked(true)
          }) {
            Icon(Icons.Default.Lock, contentDescription = "قفل الشاشة البيومتري", tint = Color.White)
          }

          IconButton(onClick = {
            viewModel.toggleDarkMode(!businessProfile.isDarkMode)
          }) {
            Icon(
              imageVector = if (businessProfile.isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
              contentDescription = if (businessProfile.isDarkMode) "تفعيل الوضع الفاتح" else "تفعيل الوضع الداكن",
              tint = Color.White
            )
          }

          IconButton(onClick = { showBackupRestoreDialog = true }) {
            Icon(Icons.Default.CloudSync, contentDescription = "النسخ الاحتياطي والاستعادة", tint = Color.White)
          }

          IconButton(onClick = { currentTab = WholesaleTab.SETTINGS.ordinal }) {
            Icon(Icons.Default.Settings, contentDescription = "الإعدادات", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = NavyPrimaryDark,
          titleContentColor = Color.White
        )
      )
    },
    floatingActionButton = {
      FloatingActionButton(
        onClick = {
          keyboardController?.hide()
          focusManager.clearFocus()
          showQuickActionSheet = true
        },
        containerColor = OrangePrimary,
        contentColor = Color.White,
        shape = CircleShape
      ) {
        Icon(Icons.Default.Add, contentDescription = "معاملة سريعة", modifier = Modifier.size(28.dp))
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (tabs[currentTab]) {
        WholesaleTab.HOME -> HomeScreen(
          viewModel = viewModel,
          onNavigateToTab = { tab ->
            currentTab = tab.ordinal
          }
        )
        WholesaleTab.SALES -> SalesScreen(viewModel = viewModel)
        WholesaleTab.PURCHASES -> PurchasesScreen(viewModel = viewModel)
        WholesaleTab.WAREHOUSE -> WarehouseScreen(viewModel = viewModel)
        WholesaleTab.ACCOUNTS -> AccountsScreen(viewModel = viewModel)
        WholesaleTab.CASHFLOW -> CashflowScreen(viewModel = viewModel)
        WholesaleTab.REPORTS -> ReportsScreen(viewModel = viewModel)
        WholesaleTab.SETTINGS -> SettingsScreen(
          viewModel = viewModel,
          onLogout = {
            // Screen handles redirect to onboarding
          }
        )
      }
    }

    // Quick Action Bottom Sheet
    if (showQuickActionSheet) {
      ModalBottomSheet(
        onDismissRequest = { showQuickActionSheet = false },
        sheetState = sheetState
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
          Text(
            text = "إضافة فاتورة / معاملة سريعة",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
          )
          Spacer(modifier = Modifier.height(14.dp))

          // 1. New Sale Invoice
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                openDialogFromSheet { currentTab = WholesaleTab.SALES.ordinal }
              },
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .background(EmeraldPrimary.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.PointOfSale, contentDescription = null, tint = EmeraldPrimary)
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text("فاتورة بيع جديدة", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("بيع جملة أو قطاعي - كاش أو آجل", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 2. New Purchase Invoice
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                openDialogFromSheet { currentTab = WholesaleTab.PURCHASES.ordinal }
              },
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .background(AmberPrimary.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.LocalShipping, contentDescription = null, tint = AmberPrimary)
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text("فاتورة توريد مشتريات", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("تسجيل فاتورة مورد وإضافة البضاعة للمخزن", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 3. Debt Collection / Settlement (Sanad Voucher)
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                openDialogFromSheet { showDebtDialog = true }
              },
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .background(OrangePrimary.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Receipt, contentDescription = null, tint = OrangePrimary)
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text("إصدار سند قبض / صرف (SANAD)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("سندات رسمية للعملاء والموردين بالتفقيط والطباعة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 4. Operating Expense
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                openDialogFromSheet { showExpenseDialog = true }
              },
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .background(Color(0xFFE53935).copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.MoneyOff, contentDescription = null, tint = Color(0xFFE53935))
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text("تسجيل مصروف تشغيلي / نثريات", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("إيجار، كهرباء، عمالة، نقل وخصم مباشر من الخزينة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 5. AI Voice Command
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                openDialogFromSheet { showVoiceDialog = true }
              },
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .background(Color(0xFF9333EA).copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Mic, contentDescription = null, tint = Color(0xFF9333EA))
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text("أمر صوتي ذكي بالذكاء الاصطناعي (AI)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("إملاء الفاتورة صوتياً ليتم تجهيزها وتفريغها تلقائياً", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 6. Backup & Restore (النسخ الاحتياطي واستعادة البيانات)
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                openDialogFromSheet { showBackupRestoreDialog = true }
              },
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .background(OrangePrimary.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.CloudSync, contentDescription = null, tint = OrangePrimary)
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text("النسخ الاحتياطي واستعادة البيانات", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("استعراض آخر نسخة محفوظة على الهاتف واستعادتها بلمسة واحدة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }

          Spacer(modifier = Modifier.height(24.dp))
        }
      }
    }

    // Quick Sanad Voucher Dialog
    if (showDebtDialog) {
      QuickSanadVoucherDialog(
        customers = customers,
        suppliers = suppliers,
        onDismiss = { showDebtDialog = false },
        onIssueReceiptVoucher = { cust, amt, notes, onDone ->
          viewModel.recordCustomerPayment(cust, amt, notes) { createdTx ->
            showDebtDialog = false
            previewVoucher = createdTx
            onDone(createdTx)
          }
        },
        onIssuePaymentVoucher = { sup, amt, notes, onDone ->
          viewModel.recordSupplierPayment(sup, amt, notes) { createdTx ->
            showDebtDialog = false
            previewVoucher = createdTx
            onDone(createdTx)
          }
        }
      )
    }

    // Official Sanad Voucher Preview Dialog
    previewVoucher?.let { tx ->
      VoucherReceiptDialog(
        transaction = tx,
        businessName = businessProfile.businessName,
        businessPhone = businessProfile.contactPhone,
        currency = businessProfile.currency,
        onDismiss = { previewVoucher = null }
      )
    }

    // Expense Quick Dialog
    if (showExpenseDialog) {
      AddExpenseQuickDialog(
        onDismiss = { showExpenseDialog = false },
        onSave = { expense ->
          viewModel.addExpense(expense.category, expense.amount, expense.recipient, expense.notes)
          showExpenseDialog = false
        }
      )
    }

    // Voice to Transaction Dialog (when triggered from FAB)
    if (showVoiceDialog) {
      VoiceToTransactionDialog(
        viewModel = viewModel,
        products = products,
        customers = customers,
        suppliers = suppliers,
        onDismiss = { showVoiceDialog = false },
        onNavigateToTab = { tabIdx ->
          currentTab = tabIdx
        }
      )
    }

    // Receipt Dialog when a sale completes or invoice is reopened
    lastCompletedInvoice?.let { (inv, items) ->
      InvoiceReceiptDialog(
        invoice = inv,
        items = items,
        businessName = businessProfile.businessName,
        businessPhone = businessProfile.contactPhone,
        businessAddress = businessProfile.address,
        onDismiss = { viewModel.dismissLastInvoice() }
      )
    }

    // Backup & Restore Popup Dialog
    if (showBackupRestoreDialog) {
      BackupRestoreDialog(
        viewModel = viewModel,
        onDismiss = { showBackupRestoreDialog = false }
      )
    }
  }
}
}
