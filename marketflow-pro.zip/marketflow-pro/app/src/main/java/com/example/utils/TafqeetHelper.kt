package com.example.utils

import java.util.Locale

/**
 * Robust Arabic Number-to-Words (Tafqeet / تفقيط) converter tailored for financial
 * accounting vouchers in Sanad ERP ("سند للمحاسبة").
 * Example: 5420.50 -> "فقط خمسة آلاف وأربعمائة وعشرون جنيهاً وخمسون قرشاً لا غير"
 */
object TafqeetHelper {

  private val units = arrayOf(
    "", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة"
  )

  private val teens = arrayOf(
    "عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر",
    "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"
  )

  private val tens = arrayOf(
    "", "عشرة", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"
  )

  private val hundreds = arrayOf(
    "", "مائة", "مئتان", "ثلاثمائة", "أربعمائة", "خمسمائة", "ستمائة", "سبعمائة", "ثمانمائة", "تسعمائة"
  )

  /**
   * Converts a double amount into formal Arabic financial words with currency.
   */
  fun convertToArabicWords(
    amount: Double,
    mainCurrency: String = "جنيه مصري",
    subCurrency: String = "قرش"
  ): String {
    if (amount <= 0.0) return "صفر $mainCurrency"

    val integerPart = amount.toLong()
    val decimalPart = Math.round((amount - integerPart) * 100).toInt()

    val integerWords = convertGroup(integerPart)
    val decimalWords = if (decimalPart > 0) convertGroup(decimalPart.toLong()) else ""

    val sb = StringBuilder()
    sb.append("فقط ")
    sb.append(integerWords)
    sb.append(" ")
    sb.append(getCurrencyName(integerPart, mainCurrency))

    if (decimalWords.isNotBlank() && decimalPart > 0) {
      sb.append(" و")
      sb.append(decimalWords)
      sb.append(" ")
      sb.append(subCurrency)
    }

    sb.append(" لا غير")
    return sb.toString().replace("\\s+".toRegex(), " ").trim()
  }

  private fun getCurrencyName(value: Long, baseCurrency: String): String {
    val lastTwoDigits = (value % 100).toInt()
    if (baseCurrency.contains("جنيه")) {
      return when {
        value == 1L -> "جنيه مصري واحد"
        value == 2L -> "جنيهان مصريان"
        lastTwoDigits in 3..10 -> "جنيهات مصرية"
        else -> "جنيهاً مصرياً"
      }
    }
    if (baseCurrency.contains("ريال")) {
      return when {
        value == 1L -> "ريال واحد"
        value == 2L -> "ريالان"
        lastTwoDigits in 3..10 -> "ريالات"
        else -> "ريالاً"
      }
    }
    return baseCurrency
  }

  private fun convertGroup(number: Long): String {
    if (number == 0L) return "صفر"

    val billions = number / 1_000_000_000L
    var remainder = number % 1_000_000_000L

    val millions = remainder / 1_000_000L
    remainder %= 1_000_000L

    val thousands = remainder / 1000L
    val subThousands = remainder % 1000L

    val parts = mutableListOf<String>()

    if (billions > 0) {
      parts.add(when (billions) {
        1L -> "مليار"
        2L -> "ملياران"
        in 3..10 -> "${convertThreeDigits(billions.toInt())} مليارات"
        else -> "${convertThreeDigits(billions.toInt())} ملياراً"
      })
    }

    if (millions > 0) {
      parts.add(when (millions) {
        1L -> "مليون"
        2L -> "مليونان"
        in 3..10 -> "${convertThreeDigits(millions.toInt())} ملايين"
        else -> "${convertThreeDigits(millions.toInt())} مليوناً"
      })
    }

    if (thousands > 0) {
      parts.add(when (thousands) {
        1L -> "ألف"
        2L -> "ألفان"
        in 3..10 -> "${convertThreeDigits(thousands.toInt())} آلاف"
        else -> "${convertThreeDigits(thousands.toInt())} ألفاً"
      })
    }

    if (subThousands > 0) {
      parts.add(convertThreeDigits(subThousands.toInt()))
    }

    return parts.joinToString(" و ")
  }

  private fun convertThreeDigits(number: Int): String {
    if (number == 0) return ""

    val h = number / 100
    val remainder = number % 100
    val u = remainder % 10
    val t = remainder / 10

    val parts = mutableListOf<String>()

    if (h > 0) {
      parts.add(hundreds[h])
    }

    if (remainder in 10..19) {
      parts.add(teens[remainder - 10])
    } else {
      if (u > 0) {
        parts.add(units[u])
      }
      if (t > 0) {
        parts.add(tens[t])
      }
    }

    return parts.joinToString(" و ")
  }
}
