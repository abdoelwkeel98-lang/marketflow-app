package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Product
import com.example.data.model.StockAudit
import com.example.data.model.StockAuditItem
import com.example.ui.WholesaleViewModel
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WarehouseScreen(
  viewModel: WholesaleViewModel,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val tabs = listOf("المخزن والأصناف", "الجرد الفعلي والتسويات")

  Column(modifier = modifier.fillMaxSize()) {
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = MaterialTheme.colorScheme.surface
    ) {
      tabs.forEachIndexed { index, title ->
        Tab(
          selected = selectedTab == index,
          onClick = { selectedTab = index },
          text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
        )
      }
    }

    if (selectedTab == 0) {
      ProductsInventoryTab(viewModel = viewModel)
    } else {
      StockAuditTab(viewModel = viewModel)
    }
  }
}

@Composable
fun ProductsInventoryTab(viewModel: WholesaleViewModel) {
  val context = LocalContext.current
  val businessProfile by viewModel.businessProfile.collectAsStateWithLifecycle()
  val products by viewModel.products.collectAsStateWithLifecycle()
  val lowStock by viewModel.lowStockProducts.collectAsStateWithLifecycle()

  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("الكل") }
  var showAddEditDialog by remember { mutableStateOf<Product?>(null) }
  var isCreatingNew by remember { mutableStateOf(false) }
  var wacCalculatorProduct by remember { mutableStateOf<Product?>(null) }
  var showGeneralWacCalculator by remember { mutableStateOf(false) }
  var isRecalculatingWac by remember { mutableStateOf(false) }

  val categories = remember(products) {
    listOf("الكل") + products.map { it.category }.distinct()
  }

  val filteredProducts = remember(products, searchQuery, selectedCategory) {
    products.filter { p ->
      val matchesQuery = p.name.contains(searchQuery, ignoreCase = true) || p.barcode.contains(searchQuery, ignoreCase = true)
      val matchesCat = selectedCategory == "الكل" || p.category == selectedCategory
      matchesQuery && matchesCat
    }
  }

  val totalInventoryCost = remember(products) {
    products.sumOf { it.totalPiecesInStock * it.pieceCostPrice }
  }
  val totalInventoryRetail = remember(products) {
    products.sumOf { it.totalPiecesInStock * it.pieceRetailPrice }
  }
  var adjustingProduct by remember { mutableStateOf<Product?>(null) }

  Box(modifier = Modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // Summary Metrics
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          MetricSmallCard(
            title = "المخزن بتكلفة WAC",
            value = String.format(Locale.ENGLISH, "%.0f ج.م", totalInventoryCost),
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.weight(1f)
          )
          MetricSmallCard(
            title = "المخزن بالقطاعي",
            value = String.format(Locale.ENGLISH, "%.0f ج.م", totalInventoryRetail),
            containerColor = EmeraldPrimary.copy(alpha = 0.15f),
            contentColor = EmeraldPrimary,
            modifier = Modifier.weight(1f)
          )
          MetricSmallCard(
            title = "نواقص المخزن",
            value = "${lowStock.size} صنف",
            containerColor = if (lowStock.isNotEmpty()) MaterialTheme.colorScheme.error.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
            contentColor = if (lowStock.isNotEmpty()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(0.9f)
          )
        }
      }

      // WAC Valuation Banner with Quick Actions
      item {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = EmeraldPrimary.copy(alpha = 0.08f),
          border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.35f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = EmeraldPrimary.copy(alpha = 0.18f),
                modifier = Modifier.size(36.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(Icons.Default.AccountBalance, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
                }
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "نظام تقييم المخزون المعتمد: متوسط التكلفة المرجح (WAC)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = EmeraldPrimary
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = EmeraldPrimary
                  ) {
                    Text(
                      text = "WAC ✓",
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.White,
                      modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                  }
                }
                Text(
                  text = "يتم تحديث تكلفة الأصناف آلياً بمتوسط التكلفة المرجح مع كل توريد بناءً على رصيد المخزن السابق والكميات المشتراة وتكلفتها.",
                  fontSize = 10.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              OutlinedButton(
                onClick = { showGeneralWacCalculator = true },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier.weight(1f)
              ) {
                Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(15.dp), tint = EmeraldPrimary)
                Spacer(modifier = Modifier.width(4.dp))
                Text("حاسبة WAC ⚖️", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
              }

              Button(
                onClick = {
                  isRecalculatingWac = true
                  viewModel.recalculateAllProductsWac { count ->
                    isRecalculatingWac = false
                    Toast.makeText(
                      context,
                      "تم تدقيق وإعادة احتساب تكلفة WAC لـ $count صنفاً بناءً على سجل فواتير الشراء بنجاح ✓",
                      Toast.LENGTH_LONG
                    ).show()
                  }
                },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier.weight(1.2f),
                enabled = !isRecalculatingWac
              ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (isRecalculatingWac) "جاري التدقيق..." else "تدقيق WAC من الفواتير 🔄",
                  fontSize = 10.5.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }
      }

      // Header Action Card with Add Product Button
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(40.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(Icons.Default.Inventory2, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
                }
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("إدارة أصناف المخزن", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                  text = if (products.isEmpty()) "المخزن فارغ • أضف منتجاتك الآن" else "إجمالي الأصناف: ${products.size} صنف مسجل",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            Button(
              onClick = {
                isCreatingNew = true
                showAddEditDialog = Product(name = "")
              },
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
              contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
            ) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("إضافة منتج جديد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      // Search & Filters
      item {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text("بحث عن صنف أو باركود...") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )
      }

      // Categories
      item {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(categories) { cat ->
            FilterChip(
              selected = selectedCategory == cat,
              onClick = { selectedCategory = cat },
              label = { Text(cat) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
              )
            )
          }
        }
      }

      // Products List
      items(filteredProducts, key = { it.id }) { product ->
        WarehouseProductItem(
          product = product,
          onEdit = { showAddEditDialog = product },
          onDelete = { viewModel.deleteProduct(product) },
          onQuickAdjust = { adjustingProduct = product },
          onWacCalculate = { wacCalculatorProduct = product }
        )
      }

      if (filteredProducts.isEmpty()) {
        item {
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center
            ) {
              Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                modifier = Modifier.size(64.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    Icons.Default.Inventory2,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(34.dp)
                  )
                }
              }
              Spacer(modifier = Modifier.height(14.dp))
              Text(
                text = if (searchQuery.isNotBlank()) "لا توجد نتائج مطابقة لبحثك" else "المخزن فارغ تماماً - جاهز للعمل",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                textAlign = TextAlign.Center
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = if (searchQuery.isNotBlank()) "جرّب البحث باسم صنف آخر أو مسح الباركود" else "ابدأ الآن بإضافة أول منتج لتجارة المواد الغذائية لتسجيل سعر التكلفة وأسعار البيع جملة وقطاعي والباركود ورصيد المخزن.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
              )
              Spacer(modifier = Modifier.height(16.dp))
              Button(
                onClick = {
                  isCreatingNew = true
                  showAddEditDialog = Product(name = "")
                },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
              ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("＋ إضافة منتج جديد إلى المخزن الآن", fontWeight = FontWeight.Bold, fontSize = 13.sp)
              }
            }
          }
        }
      }
    }

    // Direct Stock Adjustment Dialog
    adjustingProduct?.let { prod ->
      QuickStockAdjustmentDialog(
        product = prod,
        onDismiss = { adjustingProduct = null },
        onConfirm = { deltaPieces, reason ->
          viewModel.quickAdjustStock(prod, deltaPieces, reason)
          adjustingProduct = null
        }
      )
    }

    // Add FAB
    ExtendedFloatingActionButton(
      onClick = {
        isCreatingNew = true
        showAddEditDialog = Product(name = "")
      },
      icon = { Icon(Icons.Default.Add, contentDescription = null) },
      text = { Text("إضافة منتج جديد", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(16.dp),
      containerColor = EmeraldPrimary,
      contentColor = Color.White
    )

    // Dialog for Add/Edit
    showAddEditDialog?.let { product ->
      ProductEditDialog(
        initialProduct = product,
        onDismiss = {
          showAddEditDialog = null
          isCreatingNew = false
        },
        onSave = { saved ->
          viewModel.saveProduct(saved)
          showAddEditDialog = null
          isCreatingNew = false
        }
      )
    }

    // WAC Product Calculator Dialog
    if (showGeneralWacCalculator || wacCalculatorProduct != null) {
      WacProductCalculatorDialog(
        initialProduct = wacCalculatorProduct,
        products = products,
        currency = businessProfile.currency,
        onDismiss = {
          showGeneralWacCalculator = false
          wacCalculatorProduct = null
        },
        onApplyWacCost = { productId, newCartonCost ->
          viewModel.updateProductWacCost(productId, newCartonCost) {
            Toast.makeText(
              context,
              "تم تحديث واعتماد تكلفة الصنف بالمتوسط الجديد WAC (${String.format(Locale.ENGLISH, "%.2f", newCartonCost)} ج.م) ✓",
              Toast.LENGTH_SHORT
            ).show()
          }
          showGeneralWacCalculator = false
          wacCalculatorProduct = null
        }
      )
    }
  }
}

@Composable
fun WarehouseProductItem(
  product: Product,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  onQuickAdjust: () -> Unit,
  onWacCalculate: () -> Unit
) {
  val isLowStock = product.totalPiecesInStock <= product.minStockAlert

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(product.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
          Text(
            text = "قسم: ${product.category} • كود: ${if (product.barcode.isNotEmpty()) product.barcode else "بدون"}",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
          OutlinedButton(
            onClick = onWacCalculate,
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(13.dp), tint = EmeraldPrimary)
            Spacer(modifier = Modifier.width(3.dp))
            Text("حاسبة WAC", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
          }

          OutlinedButton(
            onClick = onQuickAdjust,
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
          ) {
            Text("تعديل رصيد", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
          IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
          }
          IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
      Spacer(modifier = Modifier.height(8.dp))

      // Stock and Pricing Details
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "الرصيد بالمخزن:",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = product.stockDisplayString(),
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              color = if (isLowStock) MaterialTheme.colorScheme.error else EmeraldPrimary
            )
            if (isLowStock) {
              Spacer(modifier = Modifier.width(4.dp))
              Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
            }
          }
        }

        Column(horizontalAlignment = Alignment.End) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(4.dp),
              color = EmeraldPrimary.copy(alpha = 0.15f)
            ) {
              Text(
                text = "WAC",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldPrimary,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
              )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "تكلفة الكرتونة: ${String.format(Locale.ENGLISH, "%.2f", product.cartonCostPrice)} ج.م",
              fontSize = 11.5.sp,
              fontWeight = FontWeight.Bold,
              color = EmeraldPrimary
            )
          }
          Text(
            text = "تكلفة القطعة (WAC): ${String.format(Locale.ENGLISH, "%.2f", product.pieceCostPrice)} ج.م",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = "جملة الكرتونة: ${product.cartonWholesalePrice} ج.م",
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            text = "قطاعي ${product.unitName}: ${product.pieceRetailPrice} ج.م",
            fontSize = 10.5.sp,
            color = MaterialTheme.colorScheme.secondary
          )
        }
      }
    }
  }
}

@Composable
fun ProductEditDialog(
  initialProduct: Product,
  onDismiss: () -> Unit,
  onSave: (Product) -> Unit
) {
  var name by remember { mutableStateOf(initialProduct.name) }
  var category by remember { mutableStateOf(initialProduct.category) }
  var barcode by remember { mutableStateOf(initialProduct.barcode) }
  var unitName by remember { mutableStateOf(initialProduct.unitName) }
  var cartonName by remember { mutableStateOf(initialProduct.cartonName) }
  var piecesPerCarton by remember { mutableStateOf(initialProduct.piecesPerCarton.toString()) }
  var cartonCostPrice by remember { mutableStateOf(initialProduct.cartonCostPrice.toString()) }
  var cartonWholesalePrice by remember { mutableStateOf(initialProduct.cartonWholesalePrice.toString()) }
  var cartonSemiWholesalePrice by remember { mutableStateOf(initialProduct.cartonSemiWholesalePrice.toString()) }
  var pieceRetailPrice by remember { mutableStateOf(initialProduct.pieceRetailPrice.toString()) }
  var totalPiecesInStock by remember { mutableStateOf(initialProduct.totalPiecesInStock.toString()) }
  var minStockAlert by remember { mutableStateOf(initialProduct.minStockAlert.toString()) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.95f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (initialProduct.id == 0L) "إضافة صنف جملة جديد" else "تعديل بيانات الصنف",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        LazyColumn(
          modifier = Modifier
            .weight(1f, fill = false)
            .fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          item {
            OutlinedTextField(
              value = name,
              onValueChange = { name = it },
              label = { Text("اسم الصنف أو السلعة *") },
              singleLine = true,
              modifier = Modifier.fillMaxWidth()
            )
          }

          item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(
                value = category,
                onValueChange = { category = it },
                label = { Text("القسم / التصنيف") },
                singleLine = true,
                modifier = Modifier.weight(1f)
              )
              OutlinedTextField(
                value = barcode,
                onValueChange = { barcode = it },
                label = { Text("الباركود") },
                singleLine = true,
                modifier = Modifier.weight(1f)
              )
            }
          }

          item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(
                value = cartonName,
                onValueChange = { cartonName = it },
                label = { Text("اسم العبوة الكبيرة (كرتونة)") },
                singleLine = true,
                modifier = Modifier.weight(1f)
              )
              OutlinedTextField(
                value = unitName,
                onValueChange = { unitName = it },
                label = { Text("اسم الوحدة (قطعة/علبة)") },
                singleLine = true,
                modifier = Modifier.weight(1f)
              )
            }
          }

          item {
            OutlinedTextField(
              value = piecesPerCarton,
              onValueChange = { piecesPerCarton = it },
              label = { Text("عدد القطع في الكرتونة *") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier.fillMaxWidth()
            )
          }

          item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(
                value = cartonCostPrice,
                onValueChange = { cartonCostPrice = it },
                label = { Text("شراء الكرتونة (التكلفة)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f)
              )
              OutlinedTextField(
                value = cartonWholesalePrice,
                onValueChange = { cartonWholesalePrice = it },
                label = { Text("بيع الكرتونة جملة") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f)
              )
            }
          }

          item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(
                value = cartonSemiWholesalePrice,
                onValueChange = { cartonSemiWholesalePrice = it },
                label = { Text("بيع نصف جملة") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f)
              )
              OutlinedTextField(
                value = pieceRetailPrice,
                onValueChange = { pieceRetailPrice = it },
                label = { Text("بيع القطعة قطاعي") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f)
              )
            }
          }

          item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(
                value = totalPiecesInStock,
                onValueChange = { totalPiecesInStock = it },
                label = { Text("الرصيد الحالي (بالقطع)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f)
              )
              OutlinedTextField(
                value = minStockAlert,
                onValueChange = { minStockAlert = it },
                label = { Text("حد التنبيه (بالقطع)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              if (name.isBlank()) return@Button
              val ppc = piecesPerCarton.toIntOrNull() ?: 12
              val cost = cartonCostPrice.toDoubleOrNull() ?: 0.0
              val ws = cartonWholesalePrice.toDoubleOrNull() ?: 0.0
              val semi = cartonSemiWholesalePrice.toDoubleOrNull() ?: ws
              val pieceRet = pieceRetailPrice.toDoubleOrNull() ?: (if (ppc > 0) ws / ppc else 0.0)
              val stock = totalPiecesInStock.toIntOrNull() ?: 0
              val minA = minStockAlert.toIntOrNull() ?: 24

              val updated = initialProduct.copy(
                name = name.trim(),
                category = category.trim().ifEmpty { "عام" },
                barcode = barcode.trim(),
                unitName = unitName.trim().ifEmpty { "قطعة" },
                cartonName = cartonName.trim().ifEmpty { "كرتونة" },
                piecesPerCarton = ppc,
                cartonCostPrice = cost,
                cartonWholesalePrice = ws,
                cartonSemiWholesalePrice = semi,
                pieceWholesalePrice = if (ppc > 0) ws / ppc else 0.0,
                pieceRetailPrice = pieceRet,
                totalPiecesInStock = stock,
                minStockAlert = minA
              )
              onSave(updated)
            },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
          ) {
            Text("حفظ الصنف", fontWeight = FontWeight.Bold)
          }

          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f)
          ) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

// =============================================================================
// نافذة وحاسبة متوسط التكلفة المرجح WAC (Weighted Average Cost Calculator)
// =============================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WacProductCalculatorDialog(
  initialProduct: Product?,
  products: List<Product>,
  currency: String,
  onDismiss: () -> Unit,
  onApplyWacCost: (productId: Long, newCartonCost: Double) -> Unit
) {
  var selectedProduct by remember { mutableStateOf(initialProduct ?: products.firstOrNull()) }
  var productDropdownExpanded by remember { mutableStateOf(false) }

  val ppc = (selectedProduct?.piecesPerCarton ?: 12).coerceAtLeast(1)
  val unitName = selectedProduct?.unitName ?: "قطعة"
  val cartonName = selectedProduct?.cartonName ?: "كرتونة"

  var currentStockCartonsStr by remember(selectedProduct) {
    mutableStateOf(selectedProduct?.cartonsInStock?.toString() ?: "10")
  }
  var currentStockPiecesStr by remember(selectedProduct) {
    mutableStateOf(selectedProduct?.remainingPiecesInStock?.toString() ?: "0")
  }
  var currentCartonCostStr by remember(selectedProduct) {
    mutableStateOf(String.format(Locale.ENGLISH, "%.2f", selectedProduct?.cartonCostPrice ?: 120.0))
  }

  // Incoming new shipment inputs
  var incomingUnitType by remember { mutableStateOf("كرتونة") }
  var incomingQtyStr by remember { mutableStateOf("20") }
  var incomingPriceStr by remember {
    mutableStateOf(String.format(Locale.ENGLISH, "%.2f", (selectedProduct?.cartonCostPrice ?: 120.0) * 1.05))
  }

  // Parse & Calculate WAC:
  val currentCartons = currentStockCartonsStr.toIntOrNull() ?: 0
  val currentPiecesOnly = currentStockPiecesStr.toIntOrNull() ?: 0
  val totalCurrentPieces = (currentCartons * ppc + currentPiecesOnly).coerceAtLeast(0)
  val currentCartonCost = currentCartonCostStr.toDoubleOrNull() ?: 0.0
  val currentPieceCost = if (ppc > 0) currentCartonCost / ppc else 0.0
  val currentTotalValue = totalCurrentPieces * currentPieceCost

  val incomingQty = incomingQtyStr.toIntOrNull() ?: 0
  val incomingPrice = incomingPriceStr.toDoubleOrNull() ?: 0.0
  val incomingTotalPieces = if (incomingUnitType == "كرتونة") incomingQty * ppc else incomingQty
  val incomingPiecePrice = if (incomingUnitType == "كرتونة") (if (ppc > 0) incomingPrice / ppc else 0.0) else incomingPrice
  val incomingTotalValue = incomingTotalPieces * incomingPiecePrice

  val combinedTotalPieces = totalCurrentPieces + incomingTotalPieces
  val calculatedWacPieceCost = if (combinedTotalPieces > 0) {
    (currentTotalValue + incomingTotalValue) / combinedTotalPieces
  } else {
    currentPieceCost
  }
  val calculatedWacCartonCost = calculatedWacPieceCost * ppc

  val costDiffPercent = if (currentCartonCost > 0) {
    ((calculatedWacCartonCost - currentCartonCost) / currentCartonCost) * 100.0
  } else 0.0

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp,
      modifier = Modifier
        .fillMaxWidth(0.96f)
        .padding(vertical = 12.dp)
    ) {
      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Header
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = EmeraldPrimary.copy(alpha = 0.15f),
                modifier = Modifier.size(36.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(Icons.Default.Calculate, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
                }
              }
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text("حاسبة متوسط التكلفة WAC ⚖️", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("Weighted Average Cost Calculator", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
            IconButton(onClick = onDismiss) {
              Icon(Icons.Default.Close, contentDescription = "إغلاق")
            }
          }
        }

        item { HorizontalDivider() }

        // Product Picker
        if (products.isNotEmpty()) {
          item {
            Box(modifier = Modifier.fillMaxWidth()) {
              Card(
                onClick = { productDropdownExpanded = true },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Text("الصنف المطبق عليه الحساب:", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                      text = selectedProduct?.name ?: "اختر صنفاً...",
                      fontWeight = FontWeight.Bold,
                      fontSize = 13.sp,
                      color = MaterialTheme.colorScheme.primary
                    )
                  }
                  Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                }
              }

              DropdownMenu(
                expanded = productDropdownExpanded,
                onDismissRequest = { productDropdownExpanded = false }
              ) {
                products.forEach { prod ->
                  DropdownMenuItem(
                    text = {
                      Column {
                        Text(prod.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("رصيد: ${prod.stockDisplayString()} • تكلفة: ${prod.cartonCostPrice} $currency", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                      }
                    },
                    onClick = {
                      selectedProduct = prod
                      productDropdownExpanded = false
                    }
                  )
                }
              }
            }
          }
        }

        // Section 1: Current Stock & Cost
        item {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Text("1. رصيد المخزن الحالي وتكلفته الدفترية:", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                  value = currentStockCartonsStr,
                  onValueChange = { currentStockCartonsStr = it },
                  label = { Text("كرتونة") },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  modifier = Modifier.weight(1f),
                  singleLine = true
                )
                OutlinedTextField(
                  value = currentStockPiecesStr,
                  onValueChange = { currentStockPiecesStr = it },
                  label = { Text("قطعة") },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  modifier = Modifier.weight(1f),
                  singleLine = true
                )
              }
              OutlinedTextField(
                value = currentCartonCostStr,
                onValueChange = { currentCartonCostStr = it },
                label = { Text("تكلفة الكرتونة الحالية ($currency)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
              )
              Text(
                text = "الإجمالي الدفتري: $totalCurrentPieces قطعة = ${String.format(Locale.ENGLISH, "%.2f", currentTotalValue)} $currency (للقطعة: ${String.format(Locale.ENGLISH, "%.2f", currentPieceCost)} $currency)",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }

        // Section 2: Incoming Shipment
        item {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = OrangePrimary.copy(alpha = 0.08f),
            border = BorderStroke(1.dp, OrangePrimary.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text("2. الشحنة الجديدة المشتراة:", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = OrangePrimary)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  FilterChip(
                    selected = incomingUnitType == "كرتونة",
                    onClick = { incomingUnitType = "كرتونة" },
                    label = { Text("كرتونة", fontSize = 10.5.sp) }
                  )
                  FilterChip(
                    selected = incomingUnitType == "قطعة",
                    onClick = { incomingUnitType = "قطعة" },
                    label = { Text("قطعة", fontSize = 10.5.sp) }
                  )
                }
              }

              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                  value = incomingQtyStr,
                  onValueChange = { incomingQtyStr = it },
                  label = { Text("كمية الشراء ($incomingUnitType)") },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  modifier = Modifier.weight(1f),
                  singleLine = true
                )
                OutlinedTextField(
                  value = incomingPriceStr,
                  onValueChange = { incomingPriceStr = it },
                  label = { Text("سعر الشراء ($currency)") },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                  modifier = Modifier.weight(1f),
                  singleLine = true
                )
              }
              Text(
                text = "قيمة الشحنة: $incomingTotalPieces قطعة = ${String.format(Locale.ENGLISH, "%.2f", incomingTotalValue)} $currency (للقطعة: ${String.format(Locale.ENGLISH, "%.2f", incomingPiecePrice)} $currency)",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }

        // Section 3: WAC Result Card
        item {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = EmeraldPrimary.copy(alpha = 0.15f),
            border = BorderStroke(1.5.dp, EmeraldPrimary),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text("3. متوسط التكلفة المرجح الناتج (WAC):", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = EmeraldPrimary)
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = if (costDiffPercent > 0) OrangePrimary else EmeraldPrimary
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  ) {
                    Icon(
                      imageVector = if (costDiffPercent >= 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                      contentDescription = null,
                      tint = Color.White,
                      modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                      text = String.format(Locale.ENGLISH, "%+.1f%%", costDiffPercent),
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.White
                    )
                  }
                }
              }

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column {
                  Text("تكلفة الكرتونة WAC الجديدة:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(
                    text = String.format(Locale.ENGLISH, "%.2f %s", calculatedWacCartonCost, currency),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = EmeraldPrimary
                  )
                }

                Column(horizontalAlignment = Alignment.End) {
                  Text("تكلفة القطعة WAC الجديدة:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(
                    text = String.format(Locale.ENGLISH, "%.2f %s", calculatedWacPieceCost, currency),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary
                  )
                }
              }

              HorizontalDivider(color = EmeraldPrimary.copy(alpha = 0.3f))

              Text(
                text = "معادلة WAC = (قيمة الرصيد الحالي ${String.format(Locale.ENGLISH, "%.1f", currentTotalValue)} + قيمة الشحنة ${String.format(Locale.ENGLISH, "%.1f", incomingTotalValue)}) ÷ إجمالي الكمية ($combinedTotalPieces قطعة)",
                fontSize = 9.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 13.sp
              )
            }
          }
        }

        // Actions
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            if (selectedProduct != null && selectedProduct!!.id > 0L) {
              Button(
                onClick = {
                  onApplyWacCost(selectedProduct!!.id, calculatedWacCartonCost)
                },
                modifier = Modifier.weight(1.3f),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                shape = RoundedCornerShape(10.dp)
              ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("اعتماد تكلفة WAC للصنف 💾", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
              }
            }

            OutlinedButton(
              onClick = onDismiss,
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(10.dp)
            ) {
              Text("إغلاق", fontSize = 12.sp)
            }
          }
        }
      }
    }
  }
}

@Composable
fun StockAuditTab(viewModel: WholesaleViewModel) {
  val context = LocalContext.current
  val products by viewModel.products.collectAsStateWithLifecycle()
  val audits by viewModel.stockAudits.collectAsStateWithLifecycle()
  val businessProfile by viewModel.businessProfile.collectAsStateWithLifecycle()

  // Map of ProductId -> Actual counted pieces
  val actualCounts = remember { mutableStateMapOf<Long, Int>() }
  var searchQuery by remember { mutableStateOf("") }
  var selectedFilter by remember { mutableStateOf("الكل") } // "الكل", "فروقات فقط", "عجز فقط", "زيادة فقط", "مطابق تماماً"
  var selectedCategory by remember { mutableStateOf("الكل") }

  var activeSubTab by remember { mutableIntStateOf(0) } // 0 = جلسة الجرد والمقارنة, 1 = سجل التسويات السابقة
  var countInputProduct by remember { mutableStateOf<Product?>(null) }
  var showReconcileConfirmDialog by remember { mutableStateOf(false) }
  var newlyGeneratedAuditId by remember { mutableStateOf<Long?>(null) }
  var selectedHistoricalAudit by remember { mutableStateOf<StockAudit?>(null) }
  var showResetToSystemDialog by remember { mutableStateOf(false) }
  var showResetToZeroDialog by remember { mutableStateOf(false) }
  var quickAdjustProduct by remember { mutableStateOf<Product?>(null) }
  var wacCalculatorAuditProduct by remember { mutableStateOf<Product?>(null) }

  // Initialize actual counts to current system counts if not set
  products.forEach { prod ->
    if (!actualCounts.containsKey(prod.id)) {
      actualCounts[prod.id] = prod.totalPiecesInStock
    }
  }

  // Calculate audit difference items
  val auditItems = remember(products, actualCounts.toMap()) {
    products.map { prod ->
      val actual = actualCounts[prod.id] ?: prod.totalPiecesInStock
      val diff = actual - prod.totalPiecesInStock
      val unitCost = prod.pieceCostPrice
      val diffCost = diff * unitCost
      StockAuditItem(
        productId = prod.id,
        productName = prod.name,
        systemQuantity = prod.totalPiecesInStock,
        actualQuantity = actual,
        diffQuantity = diff,
        unitPieceCost = unitCost,
        diffCostValue = diffCost
      )
    }
  }

  val totalExpectedPieces = remember(products) { products.sumOf { it.totalPiecesInStock } }
  val totalExpectedValue = remember(products) { products.sumOf { it.totalPiecesInStock * it.pieceCostPrice } }
  val totalCountedPieces = remember(auditItems) { auditItems.sumOf { it.actualQuantity } }
  val totalCountedValue = remember(auditItems) { auditItems.sumOf { it.actualQuantity * it.unitPieceCost } }

  val totalDiscrepancyValue = remember(auditItems) {
    auditItems.sumOf { it.diffCostValue }
  }
  val totalDeficitValue = remember(auditItems) {
    auditItems.filter { it.diffQuantity < 0 }.sumOf { -it.diffCostValue }
  }
  val totalSurplusValue = remember(auditItems) {
    auditItems.filter { it.diffQuantity > 0 }.sumOf { it.diffCostValue }
  }
  val deficitCount = remember(auditItems) { auditItems.count { it.diffQuantity < 0 } }
  val surplusCount = remember(auditItems) { auditItems.count { it.diffQuantity > 0 } }
  val matchedCount = remember(auditItems) { auditItems.count { it.diffQuantity == 0 } }
  val varianceCount = remember(auditItems) { auditItems.count { it.diffQuantity != 0 } }

  val exportWacAuditReport: () -> Unit = {
    val dateStr = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.ENGLISH).format(Date())
    val sb = StringBuilder()
    sb.appendLine("==========================================")
    sb.appendLine("   تقرير الجرد المخزني الفعلي (نظام WAC)")
    sb.appendLine("==========================================")
    sb.appendLine("المنشأة: ${businessProfile.businessName}")
    sb.appendLine("التاريخ والوقت: $dateStr")
    sb.appendLine("نظام التقييم المعتمد: متوسط التكلفة المرجح (WAC)")
    sb.appendLine("العملة: ${businessProfile.currency}")
    sb.appendLine("------------------------------------------")
    sb.appendLine("إجمالي الأصناف: ${products.size}")
    sb.appendLine("الرصيد الدفتري المتوقع: $totalExpectedPieces قطعة (${String.format(Locale.ENGLISH, "%.2f", totalExpectedValue)} ${businessProfile.currency})")
    sb.appendLine("الرصيد الفعلي المجرود: $totalCountedPieces قطعة (${String.format(Locale.ENGLISH, "%.2f", totalCountedValue)} ${businessProfile.currency})")
    sb.appendLine("صافي فارق الجرد: ${totalCountedPieces - totalExpectedPieces} قطعة (${String.format(Locale.ENGLISH, "%+.2f", totalDiscrepancyValue)} ${businessProfile.currency})")
    sb.appendLine("• أصناف بها عجز: $deficitCount صنف (بقيمة: ${String.format(Locale.ENGLISH, "%.2f", totalDeficitValue)} ${businessProfile.currency})")
    sb.appendLine("• أصناف بها زيادة: $surplusCount صنف (بقيمة: ${String.format(Locale.ENGLISH, "%.2f", totalSurplusValue)} ${businessProfile.currency})")
    sb.appendLine("• أصناف مطابقة: $matchedCount صنف")
    sb.appendLine("------------------------------------------")
    sb.appendLine("تفاصيل الفروقات بتكلفة WAC:")
    for (item in auditItems.filter { it.diffQuantity != 0 }) {
      val status = if (item.diffQuantity < 0) "عجز [${-item.diffQuantity}]" else "زيادة [+${item.diffQuantity}]"
      sb.appendLine("• ${item.productName}: متوقع=${item.systemQuantity} | فعلي=${item.actualQuantity} | $status | تكلفة WAC للقطعة=${String.format(Locale.ENGLISH, "%.2f", item.unitPieceCost)} | فارق القيمة=${String.format(Locale.ENGLISH, "%+.2f", item.diffCostValue)} ${businessProfile.currency}")
    }
    sb.appendLine("==========================================")
    sb.appendLine("تم الإصدار بواسطة نظام سند لإدارة المخازن والحسابات")

    val sendIntent = Intent().apply {
      action = Intent.ACTION_SEND
      putExtra(Intent.EXTRA_TEXT, sb.toString())
      type = "text/plain"
    }
    context.startActivity(Intent.createChooser(sendIntent, "مشاركة تقرير جرد WAC عبر"))
  }

  val categories = remember(products) {
    listOf("الكل") + products.map { it.category }.distinct()
  }

  // Filtered products according to search & chips
  val filteredProducts = remember(products, actualCounts.toMap(), searchQuery, selectedFilter, selectedCategory) {
    products.filter { p ->
      val actual = actualCounts[p.id] ?: p.totalPiecesInStock
      val diff = actual - p.totalPiecesInStock
      val matchesSearch = p.name.contains(searchQuery, ignoreCase = true) || p.barcode.contains(searchQuery, ignoreCase = true)
      val matchesCat = selectedCategory == "الكل" || p.category == selectedCategory
      val matchesStatus = when (selectedFilter) {
        "فروقات فقط" -> diff != 0
        "عجز فقط" -> diff < 0
        "زيادة فقط" -> diff > 0
        "مطابق تماماً" -> diff == 0
        else -> true
      }
      matchesSearch && matchesCat && matchesStatus
    }
  }

  Column(modifier = Modifier.fillMaxSize()) {
    // شريط التبديل بين جلسة الجرد وسجل التسويات
    Surface(
      color = MaterialTheme.colorScheme.surface,
      shadowElevation = 1.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        FilterChip(
          selected = activeSubTab == 0,
          onClick = { activeSubTab = 0 },
          leadingIcon = {
            Icon(Icons.Default.FactCheck, contentDescription = null, modifier = Modifier.size(16.dp))
          },
          label = {
            Text(
              "جلسة الجرد والمقارنة",
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = EmeraldPrimary,
            selectedLabelColor = Color.White,
            selectedLeadingIconColor = Color.White
          ),
          modifier = Modifier.weight(1f)
        )

        FilterChip(
          selected = activeSubTab == 1,
          onClick = { activeSubTab = 1 },
          leadingIcon = {
            Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
          },
          label = {
            Text(
              "سجل تسويات الجرد (${audits.size})",
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primary,
            selectedLabelColor = Color.White,
            selectedLeadingIconColor = Color.White
          ),
          modifier = Modifier.weight(1f)
        )
      }
    }

    if (activeSubTab == 0) {
      // -----------------------------------------------------------------------
      // التبويب 1: جلسة الجرد ومقارنة الرصيد المتوقع بالفعلي
      // -----------------------------------------------------------------------
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // بطاقة ملخص الجرد والمقارنة الشاملة
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = EmeraldPrimary.copy(alpha = 0.15f),
                    modifier = Modifier.size(36.dp)
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Icon(Icons.Default.FactCheck, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
                    }
                  }
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Text("الجرد الفعلي للمخزون والتسويات بنظام WAC", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                      Spacer(modifier = Modifier.width(6.dp))
                      Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = EmeraldPrimary
                      ) {
                        Text(
                          text = "WAC ✓",
                          fontSize = 9.sp,
                          fontWeight = FontWeight.Bold,
                          color = Color.White,
                          modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                      }
                    }
                    Text("مقارنة الرصيد الدفتري المتوقع بالفعلي وتقييم الفروقات بمتوسط التكلفة WAC", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }

                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = MaterialTheme.colorScheme.primaryContainer
                ) {
                  Text(
                    text = "${products.size} صنف بالمخزن",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              // جدول مقارنة القيم الإجمالية (Expected vs Counted vs Variance)
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp, horizontal = 8.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  // المتوقع بالنظام
                  Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text("المتوقع بالنظام (WAC)", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                      text = "$totalExpectedPieces قطعة",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                      text = String.format(Locale.ENGLISH, "%.1f %s", totalExpectedValue, businessProfile.currency),
                      fontSize = 10.sp,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }

                  Box(modifier = Modifier.height(34.dp).width(1.dp).background(MaterialTheme.colorScheme.outlineVariant))

                  // الفعلي المجرود
                  Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text("الفعلي المجرود (WAC)", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                      text = "$totalCountedPieces قطعة",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                      text = String.format(Locale.ENGLISH, "%.1f %s", totalCountedValue, businessProfile.currency),
                      fontSize = 10.sp,
                      color = MaterialTheme.colorScheme.primary
                    )
                  }

                  Box(modifier = Modifier.height(34.dp).width(1.dp).background(MaterialTheme.colorScheme.outlineVariant))

                  // صافي فارق التسوية
                  Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1.1f)) {
                    Text("صافي فارق التسوية (WAC)", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val netDiffPieces = totalCountedPieces - totalExpectedPieces
                    Text(
                      text = String.format(Locale.ENGLISH, "%+d قطعة", netDiffPieces),
                      fontSize = 12.sp,
                      fontWeight = FontWeight.ExtraBold,
                      color = if (netDiffPieces < 0) MaterialTheme.colorScheme.error else if (netDiffPieces > 0) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                      text = String.format(Locale.ENGLISH, "%+.1f %s", totalDiscrepancyValue, businessProfile.currency),
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = if (totalDiscrepancyValue < 0) MaterialTheme.colorScheme.error else if (totalDiscrepancyValue > 0) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              // مؤشرات تفصيلية للعجز والزيادة والمطابقة
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Surface(
                  color = MaterialTheme.colorScheme.error.copy(alpha = 0.1f),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.weight(1f)
                ) {
                  Column(modifier = Modifier.padding(8.dp)) {
                    Text("إجمالي العجز:", fontSize = 10.sp, color = MaterialTheme.colorScheme.error)
                    Text(
                      text = String.format(Locale.ENGLISH, "%.1f %s", totalDeficitValue, businessProfile.currency),
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.error
                    )
                    Text("$deficitCount صنف به عجز", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }

                Surface(
                  color = EmeraldPrimary.copy(alpha = 0.1f),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.weight(1f)
                ) {
                  Column(modifier = Modifier.padding(8.dp)) {
                    Text("إجمالي الزيادة:", fontSize = 10.sp, color = EmeraldPrimary)
                    Text(
                      text = String.format(Locale.ENGLISH, "%.1f %s", totalSurplusValue, businessProfile.currency),
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = EmeraldPrimary
                    )
                    Text("$surplusCount صنف به زيادة", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }

                Surface(
                  color = MaterialTheme.colorScheme.surfaceVariant,
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.weight(1f)
                ) {
                  Column(modifier = Modifier.padding(8.dp)) {
                    Text("أصناف مطابقة:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                      text = "$matchedCount صنف",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                    Text("فرق: 0.0 ${businessProfile.currency}", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              // أزرار الضبط المسبق للجرد (مطابقة الكل / تصفير الكل)
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedButton(
                  onClick = { showResetToSystemDialog = true },
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(8.dp),
                  contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
                ) {
                  Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("مطابقة الكل بالنظام", fontSize = 11.sp)
                }

                OutlinedButton(
                  onClick = { showResetToZeroDialog = true },
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(8.dp),
                  contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
                ) {
                  Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("تصفير العد (بدء من 0)", fontSize = 11.sp)
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              // أزرار اعتماد تسوية WAC وتصدير التقرير
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedButton(
                  onClick = exportWacAuditReport,
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(10.dp),
                  contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)
                ) {
                  Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(15.dp), tint = MaterialTheme.colorScheme.primary)
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("تقرير جرد WAC 📄", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                  onClick = { showReconcileConfirmDialog = true },
                  modifier = Modifier.weight(1.35f),
                  shape = RoundedCornerShape(10.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                  contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)
                ) {
                  Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(17.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = if (varianceCount > 0)
                      "اعتماد تسوية WAC ($varianceCount صنف)"
                    else
                      "اعتماد تسوية الجرد (مطابق)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.5.sp
                  )
                }
              }
            }
          }
        }

        // شريط البحث ومسح الباركود السريع للجرد
        item {
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("بحث باسم السلعة أو كود الباركود...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
              if (searchQuery.isNotEmpty()) {
                IconButton(onClick = { searchQuery = "" }) {
                  Icon(Icons.Default.Close, contentDescription = "مسح")
                }
              } else {
                IconButton(onClick = {
                  // محاكاة مسح الباركود: إيجاد صنف وزيادة العد الفعلي له بقطعة واحدة فوراً
                  val target = products.firstOrNull { it.barcode.isNotEmpty() } ?: products.firstOrNull()
                  if (target != null) {
                    val current = actualCounts[target.id] ?: target.totalPiecesInStock
                    actualCounts[target.id] = current + 1
                    searchQuery = target.barcode.ifEmpty { target.name }
                    Toast.makeText(
                      context,
                      "تم مسح باركود ${target.name}: زيادة العد بقطعة واحدة (الإجمالي: ${current + 1})",
                      Toast.LENGTH_SHORT
                    ).show()
                  }
                }) {
                  Icon(Icons.Default.QrCodeScanner, contentDescription = "مسح باركود", tint = MaterialTheme.colorScheme.primary)
                }
              }
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
          )
        }

        // فلاتر الحالة (الكل، فروقات فقط، عجز فقط، زيادة فقط، مطابق)
        item {
          val statusFilters = listOf("الكل", "فروقات فقط", "عجز فقط", "زيادة فقط", "مطابق تماماً")
          LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(statusFilters) { filter ->
              FilterChip(
                selected = selectedFilter == filter,
                onClick = { selectedFilter = filter },
                label = {
                  Text(
                    text = when (filter) {
                      "الكل" -> "الكل (${products.size})"
                      "فروقات فقط" -> "فروقات فقط ($varianceCount)"
                      "عجز فقط" -> "عجز فقط ($deficitCount)"
                      "زيادة فقط" -> "زيادة فقط ($surplusCount)"
                      "مطابق تماماً" -> "مطابق تماماً ($matchedCount)"
                      else -> filter
                    },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                  )
                },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = when (filter) {
                    "عجز فقط" -> MaterialTheme.colorScheme.error
                    "زيادة فقط" -> EmeraldPrimary
                    "فروقات فقط" -> MaterialTheme.colorScheme.primary
                    else -> MaterialTheme.colorScheme.primary
                  },
                  selectedLabelColor = Color.White
                )
              )
            }
          }
        }

        // فلاتر الأقسام إن وجدت
        if (categories.size > 2) {
          item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              items(categories) { cat ->
                FilterChip(
                  selected = selectedCategory == cat,
                  onClick = { selectedCategory = cat },
                  label = { Text(cat, fontSize = 11.sp) }
                )
              }
            }
          }
        }

        if (filteredProducts.isEmpty()) {
          item {
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
              Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                Text("لا توجد أصناف مطابقة للبحث أو التصفية الحالية", color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }

        // بطاقات الأصناف للمقارنة بين الرصيد المتوقع والمجرود فعلياً
        items(filteredProducts, key = { it.id }) { product ->
          val count = actualCounts[product.id] ?: product.totalPiecesInStock
          val diff = count - product.totalPiecesInStock
          val diffCost = diff * product.pieceCostPrice

          val ppc = product.piecesPerCarton.coerceAtLeast(1)
          val actualCartons = count / ppc
          val actualPieces = count % ppc

          val systemCartons = product.totalPiecesInStock / ppc
          val systemPieces = product.totalPiecesInStock % ppc

          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              // رأس بطاقة الصنف مع شارة الفارق
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(product.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                  Text(
                    text = "القسم: ${product.category} • كود: ${if (product.barcode.isNotEmpty()) product.barcode else "بدون"}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                  if (product.piecesPerCarton > 1) {
                    Text(
                      text = "العبوة: ${product.piecesPerCarton} ${product.unitName} لكل ${product.cartonName}",
                      fontSize = 10.5.sp,
                      color = MaterialTheme.colorScheme.primary
                    )
                  }
                }

                // شارة فارق الجرد
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = when {
                    diff < 0 -> MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
                    diff > 0 -> EmeraldPrimary.copy(alpha = 0.12f)
                    else -> MaterialTheme.colorScheme.surfaceVariant
                  }
                ) {
                  Text(
                    text = when {
                      diff < 0 -> "عجز: ${-diff} ${product.unitName} (${String.format(Locale.ENGLISH, "%.1f", -diffCost)} ${businessProfile.currency})"
                      diff > 0 -> "زيادة: +$diff ${product.unitName} (+${String.format(Locale.ENGLISH, "%.1f", diffCost)} ${businessProfile.currency})"
                      else -> "مطابق تماماً ✓"
                    },
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = when {
                      diff < 0 -> MaterialTheme.colorScheme.error
                      diff > 0 -> EmeraldPrimary
                      else -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              // مقارنة واضحة جنباً إلى جنب: المتوقع بالنظام مقابل الفعلي المجرود
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  // المتوقع بالنظام
                  Column(modifier = Modifier.weight(1f)) {
                    Text("المسجل بالنظام (Expected):", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                      text = if (product.piecesPerCarton > 1)
                        "$systemCartons ${product.cartonName} و $systemPieces ${product.unitName} ($systemPieces ق)"
                      else
                        "${product.totalPiecesInStock} ${product.unitName}",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                      text = "القيمة (WAC): ${String.format(Locale.ENGLISH, "%.1f", product.totalPiecesInStock * product.pieceCostPrice)} ${businessProfile.currency}",
                      fontSize = 10.sp,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }

                  Box(modifier = Modifier.height(30.dp).width(1.dp).background(MaterialTheme.colorScheme.outlineVariant))

                  // الفعلي المجرود
                  Column(modifier = Modifier.weight(1f).padding(start = 8.dp)) {
                    Text("الفعلي المجرود (Counted):", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(
                      text = if (product.piecesPerCarton > 1)
                        "$actualCartons ${product.cartonName} و $actualPieces ${product.unitName} ($count ق)"
                      else
                        "$count ${product.unitName}",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.ExtraBold,
                      color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                      text = "القيمة (WAC): ${String.format(Locale.ENGLISH, "%.1f", count * product.pieceCostPrice)} ${businessProfile.currency}",
                      fontSize = 10.sp,
                      color = MaterialTheme.colorScheme.primary
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              // أزرار التحكم بالكمية المجرودة (إدخال مباشر + أزرار الزيادة والنقصان السريعة)
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  // زر فتح نافذة إدخال العد الفعلي المباشر
                  OutlinedButton(
                    onClick = { countInputProduct = product },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                  ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("إدخال العد", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                  }

                  // زر حاسبة WAC للصنف
                  OutlinedButton(
                    onClick = { wacCalculatorAuditProduct = product },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                  ) {
                    Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(13.dp), tint = EmeraldPrimary)
                    Spacer(modifier = Modifier.width(2.dp))
                    Text("WAC", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                  }
                }

                // أزرار الزيادة والنقصان السريعة
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                  // -1 قطعة
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                      .size(34.dp)
                      .clickable {
                        actualCounts[product.id] = (count - 1).coerceAtLeast(0)
                      }
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Icon(Icons.Default.Remove, contentDescription = "-1", modifier = Modifier.size(16.dp))
                    }
                  }

                  // +1 قطعة
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier
                      .size(34.dp)
                      .clickable {
                        actualCounts[product.id] = count + 1
                      }
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Icon(Icons.Default.Add, contentDescription = "+1", modifier = Modifier.size(16.dp))
                    }
                  }

                  if (product.piecesPerCarton > 1) {
                    // +1 كرتونة
                    Button(
                      onClick = {
                        actualCounts[product.id] = count + product.piecesPerCarton
                      },
                      shape = RoundedCornerShape(6.dp),
                      contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                      modifier = Modifier.height(34.dp),
                      colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                      Text("+1 كرتونة", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                  }

                  // زر استعادة رصيد النظام
                  IconButton(
                    onClick = {
                      actualCounts[product.id] = product.totalPiecesInStock
                    },
                    modifier = Modifier.size(30.dp)
                  ) {
                    Icon(
                      Icons.Default.Refresh,
                      contentDescription = "استعادة رصيد النظام",
                      tint = MaterialTheme.colorScheme.onSurfaceVariant,
                      modifier = Modifier.size(16.dp)
                    )
                  }
                }
              }

              // رابط تسوية فورية لهذا الصنف فقط
              Spacer(modifier = Modifier.height(6.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
              ) {
                Text(
                  text = "تسوية فورية لهذا الصنف >",
                  fontSize = 10.5.sp,
                  color = MaterialTheme.colorScheme.primary,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier
                    .clickable { quickAdjustProduct = product }
                    .padding(4.dp)
                )
              }
            }
          }
        }
      }
    } else {
      // -----------------------------------------------------------------------
      // التبويب 2: سجل تسويات الجرد المخزني التاريخية
      // -----------------------------------------------------------------------
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text("سجل تسويات الجرد المخزني", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                  Text("كافة محاضر الجرد والتسويات التي تم اعتمادها وترحيلها للحسابات", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }

              Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.primaryContainer
              ) {
                Text(
                  text = "${audits.size} تسوية معتمدة",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onPrimaryContainer,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
              }
            }
          }
        }

        if (audits.isEmpty()) {
          item {
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
              Box(modifier = Modifier.padding(30.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  Icon(Icons.Default.FactCheck, contentDescription = null, modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                  Spacer(modifier = Modifier.height(8.dp))
                  Text("لا توجد تسويات جرد مخزنية مسجلة حتى الآن", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Spacer(modifier = Modifier.height(4.dp))
                  Text("قم بإجراء جرد فعلي واعتماد النتائج ليتم إنشاء سجل التسوية آلياً", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            }
          }
        } else {
          items(audits, key = { it.id }) { audit ->
            val dateStr = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale("ar")).format(Date(audit.auditDate))
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { selectedHistoricalAudit = audit },
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
              elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                      shape = RoundedCornerShape(4.dp),
                      color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                    ) {
                      Text(
                        text = "تسوية #${audit.id}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                      )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(audit.title, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                  }
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(dateStr, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  if (audit.notes.isNotEmpty()) {
                    Text(audit.notes, fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }

                Column(horizontalAlignment = Alignment.End) {
                  Text(
                    text = String.format(Locale.ENGLISH, "صافي: %+.2f %s", audit.totalDiscrepancyValue, businessProfile.currency),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.5.sp,
                    color = if (audit.totalDiscrepancyValue < 0) MaterialTheme.colorScheme.error else EmeraldPrimary
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                  ) {
                    Text(
                      text = "عرض المحضر >",
                      fontSize = 10.sp,
                      color = MaterialTheme.colorScheme.primary,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  // ---------------------------------------------------------------------------
  // نافذة إدخال العد الفعلي المباشر للصنف
  // ---------------------------------------------------------------------------
  countInputProduct?.let { prod ->
    ProductCountInputDialog(
      product = prod,
      currentCount = actualCounts[prod.id] ?: prod.totalPiecesInStock,
      currency = businessProfile.currency,
      onDismiss = { countInputProduct = null },
      onConfirm = { newCount ->
        actualCounts[prod.id] = newCount
        countInputProduct = null
      }
    )
  }

  // ---------------------------------------------------------------------------
  // نافذة تأكيد واعتماد محضر تسوية الجرد
  // ---------------------------------------------------------------------------
  if (showReconcileConfirmDialog) {
    ReconcileConfirmationDialog(
      deficitCount = deficitCount,
      surplusCount = surplusCount,
      matchedCount = matchedCount,
      deficitValue = totalDeficitValue,
      surplusValue = totalSurplusValue,
      netDiscrepancy = totalDiscrepancyValue,
      currency = businessProfile.currency,
      onDismiss = { showReconcileConfirmDialog = false },
      onConfirm = { title, notes, applyToInventory ->
        viewModel.performStockAudit(
          title = title.ifBlank { "تسوية جرد مخزني - " + SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH).format(Date()) },
          notes = notes.ifBlank { "تمت التسوية آلياً بالرصيد الفعلي للمخزن" },
          auditItems = auditItems,
          applyToInventory = applyToInventory,
          onComplete = { auditId ->
            showReconcileConfirmDialog = false
            newlyGeneratedAuditId = auditId
          }
        )
      }
    )
  }

  // ---------------------------------------------------------------------------
  // نافذة عرض محضر وسجل تسوية الجرد المعتمد (الجديد أو التاريخي)
  // ---------------------------------------------------------------------------
  val activeVoucherAudit = selectedHistoricalAudit ?: audits.find { it.id == newlyGeneratedAuditId }
  activeVoucherAudit?.let { audit ->
    StockAdjustmentVoucherDialog(
      audit = audit,
      isNewlyGenerated = (newlyGeneratedAuditId == audit.id),
      businessName = businessProfile.businessName,
      currency = businessProfile.currency,
      viewModel = viewModel,
      onDismiss = {
        selectedHistoricalAudit = null
        newlyGeneratedAuditId = null
      }
    )
  }

  // ---------------------------------------------------------------------------
  // نافذة تأكيد مطابقة الكل بالنظام
  // ---------------------------------------------------------------------------
  if (showResetToSystemDialog) {
    Dialog(onDismissRequest = { showResetToSystemDialog = false }) {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth(0.9f)
      ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("تأكيد مطابقة العد بالنظام", fontWeight = FontWeight.Bold, fontSize = 15.sp)
          Text("هل تريد استعادة جميع الكميات الفعلية لتطابق الأرصدة الدفترية المسجلة بالنظام حالياً؟", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = {
                products.forEach { actualCounts[it.id] = it.totalPiecesInStock }
                showResetToSystemDialog = false
                Toast.makeText(context, "تمت استعادة الأرصدة لتطابق النظام", Toast.LENGTH_SHORT).show()
              },
              colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
              modifier = Modifier.weight(1f)
            ) {
              Text("تأكيد المطابقة")
            }
            OutlinedButton(onClick = { showResetToSystemDialog = false }, modifier = Modifier.weight(1f)) {
              Text("إلغاء")
            }
          }
        }
      }
    }
  }

  // ---------------------------------------------------------------------------
  // نافذة تأكيد تصفير العد للبدء من الصفر
  // ---------------------------------------------------------------------------
  if (showResetToZeroDialog) {
    Dialog(onDismissRequest = { showResetToZeroDialog = false }) {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth(0.9f)
      ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("تأكيد تصفير العد الفعلي", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.error)
          Text("هل تريد تعيين الكميات الفعلية المجرودة لجميع الأصناف إلى (صفر) للبدء في عد المخزن صنفاً صنفاً؟", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = {
                products.forEach { actualCounts[it.id] = 0 }
                showResetToZeroDialog = false
                Toast.makeText(context, "تم تصفير الكميات الفعلية للبدء في الجرد", Toast.LENGTH_SHORT).show()
              },
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
              modifier = Modifier.weight(1f)
            ) {
              Text("تصفير الكل")
            }
            OutlinedButton(onClick = { showResetToZeroDialog = false }, modifier = Modifier.weight(1f)) {
              Text("إلغاء")
            }
          }
        }
      }
    }
  }

  // ---------------------------------------------------------------------------
  // تسوية سريعة لصنف منفرد
  // ---------------------------------------------------------------------------
  quickAdjustProduct?.let { prod ->
    QuickStockAdjustmentDialog(
      product = prod,
      onDismiss = { quickAdjustProduct = null },
      onConfirm = { delta, reason ->
        viewModel.quickAdjustStock(prod, delta, reason) {
          actualCounts[prod.id] = (prod.totalPiecesInStock + delta).coerceAtLeast(0)
          quickAdjustProduct = null
        }
      }
    )
  }
}

// -----------------------------------------------------------------------------
// نافذة إدخال العد الفعلي المباشر للصنف
// -----------------------------------------------------------------------------
@Composable
fun ProductCountInputDialog(
  product: Product,
  currentCount: Int,
  currency: String,
  onDismiss: () -> Unit,
  onConfirm: (Int) -> Unit
) {
  val ppc = product.piecesPerCarton.coerceAtLeast(1)
  var cartonsStr by remember { mutableStateOf((currentCount / ppc).toString()) }
  var piecesStr by remember { mutableStateOf((currentCount % ppc).toString()) }
  var totalPiecesDirectStr by remember { mutableStateOf(currentCount.toString()) }
  var isDirectPiecesMode by remember { mutableStateOf(product.piecesPerCarton <= 1) }

  val computedTotalPieces = remember(cartonsStr, piecesStr, totalPiecesDirectStr, isDirectPiecesMode) {
    if (isDirectPiecesMode) {
      totalPiecesDirectStr.toIntOrNull() ?: 0
    } else {
      val c = cartonsStr.toIntOrNull() ?: 0
      val p = piecesStr.toIntOrNull() ?: 0
      c * ppc + p
    }
  }

  val diff = computedTotalPieces - product.totalPiecesInStock
  val diffCost = diff * product.pieceCostPrice

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.95f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("تسجيل العد الفعلي للصنف", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(product.name, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        HorizontalDivider()

        // بطاقة معلومات الرصيد المتوقع بالنظام
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text("المسجل بالنظام (Expected):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                "${product.stockDisplayString()} (${product.totalPiecesInStock} ${product.unitName})",
                fontWeight = FontWeight.Bold,
                fontSize = 12.5.sp
              )
            }
            Column(horizontalAlignment = Alignment.End) {
              Text("تكلفة القطعة:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                "${String.format(Locale.ENGLISH, "%.2f", product.pieceCostPrice)} $currency",
                fontWeight = FontWeight.Bold,
                fontSize = 12.5.sp
              )
            }
          }
        }

        if (product.piecesPerCarton > 1) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            FilterChip(
              selected = !isDirectPiecesMode,
              onClick = {
                isDirectPiecesMode = false
                val cur = totalPiecesDirectStr.toIntOrNull() ?: computedTotalPieces
                cartonsStr = (cur / ppc).toString()
                piecesStr = (cur % ppc).toString()
              },
              label = { Text("بالكرتونة والقطع (${product.piecesPerCarton} ق/ك)", fontSize = 11.sp) },
              modifier = Modifier.weight(1f)
            )
            FilterChip(
              selected = isDirectPiecesMode,
              onClick = {
                isDirectPiecesMode = true
                totalPiecesDirectStr = computedTotalPieces.toString()
              },
              label = { Text("بالقطع مباشرة", fontSize = 11.sp) },
              modifier = Modifier.weight(1f)
            )
          }
        }

        if (!isDirectPiecesMode && product.piecesPerCarton > 1) {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = cartonsStr,
              onValueChange = { cartonsStr = it },
              label = { Text("الكراتين (${product.cartonName})") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
              value = piecesStr,
              onValueChange = { piecesStr = it },
              label = { Text("القطع (${product.unitName})") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )
          }
        } else {
          OutlinedTextField(
            value = totalPiecesDirectStr,
            onValueChange = { totalPiecesDirectStr = it },
            label = { Text("إجمالي الكمية الفعلية المجرودة بالقطع") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }

        // حساب مباشر للفارق الناتج
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = when {
            diff < 0 -> MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
            diff > 0 -> EmeraldPrimary.copy(alpha = 0.12f)
            else -> MaterialTheme.colorScheme.surfaceVariant
          },
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("الرصيد الفعلي بعد التعديل:", fontSize = 11.sp)
              Text(
                "$computedTotalPieces ${product.unitName}" +
                  if (product.piecesPerCarton > 1) " (${computedTotalPieces / ppc} كرتونة و ${computedTotalPieces % ppc} قطعة)" else "",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              )
            }
            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = when {
                  diff < 0 -> "عجز: ${-diff} ${product.unitName}"
                  diff > 0 -> "زيادة: +$diff ${product.unitName}"
                  else -> "مطابق تماماً ✓"
                },
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = when {
                  diff < 0 -> MaterialTheme.colorScheme.error
                  diff > 0 -> EmeraldPrimary
                  else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
              )
              Text(
                text = String.format(Locale.ENGLISH, "%+.2f %s", diffCost, currency),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = when {
                  diff < 0 -> MaterialTheme.colorScheme.error
                  diff > 0 -> EmeraldPrimary
                  else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
              )
            }
          }
        }

        // أزرار الضبط السريع
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          OutlinedButton(
            onClick = {
              if (isDirectPiecesMode) {
                totalPiecesDirectStr = product.totalPiecesInStock.toString()
              } else {
                cartonsStr = (product.totalPiecesInStock / ppc).toString()
                piecesStr = (product.totalPiecesInStock % ppc).toString()
              }
            },
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
          ) {
            Text("مطابقة بالنظام", fontSize = 11.sp)
          }

          OutlinedButton(
            onClick = {
              if (isDirectPiecesMode) {
                totalPiecesDirectStr = "0"
              } else {
                cartonsStr = "0"
                piecesStr = "0"
              }
            },
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
          ) {
            Text("تصفير (0)", fontSize = 11.sp)
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              onConfirm(computedTotalPieces.coerceAtLeast(0))
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ العد الفعلي", fontWeight = FontWeight.Bold)
          }

          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f)
          ) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// نافذة تأكيد واعتماد محضر تسوية الجرد وتوليد السجل
// -----------------------------------------------------------------------------
@Composable
fun ReconcileConfirmationDialog(
  deficitCount: Int,
  surplusCount: Int,
  matchedCount: Int,
  deficitValue: Double,
  surplusValue: Double,
  netDiscrepancy: Double,
  currency: String,
  onDismiss: () -> Unit,
  onConfirm: (title: String, notes: String, applyToInventory: Boolean) -> Unit
) {
  val dateTag = SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH).format(Date())
  var sessionTitle by remember { mutableStateOf("تسوية جرد مخزني - $dateTag") }
  var auditorNotes by remember { mutableStateOf("مطابقة الجرد الفعلي للمخزن مع الأرصدة الدفترية وتوليد سجل التسوية") }
  var selectedReason by remember { mutableStateOf("تسوية جرد دوري شامل") }
  var applyToInventory by remember { mutableStateOf(true) }

  val reasons = listOf("تسوية جرد دوري شامل", "عجز وفقد مخزني", "تالف وهالك", "فائض توريد غير مقيد", "جرد مفاجئ")

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.95f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("تأكيد توليد سجل تسوية الجرد", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Stock Adjustment Record", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        HorizontalDivider()

        // بطاقة ملخص الفروقات
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.surfaceVariant,
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("ملخص نتائج الجرد الفعلي:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("• أصناف بها عجز: $deficitCount صنف (بقيمة: ${String.format(Locale.ENGLISH, "%.2f", deficitValue)} $currency)", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
            Text("• أصناف بها زيادة: $surplusCount صنف (بقيمة: ${String.format(Locale.ENGLISH, "%.2f", surplusValue)} $currency)", color = EmeraldPrimary, fontSize = 11.sp)
            Text("• أصناف مطابقة تماماً: $matchedCount صنف", fontSize = 11.sp)
            Text(
              "• صافي الفروقات المالية: ${String.format(Locale.ENGLISH, "%+.2f", netDiscrepancy)} $currency",
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              color = if (netDiscrepancy < 0) MaterialTheme.colorScheme.error else EmeraldPrimary
            )
          }
        }

        OutlinedTextField(
          value = sessionTitle,
          onValueChange = { sessionTitle = it },
          label = { Text("عنوان محضر التسوية *") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Text("سبب التسوية:", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(reasons) { r ->
            FilterChip(
              selected = selectedReason == r,
              onClick = {
                selectedReason = r
                auditorNotes = "$r - مطابقة الجرد الفعلي للمخزن"
              },
              label = { Text(r, fontSize = 11.sp) }
            )
          }
        }

        OutlinedTextField(
          value = auditorNotes,
          onValueChange = { auditorNotes = it },
          label = { Text("ملاحظات القائم بالجرد والتفاصيل") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        // خيار تحديث المخزن وتوليد قيود اليومية
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = EmeraldPrimary.copy(alpha = 0.08f),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              "تحديث أرصدة المخزن بالنظام وتوليد قيود تسوية العجز/الزيادة آلياً",
              fontSize = 11.sp,
              color = EmeraldPrimary,
              fontWeight = FontWeight.SemiBold
            )
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              onConfirm(sessionTitle.trim(), auditorNotes.trim(), applyToInventory)
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            modifier = Modifier.weight(1f)
          ) {
            Text("اعتماد وتوليد السجل الآن", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// نافذة عرض محضر وسجل تسوية الجرد المخزني المعتمد (Stock Adjustment Voucher)
// -----------------------------------------------------------------------------
@Composable
fun StockAdjustmentVoucherDialog(
  audit: StockAudit,
  isNewlyGenerated: Boolean,
  businessName: String,
  currency: String,
  viewModel: WholesaleViewModel,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val auditItems by viewModel.getStockAuditItems(audit.id).collectAsState(initial = emptyList())
  val dateStr = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale("ar")).format(Date(audit.auditDate))

  val deficitItems = auditItems.filter { it.diffQuantity < 0 }
  val surplusItems = auditItems.filter { it.diffQuantity > 0 }
  val matchedItems = auditItems.filter { it.diffQuantity == 0 }

  val reportText = buildString {
    appendLine("══════════════════════════════════════")
    appendLine("📦 محضر وسجل تسوية جرد مخزني رسمي")
    appendLine("المنشأة: $businessName")
    appendLine("رقم السجل: ADJ-${audit.id}")
    appendLine("العنوان: ${audit.title}")
    appendLine("التاريخ والوقت: $dateStr")
    if (audit.notes.isNotEmpty()) appendLine("الملاحظات: ${audit.notes}")
    appendLine("──────────────────────────────────────")
    appendLine("صافي الفروقات المالية: ${String.format(Locale.ENGLISH, "%+.2f", audit.totalDiscrepancyValue)} $currency")
    appendLine("أصناف العجز: ${deficitItems.size} صنف | أصناف الزيادة: ${surplusItems.size} صنف")
    appendLine("──────────────────────────────────────")
    appendLine("تفاصيل الأصناف المعدلة:")
    auditItems.forEach { item ->
      appendLine("• ${item.productName}: متوقع=${item.systemQuantity} | فعلي=${item.actualQuantity} | الفارق=${item.diffQuantity} (${String.format(Locale.ENGLISH, "%+.2f", item.diffCostValue)} $currency)")
    }
    appendLine("══════════════════════════════════════")
  }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.98f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp)
      ) {
        // شريط الرأس مع شارة التأكيد
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = EmeraldPrimary.copy(alpha = 0.15f),
              modifier = Modifier.size(36.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
              }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = if (isNewlyGenerated) "تم توليد سجل التسوية بنجاح!" else "محضر تسوية جرد مخزني",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = if (isNewlyGenerated) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
              )
              Text("رقم السجل: ADJ-${audit.id} • $dateStr", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // ملخص المحضر المالي
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(audit.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            if (audit.notes.isNotEmpty()) {
              Text(audit.notes, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "صافي أثر التسوية:",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = String.format(Locale.ENGLISH, "%+.2f %s", audit.totalDiscrepancyValue, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.sp,
                color = if (audit.totalDiscrepancyValue < 0) MaterialTheme.colorScheme.error else EmeraldPrimary
              )
            }
            Text(
              text = "${deficitItems.size} صنف عجز • ${surplusItems.size} صنف زيادة • ${matchedItems.size} صنف مطابق",
              fontSize = 10.5.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text("جدول مقارنة الأصناف وتسويتها:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))

        // قائمة الأصناف داخل المحضر
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.surfaceVariant,
          modifier = Modifier
            .fillMaxWidth()
            .height(250.dp)
        ) {
          LazyColumn(
            modifier = Modifier.padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            items(auditItems) { item ->
              Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(item.productName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(
                      text = "متوقع: ${item.systemQuantity} • فعلي: ${item.actualQuantity} • تكلفة: ${String.format(Locale.ENGLISH, "%.1f", item.unitPieceCost)} $currency",
                      fontSize = 10.sp,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }

                  Column(horizontalAlignment = Alignment.End) {
                    Text(
                      text = String.format(Locale.ENGLISH, "فارق: %+d قطعة", item.diffQuantity),
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = if (item.diffQuantity < 0) MaterialTheme.colorScheme.error else if (item.diffQuantity > 0) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                      text = String.format(Locale.ENGLISH, "(%+.1f %s)", item.diffCostValue, currency),
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = if (item.diffQuantity < 0) MaterialTheme.colorScheme.error else if (item.diffQuantity > 0) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // أزرار النسخ والمشاركة
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
              val clip = ClipData.newPlainText("Stock Audit Report", reportText)
              clipboard.setPrimaryClip(clip)
              Toast.makeText(context, "تم نسخ محضر التسوية إلى الحافظة بنجاح", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
          ) {
            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("نسخ المحضر", fontSize = 11.sp)
          }

          Button(
            onClick = {
              val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, reportText)
                type = "text/plain"
              }
              val shareIntent = Intent.createChooser(sendIntent, "مشاركة محضر التسوية عبر")
              context.startActivity(shareIntent)
            },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
          ) {
            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("مشاركة واتساب", fontSize = 11.sp)
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// نافذة تعديل رصيد الجرد المباشر لصنف منفرد
// -----------------------------------------------------------------------------
@Composable
fun QuickStockAdjustmentDialog(
  product: Product,
  onDismiss: () -> Unit,
  onConfirm: (deltaPieces: Int, reason: String) -> Unit
) {
  var isIncrease by remember { mutableStateOf(false) } // false = decrease, true = increase
  var quantityStr by remember { mutableStateOf("1") }
  var unitType by remember { mutableStateOf("كرتونة") }
  var reason by remember { mutableStateOf("تسوية جرد دورية") }

  val reasons = listOf("تسوية جرد دورية", "تالف أو كسر", "منتهي الصلاحية", "عجز مخزني", "فائض توريد")

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.95f)
    ) {
      Column(modifier = Modifier.padding(18.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("تعديل رصيد الجرد المباشر", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(product.name, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

        Text("نوع الحركة:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          Button(
            onClick = { isIncrease = false },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (!isIncrease) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.surfaceVariant,
              contentColor = if (!isIncrease) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
            )
          ) {
            Text("عجز / نقصان (-)", fontWeight = FontWeight.Bold)
          }
          Button(
            onClick = { isIncrease = true },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (isIncrease) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
              contentColor = if (isIncrease) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
            )
          ) {
            Text("زيادة / فائض (+)", fontWeight = FontWeight.Bold)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = quantityStr,
            onValueChange = { quantityStr = it },
            label = { Text("الكمية") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f)
          )
          Column(modifier = Modifier.weight(1f)) {
            Text("الوحدة:", fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              FilterChip(
                selected = unitType == "كرتونة",
                onClick = { unitType = "كرتونة" },
                label = { Text("كرتونة") }
              )
              FilterChip(
                selected = unitType == product.unitName,
                onClick = { unitType = product.unitName },
                label = { Text(product.unitName) }
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text("سبب التعديل:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(reasons) { r ->
            FilterChip(
              selected = reason == r,
              onClick = { reason = r },
              label = { Text(r, fontSize = 11.sp) }
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        val currentStock = product.totalPiecesInStock
        val qty = quantityStr.toIntOrNull() ?: 0
        val changePieces = if (unitType == "كرتونة") qty * product.piecesPerCarton else qty
        val delta = if (isIncrease) changePieces else -changePieces
        val newStock = (currentStock + delta).coerceAtLeast(0)

        Text(
          text = "الرصيد بعد التعديل: $newStock قطعة",
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(14.dp))

        Button(
          onClick = {
            if (qty > 0) {
              onConfirm(delta, reason)
            }
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isIncrease) EmeraldPrimary else MaterialTheme.colorScheme.error
          )
        ) {
          Text("تأكيد وتحديث رصيد المخزن", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
fun MetricSmallCard(
  title: String,
  value: String,
  containerColor: Color,
  contentColor: Color,
  modifier: Modifier = Modifier
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(10.dp),
    color = containerColor
  ) {
    Column(modifier = Modifier.padding(8.dp)) {
      Text(title, fontSize = 11.sp, color = contentColor.copy(alpha = 0.8f))
      Spacer(modifier = Modifier.height(2.dp))
      Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = contentColor)
    }
  }
}


