package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.GeneralLedgerEntry
import com.example.data.model.JournalEntry
import com.example.data.model.JournalLine
import com.example.data.model.TrialBalanceRow
import com.example.ui.WholesaleViewModel
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.CrimsonRed
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TrialBalanceTab(
  viewModel: WholesaleViewModel,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val rows by viewModel.trialBalance.collectAsStateWithLifecycle()
  val totals by viewModel.trialBalanceTotals.collectAsStateWithLifecycle()
  val isBalanced by viewModel.isTrialBalanceBalanced.collectAsStateWithLifecycle()
  var selectedAccountForLedger by remember { mutableStateOf<TrialBalanceRow?>(null) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 24.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // 1. Balance Status Banner
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
          containerColor = if (isBalanced) EmeraldPrimary.copy(alpha = 0.12f) else CrimsonRed.copy(alpha = 0.12f)
        )
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = if (isBalanced) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint = if (isBalanced) EmeraldPrimary else CrimsonRed,
            modifier = Modifier.size(28.dp)
          )
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = if (isBalanced) "ميزان المراجعة متزن 100% (القيد المزدوج سليم)" else "تنبيه: يوجد عدم اتزان في ميزان المراجعة",
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
              color = if (isBalanced) EmeraldPrimary else CrimsonRed
            )
            Text(
              text = "نظام القيد المزدوج (Double-Entry) يعمل تلقائياً بالخلفية لربط المبيعات والمشتريات والمخزون والخزينة.",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }

    // 2. Summary Totals Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text("إجمالي الحركات المدينة:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = String.format(Locale.ENGLISH, "%.2f ج.م", totals.first),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldPrimary
              )
            }
            Column(horizontalAlignment = Alignment.End) {
              Text("إجمالي الحركات الدائنة:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = String.format(Locale.ENGLISH, "%.2f ج.م", totals.second),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = OrangePrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))
          HorizontalDivider()
          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "الفارق بين المدين والدائن: ${String.format(Locale.ENGLISH, "%.2f ج.م", kotlin.math.abs(totals.first - totals.second))}",
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              color = if (isBalanced) EmeraldPrimary else CrimsonRed
            )

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              IconButton(
                onClick = {
                  val text = viewModel.getTrialBalanceReportText()
                  val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                  clipboard.setPrimaryClip(ClipData.newPlainText("Trial Balance", text))
                  Toast.makeText(context, "تم نسخ تقرير ميزان المراجعة", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(Icons.Default.ContentCopy, contentDescription = "نسخ", modifier = Modifier.size(16.dp))
              }

              IconButton(
                onClick = {
                  val text = viewModel.getTrialBalanceReportText()
                  val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "ميزان المراجعة المالي")
                    putExtra(Intent.EXTRA_TEXT, text)
                  }
                  context.startActivity(Intent.createChooser(shareIntent, "مشاركة ميزان المراجعة عبر واتساب"))
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(Icons.Default.Share, contentDescription = "مشاركة", tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
              }
            }
          }
        }
      }
    }

    // 3. Accounts Table Header
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
          .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("الحساب ودليل الحسابات", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(1.5f))
        Text("حركات مدينة", fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text("حركات دائنة", fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text("الرصيد النهائي", fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.weight(1.2f))
      }
    }

    // 4. Accounts List
    items(rows, key = { it.accountCode }) { row ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { selectedAccountForLedger = row },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Code & Name
            Column(modifier = Modifier.weight(1.5f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                ) {
                  Text(
                    text = row.accountCode,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                  )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = row.accountName,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
              }
              Text(
                text = "${row.category} (${if (row.normalBalance == "DEBIT") "طبيعته مدين" else "طبيعته دائن"})",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            // Debit
            Text(
              text = String.format(Locale.ENGLISH, "%.1f", row.totalDebit),
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium,
              color = if (row.totalDebit > 0) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.weight(1f)
            )

            // Credit
            Text(
              text = String.format(Locale.ENGLISH, "%.1f", row.totalCredit),
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium,
              color = if (row.totalCredit > 0) OrangePrimary else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.weight(1f)
            )

            // Net Balance
            Column(modifier = Modifier.weight(1.2f), horizontalAlignment = Alignment.End) {
              if (row.netDebitBalance > 0) {
                Text(
                  text = String.format(Locale.ENGLISH, "%.1f مدين", row.netDebitBalance),
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = EmeraldPrimary
                )
              } else if (row.netCreditBalance > 0) {
                Text(
                  text = String.format(Locale.ENGLISH, "%.1f دائن", row.netCreditBalance),
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = OrangePrimary
                )
              } else {
                Text(
                  text = "0.0 متزن",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Medium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              Text("اضغط لعرض الأستاذ", fontSize = 9.sp, color = MaterialTheme.colorScheme.primary)
            }
          }
        }
      }
    }
  }

  // General Ledger Dialog
  selectedAccountForLedger?.let { accountRow ->
    GeneralLedgerDialog(
      account = accountRow,
      viewModel = viewModel,
      onDismiss = { selectedAccountForLedger = null }
    )
  }
}

@Composable
fun GeneralLedgerDialog(
  account: TrialBalanceRow,
  viewModel: WholesaleViewModel,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val ledgerEntries = remember(account.accountCode) {
    viewModel.getLedgerForAccount(account.accountCode)
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .clip(RoundedCornerShape(18.dp)),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "دفتر أستاذ: ${account.accountName}",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
              )
              Text(
                text = "كود الحساب: ${account.accountCode} • ${account.category}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(10.dp))

        // Ledger Table Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 8.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("التاريخ / البيان", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
          Text("مدين (+)", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
          Text("دائن (-)", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
          Text("الرصيد التراكمي", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Ledger Entries List
        LazyColumn(
          modifier = Modifier
            .weight(1f, fill = false)
            .fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          if (ledgerEntries.isEmpty()) {
            item {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(24.dp),
                contentAlignment = Alignment.Center
              ) {
                Text("لا توجد حركات مقيدة على هذا الحساب حالياً.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }

          items(ledgerEntries) { entry ->
            val dateStr = SimpleDateFormat("dd/MM HH:mm", Locale.ENGLISH).format(Date(entry.timestamp))
            Card(
              modifier = Modifier.fillMaxWidth(),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
              shape = RoundedCornerShape(8.dp)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1.5f)) {
                  Text(text = entry.description, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                  Text(text = "$dateStr • ${entry.entryNumber}", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Text(
                  text = if (entry.debit > 0) String.format(Locale.ENGLISH, "%.1f", entry.debit) else "-",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (entry.debit > 0) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.weight(0.8f)
                )

                Text(
                  text = if (entry.credit > 0) String.format(Locale.ENGLISH, "%.1f", entry.credit) else "-",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (entry.credit > 0) OrangePrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.weight(0.8f)
                )

                Text(
                  text = String.format(Locale.ENGLISH, "%.1f", entry.runningBalance),
                  fontSize = 11.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.weight(1f)
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Total Summary
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "إجمالي الحركات: ${ledgerEntries.size} قيد",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = "الرصيد الختامي: ${if (account.netDebitBalance > 0) "${account.netDebitBalance} ج.م مدين" else "${account.netCreditBalance} ج.م دائن"}",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Action Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val sb = StringBuilder()
              sb.appendLine("📖 *دفتر أستاذ حساب ${account.accountName} (${account.accountCode})*")
              sb.appendLine("--------------------------------")
              ledgerEntries.forEach { e ->
                sb.appendLine("• ${e.description}")
                sb.appendLine("  مدين: ${e.debit} | دائن: ${e.credit} | الرصيد: ${e.runningBalance}")
              }
              sb.appendLine("--------------------------------")
              sb.appendLine("الرصيد النهائي: ${if (account.netDebitBalance > 0) "${account.netDebitBalance} مدين" else "${account.netCreditBalance} دائن"}")

              val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "دفتر أستاذ ${account.accountName}")
                putExtra(Intent.EXTRA_TEXT, sb.toString())
              }
              context.startActivity(Intent.createChooser(shareIntent, "مشاركة دفتر الأستاذ عبر واتساب"))
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("مشاركة عبر واتساب", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f)
          ) {
            Text("إغلاق", fontSize = 12.sp)
          }
        }
      }
    }
  }
}

@Composable
fun JournalEntriesTab(
  viewModel: WholesaleViewModel,
  modifier: Modifier = Modifier
) {
  val journalEntries by viewModel.journalEntries.collectAsStateWithLifecycle()
  val journalLines by viewModel.journalLines.collectAsStateWithLifecycle()
  val linesByEntry = remember(journalLines) {
    journalLines.groupBy { it.entryId }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 24.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text("دفتر اليومية العامة الآلي (Double-Entry)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(
              "يسجل النظام تلقائياً قيود اليومية المحاسبية المزدوجة لكل عملية بيع أو شراء أو سداد أو جرد لضمان سلامة ميزان المراجعة.",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }

    if (journalEntries.isEmpty()) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(40.dp),
          contentAlignment = Alignment.Center
        ) {
          Text("لا توجد قيود يومية مسجلة بعد", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    }

    items(journalEntries, key = { it.id }) { entry ->
      JournalEntryCard(entry = entry, lines = linesByEntry[entry.id] ?: emptyList())
    }
  }
}

@Composable
fun JournalEntryCard(
  entry: JournalEntry,
  lines: List<JournalLine>
) {
  var isExpanded by remember { mutableStateOf(false) }
  val dateStr = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")).format(Date(entry.timestamp))

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { isExpanded = !isExpanded },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = when (entry.referenceType) {
              "SALE" -> EmeraldPrimary.copy(alpha = 0.2f)
              "PURCHASE" -> OrangePrimary.copy(alpha = 0.2f)
              "CUSTOMER_PAYMENT" -> EmeraldPrimary.copy(alpha = 0.15f)
              "SUPPLIER_PAYMENT" -> CrimsonRed.copy(alpha = 0.15f)
              "EXPENSE" -> CrimsonRed.copy(alpha = 0.15f)
              "AUDIT" -> MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
              else -> MaterialTheme.colorScheme.surfaceVariant
            }
          ) {
            Text(
              text = when (entry.referenceType) {
                "SALE" -> "بيع جملة"
                "PURCHASE" -> "شراء وتوريد"
                "CUSTOMER_PAYMENT" -> "سند قبض"
                "SUPPLIER_PAYMENT" -> "سند صرف"
                "EXPENSE" -> "مصروفات"
                "AUDIT" -> "تسوية جرد"
                "OPENING" -> "قيد افتتاحي"
                else -> "قيد عام"
              },
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = when (entry.referenceType) {
                "SALE" -> EmeraldPrimary
                "PURCHASE" -> OrangePrimary
                "SUPPLIER_PAYMENT", "EXPENSE" -> CrimsonRed
                else -> MaterialTheme.colorScheme.primary
              },
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
            )
          }

          Spacer(modifier = Modifier.width(8.dp))

          Column {
            Text(entry.description, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("${entry.entryNumber} • $dateStr", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Column(horizontalAlignment = Alignment.End) {
            Text(
              text = String.format(Locale.ENGLISH, "%.2f ج.م", entry.totalDebit),
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              color = MaterialTheme.colorScheme.primary
            )
            Text("متزن ✓", fontSize = 9.sp, color = EmeraldPrimary, fontWeight = FontWeight.Bold)
          }
          IconButton(onClick = { isExpanded = !isExpanded }, modifier = Modifier.size(28.dp)) {
            Icon(
              imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
              contentDescription = null
            )
          }
        }
      }

      // Expanded lines details
      AnimatedVisibility(visible = isExpanded) {
        Column(modifier = Modifier.padding(top = 10.dp)) {
          HorizontalDivider()
          Spacer(modifier = Modifier.height(8.dp))

          lines.forEach { line ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1.5f)) {
                Text("${line.accountCode} - ${line.accountName}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                if (line.notes.isNotBlank()) {
                  Text(line.notes, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }

              if (line.debit > 0) {
                Text(
                  text = "منه (مدين): ${String.format(Locale.ENGLISH, "%.2f", line.debit)}",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = EmeraldPrimary
                )
              } else {
                Text(
                  text = "له (دائن): ${String.format(Locale.ENGLISH, "%.2f", line.credit)}",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = OrangePrimary
                )
              }
            }
          }
        }
      }
    }
  }
}
