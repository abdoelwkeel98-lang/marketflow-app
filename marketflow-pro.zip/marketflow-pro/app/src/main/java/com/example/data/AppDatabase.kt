package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.AppDao
import com.example.data.model.Account
import com.example.data.model.Customer
import com.example.data.model.Expense
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItem
import com.example.data.model.InvoiceType
import com.example.data.model.JournalEntry
import com.example.data.model.JournalLine
import com.example.data.model.PaymentTransaction
import com.example.data.model.PaymentType
import com.example.data.model.Product
import com.example.data.model.StockAudit
import com.example.data.model.StockAuditItem
import com.example.data.model.Supplier
import com.example.data.model.TransactionType
import com.example.data.model.Employee
import com.example.data.model.DelegateSyncLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [
    Product::class,
    Customer::class,
    Supplier::class,
    Invoice::class,
    InvoiceItem::class,
    PaymentTransaction::class,
    Expense::class,
    StockAudit::class,
    StockAuditItem::class,
    Account::class,
    JournalEntry::class,
    JournalLine::class,
    Employee::class,
    DelegateSyncLog::class
  ],
  version = 4,
  exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
  abstract fun appDao(): AppDao

  companion object {
    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AppDatabase::class.java,
          "alwakeel_food_database"
        )
          .fallbackToDestructiveMigration()
          .addCallback(DatabaseCallback(scope))
          .build()
        INSTANCE = instance
        instance
      }
    }

    private class DatabaseCallback(
      private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
      override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        INSTANCE?.let { database ->
          scope.launch(Dispatchers.IO) {
            populateInitialData(database.appDao())
          }
        }
      }
    }

    suspend fun populateInitialData(dao: AppDao) {
      if (dao.getAccountsCount() > 0) return

      // Initialize Standard Chart of Accounts only (دليل الحسابات المحاسبي الموحد - بدون أي بيانات أولية أو فواتير أو عملاء)
      val defaultAccounts = listOf(
        Account(
          code = "101",
          name = "الصندوق والخزينة النقدية",
          category = "أصول متداولة",
          normalBalance = "DEBIT",
          description = "النقدية السائلة بالدرج والخزينة الرئيسية"
        ),
        Account(
          code = "102",
          name = "العملاء والمدينون (حسابات السوق)",
          category = "أصول متداولة",
          normalBalance = "DEBIT",
          description = "المبالغ المستحقة على العملاء الآجلين"
        ),
        Account(
          code = "103",
          name = "مخزون البضاعة (نظام الجرد المستمر)",
          category = "أصول متداولة",
          normalBalance = "DEBIT",
          description = "قيمة بضاعة المخزن بالتكلفة المحسوبة بالمتوسط المترجح WAC"
        ),
        Account(
          code = "201",
          name = "الموردون والدائنون (شركات التوزيع)",
          category = "خصوم متداولة",
          normalBalance = "CREDIT",
          description = "المستحقات الواجبة للموردين والشركات الموردة"
        ),
        Account(
          code = "301",
          name = "رأس المال وحقوق الملكية",
          category = "حقوق الملكية",
          normalBalance = "CREDIT",
          description = "رأس المال التجاري المستثمر بالمشروع"
        ),
        Account(
          code = "401",
          name = "إيرادات مبيعات البضاعة",
          category = "إيرادات",
          normalBalance = "CREDIT",
          description = "مبيعات المحل والجملة الإجمالية"
        ),
        Account(
          code = "501",
          name = "تكلفة البضاعة المباعة (COGS)",
          category = "تكلفة المبيعات",
          normalBalance = "DEBIT",
          description = "تكلفة السلع المباعة بالمتوسط المترجح للجرد المستمر"
        ),
        Account(
          code = "502",
          name = "المصروفات العمومية والتشغيلية",
          category = "مصروفات تشغيلية",
          normalBalance = "DEBIT",
          description = "إيجار، كهرباء، عمالة، مشالات، نثريات"
        ),
        Account(
          code = "503",
          name = "فروقات وتسويات عجز المخزون",
          category = "مصروفات تشغيلية",
          normalBalance = "DEBIT",
          description = "التسويات الدورية الناتجة عن الجرد الفعلي للمخزن"
        )
      )
      dao.insertAccounts(defaultAccounts)

      // Initialize Default Employees if empty
      if (dao.getEmployeeCount() == 0) {
        val manager = Employee(
          name = "المدير العام",
          phone = "01000000000",
          pinCode = "1234",
          role = "مدير عام",
          isDelegate = false,
          isActive = true,
          canSell = true,
          canViewCostPrice = true,
          canViewProfits = true,
          canGiveDiscount = true,
          canManualPriceOverride = true,
          canPurchase = true,
          canManageWarehouse = true,
          canManageCustomers = true,
          canCollectCash = true,
          canDeleteInvoice = true,
          canAccessReports = true,
          canAccessSettings = true,
          pairingCode = "WAKEEL-SYNC-7824"
        )
        dao.insertEmployee(manager)

        val delegate = Employee(
          name = "أحمد فتحي (مندوب توزيع)",
          phone = "01123456789",
          pinCode = "2222",
          role = "مندوب مبيعات",
          isDelegate = true,
          isActive = true,
          canSell = true,
          canViewCostPrice = false,
          canViewProfits = false,
          canGiveDiscount = true,
          canManualPriceOverride = false,
          canPurchase = false,
          canManageWarehouse = false,
          canManageCustomers = true,
          canCollectCash = true,
          canDeleteInvoice = false,
          canAccessReports = false,
          canAccessSettings = false,
          pairingCode = "WAKEEL-SYNC-7824"
        )
        dao.insertEmployee(delegate)
      }
    }
  }
}
