package com.example.ui.components

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.WholesaleViewModel
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import com.example.utils.BackupManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * نافذة منبثقة متطورة للنسخ الاحتياطي واستعادة البيانات
 * - تعرض آخر نسخة احتياطية محفوظة على ذاكرة الهاتف دون الحاجة للدخول للملفات
 * - زر استعادة فوري بنقرة واحدة
 * - تفعيل النسخ اليومي التلقائي
 * - تحديد مجلد الحفظ في ذاكرة الهاتف
 * - استبدال النسخة القديمة بالنسخة الحديثة لتبقى دائماً نسخة واحدة فقط
 */
@Composable
fun BackupRestoreDialog(
  viewModel: WholesaleViewModel,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val profile by viewModel.businessProfile.collectAsStateWithLifecycle()

  var isLoadingLatestBackup by remember { mutableStateOf(true) }
  var latestBackupSummary by remember { mutableStateOf<BackupManager.BackupSummary?>(null) }
  var isBackingUpNow by remember { mutableStateOf(false) }
  var isRestoringNow by remember { mutableStateOf(false) }
  var showConfirmRestoreDialog by remember { mutableStateOf(false) }
  var customBackupJsonToRestore by remember { mutableStateOf<String?>(null) }

  val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f

  // قراءة وفحص آخر نسخة احتياطية عند فتح النافذة
  fun loadLatestBackup() {
    scope.launch {
      isLoadingLatestBackup = true
      val summary = viewModel.getLatestBackupSummary()
      latestBackupSummary = summary
      isLoadingLatestBackup = false
    }
  }

  LaunchedEffect(Unit) {
    loadLatestBackup()
  }

  // منتقي مجلد الحفظ في ذاكرة الهاتف Storage Access Framework
  val folderPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocumentTree()
  ) { uri: Uri? ->
    if (uri != null) {
      try {
        context.contentResolver.takePersistableUriPermission(
          uri,
          Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
      } catch (_: Exception) {}

      val folderName = uri.lastPathSegment?.substringAfterLast(":") ?: "مجلد المستندات المحدد"
      viewModel.setBackupFolder(uri, "ذاكرة الهاتف / $folderName")
      Toast.makeText(context, "تم تحديد مجلد الحفظ بنجاح: $folderName", Toast.LENGTH_SHORT).show()
      loadLatestBackup()
    }
  }

  // منتقي ملف نسخة احتياطية خارجية (في حال رغب المستخدم باختيار ملف محدد)
  val filePickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument()
  ) { uri: Uri? ->
    if (uri != null) {
      scope.launch(Dispatchers.IO) {
        try {
          val jsonText = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
          if (!jsonText.isNullOrBlank()) {
            withContext(Dispatchers.Main) {
              customBackupJsonToRestore = jsonText
              showConfirmRestoreDialog = true
            }
          } else {
            withContext(Dispatchers.Main) {
              Toast.makeText(context, "الملف فارغ أو غير صالح", Toast.LENGTH_SHORT).show()
            }
          }
        } catch (e: Exception) {
          withContext(Dispatchers.Main) {
            Toast.makeText(context, "خطأ في قراءة ملف النسخة: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
          }
        }
      }
    }
  }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp,
      border = if (isDark) BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)) else null,
      modifier = Modifier
        .fillMaxWidth(0.98f)
        .padding(vertical = 12.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        // رأس النافذة
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = CircleShape,
              color = OrangePrimary.copy(alpha = 0.15f),
              modifier = Modifier.size(42.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.CloudSync,
                  contentDescription = null,
                  tint = OrangePrimary,
                  modifier = Modifier.size(24.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "النسخ الاحتياطي واستعادة البيانات",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "أمان البيانات والحفظ الذاتي على ذاكرة الهاتف",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

        // 1. بطاقة تحديد مجلد الحفظ في ذاكرة الهاتف
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Folder, contentDescription = null, tint = OrangePrimary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("مجلد الحفظ في الهاتف:", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
              }
              TextButton(
                onClick = { folderPickerLauncher.launch(null) },
                shape = RoundedCornerShape(8.dp)
              ) {
                Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تغيير المجلد", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
              }
            }

            Text(
              text = profile.backupFolderDisplayName.ifBlank { "ذاكرة الهاتف / مجلد المستندات Documents" },
              fontSize = 11.5.sp,
              color = MaterialTheme.colorScheme.onSurface,
              fontWeight = FontWeight.Medium
            )

            Text(
              text = "📌 ميزة الاستبدال التلقائي: يتم حفظ نسخة واحدة فقط وتحديثها تلقائياً لتوفير المساحة وتجنب التكرار.",
              fontSize = 10.5.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              lineHeight = 15.sp
            )
          }
        }

        // 2. خيار النسخ الاحتياطي التلقائي اليومي
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text("النسخ الاحتياطي اليومي التلقائي", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("حفظ نسخة جديدة يومياً واستبدال القديمة تلقائياً دون تدخل منك", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Switch(
            checked = profile.autoBackupEnabled,
            onCheckedChange = { checked ->
              viewModel.updateBusinessProfile(profile.copy(autoBackupEnabled = checked))
              if (checked) {
                Toast.makeText(context, "تم تفعيل النسخ اليومي التلقائي ✓", Toast.LENGTH_SHORT).show()
              }
            },
            colors = SwitchDefaults.colors(
              checkedThumbColor = Color.White,
              checkedTrackColor = OrangePrimary
            )
          )
        }

        // 3. قسم: آخر نسخة احتياطية تم حفظها على الهاتف (للاستعادة السريعة)
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (latestBackupSummary != null) {
              EmeraldPrimary.copy(alpha = if (isDark) 0.18f else 0.08f)
            } else {
              MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            }
          ),
          border = BorderStroke(
            1.5.dp,
            if (latestBackupSummary != null) EmeraldPrimary.copy(alpha = 0.45f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
          )
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = if (latestBackupSummary != null) Icons.Default.CheckCircle else Icons.Default.Info,
                  contentDescription = null,
                  tint = if (latestBackupSummary != null) EmeraldPrimary else MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "آخر نسخة احتياطية على الهاتف",
                  fontWeight = FontWeight.ExtraBold,
                  fontSize = 14.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
              }

              if (isLoadingLatestBackup) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
              } else {
                IconButton(onClick = { loadLatestBackup() }, modifier = Modifier.size(28.dp)) {
                  Icon(Icons.Default.Autorenew, contentDescription = "تحديث", modifier = Modifier.size(16.dp))
                }
              }
            }

            if (latestBackupSummary != null) {
              val backup = latestBackupSummary!!

              // تفاصيل النسخة
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(10.dp))
                  .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("📅 تاريخ ووقت النسخة:", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(backup.dateFormatted, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("💾 حجم ملف النسخة:", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(backup.fileSizeFormatted, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                Text("📊 محتويات وسجلات النسخة المحفوظة:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("📦 الأصناف والمنتجات:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text("${backup.productsCount} صنف", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("👥 العملاء والموردين:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text("${backup.customersCount + backup.suppliersCount} حساب", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("🧾 فواتير البيع والشراء:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text("${backup.invoicesCount} فاتورة", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("💵 سندات الخزينة والمصروفات:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text("${backup.transactionsCount + backup.expensesCount} معاملة", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
              }

              // زر الاستعادة الفوري المباشر دون الحاجة للملفات
              Button(
                onClick = {
                  customBackupJsonToRestore = backup.rawJson
                  showConfirmRestoreDialog = true
                },
                enabled = !isRestoringNow,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.fillMaxWidth()
              ) {
                if (isRestoringNow) {
                  CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("جاري استعادة البيانات...", fontWeight = FontWeight.Bold)
                } else {
                  Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("استعادة هذه النسخة الآن بنقرة واحدة ✓", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                }
              }
            } else {
              // في حال لم يتم العثور على نسخة سابقة
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(10.dp))
                  .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Text(
                  text = "لا توجد نسخة احتياطية محفوظة حالياً في هذا المجلد",
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = "اضغط على زر (إنشاء نسخة احتياطية الآن) بالأسفل لحفظ أول نسخة في ذاكرة هاتفك فوراً.",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  lineHeight = 15.sp
                )
              }
            }
          }
        }

        // 4. أزرار الإجراءات الإضافية: إنشاء نسخة فورية / مشاركة / استيراد ملف
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // زر نسخ احتياطي فوري واستبدال النسخة
          Button(
            onClick = {
              isBackingUpNow = true
              viewModel.performBackup { result ->
                isBackingUpNow = false
                if (result.success) {
                  Toast.makeText(context, "تم حفظ النسخة الاحتياطية واستبدال القديمة بنجاح ✓", Toast.LENGTH_SHORT).show()
                  loadLatestBackup()
                } else {
                  Toast.makeText(context, "فشل النسخ: ${result.errorMessage}", Toast.LENGTH_LONG).show()
                }
              }
            },
            enabled = !isBackingUpNow,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
            modifier = Modifier.weight(1.3f)
          ) {
            if (isBackingUpNow) {
              CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
              Spacer(modifier = Modifier.width(6.dp))
              Text("جاري الحفظ...", fontSize = 11.5.sp)
            } else {
              Icon(Icons.Default.Backup, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("إنشاء نسخة احتياطية الآن 💾", fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
            }
          }

          // زر مشاركة النسخة كملف خارجي
          OutlinedButton(
            onClick = {
              latestBackupSummary?.let { summary ->
                try {
                  val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "نسخة احتياطية لنظام الوكيل لتجارة المواد الغذائية")
                    putExtra(Intent.EXTRA_TEXT, summary.rawJson)
                  }
                  context.startActivity(Intent.createChooser(shareIntent, "مشاركة النسخة الاحتياطية"))
                } catch (e: Exception) {
                  Toast.makeText(context, "تعذر مشاركة الملف: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
              } ?: run {
                Toast.makeText(context, "يرجى إنشاء نسخة احتياطية أولاً للمشاركة", Toast.LENGTH_SHORT).show()
              }
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(0.7f)
          ) {
            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("مشاركة", fontSize = 11.sp)
          }
        }

        // خيار استعادة ملف من الذاكرة (خيار إضافي مرن)
        TextButton(
          onClick = { filePickerLauncher.launch(arrayOf("*/*")) },
          modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
          Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("اختيار ملف نسخة احتياطية خارجي من الذاكرة...", fontSize = 11.5.sp)
        }
      }
    }
  }

  // نافذة تأكيد الاستعادة لحماية البيانات من الاستبدال غير المقصود
  if (showConfirmRestoreDialog && customBackupJsonToRestore != null) {
    AlertDialog(
      onDismissRequest = { showConfirmRestoreDialog = false },
      icon = {
        Icon(Icons.Default.Warning, contentDescription = null, tint = OrangePrimary, modifier = Modifier.size(36.dp))
      },
      title = {
        Text("تأكيد استعادة النسخة الاحتياطية", fontWeight = FontWeight.Bold, fontSize = 16.sp)
      },
      text = {
        Text(
          "⚠️ تنبيه أمان هام:\n\nاستعادة النسخة الاحتياطية ستقوم باستبدال كافة البيانات الحالية بالكامل (المنتجات، فواتير المبيعات والمشتريات، الخزينة، الحسابات والعملاء) ببيانات النسخة المحددة.\n\nهل أنت متأكد من رغبتك في المتابعة والاستعادة الآن؟",
          fontSize = 12.5.sp,
          lineHeight = 18.sp,
          color = MaterialTheme.colorScheme.onSurface
        )
      },
      confirmButton = {
        Button(
          onClick = {
            showConfirmRestoreDialog = false
            isRestoringNow = true
            viewModel.restoreFromBackup(customBackupJsonToRestore!!) { success ->
              isRestoringNow = false
              if (success) {
                Toast.makeText(context, "تمت استعادة كافة البيانات وقاعدة البيانات بنجاح تام ✓", Toast.LENGTH_LONG).show()
                onDismiss()
              } else {
                Toast.makeText(context, "فشلت استعادة النسخة، يرجى التأكد من سلامة الملف", Toast.LENGTH_LONG).show()
              }
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
        ) {
          Text("نعم، استعادة البيانات الآن", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        OutlinedButton(onClick = { showConfirmRestoreDialog = false }) {
          Text("إلغاء")
        }
      }
    )
  }
}
