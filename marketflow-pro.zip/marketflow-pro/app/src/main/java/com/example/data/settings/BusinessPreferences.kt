package com.example.data.settings

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class BusinessProfile(
  val isLoggedIn: Boolean = true,
  val phoneNumber: String = "01001234567",
  val userName: String = "عبد الرحمن الوكيل",
  val userRole: String = "أدمن (مدير عام)", // أدمن (مدير عام), كاشير, محاسب
  val businessName: String = "الوكيل لتجارة المواد الغذائية",
  val businessType: String = "تجارة مواد غذائية ومخزن جملة",
  val currency: String = "ج.م",
  val contactPhone: String = "01001234567",
  val address: String = "شارع السوق التجاري - مخازن الوكيل، القاهرة",
  val taxNumber: String = "982-415-321",
  val commercialRecord: String = "CR-74892",
  val selectedCashbox: String = "الخزينة الرئيسية (درج النقدية)",
  val printerType: String = "حراري 80mm", // حراري 80mm, حراري 58mm, A4
  val bluetoothPrinterName: String = "POS-80BT (متصل)",
  val receiptFooterNote: String = "شكراً لتعاملكم معنا، البضاعة المباعة ترد خلال 14 يوماً بالفاتورة",
  val isDarkMode: Boolean = false,
  val autoBackupEnabled: Boolean = true,
  val lastBackupTime: Long = System.currentTimeMillis() - 86400000L,
  val backupFolderUri: String = "",
  val backupFolderDisplayName: String = "ذاكرة الهاتف / مجلد المستندات Documents",
  val lastBackupFileName: String = "ALWAKEEL_ERP_LATEST_BACKUP.sanad",
  val lastBackupSizeFormatted: String = "",
  val lastBackupSummary: String = "",

  // ================= إعدادات شاشة المبيعات والكاشير =================
  val salesDefaultPaymentType: String = "نقدي", // نقدي, آجل, دفع جزئي
  val salesDefaultPricingTier: String = "قطاعي (مستهلك)", // قطاعي (مستهلك), جملة, جملة الجملة
  val salesPreventNegativeStock: Boolean = false, // منع البيع بالسالب عند نفاد الكمية
  val salesWarnBelowCost: Boolean = true, // تحذير عند البيع بأقل من سعر التكلفة
  val salesAllowSellingBelowCost: Boolean = false, // السماح بالبيع بأقل من سعر التكلفة
  val salesAllowSellingBelowInvoiceTotal: Boolean = true, // السماح بالبيع بأقل من قيمة الفاتورة وقبول دفع أقل
  val salesEnableDiscount: Boolean = true, // تفعيل ميزة الخصم في شاشة المبيعات
  val salesDefaultDiscountType: String = "مبلغ", // نوع الخصم: "مبلغ" أو "نسبة مئوية"
  val salesMaxDiscountPercent: Double = 30.0, // الحد الأقصى للخصم المسموح به %
  val salesAllowItemLevelDiscount: Boolean = true, // السماح بالخصم على مستوى الصنف الفردي
  val salesAllowCustomInvoiceDate: Boolean = true, // السماح بتعديل تاريخ ووقت الفاتورة
  val salesAllowManualPriceOverride: Boolean = true, // السماح بتعديل سعر بيع الصنف يدوياً
  val salesDefaultUnit: String = "علبة", // الوحدة الأساسية في المبيعات علبة
  val salesRequireCustomerSelection: Boolean = false, // اشتراط اختيار عميل مسجل لكل فاتورة
  val salesAutoMergeDuplicateItems: Boolean = true, // دمج كميات الصنف المكرر في السلة
  val salesEnableInvoiceNotes: Boolean = true, // إمكانية إضافة ملاحظات على الفاتورة
  val salesConfirmClearCart: Boolean = true, // تأكيد قبل تفريغ السلة
  val salesAutoPrintReceipt: Boolean = false, // طباعة الفاتورة تلقائياً بعد الحفظ
  val salesShowProfitToCashier: Boolean = false, // إظهار هامش ربح الفاتورة للكاشير
  val salesBarcodeAddSinglePieceDirectly: Boolean = true, // إضافة قطعة واحدة مباشرة عند مسح الباركود
  val salesDefaultCustomerName: String = "عميل نقدي عام",
  val salesEnableQuickPaymentButtons: Boolean = true, // أزرار فئات النقدية السريعة وحساب الباقي للعميل
  val salesCheckCustomerCreditLimit: Boolean = true, // التحقق من سقف الدين والحد الائتماني للعميل
  val salesEnableRoundTotal: Boolean = false, // تقريب كسور المبالغ لأقرب جنيه تلقائياً

  // ================= إعدادات شاشة المشتريات والتوريد =================
  val purchasesDefaultPaymentType: String = "نقدي (من الخزينة)", // نقدي (من الخزينة), آجل للمورد
  val purchasesUpdateCostAutomatically: Boolean = true, // تحديث سعر التكلفة بآخر سعر شراء
  val purchasesWarnIfCostIncreased: Boolean = true, // تنبيه عند ارتفاع سعر الشراء عن السابق
  val purchasesDefaultUnit: String = "كرتونة", // الوحدة الأساسية في المشتريات كرتونة
  val purchasesAllowManualPriceOverride: Boolean = true, // السماح بتعديل سعر شراء الصنف يدوياً
  val purchasesRequireInvoiceNumber: Boolean = false, // اشتراط رقم فاتورة المورد
  val purchasesDefaultSupplierName: String = "مورد عام نقدي",

  // ================= إعدادات المخازن والجرد والأصناف =================
  val warehouseLowStockThreshold: Int = 5, // الحد الأدنى للتنبيه بالنواقص
  val warehouseEnableLowStockAlerts: Boolean = true, // تفعيل إشعارات وتنبيهات النواقص
  val warehouseValuationMethod: String = "متوسط التكلفة المرجح", // متوسط التكلفة المرجح, آخر سعر شراء
  val warehouseShowCartonsAndPieces: Boolean = true, // إظهار الرصيد بالكرتونة والقطعة معاً
  val warehouseAutoReconciliationAudit: Boolean = true, // إنشاء قيد وسجل تسوية مخزنية تلقائياً

  // ================= إعدادات الخزينة والمالية والضرائب =================
  val vatTaxEnabled: Boolean = false, // تفعيل ضريبة القيمة المضافة
  val vatTaxRatePercent: Double = 14.0, // نسبة الضريبة المئوية %
  val vatTaxIncludedInPrice: Boolean = true, // الأسعار شاملة الضريبة
  val treasuryMaxDrawerLimit: Double = 10000.0, // الحد الأقصى للنقدية في الدرج
  val treasuryRequireShiftClosureApproval: Boolean = false, // اشتراط موافقة المدير لإغلاق الوردية

  // ================= إعدادات الطابعة وفواتير الإيصالات =================
  val receiptHeaderTitle: String = "فاتورة ضريبية مبسطة",
  val receiptPrintQrCode: Boolean = true, // طباعة رمز الاستجابة السريع QR
  val receiptPrintCustomerBalance: Boolean = true, // طباعة الرصيد السابق والمتبقي على العميل
  val receiptCopiesCount: Int = 1, // عدد النسخ المطبوعة

  // ================= إعدادات الصلاحيات والأمان =================
  val securityRequireAdminPasswordForDelete: Boolean = true, // طلب إذن المدير لحذف الفواتير
  val securityHideProfitsFromCashier: Boolean = true, // حجب تقارير الأرباح عن الكاشير
  val securityLockInvoicesAfterIssue: Boolean = true, // قفل الفواتير بعد إصدارها ومنع التعديل المباشر

  // ================= إعدادات الصوت والماسح =================
  val soundBeepOnScan: Boolean = true, // نغمة صوتية عند مسح الباركود بنجاح
  val vibrateOnScan: Boolean = true, // اهتزاز عند مسح الباركود

  // ================= إعدادات تعدد الموظفين والمناديب والمزامنة =================
  val activeEmployeeId: Long = 1L,
  val activeEmployeeName: String = "المدير العام",
  val activeEmployeeRole: String = "مدير عام",
  val activeEmployeePin: String = "1234",
  val deviceRole: String = "MANAGER", // "MANAGER" (جهاز المدير الرئيسي), "DELEGATE" (جهاز المندوب الميداني)
  val companySyncKey: String = "WAKEEL-SYNC-7824", // مفتاح الربط المشترك
  val delegateEmployeeId: Long = 0L,
  val delegateEmployeeName: String = "",
  val autoSyncWhenOnline: Boolean = true,
  val lastSyncTimestamp: Long = 0L,
  val lastSyncSummary: String = ""
)

class BusinessPreferences(context: Context) {
  private val prefs: SharedPreferences =
    context.getSharedPreferences("wholesale_supermarket_prefs", Context.MODE_PRIVATE)

  private val _profile = MutableStateFlow(loadProfile())
  val profile: StateFlow<BusinessProfile> = _profile.asStateFlow()

  private fun loadProfile(): BusinessProfile {
    return BusinessProfile(
      isLoggedIn = prefs.getBoolean("is_logged_in", true),
      phoneNumber = prefs.getString("phone_number", "01001234567") ?: "01001234567",
      userName = prefs.getString("user_name", "عبد الرحمن الوكيل") ?: "عبد الرحمن الوكيل",
      userRole = prefs.getString("user_role", "أدمن (مدير عام)") ?: "أدمن (مدير عام)",
      businessName = prefs.getString("business_name", "الوكيل لتجارة المواد الغذائية") ?: "الوكيل لتجارة المواد الغذائية",
      businessType = prefs.getString("business_type", "تجارة مواد غذائية ومخزن جملة") ?: "تجارة مواد غذائية ومخزن جملة",
      currency = prefs.getString("currency", "ج.م") ?: "ج.م",
      contactPhone = prefs.getString("contact_phone", "01001234567") ?: "01001234567",
      address = prefs.getString("address", "شارع السوق التجاري - مخازن الوكيل، القاهرة") ?: "شارع السوق التجاري - مخازن الوكيل، القاهرة",
      taxNumber = prefs.getString("tax_number", "982-415-321") ?: "982-415-321",
      commercialRecord = prefs.getString("commercial_record", "CR-74892") ?: "CR-74892",
      selectedCashbox = prefs.getString("selected_cashbox", "الخزينة الرئيسية (درج النقدية)") ?: "الخزينة الرئيسية (درج النقدية)",
      printerType = prefs.getString("printer_type", "حراري 80mm") ?: "حراري 80mm",
      bluetoothPrinterName = prefs.getString("bt_printer", "POS-80BT (متصل)") ?: "POS-80BT (متصل)",
      receiptFooterNote = prefs.getString("receipt_footer", "شكراً لتعاملكم معنا، البضاعة المباعة ترد خلال 14 يوماً بالفاتورة") ?: "شكراً لتعاملكم معنا، البضاعة المباعة ترد خلال 14 يوماً بالفاتورة",
      isDarkMode = prefs.getBoolean("is_dark_mode", false),
      autoBackupEnabled = prefs.getBoolean("auto_backup", true),
      lastBackupTime = prefs.getLong("last_backup", System.currentTimeMillis() - 86400000L),
      backupFolderUri = prefs.getString("backup_folder_uri", "") ?: "",
      backupFolderDisplayName = prefs.getString("backup_folder_name", "ذاكرة الهاتف / مجلد المستندات Documents") ?: "ذاكرة الهاتف / مجلد المستندات Documents",
      lastBackupFileName = prefs.getString("last_backup_file_name", "ALWAKEEL_ERP_LATEST_BACKUP.sanad") ?: "ALWAKEEL_ERP_LATEST_BACKUP.sanad",
      lastBackupSizeFormatted = prefs.getString("last_backup_size", "") ?: "",
      lastBackupSummary = prefs.getString("last_backup_summary", "") ?: "",

      // Sales settings
      salesDefaultPaymentType = prefs.getString("sales_default_payment_type", "نقدي") ?: "نقدي",
      salesDefaultPricingTier = prefs.getString("sales_default_pricing_tier", "قطاعي (مستهلك)") ?: "قطاعي (مستهلك)",
      salesPreventNegativeStock = prefs.getBoolean("sales_prevent_negative_stock", false),
      salesWarnBelowCost = prefs.getBoolean("sales_warn_below_cost", true),
      salesAllowSellingBelowCost = prefs.getBoolean("sales_allow_below_cost", false),
      salesAllowSellingBelowInvoiceTotal = prefs.getBoolean("sales_allow_below_invoice_total", true),
      salesEnableDiscount = prefs.getBoolean("sales_enable_discount", true),
      salesDefaultDiscountType = prefs.getString("sales_default_discount_type", "مبلغ") ?: "مبلغ",
      salesMaxDiscountPercent = prefs.getFloat("sales_max_discount_pct", 30.0f).toDouble(),
      salesAllowItemLevelDiscount = prefs.getBoolean("sales_allow_item_discount", true),
      salesAllowCustomInvoiceDate = prefs.getBoolean("sales_allow_custom_inv_date", true),
      salesAllowManualPriceOverride = prefs.getBoolean("sales_allow_manual_price", true),
      salesDefaultUnit = prefs.getString("sales_default_unit", "علبة") ?: "علبة",
      salesRequireCustomerSelection = prefs.getBoolean("sales_require_cust_select", false),
      salesAutoMergeDuplicateItems = prefs.getBoolean("sales_auto_merge_duplicates", true),
      salesEnableInvoiceNotes = prefs.getBoolean("sales_enable_invoice_notes", true),
      salesConfirmClearCart = prefs.getBoolean("sales_confirm_clear_cart", true),
      salesAutoPrintReceipt = prefs.getBoolean("sales_auto_print_receipt", false),
      salesShowProfitToCashier = prefs.getBoolean("sales_show_profit_to_cashier", false),
      salesBarcodeAddSinglePieceDirectly = prefs.getBoolean("sales_barcode_single_piece", true),
      salesDefaultCustomerName = prefs.getString("sales_default_customer", "عميل نقدي عام") ?: "عميل نقدي عام",
      salesEnableQuickPaymentButtons = prefs.getBoolean("sales_enable_quick_pay", true),
      salesCheckCustomerCreditLimit = prefs.getBoolean("sales_check_credit_limit", true),
      salesEnableRoundTotal = prefs.getBoolean("sales_enable_round_total", false),

      // Purchases settings
      purchasesDefaultPaymentType = prefs.getString("purchases_default_payment_type", "نقدي (من الخزينة)") ?: "نقدي (من الخزينة)",
      purchasesUpdateCostAutomatically = prefs.getBoolean("purchases_update_cost_auto", true),
      purchasesWarnIfCostIncreased = prefs.getBoolean("purchases_warn_cost_increase", true),
      purchasesDefaultUnit = prefs.getString("purchases_default_unit", "كرتونة") ?: "كرتونة",
      purchasesAllowManualPriceOverride = prefs.getBoolean("purchases_allow_manual_price", true),
      purchasesRequireInvoiceNumber = prefs.getBoolean("purchases_require_inv_num", false),
      purchasesDefaultSupplierName = prefs.getString("purchases_default_supplier", "مورد عام نقدي") ?: "مورد عام نقدي",

      // Warehouse settings
      warehouseLowStockThreshold = prefs.getInt("warehouse_low_stock_threshold", 5),
      warehouseEnableLowStockAlerts = prefs.getBoolean("warehouse_low_stock_alerts", true),
      warehouseValuationMethod = prefs.getString("warehouse_valuation_method", "متوسط التكلفة المرجح") ?: "متوسط التكلفة المرجح",
      warehouseShowCartonsAndPieces = prefs.getBoolean("warehouse_show_cartons_pieces", true),
      warehouseAutoReconciliationAudit = prefs.getBoolean("warehouse_auto_reconcile", true),

      // Treasury settings
      vatTaxEnabled = prefs.getBoolean("vat_tax_enabled", false),
      vatTaxRatePercent = prefs.getFloat("vat_tax_rate", 14.0f).toDouble(),
      vatTaxIncludedInPrice = prefs.getBoolean("vat_tax_included", true),
      treasuryMaxDrawerLimit = prefs.getFloat("treasury_max_drawer", 10000.0f).toDouble(),
      treasuryRequireShiftClosureApproval = prefs.getBoolean("treasury_shift_closure_approval", false),

      // Receipt settings
      receiptHeaderTitle = prefs.getString("receipt_header_title", "فاتورة ضريبية مبسطة") ?: "فاتورة ضريبية مبسطة",
      receiptPrintQrCode = prefs.getBoolean("receipt_print_qr", true),
      receiptPrintCustomerBalance = prefs.getBoolean("receipt_print_cust_balance", true),
      receiptCopiesCount = prefs.getInt("receipt_copies_count", 1),

      // Security settings
      securityRequireAdminPasswordForDelete = prefs.getBoolean("sec_admin_pw_delete", true),
      securityHideProfitsFromCashier = prefs.getBoolean("sec_hide_profits_cashier", true),
      securityLockInvoicesAfterIssue = prefs.getBoolean("sec_lock_invoices_after_issue", true),

      // Sound settings
      soundBeepOnScan = prefs.getBoolean("sound_beep_on_scan", true),
      vibrateOnScan = prefs.getBoolean("vibrate_on_scan", true),

      // Employee and Delegate Sync settings
      activeEmployeeId = prefs.getLong("active_employee_id", 1L),
      activeEmployeeName = prefs.getString("active_employee_name", "المدير العام") ?: "المدير العام",
      activeEmployeeRole = prefs.getString("active_employee_role", "مدير عام") ?: "مدير عام",
      activeEmployeePin = prefs.getString("active_employee_pin", "1234") ?: "1234",
      deviceRole = prefs.getString("device_role", "MANAGER") ?: "MANAGER",
      companySyncKey = prefs.getString("company_sync_key", "WAKEEL-SYNC-7824") ?: "WAKEEL-SYNC-7824",
      delegateEmployeeId = prefs.getLong("delegate_employee_id", 0L),
      delegateEmployeeName = prefs.getString("delegate_employee_name", "") ?: "",
      autoSyncWhenOnline = prefs.getBoolean("auto_sync_when_online", true),
      lastSyncTimestamp = prefs.getLong("last_sync_timestamp", 0L),
      lastSyncSummary = prefs.getString("last_sync_summary", "") ?: ""
    )
  }

  fun updateProfile(profile: BusinessProfile) {
    prefs.edit().apply {
      putBoolean("is_logged_in", profile.isLoggedIn)
      putString("phone_number", profile.phoneNumber)
      putString("user_name", profile.userName)
      putString("user_role", profile.userRole)
      putString("business_name", profile.businessName)
      putString("business_type", profile.businessType)
      putString("currency", profile.currency)
      putString("contact_phone", profile.contactPhone)
      putString("address", profile.address)
      putString("tax_number", profile.taxNumber)
      putString("commercial_record", profile.commercialRecord)
      putString("selected_cashbox", profile.selectedCashbox)
      putString("printer_type", profile.printerType)
      putString("bt_printer", profile.bluetoothPrinterName)
      putString("receipt_footer", profile.receiptFooterNote)
      putBoolean("is_dark_mode", profile.isDarkMode)
      putBoolean("auto_backup", profile.autoBackupEnabled)
      putLong("last_backup", profile.lastBackupTime)
      putString("backup_folder_uri", profile.backupFolderUri)
      putString("backup_folder_name", profile.backupFolderDisplayName)
      putString("last_backup_file_name", profile.lastBackupFileName)
      putString("last_backup_size", profile.lastBackupSizeFormatted)
      putString("last_backup_summary", profile.lastBackupSummary)

      // Sales
      putString("sales_default_payment_type", profile.salesDefaultPaymentType)
      putString("sales_default_pricing_tier", profile.salesDefaultPricingTier)
      putBoolean("sales_prevent_negative_stock", profile.salesPreventNegativeStock)
      putBoolean("sales_warn_below_cost", profile.salesWarnBelowCost)
      putBoolean("sales_allow_below_cost", profile.salesAllowSellingBelowCost)
      putBoolean("sales_allow_below_invoice_total", profile.salesAllowSellingBelowInvoiceTotal)
      putBoolean("sales_enable_discount", profile.salesEnableDiscount)
      putString("sales_default_discount_type", profile.salesDefaultDiscountType)
      putFloat("sales_max_discount_pct", profile.salesMaxDiscountPercent.toFloat())
      putBoolean("sales_allow_item_discount", profile.salesAllowItemLevelDiscount)
      putBoolean("sales_allow_custom_inv_date", profile.salesAllowCustomInvoiceDate)
      putBoolean("sales_allow_manual_price", profile.salesAllowManualPriceOverride)
      putString("sales_default_unit", profile.salesDefaultUnit)
      putBoolean("sales_require_cust_select", profile.salesRequireCustomerSelection)
      putBoolean("sales_auto_merge_duplicates", profile.salesAutoMergeDuplicateItems)
      putBoolean("sales_enable_invoice_notes", profile.salesEnableInvoiceNotes)
      putBoolean("sales_confirm_clear_cart", profile.salesConfirmClearCart)
      putBoolean("sales_auto_print_receipt", profile.salesAutoPrintReceipt)
      putBoolean("sales_show_profit_to_cashier", profile.salesShowProfitToCashier)
      putBoolean("sales_barcode_single_piece", profile.salesBarcodeAddSinglePieceDirectly)
      putString("sales_default_customer", profile.salesDefaultCustomerName)
      putBoolean("sales_enable_quick_pay", profile.salesEnableQuickPaymentButtons)
      putBoolean("sales_check_credit_limit", profile.salesCheckCustomerCreditLimit)
      putBoolean("sales_enable_round_total", profile.salesEnableRoundTotal)

      // Purchases
      putString("purchases_default_payment_type", profile.purchasesDefaultPaymentType)
      putBoolean("purchases_update_cost_auto", profile.purchasesUpdateCostAutomatically)
      putBoolean("purchases_warn_cost_increase", profile.purchasesWarnIfCostIncreased)
      putString("purchases_default_unit", profile.purchasesDefaultUnit)
      putBoolean("purchases_allow_manual_price", profile.purchasesAllowManualPriceOverride)
      putBoolean("purchases_require_inv_num", profile.purchasesRequireInvoiceNumber)
      putString("purchases_default_supplier", profile.purchasesDefaultSupplierName)

      // Warehouse
      putInt("warehouse_low_stock_threshold", profile.warehouseLowStockThreshold)
      putBoolean("warehouse_low_stock_alerts", profile.warehouseEnableLowStockAlerts)
      putString("warehouse_valuation_method", profile.warehouseValuationMethod)
      putBoolean("warehouse_show_cartons_pieces", profile.warehouseShowCartonsAndPieces)
      putBoolean("warehouse_auto_reconcile", profile.warehouseAutoReconciliationAudit)

      // Treasury
      putBoolean("vat_tax_enabled", profile.vatTaxEnabled)
      putFloat("vat_tax_rate", profile.vatTaxRatePercent.toFloat())
      putBoolean("vat_tax_included", profile.vatTaxIncludedInPrice)
      putFloat("treasury_max_drawer", profile.treasuryMaxDrawerLimit.toFloat())
      putBoolean("treasury_shift_closure_approval", profile.treasuryRequireShiftClosureApproval)

      // Receipt
      putString("receipt_header_title", profile.receiptHeaderTitle)
      putBoolean("receipt_print_qr", profile.receiptPrintQrCode)
      putBoolean("receipt_print_cust_balance", profile.receiptPrintCustomerBalance)
      putInt("receipt_copies_count", profile.receiptCopiesCount)

      // Security
      putBoolean("sec_admin_pw_delete", profile.securityRequireAdminPasswordForDelete)
      putBoolean("sec_hide_profits_cashier", profile.securityHideProfitsFromCashier)
      putBoolean("sec_lock_invoices_after_issue", profile.securityLockInvoicesAfterIssue)

      // Sound
      putBoolean("sound_beep_on_scan", profile.soundBeepOnScan)
      putBoolean("vibrate_on_scan", profile.vibrateOnScan)

      // Employee and Delegate Sync
      putLong("active_employee_id", profile.activeEmployeeId)
      putString("active_employee_name", profile.activeEmployeeName)
      putString("active_employee_role", profile.activeEmployeeRole)
      putString("active_employee_pin", profile.activeEmployeePin)
      putString("device_role", profile.deviceRole)
      putString("company_sync_key", profile.companySyncKey)
      putLong("delegate_employee_id", profile.delegateEmployeeId)
      putString("delegate_employee_name", profile.delegateEmployeeName)
      putBoolean("auto_sync_when_online", profile.autoSyncWhenOnline)
      putLong("last_sync_timestamp", profile.lastSyncTimestamp)
      putString("last_sync_summary", profile.lastSyncSummary)

      apply()
    }
    _profile.value = profile
  }

  fun setSelectedCashbox(cashbox: String) {
    updateProfile(_profile.value.copy(selectedCashbox = cashbox))
  }

  fun setDarkMode(enabled: Boolean) {
    updateProfile(_profile.value.copy(isDarkMode = enabled))
  }

  fun setUserRole(role: String) {
    updateProfile(_profile.value.copy(userRole = role))
  }

  fun setLoggedIn(loggedIn: Boolean) {
    updateProfile(_profile.value.copy(isLoggedIn = loggedIn))
  }

  fun recordBackup() {
    updateProfile(_profile.value.copy(lastBackupTime = System.currentTimeMillis()))
  }
}
