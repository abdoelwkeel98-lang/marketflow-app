package com.example.ui.screens.reports

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Straighten
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.ReportPeriodSelectorBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.platform.LocalContext
import com.example.utils.ReportExportHelper
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItem
import com.example.data.model.InvoiceType
import com.example.data.model.PaymentType
import com.example.data.model.Product
import com.example.data.model.Supplier
import com.example.ui.ReportPeriod
import com.example.ui.WholesaleViewModel
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldPrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * تقارير المشتريات والتوريد الاحترافية متعددة الأبعاد:
 * - حسب المورد (By Supplier)
 * - حسب المنتج (By Product)
 * - حسب الوحدة (By Unit: كرتونة / قطعة)
 * - حسب اليوم والتاريخ (By Day / Date)
 * - حسب التصنيف والقسم (By Category)
 */
data class PurchasesDimensionItem(
  val id: Int,
  val title: String,
  val subtitle: String,
  val icon: androidx.compose.ui.graphics.vector.ImageVector,
  val iconColor: Color
)

@Composable
fun DetailedPurchasesReportsView(
  viewModel: WholesaleViewModel,
  purchaseInvoices: List<Invoice>,
  invoiceItems: List<InvoiceItem>,
  products: List<Product>,
  suppliers: List<Supplier>,
  period: ReportPeriod,
  currency: String
) {
  var selectedDimension by remember { mutableIntStateOf(0) }
  var searchQuery by remember { mutableStateOf("") }
  var sortOrder by remember { mutableIntStateOf(0) } // 0: الأعلى تكلفة, 1: الأكثر كمية
  var isDimensionListExpanded by remember { mutableStateOf(false) }

  // قراءة فلاتر التاريخ واليوم المخصص والمدة المحددة
  val selectedPeriod by viewModel.selectedReportPeriod.collectAsStateWithLifecycle()
  val customDayTimestamp by viewModel.customDayTimestamp.collectAsStateWithLifecycle()
  val customDateRange by viewModel.customDateRange.collectAsStateWithLifecycle()

  val (startTimestamp, endTimestamp) = remember(selectedPeriod, customDayTimestamp, customDateRange) {
    viewModel.getPeriodDateRange(selectedPeriod, customDayTimestamp, customDateRange)
  }

  // تصفية فواتير الشراء بالفترة المحددة بدقة متناهية (اليوم المخصص أو المدة المعينة)
  val filteredInvoices = remember(purchaseInvoices, startTimestamp, endTimestamp) {
    purchaseInvoices.filter { it.type == InvoiceType.PURCHASE && it.timestamp in startTimestamp..endTimestamp }
  }

  val validInvoiceIds = remember(filteredInvoices) {
    filteredInvoices.map { it.id }.toSet()
  }

  // بنود فواتير الشراء
  val filteredItems = remember(invoiceItems, validInvoiceIds) {
    invoiceItems.filter { it.invoiceId in validInvoiceIds }
  }

  // مؤشرات الإجمالي
  val totalPurchasesAmount = remember(filteredInvoices) { filteredInvoices.sumOf { it.totalAmount } }
  val totalPaidCash = remember(filteredInvoices) { filteredInvoices.sumOf { it.paidAmount } }
  val totalCreditRemaining = remember(filteredInvoices) { filteredInvoices.sumOf { it.remainingAmount } }
  val totalInvoiceCount = filteredInvoices.size

  val dimensions = remember {
    listOf(
      PurchasesDimensionItem(0, "🏭 حسب المورد", "حجم التوريدات والمدفوع والآجل المتبقي لكل مورد", Icons.Default.Business, Color(0xFF2563EB)),
      PurchasesDimensionItem(1, "🏷️ حسب المنتج والأصناف", "الأصناف الموردة والكميات والتكلفة لكل صنف", Icons.Default.ShoppingBag, EmeraldPrimary),
      PurchasesDimensionItem(2, "📦 حسب نوع الوحدة (كرتونة / قطعة)", "التوريد بالكرتونة والقطعة وتكلفة الوحدات", Icons.Default.Straighten, Color(0xFF7C3AED)),
      PurchasesDimensionItem(3, "📅 حسب اليوم والتاريخ", "حركة التوريدات اليومية وتوزيع المشتريات", Icons.Default.CalendarToday, Color(0xFFD97706)),
      PurchasesDimensionItem(4, "🗂️ حسب التصنيف والقسم", "تحليل مشتريات الأقسام والتصنيفات المختلفة", Icons.Default.Category, Color(0xFF059669)),
      PurchasesDimensionItem(5, "🧾 حسب الفاتورة", "كشف تفصيلي بفواتير الشراء والمسدد كاش والآجل المتبقي", Icons.Default.Description, Color(0xFFE11D48))
    )
  }

  val context = LocalContext.current
  val businessProfile by viewModel.businessProfile.collectAsStateWithLifecycle()
  val topProducts by viewModel.topSellingProducts.collectAsStateWithLifecycle()
  val expensesByCategory by viewModel.expensesByCategory.collectAsStateWithLifecycle()
  val profitReport by viewModel.profitReport.collectAsStateWithLifecycle()

  Column(modifier = Modifier.fillMaxSize()) {
    // 1. شريط فلترة الفترة واليوم المخصص والمدة المحددة
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 4.dp),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
      Column(modifier = Modifier.padding(10.dp)) {
        ReportPeriodSelectorBar(
          viewModel = viewModel,
          showLabel = true
        )
      }
    }

    // 2. بطاقة إحصائيات المشتريات والتوريد الإجمالية
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 4.dp),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text("إجمالي التوريدات", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.2f %s", totalPurchasesAmount, currency),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            text = "$totalInvoiceCount فاتورة توريد",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Box(
          modifier = Modifier
            .height(36.dp)
            .width(1.dp)
            .background(MaterialTheme.colorScheme.outlineVariant)
        )

        Column(modifier = Modifier.weight(1f).padding(horizontal = 8.dp)) {
          Text("المسدد كاش", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.2f %s", totalPaidCash, currency),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp,
            color = EmeraldPrimary
          )
          Text("خرج من الخزينة", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Box(
          modifier = Modifier
            .height(36.dp)
            .width(1.dp)
            .background(MaterialTheme.colorScheme.outlineVariant)
        )

        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
          Text("الآجل للموردين", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.2f %s", totalCreditRemaining, currency),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp,
            color = if (totalCreditRemaining > 0) MaterialTheme.colorScheme.error else EmeraldPrimary
          )
          Text("التزام مالي", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    }

    // شريط أزرار الطباعة والتصدير الشامل (Print, PDF, Image, Share)
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 2.dp),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedButton(
          onClick = {
            ReportExportHelper.printReportViaSystem(
              context = context,
              report = profitReport,
              period = selectedPeriod,
              businessName = businessProfile.businessName,
              phone = businessProfile.contactPhone,
              address = businessProfile.address,
              topProducts = topProducts,
              expensesByCategory = expensesByCategory,
              customTitle = "تقرير المشتريات - ${dimensions[selectedDimension].title}"
            )
          },
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(4.dp))
          Text("طباعة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Button(
          onClick = {
            val pdfFile = ReportExportHelper.generateFinancialReportPdf(
              context = context,
              report = profitReport,
              period = selectedPeriod,
              businessName = businessProfile.businessName,
              phone = businessProfile.contactPhone,
              address = businessProfile.address,
              topProducts = topProducts,
              expensesByCategory = expensesByCategory,
              customTitle = "تقرير المشتريات - ${dimensions[selectedDimension].title}"
            )
            ReportExportHelper.shareFile(
              context = context,
              file = pdfFile,
              mimeType = "application/pdf",
              title = "مشاركة تقرير المشتريات PDF"
            )
          },
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Button(
          onClick = {
            val imgFile = ReportExportHelper.generateFinancialReportImage(
              context = context,
              report = profitReport,
              period = selectedPeriod,
              businessName = businessProfile.businessName,
              topProducts = topProducts,
              customTitle = "تقرير المشتريات - ${dimensions[selectedDimension].title}"
            )
            ReportExportHelper.shareFile(
              context = context,
              file = imgFile,
              mimeType = "image/png",
              title = "مشاركة صورة تقرير المشتريات"
            )
          },
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("صورة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        IconButton(
          onClick = {
            val dateStr = SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH).format(Date())
            val txt = "📦 تقرير المشتريات والتوريدات (${businessProfile.businessName})\nالفترة: ${selectedPeriod.label} ($dateStr)\n• إجمالي المشتريات: ${String.format(Locale.ENGLISH, "%.2f", totalPurchasesAmount)} $currency (${totalInvoiceCount} فاتورة)\n• المسدد كاش: ${String.format(Locale.ENGLISH, "%.2f", totalPaidCash)} $currency\n• الآجل المتبقي للموردين: ${String.format(Locale.ENGLISH, "%.2f", totalCreditRemaining)} $currency"
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Purchases Report", txt))
            Toast.makeText(context, "تم نسخ ملخص المشتريات للحافظة ✓", Toast.LENGTH_SHORT).show()
          },
          modifier = Modifier.size(32.dp)
        ) {
          Icon(Icons.Default.ContentCopy, contentDescription = "نسخ", modifier = Modifier.size(16.dp))
        }
      }
    }

    // 3. قائمة اختيار أبعاد التقرير أسفل ملخص التوريدات والفترة
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 4.dp),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
      Column(modifier = Modifier.padding(10.dp)) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { isDimensionListExpanded = !isDimensionListExpanded }
            .padding(vertical = 2.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = dimensions[selectedDimension].iconColor.copy(alpha = 0.15f),
              modifier = Modifier.size(32.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  dimensions[selectedDimension].icon,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp),
                  tint = dimensions[selectedDimension].iconColor
                )
              }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text("عرض تقرير المشتريات حسب:", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = dimensions[selectedDimension].title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
            modifier = Modifier.clickable { isDimensionListExpanded = !isDimensionListExpanded }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = if (isDimensionListExpanded) "إغلاق القائمة ▲" else "تغيير التصنيف (${dimensions.size}) ▼",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
            }
          }
        }

        AnimatedVisibility(visible = isDimensionListExpanded) {
          Column(
            modifier = Modifier.padding(top = 10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            HorizontalDivider(modifier = Modifier.padding(bottom = 4.dp))
            dimensions.forEachIndexed { idx, dim ->
              val isSelected = selectedDimension == idx
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                border = if (isSelected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable {
                    selectedDimension = idx
                    searchQuery = ""
                    isDimensionListExpanded = false
                  }
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Surface(
                      shape = RoundedCornerShape(6.dp),
                      color = dim.iconColor.copy(alpha = 0.15f),
                      modifier = Modifier.size(28.dp)
                    ) {
                      Box(contentAlignment = Alignment.Center) {
                        Icon(dim.icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = dim.iconColor)
                      }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                      Text(
                        text = dim.title,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                      )
                      Text(
                        text = dim.subtitle,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                    }
                  }

                  if (isSelected) {
                    Icon(
                      Icons.Default.CheckCircle,
                      contentDescription = null,
                      modifier = Modifier.size(18.dp),
                      tint = MaterialTheme.colorScheme.primary
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    // 4. شريط البحث والترتيب
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("بحث في نتائج التوريد...", fontSize = 12.sp) },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(Icons.Default.Clear, contentDescription = "مسح", modifier = Modifier.size(16.dp))
            }
          }
        },
        singleLine = true,
        modifier = Modifier.weight(1f).height(46.dp),
        shape = RoundedCornerShape(10.dp)
      )

      Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.clickable {
          sortOrder = if (sortOrder == 0) 1 else 0
        }
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (sortOrder == 0) "الأعلى توريداً ⬇" else "الأكثر كمية ⬇",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
        }
      }
    }

    // 4. محتوى التقرير حسب البعد
    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
      when (selectedDimension) {
        0 -> PurchasesBySupplierSubReport(
          invoices = filteredInvoices,
          suppliers = suppliers,
          totalPurchases = totalPurchasesAmount,
          searchQuery = searchQuery,
          currency = currency
        )
        1 -> PurchasesByProductSubReport(
          items = filteredItems,
          products = products,
          totalPurchases = totalPurchasesAmount,
          searchQuery = searchQuery,
          currency = currency
        )
        2 -> PurchasesByUnitSubReport(
          items = filteredItems,
          totalPurchases = totalPurchasesAmount,
          currency = currency
        )
        3 -> PurchasesByDaySubReport(
          invoices = filteredInvoices,
          searchQuery = searchQuery,
          currency = currency
        )
        4 -> PurchasesByCategorySubReport(
          items = filteredItems,
          products = products,
          totalPurchases = totalPurchasesAmount,
          searchQuery = searchQuery,
          currency = currency
        )
        5 -> PurchasesByInvoiceSubReport(
          invoices = filteredInvoices,
          searchQuery = searchQuery,
          currency = currency
        )
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 1. تقرير المشتريات حسب المورد (Purchases by Supplier)
// -----------------------------------------------------------------------------
data class SupplierPurchasesRow(
  val supplierId: Long,
  val supplierName: String,
  val company: String,
  val phone: String,
  val invoiceCount: Int,
  val totalPurchases: Double,
  val totalPaid: Double,
  val totalRemaining: Double,
  val currentBalance: Double
)

@Composable
fun PurchasesBySupplierSubReport(
  invoices: List<Invoice>,
  suppliers: List<Supplier>,
  totalPurchases: Double,
  searchQuery: String,
  currency: String
) {
  val supplierMap = remember(suppliers) { suppliers.associateBy { it.id } }

  val rows = remember(invoices, supplierMap, searchQuery) {
    val grouped = invoices.groupBy { it.partyId }
    val list = grouped.map { (sId, sInvoices) ->
      val sup = supplierMap[sId]
      val name = if (sId == 0L) "مورد نقدي عام" else (sup?.name ?: sInvoices.firstOrNull()?.partyName ?: "مورد")
      val company = sup?.company ?: ""
      val phone = sup?.phone ?: ""
      val count = sInvoices.size
      val total = sInvoices.sumOf { it.totalAmount }
      val paid = sInvoices.sumOf { it.paidAmount }
      val rem = sInvoices.sumOf { it.remainingAmount }
      val balance = sup?.currentBalance ?: 0.0

      SupplierPurchasesRow(
        supplierId = sId,
        supplierName = name,
        company = company,
        phone = phone,
        invoiceCount = count,
        totalPurchases = total,
        totalPaid = paid,
        totalRemaining = rem,
        currentBalance = balance
      )
    }.sortedByDescending { it.totalPurchases }

    if (searchQuery.isBlank()) list else list.filter {
      it.supplierName.contains(searchQuery, ignoreCase = true) ||
          it.company.contains(searchQuery, ignoreCase = true) ||
          it.phone.contains(searchQuery)
    }
  }

  if (rows.isEmpty()) {
    EmptyReportView(message = "لا توجد مشتريات موردين مسجلة في هذه الفترة")
  } else {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(rows, key = { it.supplierId }) { row ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(34.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.Business, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(row.supplierName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                  if (row.company.isNotEmpty() || row.phone.isNotEmpty()) {
                    Text(
                      text = listOf(row.company, row.phone).filter { it.isNotEmpty() }.joinToString(" • "),
                      fontSize = 11.sp,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }
              }

              Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
              ) {
                Text(
                  text = "${row.invoiceCount} فاتورة توريد",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text("إجمالي التوريدات", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f %s", row.totalPurchases, currency),
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = MaterialTheme.colorScheme.primary
                )
              }
              Column {
                Text("المسدد كاش", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f %s", row.totalPaid, currency),
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 12.sp,
                  color = EmeraldPrimary
                )
              }
              Column(horizontalAlignment = Alignment.End) {
                Text("الآجل المقيد", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f %s", row.totalRemaining, currency),
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = if (row.totalRemaining > 0) MaterialTheme.colorScheme.error else Color.Gray
                )
              }
            }

            if (row.currentBalance > 0) {
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "⚠️ رصيد سابق مستحق للمورد: ${String.format(Locale.ENGLISH, "%.2f %s", row.currentBalance, currency)}",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.error
              )
            }
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 2. تقرير المشتريات حسب المنتج (Purchases by Product)
// -----------------------------------------------------------------------------
data class ProductPurchasesRow(
  val productId: Long,
  val productName: String,
  val category: String,
  val cartonQuantity: Int,
  val pieceQuantity: Int,
  val totalPieces: Int,
  val totalCost: Double,
  val sharePercent: Double
)

@Composable
fun PurchasesByProductSubReport(
  items: List<InvoiceItem>,
  products: List<Product>,
  totalPurchases: Double,
  searchQuery: String,
  currency: String
) {
  val prodMap = remember(products) { products.associateBy { it.id } }

  val rows = remember(items, prodMap, totalPurchases, searchQuery) {
    val grouped = items.groupBy { it.productId }
    val list = grouped.map { (pId, pItems) ->
      val prod = prodMap[pId]
      val name = prod?.name ?: pItems.firstOrNull()?.productName ?: "صنف"
      val cat = prod?.category ?: "عام"
      val cartons = pItems.filter { it.unitType == "كرتونة" }.sumOf { it.quantity }
      val pieces = pItems.filter { it.unitType != "كرتونة" }.sumOf { it.quantity }
      val totalPieces = pItems.sumOf { it.totalPieces }
      val totalCost = pItems.sumOf { it.totalPrice }
      val share = if (totalPurchases > 0) (totalCost / totalPurchases) * 100.0 else 0.0

      ProductPurchasesRow(
        productId = pId,
        productName = name,
        category = cat,
        cartonQuantity = cartons,
        pieceQuantity = pieces,
        totalPieces = totalPieces,
        totalCost = totalCost,
        sharePercent = share
      )
    }.sortedByDescending { it.totalCost }

    if (searchQuery.isBlank()) list else list.filter {
      it.productName.contains(searchQuery, ignoreCase = true) ||
          it.category.contains(searchQuery, ignoreCase = true)
    }
  }

  if (rows.isEmpty()) {
    EmptyReportView(message = "لا توجد مشتريات أصناف مسجلة في هذه الفترة")
  } else {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(rows, key = { it.productId }) { row ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(row.productName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                  text = "${row.category} • إجمالي القطع الموردة: ${row.totalPieces}",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
              ) {
                Text(
                  text = String.format(Locale.ENGLISH, "حصة %.1f%%", row.sharePercent),
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              if (row.cartonQuantity > 0) {
                Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                  Text("📦 كراتين: ${row.cartonQuantity}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
              }
              if (row.pieceQuantity > 0) {
                Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                  Text("🔘 قطع: ${row.pieceQuantity}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
              }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text("إجمالي تكلفة الشراء والتوريد:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = String.format(Locale.ENGLISH, "%.2f %s", row.totalCost, currency),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.primary
              )
            }
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 3. تقرير المشتريات حسب الوحدة (Purchases by Unit)
// -----------------------------------------------------------------------------
@Composable
fun PurchasesByUnitSubReport(
  items: List<InvoiceItem>,
  totalPurchases: Double,
  currency: String
) {
  val cartonItems = remember(items) { items.filter { it.unitType == "كرتونة" } }
  val pieceItems = remember(items) { items.filter { it.unitType != "كرتونة" } }

  val cartonQuantity = remember(cartonItems) { cartonItems.sumOf { it.quantity } }
  val cartonCost = remember(cartonItems) { cartonItems.sumOf { it.totalPrice } }

  val pieceQuantity = remember(pieceItems) { pieceItems.sumOf { it.quantity } }
  val pieceCost = remember(pieceItems) { pieceItems.sumOf { it.totalPrice } }

  val totalCombined = cartonCost + pieceCost
  val cartonPct = if (totalCombined > 0) (cartonCost / totalCombined).toFloat() else 0f
  val piecePct = if (totalCombined > 0) (pieceCost / totalCombined).toFloat() else 0f

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(14.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Text(
        text = "مقارنة توريدات الكراتين بالجملة مقابل القطع الفردية",
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp
      )
      Text(
        text = "يوضح حجم الإنفاق على شراء الكراتين مقارنة بشراء القطع",
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "📦 توريدات الكراتين: " + String.format(Locale.ENGLISH, "%.1f%%", cartonPct * 100),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = EmeraldPrimary
            )
            Text(
              text = "🔘 توريدات القطع: " + String.format(Locale.ENGLISH, "%.1f%%", piecePct * 100),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          LinearProgressIndicator(
            progress = { cartonPct },
            modifier = Modifier
              .fillMaxWidth()
              .height(10.dp),
            color = EmeraldPrimary,
            trackColor = MaterialTheme.colorScheme.primary
          )
        }
      }
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = EmeraldPrimary.copy(alpha = 0.08f)),
        border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.3f))
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .background(EmeraldPrimary.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Inventory2, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("شراء كراتين (جملة)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("توريد البضائع بالكرتونة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            Surface(shape = RoundedCornerShape(6.dp), color = EmeraldPrimary) {
              Text(
                text = "$cartonQuantity كرتونة",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("إجمالي تكلفة شراء الكراتين:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
              text = String.format(Locale.ENGLISH, "%.2f %s", cartonCost, currency),
              fontWeight = FontWeight.ExtraBold,
              fontSize = 15.sp,
              color = EmeraldPrimary
            )
          }
        }
      }
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Straighten, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("شراء قطع فردية (تجزئة)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("توريد بالقطعة أو العلبة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.primary) {
              Text(
                text = "$pieceQuantity قطعة",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("إجمالي تكلفة شراء القطع:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
              text = String.format(Locale.ENGLISH, "%.2f %s", pieceCost, currency),
              fontWeight = FontWeight.ExtraBold,
              fontSize = 15.sp,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 4. تقرير المشتريات حسب اليوم (Purchases by Day)
// -----------------------------------------------------------------------------
data class DayPurchasesRow(
  val dateString: String,
  val dayName: String,
  val invoiceCount: Int,
  val totalPurchases: Double,
  val cashAmount: Double,
  val creditAmount: Double
)

@Composable
fun PurchasesByDaySubReport(
  invoices: List<Invoice>,
  searchQuery: String,
  currency: String
) {
  val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH) }
  val dayNameFormat = remember { SimpleDateFormat("EEEE", Locale("ar")) }

  val rows = remember(invoices, searchQuery) {
    val grouped = invoices.groupBy { dateFormat.format(Date(it.timestamp)) }
    val list = grouped.map { (dateStr, dayInvoices) ->
      val firstTs = dayInvoices.firstOrNull()?.timestamp ?: 0L
      val dayName = dayNameFormat.format(Date(firstTs))
      val count = dayInvoices.size
      val total = dayInvoices.sumOf { it.totalAmount }
      val cash = dayInvoices.sumOf { it.paidAmount }
      val credit = dayInvoices.sumOf { it.remainingAmount }

      DayPurchasesRow(
        dateString = dateStr,
        dayName = dayName,
        invoiceCount = count,
        totalPurchases = total,
        cashAmount = cash,
        creditAmount = credit
      )
    }.sortedByDescending { it.dateString }

    if (searchQuery.isBlank()) list else list.filter {
      it.dateString.contains(searchQuery) || it.dayName.contains(searchQuery)
    }
  }

  if (rows.isEmpty()) {
    EmptyReportView(message = "لا توجد مشتريات وتوريدات في هذه الفترة")
  } else {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(rows, key = { it.dateString }) { row ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(34.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.CalendarToday, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text("${row.dayName} (${row.dateString})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                  Text("${row.invoiceCount} فاتورة توريد", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }

              Text(
                text = String.format(Locale.ENGLISH, "%.2f %s", row.totalPurchases, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.primary
              )
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(6.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("المسدد كاش: ${String.format(Locale.ENGLISH, "%.1f", row.cashAmount)}", fontSize = 10.sp, color = EmeraldPrimary, fontWeight = FontWeight.SemiBold)
              Text("المتبقي آجل: ${String.format(Locale.ENGLISH, "%.1f", row.creditAmount)}", fontSize = 10.sp, color = if (row.creditAmount > 0) MaterialTheme.colorScheme.error else Color.Gray)
            }
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 5. تقرير المشتريات حسب التصنيف (Purchases by Category)
// -----------------------------------------------------------------------------
data class CategoryPurchasesRow(
  val categoryName: String,
  val productCount: Int,
  val piecesSupplied: Int,
  val totalCost: Double,
  val sharePercent: Double
)

@Composable
fun PurchasesByCategorySubReport(
  items: List<InvoiceItem>,
  products: List<Product>,
  totalPurchases: Double,
  searchQuery: String,
  currency: String
) {
  val prodMap = remember(products) { products.associateBy { it.id } }

  val rows = remember(items, prodMap, totalPurchases, searchQuery) {
    val grouped = items.groupBy { item ->
      prodMap[item.productId]?.category ?: "عام"
    }

    val list = grouped.map { (cat, catItems) ->
      val prodCount = catItems.map { it.productId }.distinct().size
      val pieces = catItems.sumOf { it.totalPieces }
      val cost = catItems.sumOf { it.totalPrice }
      val share = if (totalPurchases > 0) (cost / totalPurchases) * 100.0 else 0.0

      CategoryPurchasesRow(
        categoryName = cat,
        productCount = prodCount,
        piecesSupplied = pieces,
        totalCost = cost,
        sharePercent = share
      )
    }.sortedByDescending { it.totalCost }

    if (searchQuery.isBlank()) list else list.filter {
      it.categoryName.contains(searchQuery, ignoreCase = true)
    }
  }

  if (rows.isEmpty()) {
    EmptyReportView(message = "لا توجد مشتريات وتوريدات في هذه الفترة")
  } else {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(rows, key = { it.categoryName }) { row ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(34.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.Category, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(row.categoryName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                  Text("${row.productCount} صنف • ${row.piecesSupplied} قطعة موردة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }

              Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
              ) {
                Text(
                  text = String.format(Locale.ENGLISH, "حصة %.1f%%", row.sharePercent),
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
              progress = { (row.sharePercent / 100f).toFloat().coerceIn(0f, 1f) },
              modifier = Modifier.fillMaxWidth().height(6.dp),
              color = MaterialTheme.colorScheme.primary,
              trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("إجمالي التكلفة المدفوعة للقسم:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = String.format(Locale.ENGLISH, "%.2f %s", row.totalCost, currency),
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary
              )
            }
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 6. تقرير المشتريات حسب الفاتورة (Purchases by Invoice)
// -----------------------------------------------------------------------------
@Composable
fun PurchasesByInvoiceSubReport(
  invoices: List<Invoice>,
  searchQuery: String,
  currency: String
) {
  val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.ENGLISH) }

  val filteredInvoices = remember(invoices, searchQuery) {
    invoices.filter {
      searchQuery.isBlank() || it.invoiceNumber.contains(searchQuery) || it.partyName.contains(searchQuery, ignoreCase = true)
    }.sortedByDescending { it.timestamp }
  }

  if (filteredInvoices.isEmpty()) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(32.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
          Icons.Default.LocalShipping,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
          modifier = Modifier.size(48.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "لا توجد فواتير شراء وتوريد في هذه الفترة",
          fontSize = 13.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          fontWeight = FontWeight.Medium
        )
      }
    }
    return
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(14.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    items(filteredInvoices, key = { it.id }) { inv ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "فاتورة شراء #${inv.invoiceNumber}",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = if (inv.paymentType == PaymentType.CASH) EmeraldPrimary.copy(alpha = 0.15f) else AmberPrimary.copy(alpha = 0.15f)
                ) {
                  Text(
                    text = if (inv.paymentType == PaymentType.CASH) "كاش مدفوع" else "آجل مورد",
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (inv.paymentType == PaymentType.CASH) EmeraldPrimary else AmberPrimary,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                  )
                }
              }
              Text(
                text = "المورد: ${inv.partyName} • ${dateFormat.format(Date(inv.timestamp))}",
                fontSize = 10.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = String.format(Locale.ENGLISH, "%.2f %s", inv.totalAmount, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                text = if (inv.remainingAmount > 0) "متبقي: ${String.format(Locale.ENGLISH, "%.1f", inv.remainingAmount)}" else "مسددة بالكامل",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (inv.remainingAmount > 0) MaterialTheme.colorScheme.error else EmeraldPrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))
          HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("المدفوع نقداً: ${String.format(Locale.ENGLISH, "%.2f", inv.paidAmount)}", fontSize = 10.5.sp, color = EmeraldPrimary)
            if (inv.remainingAmount > 0) {
              Text("الآجل على المحل: ${String.format(Locale.ENGLISH, "%.2f", inv.remainingAmount)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.error)
            }
            if (inv.discount > 0) {
              Text("خصم شراء: ${String.format(Locale.ENGLISH, "%.1f", inv.discount)}", fontSize = 10.5.sp, color = EmeraldPrimary)
            }
          }
        }
      }
    }
  }
}
