package com.example.ui.screens

import android.app.DatePickerDialog
import android.widget.Toast
import java.util.Calendar
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Expense
import com.example.data.model.InvoiceType
import com.example.data.model.PaymentTransaction
import com.example.data.model.TransactionType
import com.example.ui.WholesaleViewModel
import com.example.ui.components.QuickSanadVoucherDialog
import com.example.ui.components.VoucherReceiptDialog
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CashflowScreen(
  viewModel: WholesaleViewModel,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var selectedTab by remember { mutableIntStateOf(0) } // 0 = حركة الخزينة, 1 = المصروفات التشغيلية
  val businessProfile by viewModel.businessProfile.collectAsStateWithLifecycle()
  val profitReport by viewModel.profitReport.collectAsStateWithLifecycle()
  val expenses by viewModel.expenses.collectAsStateWithLifecycle()
  val transactions by viewModel.transactions.collectAsStateWithLifecycle()
  val salesInvoices by viewModel.salesInvoices.collectAsStateWithLifecycle()
  val purchaseInvoices by viewModel.purchaseInvoices.collectAsStateWithLifecycle()

  var showAddExpenseDialog by remember { mutableStateOf(false) }
  var showAddCashDepositDialog by remember { mutableStateOf(false) }
  var showCashboxSwitchDialog by remember { mutableStateOf(false) }
  var showQuickSanadDialog by remember { mutableStateOf(false) }
  var previewVoucher by remember { mutableStateOf<PaymentTransaction?>(null) }
  val customers by viewModel.customers.collectAsStateWithLifecycle()
  val suppliers by viewModel.suppliers.collectAsStateWithLifecycle()

  val tabs = listOf("حركة الخزينة والسيولة", "سجل المصروفات التشغيلية")

  Column(modifier = modifier.fillMaxSize()) {
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = MaterialTheme.colorScheme.surface
    ) {
      tabs.forEachIndexed { index, title ->
        Tab(
          selected = selectedTab == index,
          onClick = { selectedTab = index },
          text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        )
      }
    }

    if (selectedTab == 0) {
      // ================= CASHBOX LOG TAB =================
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        // Active Cashbox Card
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
          ) {
            Column(modifier = Modifier.padding(18.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.AccountBalanceWallet,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = businessProfile.selectedCashbox,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                  )
                }

                OutlinedButton(
                  onClick = { showCashboxSwitchDialog = true },
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("تبديل الخزينة", fontSize = 11.sp)
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              Text(
                text = "الرصيد النقدي الإغلاقي الحالي:",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
              )
              Text(
                text = String.format(Locale.ENGLISH, "%.2f %s", profitReport.cashDrawerBalance, businessProfile.currency),
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
              )
            }
          }
        }

        // Quick Actions in Cashflow (إيداع نقدية وسندات القبض والصرف)
        item {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Main Treasury Deposit Button
            Button(
              onClick = { showAddCashDepositDialog = true },
              modifier = Modifier.fillMaxWidth(),
              colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
              shape = RoundedCornerShape(12.dp)
            ) {
              Icon(Icons.Default.AddCard, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("إيداع نقدية في الخزينة + (تغذية الصندوق / رأس مال)", fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Button(
                onClick = { showQuickSanadDialog = true },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                shape = RoundedCornerShape(10.dp)
              ) {
                Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("سند قبض + (عميل)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }

              Button(
                onClick = { showQuickSanadDialog = true },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                shape = RoundedCornerShape(10.dp)
              ) {
                Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("سند صرف + (مورد)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }

        // Cash Inflow vs Outflow Cards
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            // Inflow
            val totalInflow = profitReport.cashInSales + profitReport.cashInCustomerPayments + profitReport.cashInDeposits
            Card(
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = EmeraldPrimary.copy(alpha = 0.12f))
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("إجمالي الوارد (+)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = String.format(Locale.ENGLISH, "%.1f %s", totalInflow, businessProfile.currency),
                  fontSize = 17.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = EmeraldPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text("مبيعات نقدية: %.0f".format(Locale.ENGLISH, profitReport.cashInSales), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("تحصيلات عملاء: %.0f".format(Locale.ENGLISH, profitReport.cashInCustomerPayments), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (profitReport.cashInDeposits > 0) {
                  Text("إيداعات وتغذية: %.0f".format(Locale.ENGLISH, profitReport.cashInDeposits), fontSize = 10.sp, color = EmeraldPrimary, fontWeight = FontWeight.SemiBold)
                }
              }
            }

            // Outflow
            val totalOutflow = profitReport.cashOutPurchases + profitReport.cashOutSupplierPayments + profitReport.totalExpenses
            Card(
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = CrimsonRed.copy(alpha = 0.12f))
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = CrimsonRed, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("إجمالي المنصرف (-)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CrimsonRed)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = String.format(Locale.ENGLISH, "%.1f %s", totalOutflow, businessProfile.currency),
                  fontSize = 17.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = CrimsonRed
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text("مشتريات: %.0f".format(Locale.ENGLISH, profitReport.cashOutPurchases), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("مصروفات: %.0f".format(Locale.ENGLISH, profitReport.totalExpenses), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }

        // Quick Actions
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = { showAddExpenseDialog = true },
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("تسجيل مصروف جديد", fontSize = 12.sp)
            }
          }
        }

        // Daily Cashbox Activity Stream
        item {
          Text(
            text = "شريط العمليات النقدية بالخزينة:",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
          )
        }

        // Combined activity items
        val recentSales = salesInvoices.filter { it.paidAmount > 0 }.take(4)
        val recentCustomerPayments = transactions.filter { it.type == TransactionType.CUSTOMER_PAYMENT }.take(4)
        val recentDeposits = transactions.filter { it.type == TransactionType.CASH_DEPOSIT }.take(4)
        val recentExpenses = expenses.take(4)
        val recentSupplierPayments = transactions.filter { it.type == TransactionType.SUPPLIER_PAYMENT }.take(4)

        items(recentDeposits) { tx ->
          CashLogItem(
            title = "إيداع نقدي بالخزينة (وارد +)",
            subtitle = "${tx.partyName}${if (tx.notes.isNotBlank()) " • " + tx.notes else ""}",
            time = tx.timestamp,
            amount = tx.amount,
            isInflow = true,
            currency = businessProfile.currency
          )
        }

        items(recentSales) { inv ->
          CashLogItem(
            title = "فاتورة بيع نقدي #${inv.invoiceNumber}",
            subtitle = inv.partyName,
            time = inv.timestamp,
            amount = inv.paidAmount,
            isInflow = true,
            currency = businessProfile.currency
          )
        }

        items(recentCustomerPayments) { tx ->
          CashLogItem(
            title = "سند قبض من عميل",
            subtitle = tx.partyName,
            time = tx.timestamp,
            amount = tx.amount,
            isInflow = true,
            currency = businessProfile.currency
          )
        }

        items(recentExpenses) { exp ->
          CashLogItem(
            title = "مصروف تشغيلي: ${exp.category}",
            subtitle = exp.notes.ifBlank { exp.recipient },
            time = exp.timestamp,
            amount = exp.amount,
            isInflow = false,
            currency = businessProfile.currency
          )
        }

        items(recentSupplierPayments) { tx ->
          CashLogItem(
            title = "سند صرف لمورد",
            subtitle = tx.partyName,
            time = tx.timestamp,
            amount = tx.amount,
            isInflow = false,
            currency = businessProfile.currency
          )
        }
      }
    } else {
      // ================= EXPENSES TAB =================
      var selectedCategoryFilter by remember { mutableStateOf("الكل") }
      val expenseCategories = listOf("الكل", "إيجار", "رواتب", "كهرباء ومرافق", "نقل وبنزين", "نثريات وضيافة", "أخرى")

      val filteredExpenses = remember(expenses, selectedCategoryFilter) {
        if (selectedCategoryFilter == "الكل") expenses
        else expenses.filter { it.category.contains(selectedCategoryFilter, ignoreCase = true) }
      }

      val totalFilteredExpense = remember(filteredExpenses) {
        filteredExpenses.sumOf { it.amount }
      }

      Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          // Total Expenses Header
          item {
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text("إجمالي المصروفات التشغيلية:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onErrorContainer)
                  Text(
                    text = String.format(Locale.ENGLISH, "%.2f %s", totalFilteredExpense, businessProfile.currency),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error
                  )
                }

                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = MaterialTheme.colorScheme.error
                ) {
                  Text(
                    text = "${filteredExpenses.size} بند",
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
              }
            }
          }

          // Category Filters
          item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              items(expenseCategories) { cat ->
                FilterChip(
                  selected = selectedCategoryFilter == cat,
                  onClick = { selectedCategoryFilter = cat },
                  label = { Text(cat, fontSize = 12.sp) },
                  colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = OrangePrimary,
                    selectedLabelColor = Color.White
                  )
                )
              }
            }
          }

          items(filteredExpenses, key = { it.id }) { expense ->
            ExpenseCard(expense = expense, currency = businessProfile.currency, onDelete = { viewModel.deleteExpense(expense) })
          }

          if (filteredExpenses.isEmpty()) {
            item {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(40.dp),
                contentAlignment = Alignment.Center
              ) {
                Text("لا توجد مصروفات مسجلة بهذا البند", color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }

        FloatingActionButton(
          onClick = { showAddExpenseDialog = true },
          modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(16.dp),
          containerColor = OrangePrimary,
          contentColor = Color.White
        ) {
          Icon(Icons.Default.Add, contentDescription = "إضافة مصروف")
        }
      }
    }
  }

  // Cashbox Switcher Dialog
  if (showCashboxSwitchDialog) {
    val cashboxes = listOf(
      "الخزينة الرئيسية (درج النقدية)",
      "محفظة فودافون كاش / إنستاباي",
      "الحساب البنكي (البنك الأهلي)"
    )
    Dialog(onDismissRequest = { showCashboxSwitchDialog = false }) {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth(0.92f)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Text("اختيار الخزينة النشطة", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          Spacer(modifier = Modifier.height(10.dp))
          cashboxes.forEach { boxName ->
            val isSelected = boxName == businessProfile.selectedCashbox
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(if (isSelected) OrangePrimary.copy(alpha = 0.15f) else Color.Transparent)
                .clickable {
                  viewModel.selectCashbox(boxName)
                  showCashboxSwitchDialog = false
                }
                .padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = if (boxName.contains("فودافون")) Icons.Default.Payment else if (boxName.contains("البنك")) Icons.Default.AccountBalance else Icons.Default.AccountBalanceWallet,
                contentDescription = null,
                tint = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = boxName,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.onSurface
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
          }
        }
      }
    }
  }

  // Add Expense Dialog
  if (showAddExpenseDialog) {
    AddExpenseDetailedDialog(
      defaultCashbox = businessProfile.selectedCashbox,
      onDismiss = { showAddExpenseDialog = false },
      onSave = { category, amount, recipient, notes ->
        viewModel.addExpense(category, amount, recipient, notes)
        showAddExpenseDialog = false
      }
    )
  }

  // Add Cash Deposit Dialog (إيداع نقدية في الخزينة)
  if (showAddCashDepositDialog) {
    AddCashDepositDialog(
      chosenCashbox = businessProfile.selectedCashbox,
      onDismiss = { showAddCashDepositDialog = false },
      onSave = { amount, source, notes, customTimestamp ->
        viewModel.recordCashDeposit(
          amount = amount,
          source = source,
          notes = notes,
          customTimestamp = customTimestamp
        ) { txId ->
          Toast.makeText(context, "تم إيداع مبلغ ${String.format(Locale.ENGLISH, "%.2f", amount)} بالخزينة وتحديث الرصيد فوراً ✓", Toast.LENGTH_SHORT).show()
        }
        showAddCashDepositDialog = false
      }
    )
  }

  if (showQuickSanadDialog) {
    QuickSanadVoucherDialog(
      customers = customers,
      suppliers = suppliers,
      onDismiss = { showQuickSanadDialog = false },
      onIssueReceiptVoucher = { cust, amt, notes, onDone ->
        viewModel.recordCustomerPayment(cust, amt, notes) { createdTx ->
          showQuickSanadDialog = false
          previewVoucher = createdTx
          onDone(createdTx)
        }
      },
      onIssuePaymentVoucher = { sup, amt, notes, onDone ->
        viewModel.recordSupplierPayment(sup, amt, notes) { createdTx ->
          showQuickSanadDialog = false
          previewVoucher = createdTx
          onDone(createdTx)
        }
      }
    )
  }

  previewVoucher?.let { tx ->
    VoucherReceiptDialog(
      transaction = tx,
      businessName = businessProfile.businessName,
      businessPhone = businessProfile.contactPhone,
      currency = businessProfile.currency,
      onDismiss = { previewVoucher = null }
    )
  }
}

@Composable
fun CashLogItem(
  title: String,
  subtitle: String,
  time: Long,
  amount: Double,
  isInflow: Boolean,
  currency: String
) {
  val dateStr = SimpleDateFormat("dd/MM - hh:mm a", Locale("ar")).format(Date(time))
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(
          shape = CircleShape,
          color = if (isInflow) EmeraldPrimary.copy(alpha = 0.15f) else CrimsonRed.copy(alpha = 0.15f),
          modifier = Modifier.size(36.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = if (isInflow) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
              contentDescription = null,
              tint = if (isInflow) EmeraldPrimary else CrimsonRed,
              modifier = Modifier.size(20.dp)
            )
          }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(dateStr, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
        }
      }

      Text(
        text = String.format(Locale.ENGLISH, "%s%.1f %s", if (isInflow) "+" else "-", amount, currency),
        fontWeight = FontWeight.ExtraBold,
        fontSize = 14.sp,
        color = if (isInflow) EmeraldPrimary else CrimsonRed
      )
    }
  }
}

@Composable
fun ExpenseCard(
  expense: Expense,
  currency: String,
  onDelete: () -> Unit
) {
  val dateStr = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")).format(Date(expense.timestamp))
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = OrangePrimary.copy(alpha = 0.15f)
          ) {
            Text(
              text = expense.category,
              color = OrangePrimary,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }
          if (expense.recipient.isNotBlank()) {
            Spacer(modifier = Modifier.width(6.dp))
            Text("المستلم: ${expense.recipient}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }

        if (expense.notes.isNotBlank()) {
          Spacer(modifier = Modifier.height(4.dp))
          Text(expense.notes, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(dateStr, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = String.format(Locale.ENGLISH, "%.2f %s", expense.amount, currency),
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
          color = MaterialTheme.colorScheme.error
        )
        IconButton(onClick = onDelete) {
          Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.outline)
        }
      }
    }
  }
}

@Composable
fun AddExpenseDetailedDialog(
  defaultCashbox: String,
  onDismiss: () -> Unit,
  onSave: (category: String, amount: Double, recipient: String, notes: String) -> Unit
) {
  var category by remember { mutableStateOf("نثريات وضيافة") }
  var amountStr by remember { mutableStateOf("") }
  var recipient by remember { mutableStateOf("") }
  var notes by remember { mutableStateOf("") }
  var chosenCashbox by remember { mutableStateOf(defaultCashbox) }

  val predefinedCategories = listOf("إيجار", "رواتب وعمالة", "كهرباء ومرافق", "نقل وبنزين", "نثريات وضيافة", "أدوات نظافة", "أخرى")

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.96f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("تسجيل مصروف تشغيلي جديد", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        OutlinedTextField(
          value = amountStr,
          onValueChange = { amountStr = it },
          label = { Text("المبلغ المنصرف *") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          modifier = Modifier.fillMaxWidth()
        )

        Text("بند المصروف:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(predefinedCategories) { cat ->
            FilterChip(
              selected = category == cat,
              onClick = { category = cat },
              label = { Text(cat, fontSize = 11.sp) }
            )
          }
        }

        OutlinedTextField(
          value = recipient,
          onValueChange = { recipient = it },
          label = { Text("اسم المستلم (الموظف / المؤجر / المندوب)") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("ملاحظات وبيان الصرف") },
          maxLines = 2,
          modifier = Modifier.fillMaxWidth()
        )

        Text("الخزينة المسحوب منها: $chosenCashbox", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val amt = amountStr.toDoubleOrNull() ?: 0.0
              if (amt > 0) {
                onSave(category, amt, recipient, notes)
              }
            },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary)
          ) {
            Text("حفظ وصرف من الخزينة", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(0.6f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

// ================= نافذة إيداع وتغذية نقدية بالخزينة =================
@Composable
fun AddCashDepositDialog(
  chosenCashbox: String,
  onDismiss: () -> Unit,
  onSave: (amount: Double, source: String, notes: String, customTimestamp: Long?) -> Unit
) {
  val context = LocalContext.current
  var amountStr by remember { mutableStateOf("") }
  var source by remember { mutableStateOf("تغذية نقدية للدرج") }
  var notes by remember { mutableStateOf("") }
  var customTimestamp by remember { mutableStateOf<Long?>(null) }

  val predefinedSources = listOf(
    "تغذية نقدية للدرج",
    "رأس مال إضافي",
    "سحب من البنك",
    "تمويل / سلفة",
    "إيرادات أخرى متنوعة",
    "رصيد افتتاحي"
  )

  val quickAmounts = listOf(500.0, 1000.0, 2000.0, 5000.0, 10000.0, 20000.0)
  val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale("ar")) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp,
      modifier = Modifier.fillMaxWidth(0.96f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = CircleShape,
              color = EmeraldPrimary.copy(alpha = 0.15f),
              modifier = Modifier.size(36.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AddCard, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
              }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text("إيداع وتغذية نقدية بالخزينة", fontWeight = FontWeight.Bold, fontSize = 16.sp)
              Text("إضافة سيولة نقدية مباشرة لدرج النقدية", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        HorizontalDivider()

        Text("الخزينة المودع بها: $chosenCashbox", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = EmeraldPrimary)

        OutlinedTextField(
          value = amountStr,
          onValueChange = { amountStr = it },
          label = { Text("المبلغ المودع بالجنيه (ج.م) *", fontWeight = FontWeight.Bold) },
          placeholder = { Text("مثال: 5000") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        // فئات نقدية سريعة للإيداع
        Text("فئات إيداع سريعة:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(quickAmounts) { amt ->
            FilterChip(
              selected = amountStr == String.format(Locale.ENGLISH, "%.0f", amt),
              onClick = { amountStr = String.format(Locale.ENGLISH, "%.0f", amt) },
              label = { Text("+${amt.toInt()} ج.م", fontSize = 11.sp) }
            )
          }
        }

        Text("مصدر النقدية / سبب الإيداع:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(predefinedSources) { s ->
            FilterChip(
              selected = source == s,
              onClick = { source = s },
              label = { Text(s, fontSize = 11.sp) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = EmeraldPrimary.copy(alpha = 0.2f),
                selectedLabelColor = EmeraldPrimary
              )
            )
          }
        }

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("بيان وملاحظات الإيداع (اختياري)") },
          placeholder = { Text("مثال: سحب من الحساب البنكي لتغذية الدرج لمشتريات اليوم..") },
          maxLines = 2,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        // تاريخ الإيداع
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "تاريخ العملية: ${dateFormat.format(Date(customTimestamp ?: System.currentTimeMillis()))}",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          TextButton(
            onClick = {
              val cal = Calendar.getInstance()
              DatePickerDialog(
                context,
                { _, y, m, d ->
                  cal.set(Calendar.YEAR, y)
                  cal.set(Calendar.MONTH, m)
                  cal.set(Calendar.DAY_OF_MONTH, d)
                  customTimestamp = cal.timeInMillis
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
              ).show()
            }
          ) {
            Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("تغيير التاريخ", fontSize = 11.sp)
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val amt = amountStr.toDoubleOrNull() ?: 0.0
              if (amt > 0) {
                onSave(amt, source, notes, customTimestamp)
              } else {
                Toast.makeText(context, "يرجى كتابة مبلغ إيداع صحيح أكبر من صفر", Toast.LENGTH_SHORT).show()
              }
            },
            modifier = Modifier.weight(1.3f),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            shape = RoundedCornerShape(10.dp)
          ) {
            Icon(Icons.Default.AddCard, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("تأكيد الإيداع بالخزينة 💵", fontWeight = FontWeight.Bold)
          }

          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(0.7f), shape = RoundedCornerShape(10.dp)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}
