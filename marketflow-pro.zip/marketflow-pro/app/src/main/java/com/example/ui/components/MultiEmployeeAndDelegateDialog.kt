package com.example.ui.components

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Employee
import com.example.data.settings.BusinessProfile
import com.example.ui.WholesaleViewModel
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import com.example.utils.DelegateSyncManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// =============================================================================
// النافذة الشاملة لإدارة الموظفين، المناديب، الصلاحيات، ومزامنة الأجهزة عن بعد
// =============================================================================
@Composable
fun MultiEmployeeAndDelegateDialog(
  viewModel: WholesaleViewModel,
  initial: BusinessProfile,
  onDismiss: () -> Unit,
  onSaveProfile: (BusinessProfile) -> Unit
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val clipboardManager = LocalClipboardManager.current

  val employees by viewModel.allEmployees.collectAsStateWithLifecycle()
  val syncLogs by viewModel.delegateSyncLogs.collectAsStateWithLifecycle()
  val pendingInvoices by viewModel.pendingSyncInvoices.collectAsStateWithLifecycle()

  var selectedTab by remember { mutableIntStateOf(0) } // 0: الموظفون والصلاحيات, 1: ربط جهاز المندوب, 2: المزامنة والحزم

  // إدارة تعديل / إضافة موظف
  var showEmployeeEditDialog by remember { mutableStateOf(false) }
  var editingEmployee by remember { mutableStateOf<Employee?>(null) }

  // حالة المزامنة اللحظية
  var isSyncing by remember { mutableStateOf(false) }
  var syncStatusMessage by remember { mutableStateOf("") }
  var showImportPayloadDialog by remember { mutableStateOf(false) }
  var pastedPayloadText by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp,
      modifier = Modifier
        .fillMaxWidth(0.98f)
        .padding(vertical = 12.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // رأس النافذة
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = CircleShape,
              color = Color(0xFFDC2626).copy(alpha = 0.12f),
              modifier = Modifier.size(40.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.Security,
                  contentDescription = null,
                  tint = Color(0xFFDC2626),
                  modifier = Modifier.size(24.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "نظام الموظفين والمناديب والمزامنة",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.5.sp
              )
              Text(
                text = "صلاحيات دقيقة بناءً على طلب المدير + مزامنة أوفلاين وسحابية",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
            Text("✕", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          }
        }

        HorizontalDivider()

        // تبويبات النافذة الرئيسية
        TabRow(
          selectedTabIndex = selectedTab,
          containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
          contentColor = MaterialTheme.colorScheme.primary,
          modifier = Modifier.fillMaxWidth()
        ) {
          Tab(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            text = { Text("👥 الموظفون والصلاحيات", fontSize = 11.5.sp, fontWeight = FontWeight.Bold) }
          )
          Tab(
            selected = selectedTab == 1,
            onClick = { selectedTab = 1 },
            text = { Text("📱 ربط جهاز المندوب", fontSize = 11.5.sp, fontWeight = FontWeight.Bold) }
          )
          Tab(
            selected = selectedTab == 2,
            onClick = { selectedTab = 2 },
            text = { Text("🔄 المزامنة وفواتير المناديب", fontSize = 11.5.sp, fontWeight = FontWeight.Bold) }
          )
        }

        // ---------------------------------------------------------------------
        // التبويب 0: قائمة الموظفين وإدارتهم وتحديد صلاحياتهم الدقيقة
        // ---------------------------------------------------------------------
        if (selectedTab == 0) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "قائمة موظفي المنشأة (${employees.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 13.5.sp
              )
              Text(
                text = "المستخدم النشط حالياً: ${initial.activeEmployeeName} (${initial.activeEmployeeRole})",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.primary
              )
            }

            Button(
              onClick = {
                editingEmployee = Employee(
                  name = "",
                  phone = "",
                  pinCode = "1234",
                  role = "كاشير",
                  isDelegate = false,
                  pairingCode = initial.companySyncKey
                )
                showEmployeeEditDialog = true
              },
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("إضافة موظف", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }

          if (employees.isEmpty()) {
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            ) {
              Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                Text("لا يوجد موظفون مسجلون. اضغط إضافة موظف جديد.", fontSize = 12.sp)
              }
            }
          } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              employees.forEach { emp ->
                val isActiveUser = emp.id == initial.activeEmployeeId || emp.name == initial.activeEmployeeName
                Card(
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(14.dp),
                  colors = CardDefaults.cardColors(
                    containerColor = if (isActiveUser) EmeraldPrimary.copy(alpha = 0.1f)
                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                  ),
                  border = if (isActiveUser) BorderStroke(1.5.dp, EmeraldPrimary) else null
                ) {
                  Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                          shape = CircleShape,
                          color = if (emp.isDelegate) OrangePrimary else if (emp.role.contains("مدير")) Color(0xFFDC2626) else MaterialTheme.colorScheme.primary,
                          modifier = Modifier.size(34.dp)
                        ) {
                          Box(contentAlignment = Alignment.Center) {
                            Icon(
                              imageVector = if (emp.isDelegate) Icons.Default.TwoWheeler else Icons.Default.Person,
                              contentDescription = null,
                              tint = Color.White,
                              modifier = Modifier.size(20.dp)
                            )
                          }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                          Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                              text = emp.name,
                              fontWeight = FontWeight.Bold,
                              fontSize = 13.5.sp
                            )
                            if (isActiveUser) {
                              Spacer(modifier = Modifier.width(6.dp))
                              Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = EmeraldPrimary,
                                modifier = Modifier.padding(2.dp)
                              ) {
                                Text(
                                  text = "الحالي النشط ✓",
                                  color = Color.White,
                                  fontSize = 9.5.sp,
                                  fontWeight = FontWeight.Bold,
                                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                              }
                            }
                          }
                          Text(
                            text = "${emp.role} • هاتف: ${emp.phone.ifBlank { "غير مسجل" }} • PIN: ${emp.pinCode}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                          )
                        }
                      }

                      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                          onClick = {
                            editingEmployee = emp
                            showEmployeeEditDialog = true
                          },
                          modifier = Modifier.size(32.dp)
                        ) {
                          Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        }
                        if (emp.role != "مدير عام") {
                          IconButton(
                            onClick = {
                              viewModel.deleteEmployee(emp) {
                                Toast.makeText(context, "تم حذف الموظف: ${emp.name}", Toast.LENGTH_SHORT).show()
                              }
                            },
                            modifier = Modifier.size(32.dp)
                          ) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                          }
                        }
                      }
                    }

                    // شريط الصلاحيات السريعة للموظف
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                      PermissionBadge(label = "بيع", granted = emp.canSell)
                      PermissionBadge(label = "شراء", granted = emp.canPurchase)
                      PermissionBadge(label = "رؤية الأرباح", granted = emp.canViewProfits)
                      PermissionBadge(label = "تعديل سعر يدوي", granted = emp.canManualPriceOverride)
                      PermissionBadge(label = "حذف فواتير", granted = emp.canDeleteInvoice)
                      if (emp.isDelegate) {
                        PermissionBadge(label = "مندوب ميداني 🛵", granted = true, highlight = true)
                      }
                    }

                    if (!isActiveUser) {
                      Button(
                        onClick = {
                          viewModel.setActiveEmployee(emp)
                          Toast.makeText(context, "تم التبديل إلى المستخدم: ${emp.name}", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth().height(34.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f))
                      ) {
                        Text("التبديل والعمل بهذا الحساب كـ [${emp.role}]", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                      }
                    }
                  }
                }
              }
            }
          }
        }

        // ---------------------------------------------------------------------
        // التبويب 1: وضع الجهاز والربط مع جهاز المندوب
        // ---------------------------------------------------------------------
        if (selectedTab == 1) {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f))
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Devices, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("تحديد دور هذا الجهاز في المنظومة", fontWeight = FontWeight.Bold, fontSize = 14.sp)
              }

              Text(
                text = "هل هذا الجهاز هو جهاز المدير الرئيسي للمحل، أم جهاز مندوب مبيعات خارجي يعمل في التوزيع؟",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )

              // خيار جهاز المدير
              val isManager = initial.deviceRole == "MANAGER"
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable {
                    viewModel.setDeviceRole("MANAGER", initial.companySyncKey)
                    Toast.makeText(context, "تم ضبط هذا الجهاز كـ [جهاز المدير الرئيسي]", Toast.LENGTH_SHORT).show()
                  },
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(
                  containerColor = if (isManager) EmeraldPrimary.copy(alpha = 0.15f)
                  else MaterialTheme.colorScheme.surface
                ),
                border = if (isManager) BorderStroke(1.5.dp, EmeraldPrimary) else null
              ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                  RadioButton(selected = isManager, onClick = {
                    viewModel.setDeviceRole("MANAGER", initial.companySyncKey)
                  })
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Text("جهاز المدير الرئيسي (المركزي)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("يستقبل مبيعات المناديب، يمتلك كامل الصلاحيات والتقارير وإدارة الموظفين والأسعار.", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
              }

              // خيار جهاز المندوب
              val isDelegate = initial.deviceRole == "DELEGATE"
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable {
                    val firstDelegate = employees.firstOrNull { it.isDelegate }
                    viewModel.setDeviceRole(
                      role = "DELEGATE",
                      syncKey = initial.companySyncKey,
                      delegateId = firstDelegate?.id ?: 0L,
                      delegateName = firstDelegate?.name ?: "مندوب مبيعات"
                    )
                    Toast.makeText(context, "تم ضبط هذا الجهاز كـ [جهاز مندوب ميداني]", Toast.LENGTH_SHORT).show()
                  },
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(
                  containerColor = if (isDelegate) OrangePrimary.copy(alpha = 0.15f)
                  else MaterialTheme.colorScheme.surface
                ),
                border = if (isDelegate) BorderStroke(1.5.dp, OrangePrimary) else null
              ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                  RadioButton(selected = isDelegate, onClick = {
                    val firstDelegate = employees.firstOrNull { it.isDelegate }
                    viewModel.setDeviceRole(
                      role = "DELEGATE",
                      syncKey = initial.companySyncKey,
                      delegateId = firstDelegate?.id ?: 0L,
                      delegateName = firstDelegate?.name ?: "مندوب مبيعات"
                    )
                  })
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Text("جهاز مندوب مبيعات وتوزيع ميداني (أوفلاين)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("يقوم بإنشاء فواتير المبيعات بدون إنترنت، وبمجرد فتح النت تُرسل الفواتير تلقائياً لجهاز المدير.", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
              }
            }
          }

          // مفتاح ربط المؤسسة (Company Sync Key)
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Key, contentDescription = null, tint = OrangePrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("رمز ربط الأجهزة المشترك (Sync Key)", fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
              }

              Text(
                text = "يجب إدخال نفس الرمز على جهاز المدير وجهاز المندوب لضمان تشفير وسلامة وصول الفواتير للمحل الصحيح:",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )

              var currentSyncKey by remember { mutableStateOf(initial.companySyncKey) }
              Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                  value = currentSyncKey,
                  onValueChange = { currentSyncKey = it },
                  label = { Text("رمز الربط المشترك") },
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(10.dp),
                  singleLine = true
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                  onClick = {
                    viewModel.updateBusinessProfile(initial.copy(companySyncKey = currentSyncKey.trim()))
                    Toast.makeText(context, "تم حفظ رمز الربط بنجاح ✓", Toast.LENGTH_SHORT).show()
                  },
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Text("حفظ")
                }
              }

              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                  onClick = {
                    clipboardManager.setText(AnnotatedString(initial.companySyncKey))
                    Toast.makeText(context, "تم نسخ رمز الربط إلى الحافظة", Toast.LENGTH_SHORT).show()
                  },
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Text("نسخ الرمز 📋", fontSize = 11.5.sp)
                }

                OutlinedButton(
                  onClick = {
                    val newCode = "WAKEEL-" + (1000..9999).random()
                    currentSyncKey = newCode
                    viewModel.updateBusinessProfile(initial.copy(companySyncKey = newCode))
                    Toast.makeText(context, "تم توليد رمز ربط جديد: $newCode", Toast.LENGTH_SHORT).show()
                  },
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Text("توليد كود جديد 🔀", fontSize = 11.5.sp)
                }
              }
            }
          }

          // اختيار المندوب المقترن بهذا الجهاز (في حال وضع المندوب)
          if (initial.deviceRole == "DELEGATE") {
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = OrangePrimary.copy(alpha = 0.1f)),
              border = BorderStroke(1.dp, OrangePrimary)
            ) {
              Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المندوب المنسوب إليه هذا الجهاز:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                val delegates = employees.filter { it.isDelegate }
                if (delegates.isEmpty()) {
                  Text("تنبيه: لا يوجد موظف مسجل بصفة (مندوب). يرجى إضافة مندوب من تبويب الموظفين.", fontSize = 11.sp, color = Color.Red)
                } else {
                  delegates.forEach { del ->
                    val isChosen = initial.delegateEmployeeId == del.id
                    Card(
                      modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                          viewModel.setDeviceRole("DELEGATE", initial.companySyncKey, del.id, del.name)
                          Toast.makeText(context, "تم تعيين المندوب: ${del.name}", Toast.LENGTH_SHORT).show()
                        },
                      shape = RoundedCornerShape(8.dp),
                      colors = CardDefaults.cardColors(
                        containerColor = if (isChosen) OrangePrimary.copy(alpha = 0.2f)
                        else MaterialTheme.colorScheme.surface
                      )
                    ) {
                      Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = isChosen, onClick = {
                          viewModel.setDeviceRole("DELEGATE", initial.companySyncKey, del.id, del.name)
                        })
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("${del.name} (هاتف: ${del.phone})", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                      }
                    }
                  }
                }
              }
            }
          }
        }

        // ---------------------------------------------------------------------
        // التبويب 2: تشغيل المزامنة، رفع واستيراد فواتير المناديب أوفلاين وسحابياً
        // ---------------------------------------------------------------------
        if (selectedTab == 2) {
          val isOnline = remember { DelegateSyncManager.isOnline(context) }

          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (isOnline) EmeraldPrimary.copy(alpha = 0.12f)
              else Color(0xFFF59E0B).copy(alpha = 0.12f)
            )
          ) {
            Row(
              modifier = Modifier.padding(14.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = if (isOnline) Icons.Default.Wifi else Icons.Default.WifiOff,
                  contentDescription = null,
                  tint = if (isOnline) EmeraldPrimary else Color(0xFFD97706),
                  modifier = Modifier.size(26.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = if (isOnline) "حالة الإنترنت: متصل بالشبكة ✓" else "حالة الإنترنت: غير متصل (أوفلاين) 📴",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp,
                    color = if (isOnline) EmeraldPrimary else Color(0xFFD97706)
                  )
                  Text(
                    text = if (isOnline) "المزامنة التلقائية جاهزة لإرسال واستقبال الفواتير"
                    else "المندوب يعمل بحرية تامة دون إنترنت، وتتجمع فواتيره لترحيلها فور الاتصال",
                    fontSize = 10.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }
          }

          // حالة الفواتير المعلقة
          if (initial.deviceRole == "DELEGATE") {
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
            ) {
              Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                  text = "فواتير المبيعات الصادرة من المندوب والمعلقة محلياً:",
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.5.sp
                )
                Text(
                  text = "عدد الفواتير الجاهزة للإرسال لجهاز المدير: ${pendingInvoices.size} فاتورة",
                  fontSize = 12.sp,
                  color = if (pendingInvoices.isNotEmpty()) Color(0xFFDC2626) else EmeraldPrimary,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          // زر المزامنة الرئيسي الفوري
          Button(
            onClick = {
              isSyncing = true
              syncStatusMessage = "جارٍ فحص الاتصال ومزامنة فواتير المناديب..."
              viewModel.syncDelegateInvoicesNow { res ->
                isSyncing = false
                syncStatusMessage = res.message
                Toast.makeText(context, res.message, Toast.LENGTH_LONG).show()
              }
            },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (initial.deviceRole == "DELEGATE") OrangePrimary else EmeraldPrimary
            ),
            enabled = !isSyncing
          ) {
            if (isSyncing) {
              CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
              Spacer(modifier = Modifier.width(8.dp))
              Text("جارٍ المزامنة...", fontWeight = FontWeight.Bold)
            } else {
              Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (initial.deviceRole == "DELEGATE") "إرسال فواتير المندوب لجهاز المدير الآن"
                else "فحص واستقبال مبيعات المناديب وتحديث الحسابات",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              )
            }
          }

          if (syncStatusMessage.isNotBlank()) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = syncStatusMessage,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(10.dp)
              )
            }
          }

          HorizontalDivider()

          // خيارات المزامنة اليدوية (مشاركة ملف عبر واتساب / نسخ حزمة أوفلاين)
          Text("مزامنة أوفلاين بديلة (مشاركة ملف / واتساب):", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // تصدير حزمة المندوب
            OutlinedButton(
              onClick = {
                viewModel.getDelegateOfflineSyncPayload { payload ->
                  DelegateSyncManager.shareDelegateSyncFile(
                    context = context,
                    payloadJson = payload,
                    delegateName = initial.delegateEmployeeName.ifBlank { initial.userName }
                  )
                }
              },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("إرسال ملف الحزمة (واتساب)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            // استيراد حزمة من ملف أو نص على جهاز المدير
            Button(
              onClick = { showImportPayloadDialog = true },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
              Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("استيراد حزمة مندوب", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }

          // سجل آخر عمليات المزامنة
          Text("سجل حركات المزامنة الأخيرة (${syncLogs.size}):", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
          if (syncLogs.isEmpty()) {
            Text("لا توجد سجلات مزامنة سابقة حتى الآن.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          } else {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              syncLogs.take(5).forEach { log ->
                val timeStr = SimpleDateFormat("dd/MM hh:mm a", Locale("ar")).format(Date(log.timestamp))
                Card(
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(8.dp),
                  colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                ) {
                  Row(
                    modifier = Modifier.padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column {
                      Text(
                        text = "المندوب: ${log.delegateName} • $timeStr",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                      )
                      Text(
                        text = log.notes,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                    }
                    Text(
                      text = "${log.invoicesCount} فاتورة",
                      fontWeight = FontWeight.ExtraBold,
                      fontSize = 11.sp,
                      color = EmeraldPrimary
                    )
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // زر الإغلاق النهائي
        Button(
          onClick = onDismiss,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        ) {
          Text("تم وإغلاق النافذة", fontWeight = FontWeight.Bold)
        }
      }
    }
  }

  // ---------------------------------------------------------------------------
  // نافذة إضافة / تعديل موظف وصلاحياته المخصصة
  // ---------------------------------------------------------------------------
  if (showEmployeeEditDialog && editingEmployee != null) {
    EmployeeEditAndPermissionsSubDialog(
      employee = editingEmployee!!,
      onDismiss = { showEmployeeEditDialog = false },
      onSave = { updatedEmp ->
        viewModel.saveEmployee(updatedEmp) {
          showEmployeeEditDialog = false
          Toast.makeText(context, "تم حفظ بيانات الموظف والصلاحيات بنجاح ✓", Toast.LENGTH_SHORT).show()
        }
      }
    )
  }

  // ---------------------------------------------------------------------------
  // نافذة استيراد حزمة فواتير المندوب (لصق نص الحزمة أو قراءتها)
  // ---------------------------------------------------------------------------
  if (showImportPayloadDialog) {
    Dialog(onDismissRequest = { showImportPayloadDialog = false }) {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth(0.96f).padding(16.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("استيراد حزمة فواتير مبيعات المندوب", fontWeight = FontWeight.Bold, fontSize = 14.sp)
          Text(
            text = "قم بلصق محتوى حزمة المندوب المستلمة عبر الواتساب أو الملف لتنزيل فواتيرها وتحديث حسابات العملاء مباشرة في جهاز المدير:",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          OutlinedTextField(
            value = pastedPayloadText,
            onValueChange = { pastedPayloadText = it },
            label = { Text("محتوى حزمة المندوب (JSON)") },
            modifier = Modifier.fillMaxWidth().height(140.dp),
            shape = RoundedCornerShape(10.dp)
          )

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = {
                val clip = clipboardManager.getText()?.text
                if (!clip.isNullOrBlank()) {
                  pastedPayloadText = clip
                }
              },
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f),
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
              Text("لصق من الحافظة 📋", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Button(
              onClick = {
                if (pastedPayloadText.isBlank()) {
                  Toast.makeText(context, "يرجى لصق محتوى الحزمة أولاً", Toast.LENGTH_SHORT).show()
                  return@Button
                }
                viewModel.importDelegateSyncPayload(pastedPayloadText) { res ->
                  showImportPayloadDialog = false
                  pastedPayloadText = ""
                  Toast.makeText(context, res.message, Toast.LENGTH_LONG).show()
                }
              },
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f),
              colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
              Text("تأكيد الاستيراد ✓", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

// =============================================================================
// شارة صغيرة للصلاحية
// =============================================================================
@Composable
private fun PermissionBadge(label: String, granted: Boolean, highlight: Boolean = false) {
  Surface(
    shape = RoundedCornerShape(6.dp),
    color = if (highlight) OrangePrimary.copy(alpha = 0.2f)
    else if (granted) EmeraldPrimary.copy(alpha = 0.15f)
    else Color.Gray.copy(alpha = 0.12f)
  ) {
    Text(
      text = if (granted) "$label ✓" else "$label ✕",
      fontSize = 9.5.sp,
      fontWeight = FontWeight.Bold,
      color = if (highlight) OrangePrimary
      else if (granted) EmeraldPrimary
      else Color.Gray,
      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
    )
  }
}

// =============================================================================
// النافذة الفرعية: تعديل بيانات الموظف وصلاحياته الدقيقة
// =============================================================================
@Composable
private fun EmployeeEditAndPermissionsSubDialog(
  employee: Employee,
  onDismiss: () -> Unit,
  onSave: (Employee) -> Unit
) {
  var name by remember { mutableStateOf(employee.name) }
  var phone by remember { mutableStateOf(employee.phone) }
  var pinCode by remember { mutableStateOf(employee.pinCode) }
  var role by remember { mutableStateOf(employee.role) }
  var isDelegate by remember { mutableStateOf(employee.isDelegate) }

  // تفاصيل الصلاحيات الفردية
  var canSell by remember { mutableStateOf(employee.canSell) }
  var canPurchase by remember { mutableStateOf(employee.canPurchase) }
  var canViewCostPrice by remember { mutableStateOf(employee.canViewCostPrice) }
  var canViewProfits by remember { mutableStateOf(employee.canViewProfits) }
  var canGiveDiscount by remember { mutableStateOf(employee.canGiveDiscount) }
  var canManualPriceOverride by remember { mutableStateOf(employee.canManualPriceOverride) }
  var canManageWarehouse by remember { mutableStateOf(employee.canManageWarehouse) }
  var canManageCustomers by remember { mutableStateOf(employee.canManageCustomers) }
  var canCollectCash by remember { mutableStateOf(employee.canCollectCash) }
  var canDeleteInvoice by remember { mutableStateOf(employee.canDeleteInvoice) }
  var canAccessReports by remember { mutableStateOf(employee.canAccessReports) }
  var canAccessSettings by remember { mutableStateOf(employee.canAccessSettings) }

  val roleTemplates = listOf(
    "مدير عام",
    "كاشير",
    "مندوب مبيعات",
    "محاسب",
    "أمين مخزن"
  )

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.96f).padding(vertical = 14.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text(
          text = if (employee.id > 0) "تعديل بيانات وصلاحيات: ${employee.name}" else "إضافة موظف جديد وتحديد صلاحياته",
          fontWeight = FontWeight.ExtraBold,
          fontSize = 15.sp
        )

        HorizontalDivider()

        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("اسم الموظف أو المندوب *") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp),
          singleLine = true
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("رقم الهاتف") },
            modifier = Modifier.weight(1.2f),
            shape = RoundedCornerShape(10.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true
          )

          OutlinedTextField(
            value = pinCode,
            onValueChange = { pinCode = it },
            label = { Text("رمز PIN الدخول") },
            modifier = Modifier.weight(0.8f),
            shape = RoundedCornerShape(10.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true
          )
        }

        Text("المسمى الوظيفي / الدور:", fontSize = 12.sp, fontWeight = FontWeight.Bold)

        // أزرار قوالب الأدوار السريعة
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          roleTemplates.forEach { tRole ->
            FilterChip(
              selected = role == tRole,
              onClick = {
                role = tRole
                // ضبط افتراضي ذكي للصلاحيات بحسب الدور المختار
                when (tRole) {
                  "مدير عام" -> {
                    isDelegate = false
                    canSell = true; canPurchase = true; canViewCostPrice = true; canViewProfits = true
                    canGiveDiscount = true; canManualPriceOverride = true; canManageWarehouse = true
                    canManageCustomers = true; canCollectCash = true; canDeleteInvoice = true
                    canAccessReports = true; canAccessSettings = true
                  }
                  "كاشير" -> {
                    isDelegate = false
                    canSell = true; canPurchase = false; canViewCostPrice = false; canViewProfits = false
                    canGiveDiscount = true; canManualPriceOverride = false; canManageWarehouse = false
                    canManageCustomers = true; canCollectCash = true; canDeleteInvoice = false
                    canAccessReports = false; canAccessSettings = false
                  }
                  "مندوب مبيعات" -> {
                    isDelegate = true
                    canSell = true; canPurchase = false; canViewCostPrice = false; canViewProfits = false
                    canGiveDiscount = true; canManualPriceOverride = false; canManageWarehouse = false
                    canManageCustomers = true; canCollectCash = true; canDeleteInvoice = false
                    canAccessReports = false; canAccessSettings = false
                  }
                  "محاسب" -> {
                    isDelegate = false
                    canSell = false; canPurchase = true; canViewCostPrice = true; canViewProfits = true
                    canGiveDiscount = false; canManualPriceOverride = false; canManageWarehouse = false
                    canManageCustomers = true; canCollectCash = true; canDeleteInvoice = false
                    canAccessReports = true; canAccessSettings = false
                  }
                  "أمين مخزن" -> {
                    isDelegate = false
                    canSell = false; canPurchase = true; canViewCostPrice = false; canViewProfits = false
                    canGiveDiscount = false; canManualPriceOverride = false; canManageWarehouse = true
                    canManageCustomers = false; canCollectCash = false; canDeleteInvoice = false
                    canAccessReports = false; canAccessSettings = false
                  }
                }
              },
              label = { Text(tRole, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            )
          }
        }

        // مفتاح تمييز المندوب الميداني
        SettingRowSwitch(
          title = "هذا الموظف يعمل كمندوب مبيعات وتوزيع ميداني 🛵",
          subtitle = "يسمح بربط جهازه المنفصل ومزامنة الفواتير أوفلاين مع جهاز المدير",
          checked = isDelegate,
          onCheckedChange = { isDelegate = it }
        )

        HorizontalDivider()

        Text("الصلاحيات المخصصة للموظف بناءً على رغبة المدير:", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)

        SettingRowSwitch(
          title = "صلاحية إنشاء فواتير البيع",
          subtitle = "السماح بإجراء عمليات البيع وإصدار الفواتير",
          checked = canSell,
          onCheckedChange = { canSell = it }
        )

        SettingRowSwitch(
          title = "إظهار سعر التكلفة وهوامش الأرباح",
          subtitle = "حجب هذه الصلاحية يحمي خصوصية وسرية أرباح المحل عن الموظف",
          checked = canViewProfits,
          onCheckedChange = {
            canViewProfits = it
            canViewCostPrice = it
          }
        )

        SettingRowSwitch(
          title = "السماح بتعديل سعر البيع يدوياً في الفاتورة",
          subtitle = "تغيير سعر بيع الصنف يدوياً أثناء تحرير الفاتورة",
          checked = canManualPriceOverride,
          onCheckedChange = { canManualPriceOverride = it }
        )

        SettingRowSwitch(
          title = "السماح بمنح خصم نقدي للعملاء",
          subtitle = "إمكانية إدخال خصم على إجمالي الفاتورة",
          checked = canGiveDiscount,
          onCheckedChange = { canGiveDiscount = it }
        )

        SettingRowSwitch(
          title = "صلاحية التوريد وفواتير المشتريات",
          subtitle = "إضافة فواتير شراء وتوريد بضاعة للمخزن",
          checked = canPurchase,
          onCheckedChange = { canPurchase = it }
        )

        SettingRowSwitch(
          title = "صلاحية إدارة العملاء والتحصيل النقدي",
          subtitle = "إضافة وتعديل بيانات العملاء وسندات القبض",
          checked = canCollectCash,
          onCheckedChange = {
            canCollectCash = it
            canManageCustomers = it
          }
        )

        SettingRowSwitch(
          title = "حذف وإلغاء الفواتير الصادرة",
          subtitle = "الحذف بدون طلب كلمة سر المدير",
          checked = canDeleteInvoice,
          onCheckedChange = { canDeleteInvoice = it }
        )

        SettingRowSwitch(
          title = "صلاحية الاطلاع على التقارير المالية والتحليلات",
          subtitle = "كشف أرباح المحل وحركة الخزينة",
          checked = canAccessReports,
          onCheckedChange = { canAccessReports = it }
        )

        SettingRowSwitch(
          title = "صلاحية الوصول لإعدادات النظام الكاملة",
          subtitle = "تعديل إعدادات البرنامج وحذف البيانات",
          checked = canAccessSettings,
          onCheckedChange = { canAccessSettings = it }
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = {
              if (name.isBlank()) return@Button
              val updated = employee.copy(
                name = name.trim(),
                phone = phone.trim(),
                pinCode = pinCode.trim().ifBlank { "1234" },
                role = role,
                isDelegate = isDelegate,
                canSell = canSell,
                canPurchase = canPurchase,
                canViewCostPrice = canViewCostPrice,
                canViewProfits = canViewProfits,
                canGiveDiscount = canGiveDiscount,
                canManualPriceOverride = canManualPriceOverride,
                canManageWarehouse = canManageWarehouse,
                canManageCustomers = canManageCustomers,
                canCollectCash = canCollectCash,
                canDeleteInvoice = canDeleteInvoice,
                canAccessReports = canAccessReports,
                canAccessSettings = canAccessSettings
              )
              onSave(updated)
            },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
          ) {
            Text("حفظ بيانات الموظف والصلاحيات", fontWeight = FontWeight.Bold)
          }

          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(0.45f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

@Composable
private fun SettingRowSwitch(
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
      .padding(horizontal = 10.dp, vertical = 7.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(modifier = Modifier.weight(1f).padding(end = 6.dp)) {
      Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      Text(subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      colors = SwitchDefaults.colors(
        checkedThumbColor = Color.White,
        checkedTrackColor = EmeraldPrimary
      )
    )
  }
}
