package com.example.utils

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.PaymentTransaction
import com.example.data.model.TransactionType
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Voucher Export & Printing Helper for Sanad Accounting ("سند للمحاسبة").
 * Handles printing and PDF generation for official Receipt Vouchers (سند قبض)
 * and Payment Vouchers (سند صرف).
 */
object VoucherExportHelper {

  fun getVoucherNumber(tx: PaymentTransaction): String {
    val prefix = when (tx.type) {
      TransactionType.CUSTOMER_PAYMENT -> "REC"
      TransactionType.SUPPLIER_PAYMENT -> "PAY"
      TransactionType.CASH_DEPOSIT -> "DEP"
      TransactionType.CASH_WITHDRAWAL -> "WDR"
    }
    return String.format(Locale.ENGLISH, "%s-%05d", prefix, tx.id)
  }

  fun getVoucherTitle(tx: PaymentTransaction): String {
    return when (tx.type) {
      TransactionType.CUSTOMER_PAYMENT -> "سند قبض رسمي"
      TransactionType.SUPPLIER_PAYMENT -> "سند صرف رسمي"
      TransactionType.CASH_DEPOSIT -> "إيصال إيداع نقدي بالخزينة"
      TransactionType.CASH_WITHDRAWAL -> "إيصال سحب نقدي من الخزينة"
    }
  }

  /**
   * Generates a PDF file for the official accounting voucher.
   */
  fun generateVoucherPdf(
    context: Context,
    tx: PaymentTransaction,
    businessName: String = "الوكيل لتجارة المواد الغذائية",
    phone: String = "",
    address: String = ""
  ): File {
    val dir = File(context.cacheDir, "vouchers").apply { mkdirs() }
    val voucherNo = getVoucherNumber(tx)
    val file = File(dir, "${voucherNo}.pdf")

    val pdfDocument = PdfDocument()
    // Standard A5 landscape or A4 half in points: 595 x 420
    val pageWidth = 595
    val pageHeight = 420
    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas

    val isReceipt = tx.type == TransactionType.CUSTOMER_PAYMENT
    val headerColor = if (isReceipt) Color.rgb(16, 120, 80) else Color.rgb(180, 83, 9)

    val paint = Paint().apply { isAntiAlias = true }

    // Outer Border & Decorative frame
    paint.color = headerColor
    paint.style = Paint.Style.STROKE
    paint.strokeWidth = 3f
    canvas.drawRoundRect(15f, 15f, (pageWidth - 15).toFloat(), (pageHeight - 15).toFloat(), 8f, 8f, paint)

    paint.strokeWidth = 1f
    canvas.drawRoundRect(20f, 20f, (pageWidth - 20).toFloat(), (pageHeight - 20).toFloat(), 6f, 6f, paint)

    // Top Header Banner
    paint.style = Paint.Style.FILL
    paint.color = headerColor
    canvas.drawRect(22f, 22f, (pageWidth - 22).toFloat(), 80f, paint)

    // Header Titles
    paint.color = Color.WHITE
    paint.textSize = 18f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText(businessName, (pageWidth - 40).toFloat(), 48f, paint)

    paint.textSize = 10f
    paint.typeface = Typeface.DEFAULT
    val storeSubtitle = if (phone.isNotBlank()) "هاتف: $phone   $address" else "نظام سند لإدارة الحسابات والمخازن"
    canvas.drawText(storeSubtitle, (pageWidth - 40).toFloat(), 68f, paint)

    // Center Voucher Title Badge
    paint.textAlign = Paint.Align.CENTER
    paint.textSize = 16f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText(getVoucherTitle(tx), (pageWidth / 2).toFloat(), 55f, paint)

    // Left info (Voucher No & Date)
    paint.textAlign = Paint.Align.LEFT
    paint.textSize = 12f
    canvas.drawText("رقم السند: $voucherNo", 40f, 48f, paint)
    val dateStr = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")).format(Date(tx.timestamp))
    paint.textSize = 10f
    paint.typeface = Typeface.DEFAULT
    canvas.drawText("التاريخ: $dateStr", 40f, 68f, paint)

    // Amount Box
    paint.color = Color.rgb(243, 244, 246)
    canvas.drawRoundRect(35f, 95f, (pageWidth - 35).toFloat(), 145f, 6f, 6f, paint)

    paint.color = headerColor
    paint.textAlign = Paint.Align.RIGHT
    paint.textSize = 12f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("المبلغ المطلوب بالأرقام:", (pageWidth - 50).toFloat(), 125f, paint)

    paint.color = Color.rgb(17, 24, 39)
    paint.textSize = 16f
    val formattedAmount = String.format(Locale.ENGLISH, "%.2f ج.م", tx.amount)
    canvas.drawText(formattedAmount, (pageWidth - 180).toFloat(), 126f, paint)

    // Body Fields
    val partyLabel = if (isReceipt) "استلمنا من السيد / السادة:" else "يصرف إلى السيد / السادة:"
    var yPos = 175f

    paint.textAlign = Paint.Align.RIGHT
    paint.color = Color.rgb(75, 85, 99)
    paint.textSize = 12f
    paint.typeface = Typeface.DEFAULT
    canvas.drawText(partyLabel, (pageWidth - 50).toFloat(), yPos, paint)

    paint.color = Color.rgb(17, 24, 39)
    paint.textSize = 13f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText(tx.partyName, (pageWidth - 200).toFloat(), yPos, paint)

    // Tafqeet in Arabic Words
    yPos += 35f
    paint.color = Color.rgb(75, 85, 99)
    paint.textSize = 12f
    paint.typeface = Typeface.DEFAULT
    canvas.drawText("مبلغ وقدره كتابة:", (pageWidth - 50).toFloat(), yPos, paint)

    paint.color = headerColor
    paint.textSize = 12f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    val tafqeetText = TafqeetHelper.convertToArabicWords(tx.amount)
    canvas.drawText(tafqeetText, (pageWidth - 150).toFloat(), yPos, paint)

    // Reason / Notes
    yPos += 35f
    paint.color = Color.rgb(75, 85, 99)
    paint.textSize = 12f
    paint.typeface = Typeface.DEFAULT
    canvas.drawText("وذلك مقابل / بيان:", (pageWidth - 50).toFloat(), yPos, paint)

    paint.color = Color.rgb(17, 24, 39)
    paint.textSize = 12f
    val reasonText = if (tx.notes.isNotBlank()) tx.notes else if (isReceipt) "سداد دفعة من الحساب الآجل" else "سداد مستحقات توريد بضاعة"
    canvas.drawText(reasonText, (pageWidth - 150).toFloat(), yPos, paint)

    // Payment Method
    yPos += 30f
    paint.color = Color.rgb(75, 85, 99)
    paint.textSize = 12f
    paint.typeface = Typeface.DEFAULT
    canvas.drawText("طريقة السداد:", (pageWidth - 50).toFloat(), yPos, paint)

    paint.color = Color.rgb(17, 24, 39)
    paint.textSize = 12f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("نقداً (خزينة الصندوق)", (pageWidth - 130).toFloat(), yPos, paint)

    // Balance After Voucher (الرصيد المتبقي بعد هذا السند)
    yPos += 28f
    val balRegex = Regex("""الرصيد بعد السند:\s*([\d.]+)\s*ج\.م""")
    val matchBal = balRegex.find(tx.notes)?.groupValues?.getOrNull(1)
    if (matchBal != null) {
      paint.color = headerColor
      paint.textSize = 12f
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      val balLabel = if (isReceipt) "الرصيد المتبقي على العميل بعد هذا السند:" else "الرصيد المتبقي للمورد بعد هذا السند:"
      canvas.drawText(balLabel, (pageWidth - 50).toFloat(), yPos, paint)
      paint.color = Color.rgb(185, 28, 28)
      canvas.drawText("$matchBal ج.م", (pageWidth - 280).toFloat(), yPos, paint)
    }

    // Divider before signatures
    paint.color = Color.rgb(229, 231, 235)
    canvas.drawLine(35f, 320f, (pageWidth - 35).toFloat(), 320f, paint)

    // Signatures
    paint.color = Color.rgb(75, 85, 99)
    paint.textSize = 11f
    paint.typeface = Typeface.DEFAULT
    paint.textAlign = Paint.Align.CENTER

    val col1 = 100f
    val col2 = 250f
    val col3 = 400f
    val col4 = 510f

    val sig1 = if (isReceipt) "المستلم / أمين الصندوق" else "المستلم"
    val sig2 = "المحاسب"
    val sig3 = "اعتماد الإدارة"
    val sig4 = "الختم الرسمي"

    canvas.drawText(sig1, col4, 345f, paint)
    canvas.drawText("..................", col4, 385f, paint)

    canvas.drawText(sig2, col3, 345f, paint)
    canvas.drawText("..................", col3, 385f, paint)

    canvas.drawText(sig3, col2, 345f, paint)
    canvas.drawText("..................", col2, 385f, paint)

    canvas.drawText(sig4, col1, 345f, paint)
    canvas.drawText("[                ]", col1, 385f, paint)

    pdfDocument.finishPage(page)

    val fos = FileOutputStream(file)
    pdfDocument.writeTo(fos)
    fos.close()
    pdfDocument.close()

    return file
  }

  /**
   * Launches Android PrintManager to print the voucher.
   */
  fun printVoucher(context: Context, tx: PaymentTransaction, businessName: String = "الوكيل لتجارة المواد الغذائية") {
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
    if (printManager == null) {
      Toast.makeText(context, "خدمة الطباعة غير متاحة على هذا الجهاز", Toast.LENGTH_SHORT).show()
      return
    }

    val voucherNo = getVoucherNumber(tx)
    val pdfFile = generateVoucherPdf(context, tx, businessName)

    val printAdapter = object : PrintDocumentAdapter() {
      override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes?,
        cancellationSignal: CancellationSignal?,
        callback: LayoutResultCallback?,
        extras: Bundle?
      ) {
        if (cancellationSignal?.isCanceled == true) {
          callback?.onLayoutCancelled()
          return
        }
        val info = PrintDocumentInfo.Builder("${voucherNo}.pdf")
          .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
          .setPageCount(1)
          .build()
        callback?.onLayoutFinished(info, true)
      }

      override fun onWrite(
        pages: Array<out PageRange>?,
        destination: ParcelFileDescriptor?,
        cancellationSignal: CancellationSignal?,
        callback: WriteResultCallback?
      ) {
        try {
          val input = FileInputStream(pdfFile)
          val output = FileOutputStream(destination?.fileDescriptor)
          val buf = ByteArray(1024)
          var bytesRead: Int
          while (input.read(buf).also { bytesRead = it } > 0) {
            output.write(buf, 0, bytesRead)
          }
          callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
          input.close()
          output.close()
        } catch (e: Exception) {
          callback?.onWriteFailed(e.message)
        }
      }
    }

    val printAttributes = PrintAttributes.Builder()
      .setMediaSize(PrintAttributes.MediaSize.ISO_A5)
      .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
      .build()

    printManager.print("طباعة_${voucherNo}", printAdapter, printAttributes)
  }

  /**
   * Shares the voucher as PDF.
   */
  fun shareVoucherPdf(context: Context, tx: PaymentTransaction, businessName: String = "الوكيل لتجارة المواد الغذائية") {
    try {
      val file = generateVoucherPdf(context, tx, businessName)
      val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

      val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "${getVoucherTitle(tx)} - ${getVoucherNumber(tx)}")
        putExtra(Intent.EXTRA_TEXT, generateVoucherText(tx, businessName))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
      context.startActivity(Intent.createChooser(intent, "مشاركة السند عبر"))
    } catch (e: Exception) {
      Toast.makeText(context, "فشل تجهيز ملف السند للمشاركة: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
  }

  /**
   * Formats voucher content into WhatsApp-ready Arabic text.
   */
  fun generateVoucherText(
    tx: PaymentTransaction,
    businessName: String = "الوكيل لتجارة المواد الغذائية",
    currency: String = "ج.م"
  ): String {
    val isReceipt = tx.type == TransactionType.CUSTOMER_PAYMENT || tx.type == TransactionType.CASH_DEPOSIT
    val voucherNo = getVoucherNumber(tx)
    val title = getVoucherTitle(tx)
    val dateStr = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")).format(Date(tx.timestamp))
    val tafqeet = TafqeetHelper.convertToArabicWords(tx.amount)

    val partyPrefix = when (tx.type) {
      TransactionType.CUSTOMER_PAYMENT -> "استلمنا من السيد/ة"
      TransactionType.SUPPLIER_PAYMENT -> "يصرف إلى السيد/ة"
      TransactionType.CASH_DEPOSIT -> "المودع / المصدر"
      TransactionType.CASH_WITHDRAWAL -> "المسحوب لصالحه"
    }

    return buildString {
      appendLine("🏛️ *$businessName*")
      appendLine("📜 *$title*")
      appendLine("━━━━━━━━━━━━━━━━━━━")
      appendLine("🔖 *رقم السند:* `$voucherNo`")
      appendLine("📅 *التاريخ:* $dateStr")
      appendLine("👤 *$partyPrefix:* ${tx.partyName}")
      appendLine("💰 *المبلغ:* ${String.format(Locale.ENGLISH, "%.2f", tx.amount)} $currency")
      appendLine("📝 *المبلغ تفقيطاً:* $tafqeet")
      appendLine("💳 *طريقة الدفع:* نقداً (الخزينة والصندوق)")
      if (tx.notes.isNotBlank()) {
        appendLine("📌 *البيان / ملاحظات:* ${tx.notes}")
      }
      val balRegex = Regex("""الرصيد بعد السند:\s*([\d.]+)\s*ج\.م""")
      val matchBal = balRegex.find(tx.notes)?.groupValues?.getOrNull(1)
      if (matchBal != null) {
        val label = if (isReceipt) "الرصيد المتبقي على العميل بعد هذا السند" else "الرصيد المتبقي للمورد بعد هذا السند"
        appendLine("⚖️ *$label:* `$matchBal $currency`")
      }
      appendLine("━━━━━━━━━━━━━━━━━━━")
      appendLine("تم الإصدار عبر برنامج *الوكيل لتجارة المواد الغذائية*")
    }
  }

  fun shareVoucherViaWhatsApp(context: Context, tx: PaymentTransaction, phone: String = "", businessName: String = "الوكيل لتجارة المواد الغذائية") {
    val message = generateVoucherText(tx, businessName)
    try {
      val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, message)
        if (phone.isNotBlank()) {
          val cleanPhone = phone.replace("[^0-9+]".toRegex(), "")
          putExtra("jid", "$cleanPhone@s.whatsapp.net")
        }
        setPackage("com.whatsapp")
      }
      context.startActivity(intent)
    } catch (_: Exception) {
      // Fallback to normal chooser
      val fallbackIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, message)
      }
      context.startActivity(Intent.createChooser(fallbackIntent, "إرسال السند عبر"))
    }
  }
}
