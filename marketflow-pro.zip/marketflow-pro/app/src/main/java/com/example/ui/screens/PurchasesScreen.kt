package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddBusiness
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItem
import com.example.data.model.PaymentType
import com.example.data.model.Product
import com.example.data.model.Supplier
import com.example.ui.PurchaseCartItem
import com.example.ui.WholesaleViewModel
import com.example.ui.components.AddEditProductDialog
import com.example.ui.components.AddEditSupplierDialog
import com.example.ui.components.DeleteInvoiceConfirmDialog
import com.example.ui.components.EditInvoiceFullDialog
import com.example.ui.components.InvoiceDetailsDialog
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * شاشة المشتريات والتوريد المطابقة تماماً لنظام وسلاسة شاشة المبيعات:
 * 1. شريط علوي لاختيار وتغيير المورد مع شريط بحث وإضافة مورد جديد.
 * 2. زر بارز لإضافة منتج يفتح شريط بحث الأصناف بالاسم والباركود.
 * 3. قائمة أصناف التوريد المضافة مع تحكم مرن في الكمية والوحدة وتكلفة الشراء.
 * 4. شريط سفلي ثابت يظهر: عدد الأصناف، إجمالي الكمية، إجمالي المشتريات، رصيد المورد السابق، وإجمالي المستحق للمورد.
 * 5. نافذة إتمام الفاتورة وسداد الحساب وطباعة الإيصال الحراري.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PurchasesScreen(
  viewModel: WholesaleViewModel,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val purchaseInvoices by viewModel.purchaseInvoices.collectAsStateWithLifecycle()

  Column(modifier = modifier.fillMaxSize()) {
    // التبويبات العلوية: فاتورة توريد جديدة وسجل فواتير المشتريات
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = MaterialTheme.colorScheme.surface,
      contentColor = MaterialTheme.colorScheme.primary
    ) {
      Tab(
        selected = selectedTab == 0,
        onClick = { selectedTab = 0 },
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("فاتورة التوريد (المشتريات)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          }
        }
      )
      Tab(
        selected = selectedTab == 1,
        onClick = { selectedTab = 1 },
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("سجل فواتير المشتريات", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            if (purchaseInvoices.isNotEmpty()) {
              Spacer(modifier = Modifier.width(6.dp))
              Surface(
                shape = CircleShape,
                color = if (selectedTab == 1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
              ) {
                Text(
                  text = "${purchaseInvoices.size}",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (selectedTab == 1) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }
          }
        }
      )
    }

    if (selectedTab == 0) {
      SimplePurchasesPosView(viewModel = viewModel)
    } else {
      PurchasesInvoicesHistoryView(
        viewModel = viewModel,
        onEditInPos = { invoice ->
          viewModel.loadPurchaseInvoiceForEditing(invoice) {
            selectedTab = 0
          }
        }
      )
    }
  }
}

// -----------------------------------------------------------------------------
// شاشة المشتريات والتوريد البسيطة (Simple Purchases POS View)
// -----------------------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimplePurchasesPosView(viewModel: WholesaleViewModel) {
  val products by viewModel.products.collectAsStateWithLifecycle()
  val suppliers by viewModel.suppliers.collectAsStateWithLifecycle()
  val purchaseCart by viewModel.purchaseCart.collectAsStateWithLifecycle()
  val selectedSupplier by viewModel.selectedSupplier.collectAsStateWithLifecycle()
  val paymentType by viewModel.purchasePaymentType.collectAsStateWithLifecycle()
  val paidAmount by viewModel.purchasePaidAmount.collectAsStateWithLifecycle()
  val editingPurchaseInvoice by viewModel.editingPurchaseInvoice.collectAsStateWithLifecycle()

  val profile by viewModel.businessProfile.collectAsStateWithLifecycle()
  val context = LocalContext.current

  // نوافذ البحث والتحكم
  var showProductSearchSheet by remember { mutableStateOf(false) }
  var showSupplierPickerSheet by remember { mutableStateOf(false) }

  // الوحدة الأساسية للتوريد تأتي مباشرة من الإعدادات
  val defaultUnit = profile.purchasesDefaultUnit.ifBlank { "كرتونة" }

  // عناصر إتمام العملية والسداد المباشر من نفس الشاشة دون أي نوافذ منبثقة
  var paidText by remember { mutableStateOf(paidAmount?.toString() ?: "") }
  var invoiceNotesText by remember { mutableStateOf("") }
  var validationError by remember { mutableStateOf<String?>(null) }
  var isSavingPurchase by remember { mutableStateOf(false) }

  // نوافذ إضافة منتج أو مورد جديد
  var showAddProductDialog by remember { mutableStateOf(false) }
  var showAddSupplierDialog by remember { mutableStateOf(false) }
  var showPurchasesSettingsDialog by remember { mutableStateOf(false) }

  // إحصائيات الفاتورة الحالية
  val itemsCount = purchaseCart.size // عدد الأصناف المختلفة
  val totalQuantity = remember(purchaseCart) { purchaseCart.sumOf { it.quantity } } // إجمالي الكمية

  // إجمالي المشتريات الحالية
  val totalPurchasesAmount = remember(purchaseCart) {
    purchaseCart.sumOf { it.totalPrice }
  }

  // رصيد المورد السابق المستحق له
  val previousSupplierBalance = selectedSupplier?.currentBalance ?: 0.0

  // إجمالي المستحق للمورد (إجمالي المشتريات + رصيد المورد السابق)
  val grandTotalDue = totalPurchasesAmount + previousSupplierBalance

  // دالة إتمام وحفظ التوريد مباشرة من نفس الشاشة دون أي نوافذ منبثقة
  fun executeCompletePurchaseInline() {
    if (purchaseCart.isEmpty()) {
      Toast.makeText(context, "الفاتورة فارغة، برجاء إضافة أصناف للتوريد أولاً", Toast.LENGTH_SHORT).show()
      return
    }

    if ((paymentType == PaymentType.CREDIT || paymentType == PaymentType.PARTIAL) && selectedSupplier == null) {
      validationError = "برجاء اختيار مورد لتقييد المبلغ الآجل في حسابه"
      Toast.makeText(context, validationError!!, Toast.LENGTH_LONG).show()
      return
    }

    validationError = null
    isSavingPurchase = true
    viewModel.completePurchase { inv ->
      isSavingPurchase = false
      Toast.makeText(context, "تم حفظ واعتماد فاتورة التوريد بنجاح ✓ (${inv.invoiceNumber})", Toast.LENGTH_LONG).show()
      paidText = ""
      invoiceNotesText = ""
    }
  }

  Box(modifier = Modifier.fillMaxSize()) {
    Column(modifier = Modifier.fillMaxSize()) {

      // شريط وضع التعديل (يظهر عند فتح فاتورة مشتريات سابقة لتعديلها)
      if (editingPurchaseInvoice != null) {
        Surface(
          color = AmberPrimary.copy(alpha = 0.15f),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, AmberPrimary),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Icon(Icons.Default.Edit, contentDescription = null, tint = AmberPrimary, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(
                  text = "وضع تعديل فاتورة توريد / شراء (${editingPurchaseInvoice?.invoiceNumber})",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = AmberPrimary
                )
                Text(
                  text = "يمكنك تعديل أي صنف، كمية، سعر شراء، أو المورد ثم الحفظ والتحديث المباشر للمخزن والحساب",
                  fontSize = 10.5.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
            OutlinedButton(
              onClick = { viewModel.cancelEditingPurchaseInvoice() },
              shape = RoundedCornerShape(8.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
              Text("إلغاء التعديل", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
            }
          }
        }
      }

      // 1. شريط التحكم العلوي: اختيار وتغيير المورد
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 8.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier
                .weight(1f)
                .clickable { showSupplierPickerSheet = true }
            ) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .background(
                    if (selectedSupplier != null) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else Color.Gray.copy(alpha = 0.12f),
                    CircleShape
                  ),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.Business,
                  contentDescription = null,
                  tint = if (selectedSupplier != null) MaterialTheme.colorScheme.primary else Color.Gray,
                  modifier = Modifier.size(20.dp)
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(
                  text = selectedSupplier?.name ?: "مورد نقدي عام (بدون حساب)",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
                if (selectedSupplier != null && selectedSupplier!!.currentBalance > 0) {
                  Text(
                    text = "له مستحق سابق: ${String.format(Locale.ENGLISH, "%.2f ج.م", selectedSupplier!!.currentBalance)}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.Bold
                  )
                } else if (selectedSupplier != null) {
                  Text(
                    text = "حسابه خالص (0.00 ج.م)",
                    fontSize = 10.sp,
                    color = EmeraldPrimary,
                    fontWeight = FontWeight.SemiBold
                  )
                }
              }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = { showPurchasesSettingsDialog = true },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(
                  Icons.Default.Tune,
                  contentDescription = "إعدادات المشتريات",
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(20.dp)
                )
              }

              Button(
                onClick = { showSupplierPickerSheet = true },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                modifier = Modifier.height(32.dp)
              ) {
                Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (selectedSupplier != null) "تغيير المورد" else "اختيار مورد", fontSize = 11.sp)
              }

              OutlinedButton(
                onClick = { showAddSupplierDialog = true },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(32.dp)
              ) {
                Icon(Icons.Default.AddBusiness, contentDescription = null, modifier = Modifier.size(13.dp))
                Spacer(modifier = Modifier.width(2.dp))
                Text("مورد جديد +", fontSize = 11.sp)
              }
            }
          }
        }
      }

      // 2. زر "إضافة منتج +" الرئيسي الواضح والبارز
      Button(
        onClick = { showProductSearchSheet = true },
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 4.dp)
          .height(48.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
      ) {
        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "إضافة صنف لفاتورة التوريد (بحث بالاسم أو الباركود) +",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold
        )
      }

      // 3. مساحة قائمة الأصناف المضافة داخل فاتورة الشراء
      if (purchaseCart.isEmpty()) {
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .padding(24.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
          ) {
            Surface(
              shape = CircleShape,
              color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
              modifier = Modifier.size(64.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  Icons.Default.LocalShipping,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(32.dp)
                )
              }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "فاتورة التوريد فارغة حالياً",
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "اضغط على زر [إضافة صنف] أعلاه للبحث عن المنتجات وإضافتها للتوريد",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center
            )
          }
        }
      } else {
        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
          contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 155.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          item {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "الأصناف المضافة للتوريد (${purchaseCart.size} صنف)",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "مسح الكل",
                color = MaterialTheme.colorScheme.error,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { viewModel.clearPurchaseCart() }
              )
            }
          }

          itemsIndexed(purchaseCart) { index, item ->
            SimplePurchaseCartItemCard(
              item = item,
              onQuantityChange = { q -> viewModel.updatePurchaseItemQuantity(index, q) },
              onUnitChange = { u -> viewModel.updatePurchaseItemUnit(index, u) },
              onCostChange = { c -> viewModel.updatePurchaseItemCost(index, c) },
              onRemove = { viewModel.removeFromPurchaseCart(index) },
              allowManualPriceOverride = profile.purchasesAllowManualPriceOverride
            )
          }

          // -------------------------------------------------------------
          // قسم سداد التوريد وإتمام الفاتورة مباشرة في نفس الشاشة دون أي نوافذ منبثقة
          // -------------------------------------------------------------
          item {
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
              elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                // عنوان القسم
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Payment, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("بيانات سداد فاتورة التوريد", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                  }
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = EmeraldPrimary.copy(alpha = 0.12f)
                  ) {
                    Text(
                      text = "إتمام مباشر بشاشة واحدة ✓",
                      color = EmeraldPrimary,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                  }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

                // 1. طريقة سداد فاتورة التوريد
                Text("طريقة السداد للمورد:", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  listOf(
                    Pair(PaymentType.CASH, "نقدي 💵"),
                    Pair(PaymentType.CREDIT, "آجل للمورد ⏳"),
                    Pair(PaymentType.PARTIAL, "دفع جزئي 🌓")
                  ).forEach { (type, label) ->
                    FilterChip(
                      selected = paymentType == type,
                      onClick = {
                        viewModel.setPurchasePaymentType(type)
                        validationError = null
                      },
                      label = { Text(label, fontSize = 11.sp, fontWeight = if (paymentType == type) FontWeight.Bold else FontWeight.Normal) },
                      colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = when (type) {
                          PaymentType.CASH -> EmeraldPrimary.copy(alpha = 0.2f)
                          PaymentType.CREDIT -> AmberPrimary.copy(alpha = 0.2f)
                          PaymentType.PARTIAL -> Color(0xFF1976D2).copy(alpha = 0.2f)
                        },
                        selectedLabelColor = when (type) {
                          PaymentType.CASH -> EmeraldPrimary
                          PaymentType.CREDIT -> AmberPrimary
                          PaymentType.PARTIAL -> Color(0xFF1976D2)
                        }
                      ),
                      modifier = Modifier.weight(1f)
                    )
                  }
                }

                // تفاصيل السداد حسب نوع الدفع
                when (paymentType) {
                  PaymentType.CASH -> {
                    Surface(
                      shape = RoundedCornerShape(8.dp),
                      color = EmeraldPrimary.copy(alpha = 0.08f),
                      modifier = Modifier.fillMaxWidth()
                    ) {
                      Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                          text = "سيتم صرف كامل قيمة الفاتورة (${String.format(Locale.ENGLISH, "%.2f ج.م", totalPurchasesAmount)}) نقداً من الخزينة",
                          fontSize = 11.sp,
                          color = EmeraldPrimary,
                          fontWeight = FontWeight.SemiBold
                        )
                      }
                    }
                  }

                  PaymentType.PARTIAL -> {
                    val rem = (totalPurchasesAmount - (paidText.toDoubleOrNull() ?: 0.0)).coerceAtLeast(0.0)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                      OutlinedTextField(
                        value = paidText,
                        onValueChange = {
                          paidText = it.filter { ch -> ch.isDigit() || ch == '.' }
                          viewModel.setPurchasePaidAmount(paidText.toDoubleOrNull())
                        },
                        label = { Text("المبلغ المسدد كاش للمورد حالياً (ج.م) *", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                      )
                      Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Text("المتبقي كدين للمورد:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                          text = String.format(Locale.ENGLISH, "%.2f ج.م", rem),
                          fontSize = 13.sp,
                          fontWeight = FontWeight.Bold,
                          color = AmberPrimary
                        )
                      }
                    }
                  }

                  PaymentType.CREDIT -> {
                    Surface(
                      shape = RoundedCornerShape(8.dp),
                      color = AmberPrimary.copy(alpha = 0.12f),
                      modifier = Modifier.fillMaxWidth()
                    ) {
                      Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = AmberPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                          text = if (selectedSupplier != null)
                            "سيتم ترحيل كامل قيمة التوريد (${String.format(Locale.ENGLISH, "%.2f ج.م", totalPurchasesAmount)}) كدين مستحق للمورد [${selectedSupplier!!.name}]"
                          else
                            "⚠️ تنبيه: يرجى اختيار مورد من أعلى الشاشة لتقييد المبلغ الآجل في حسابه",
                          fontSize = 11.sp,
                          color = if (selectedSupplier != null) AmberPrimary else MaterialTheme.colorScheme.error,
                          fontWeight = FontWeight.SemiBold
                        )
                      }
                    }
                  }
                }

                // 2. رقم فاتورة المورد الورقية أو الملاحظات
                OutlinedTextField(
                  value = invoiceNotesText,
                  onValueChange = { invoiceNotesText = it },
                  placeholder = { Text("رقم الفاتورة الورقية أو ملاحظات التوريد (اختياري)...", fontSize = 11.5.sp) },
                  singleLine = true,
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(10.dp)
                )

                // رسائل الخطأ
                validationError?.let { err ->
                  Text(
                    text = err,
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold
                  )
                }

                // زر إتمام وحفظ التوريد المباشر
                Button(
                  onClick = { executeCompletePurchaseInline() },
                  enabled = !isSavingPurchase,
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp),
                  shape = RoundedCornerShape(12.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                  if (isSavingPurchase) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("جاري حفظ واعتماد التوريد...", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                  } else {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("✓ إتمام وحفظ فاتورة التوريد مباشرة 💾", fontSize = 13.5.sp, fontWeight = FontWeight.ExtraBold)
                  }
                }
              }
            }
          }
        }
      }
    }

    // -------------------------------------------------------------------------
    // 4. الشريط السفلي الثابت (يظهر إجمالي المشتريات، رصيد المورد السابق، وإجمالي المستحق)
    // -------------------------------------------------------------------------
    Surface(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth(),
      shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
      color = MaterialTheme.colorScheme.surface,
      shadowElevation = 16.dp,
      border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 10.dp)
      ) {
        // سطر الإحصائيات السريعة: العدد، إجمالي الكمية، نوع العملية
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text("العدد: ", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("$itemsCount صنف", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            Text("إجمالي الكمية: ", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("$totalQuantity", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          Surface(
            shape = RoundedCornerShape(6.dp),
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
          ) {
            Text(
              text = "توريد مخزن",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // بطاقة الحساب المالي (إجمالي المشتريات + رصيد المورد السابق = إجمالي المستحق)
        Surface(
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            // 1. إجمالي المشتريات (الفاتورة الحالية)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text("إجمالي المشتريات (الفاتورة الحالية):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = String.format(Locale.ENGLISH, "%.2f ج.م", totalPurchasesAmount),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
            }

            // 2. رصيد المورد السابق
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text("رصيد المورد السابق:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (selectedSupplier != null) {
                  Text(
                    text = " [${selectedSupplier!!.name}]",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                }
              }
              Text(
                text = String.format(Locale.ENGLISH, "%.2f ج.م", previousSupplierBalance),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (previousSupplierBalance > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
              )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 3.dp))

            // 3. إجمالي المستحق للمورد
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "إجمالي المستحق للمورد (شامل الحساب السابق):",
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = String.format(Locale.ENGLISH, "%.2f ج.م", grandTotalDue),
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (grandTotalDue > 0) AmberPrimary else MaterialTheme.colorScheme.primary
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // زر إتمام فاتورة الشراء والسداد المباشر (بدون أي نوافذ منبثقة)
        Button(
          onClick = {
            if (purchaseCart.isNotEmpty()) {
              executeCompletePurchaseInline()
            }
          },
          enabled = purchaseCart.isNotEmpty() && !isSavingPurchase,
          modifier = Modifier
            .fillMaxWidth()
            .height(44.dp),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = EmeraldPrimary,
            disabledContainerColor = Color.LightGray
          )
        ) {
          if (isSavingPurchase) {
            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            Spacer(modifier = Modifier.width(6.dp))
            Text("جاري الحفظ والاعتماد...", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          } else {
            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (purchaseCart.isEmpty()) "أضف أصناف لإتمام التوريد" else "✓ إتمام وحفظ فاتورة التوريد مباشرة 💾",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
          }
        }
      }
    }

    // -------------------------------------------------------------------------
    // نافذة اختيار المورد مع شريط بحث مدمج
    // -------------------------------------------------------------------------
    if (showSupplierPickerSheet) {
      ModalBottomSheet(
        onDismissRequest = { showSupplierPickerSheet = false },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
      ) {
        SupplierSearchAndPickerSheet(
          suppliers = suppliers,
          selectedSupplier = selectedSupplier,
          onSelectSupplier = { sup ->
            viewModel.selectSupplier(sup)
            showSupplierPickerSheet = false
          },
          onAddNewSupplierDialog = {
            showSupplierPickerSheet = false
            showAddSupplierDialog = true
          },
          onClose = { showSupplierPickerSheet = false }
        )
      }
    }

    // -------------------------------------------------------------------------
    // نافذة البحث عن المنتجات لإضافتها للتوريد
    // -------------------------------------------------------------------------
    if (showProductSearchSheet) {
      ModalBottomSheet(
        onDismissRequest = { showProductSearchSheet = false },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
      ) {
        PurchaseProductSearchAndPickerSheet(
          products = products,
          purchaseCart = purchaseCart,
          defaultUnit = defaultUnit,
          onQuantityChange = { product, unitType, delta ->
            viewModel.changePurchaseCartQuantity(product, unitType, delta)
          },
          onAddNewProductDialog = {
            showProductSearchSheet = false
            showAddProductDialog = true
          },
          onClose = { showProductSearchSheet = false }
        )
      }
    }

    // إضافة صنف جديد
    if (showAddProductDialog) {
      AddEditProductDialog(
        showUnitTypeSelection = false,
        onDismiss = { showAddProductDialog = false },
        onSave = { newProd ->
          viewModel.saveProduct(newProd) { savedProduct ->
            val cost = if (defaultUnit == "كرتونة") {
              if (savedProduct.cartonCostPrice > 0) savedProduct.cartonCostPrice else savedProduct.pieceCostPrice * savedProduct.piecesPerCarton.coerceAtLeast(1)
            } else {
              if (savedProduct.pieceCostPrice > 0) savedProduct.pieceCostPrice else if (savedProduct.piecesPerCarton > 0) savedProduct.cartonCostPrice / savedProduct.piecesPerCarton else 0.0
            }
            viewModel.addToPurchaseCart(savedProduct, unitType = defaultUnit, cost = cost)
          }
          showAddProductDialog = false
        }
      )
    }

    // إضافة مورد جديد
    if (showAddSupplierDialog) {
      AddEditSupplierDialog(
        onDismiss = { showAddSupplierDialog = false },
        onSave = { newSupplier ->
          viewModel.saveSupplier(newSupplier) { savedSupplier ->
            viewModel.selectSupplier(savedSupplier)
          }
          showAddSupplierDialog = false
        }
      )
    }

    // نافذة إعدادات شاشة المشتريات والتوريد وتعديل الأسعار
    if (showPurchasesSettingsDialog) {
      PurchasesSettingsDialog(
        initial = profile,
        onDismiss = { showPurchasesSettingsDialog = false },
        onSave = { updated ->
          viewModel.updateBusinessProfile(updated)
          showPurchasesSettingsDialog = false
          Toast.makeText(context, "تم حفظ إعدادات شاشة المشتريات بنجاح ✓", Toast.LENGTH_SHORT).show()
        }
      )
    }
  }
}

// -----------------------------------------------------------------------------
// بطاقة الصنف المضاف في فاتورة التوريد
// -----------------------------------------------------------------------------
@Composable
fun SimplePurchaseCartItemCard(
  item: PurchaseCartItem,
  onQuantityChange: (Int) -> Unit,
  onUnitChange: (String) -> Unit = {},
  onCostChange: (Double) -> Unit = {},
  onRemove: () -> Unit,
  allowManualPriceOverride: Boolean = false
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = item.product.name,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Spacer(modifier = Modifier.height(2.dp))
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
          ) {
            Text(
              text = "سعر الشراء: " + String.format(Locale.ENGLISH, "%.2f ج.م", item.unitCostPrice),
              fontSize = 11.5.sp,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }
        }

        // أزرار التحكم بالكمية (+ / -)
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
              .size(32.dp)
              .clickable { onQuantityChange(item.quantity - 1) }
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Default.Remove, contentDescription = "تقليل", modifier = Modifier.size(16.dp))
            }
          }

          Text(
            text = "${item.quantity}",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 6.dp)
          )

          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
            modifier = Modifier
              .size(32.dp)
              .clickable { onQuantityChange(item.quantity + 1) }
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                Icons.Default.Add,
                contentDescription = "زيادة",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
              )
            }
          }

          Spacer(modifier = Modifier.width(6.dp))

          // حذف الصنف من الفاتورة
          IconButton(onClick = onRemove, modifier = Modifier.size(30.dp)) {
            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // السطر السفلي: عرض الوحدة المعينة من الإعدادات وإجمالي تكلفة الصنف
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
        ) {
          Text(
            text = "الوحدة: ${item.unitType}",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
          )
        }

        Text(
          text = "الإجمالي: " + String.format(Locale.ENGLISH, "%.2f ج.م", item.totalPrice),
          fontWeight = FontWeight.ExtraBold,
          fontSize = 13.sp,
          color = MaterialTheme.colorScheme.primary
        )
      }
    }
  }
}

// -----------------------------------------------------------------------------
// نافذة اختيار المورد مع شريط بحث مدمج
// -----------------------------------------------------------------------------
@Composable
fun SupplierSearchAndPickerSheet(
  suppliers: List<Supplier>,
  selectedSupplier: Supplier?,
  onSelectSupplier: (Supplier?) -> Unit,
  onAddNewSupplierDialog: () -> Unit,
  onClose: () -> Unit
) {
  var supplierSearchQuery by remember { mutableStateOf("") }

  val filteredSuppliers = remember(suppliers, supplierSearchQuery) {
    suppliers.filter { sup ->
      sup.name.contains(supplierSearchQuery, ignoreCase = true) ||
          sup.phone.contains(supplierSearchQuery) ||
          sup.company.contains(supplierSearchQuery, ignoreCase = true)
    }
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "اختيار مورد فاتورة التوريد",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      IconButton(onClick = onClose) {
        Icon(Icons.Default.Close, contentDescription = "إغلاق")
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // شريط البحث الخاص بالموردين
    OutlinedTextField(
      value = supplierSearchQuery,
      onValueChange = { supplierSearchQuery = it },
      placeholder = { Text("بحث عن مورد بالاسم، الشركة، أو رقم الهاتف...", fontSize = 13.sp) },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
      trailingIcon = {
        if (supplierSearchQuery.isNotEmpty()) {
          IconButton(onClick = { supplierSearchQuery = "" }) {
            Icon(Icons.Default.Clear, contentDescription = "مسح")
          }
        }
      },
      singleLine = true,
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp)
    )

    Spacer(modifier = Modifier.height(10.dp))

    // زر مورد نقدي عام وزر إضافة مورد جديد
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Button(
        onClick = { onSelectSupplier(null) },
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = if (selectedSupplier == null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
          contentColor = if (selectedSupplier == null) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
        ),
        modifier = Modifier.weight(1f)
      ) {
        Icon(Icons.Default.Business, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("مورد نقدي عام", fontSize = 12.sp, fontWeight = FontWeight.Bold)
      }

      OutlinedButton(
        onClick = onAddNewSupplierDialog,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.weight(1f)
      ) {
        Icon(Icons.Default.AddBusiness, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("إضافة مورد جديد +", fontSize = 12.sp, fontWeight = FontWeight.Bold)
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    Text(
      text = "قائمة الموردين المسجلين (${filteredSuppliers.size}):",
      fontSize = 12.sp,
      fontWeight = FontWeight.SemiBold,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Spacer(modifier = Modifier.height(4.dp))

    // قائمة الموردين المطابقة للبحث
    LazyColumn(
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(max = 380.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      items(filteredSuppliers, key = { it.id }) { supplier ->
        val isSelected = selectedSupplier?.id == supplier.id

        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelectSupplier(supplier) },
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
          ),
          border = if (isSelected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Box(
                modifier = Modifier
                  .size(34.dp)
                  .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.Business,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(18.dp)
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = supplier.name,
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp
                )
                if (supplier.company.isNotEmpty() || supplier.phone.isNotEmpty()) {
                  Text(
                    text = listOf(supplier.company, supplier.phone).filter { it.isNotEmpty() }.joinToString(" • "),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }

            // رصيد المورد
            Column(horizontalAlignment = Alignment.End) {
              if (supplier.currentBalance > 0) {
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
                ) {
                  Text(
                    text = "له مستحق: ${String.format(Locale.ENGLISH, "%.2f", supplier.currentBalance)} ج.م",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              } else {
                Text(
                  text = "الحساب: 0.00 ج.م",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }

      if (filteredSuppliers.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(24.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("لا يوجد مورد يطابق هذا البحث", color = MaterialTheme.colorScheme.onSurfaceVariant)
              Spacer(modifier = Modifier.height(6.dp))
              OutlinedButton(onClick = onAddNewSupplierDialog) {
                Text("إضافة كمورد جديد الآن")
              }
            }
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// نافذة البحث عن المنتجات لإضافتها للتوريد
// -----------------------------------------------------------------------------
@Composable
fun PurchaseProductSearchAndPickerSheet(
  products: List<Product>,
  purchaseCart: List<PurchaseCartItem>,
  defaultUnit: String = "كرتونة",
  onQuantityChange: (Product, String, Int) -> Unit,
  onAddNewProductDialog: () -> Unit,
  onClose: () -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("الكل") }

  val categories = remember(products) {
    listOf("الكل") + products.map { it.category }.distinct()
  }

  val filteredProducts = remember(products, searchQuery, selectedCategory) {
    products.filter { prod ->
      val matchSearch = prod.name.contains(searchQuery, ignoreCase = true) ||
          prod.barcode.contains(searchQuery, ignoreCase = true)
      val matchCat = selectedCategory == "الكل" || prod.category == selectedCategory
      matchSearch && matchCat
    }
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "البحث عن صنف وإضافته للتوريد",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "البحث عن الأصناف وإضافتها لتوريد المخزن",
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.primary,
          fontWeight = FontWeight.SemiBold
        )
      }
      IconButton(onClick = onClose) {
        Icon(Icons.Default.Close, contentDescription = "إغلاق")
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // شريط البحث المباشر مع علامة (✕) لمسح المكتوب فوراً
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      placeholder = { Text("اكتب اسم المنتج أو امسح الباركود للتوريد...", fontSize = 13.sp) },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
      trailingIcon = {
        if (searchQuery.isNotEmpty()) {
          IconButton(onClick = { searchQuery = "" }) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "إلغاء المكتوب ومسح البحث",
              tint = MaterialTheme.colorScheme.error
            )
          }
        }
      },
      singleLine = true,
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp)
    )

    Spacer(modifier = Modifier.height(8.dp))

    // فلاتر الأقسام السريعة وزر صنف جديد
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "الأقسام:",
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Text(
        text = "+ صنف جديد غير مسجل",
        color = EmeraldPrimary,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        modifier = Modifier.clickable { onAddNewProductDialog() }
      )
    }

    Spacer(modifier = Modifier.height(4.dp))

    // قائمة فئات الأقسام
    LazyRow(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      items(categories) { cat ->
        FilterChip(
          selected = selectedCategory == cat,
          onClick = { selectedCategory = cat },
          label = { Text(cat, fontSize = 11.sp) }
        )
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // قائمة الأصناف المطابقة للتوريد
    LazyColumn(
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(max = 420.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(filteredProducts, key = { it.id }) { product ->
        val cartonCost = if (product.cartonCostPrice > 0.0) {
          product.cartonCostPrice
        } else if (product.piecesPerCarton > 0 && product.pieceCostPrice > 0.0) {
          product.pieceCostPrice * product.piecesPerCarton
        } else {
          product.pieceCostPrice
        }

        val pieceCost = if (product.pieceCostPrice > 0.0) {
          product.pieceCostPrice
        } else if (product.piecesPerCarton > 0 && product.cartonCostPrice > 0.0) {
          product.cartonCostPrice / product.piecesPerCarton
        } else {
          product.cartonCostPrice
        }

        val cartonQty = purchaseCart.find { it.product.id == product.id && it.unitType == "كرتونة" }?.quantity ?: 0
        val pieceQty = purchaseCart.find { it.product.id == product.id && (it.unitType == "قطعة" || it.unitType == "علبة") }?.quantity ?: 0
        val totalInCart = cartonQty + pieceQty
        val isInCart = totalInCart > 0

        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isInCart) EmeraldPrimary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
          ),
          border = if (isInCart) BorderStroke(1.5.dp, EmeraldPrimary.copy(alpha = 0.6f)) else null
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp)
          ) {
            // بيانات المنتج
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = product.name,
                fontWeight = FontWeight.Bold,
                fontSize = 13.5.sp,
                modifier = Modifier.weight(1f)
              )
              if (isInCart) {
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = EmeraldPrimary
                ) {
                  Text(
                    text = "بالفاتورة ✓: ${if (cartonQty > 0) "$cartonQty كرتونة " else ""}${if (pieceQty > 0) "$pieceQty علبة" else ""}",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "${product.category} • الكرتونة = ${product.piecesPerCarton} علبة",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Surface(
                shape = RoundedCornerShape(4.dp),
                color = EmeraldPrimary.copy(alpha = 0.15f)
              ) {
                Text(
                  text = "المخزن الحالي: ${product.stockDisplayString()}",
                  fontSize = 10.5.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = EmeraldPrimary,
                  modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "تكلفة كرتونة: ${String.format(Locale.ENGLISH, "%.1f ج.م", cartonCost)}",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                text = "تكلفة علبة: ${String.format(Locale.ENGLISH, "%.1f ج.م", pieceCost)}",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
              )
            }

            HorizontalDivider(
              modifier = Modifier.padding(vertical = 8.dp),
              color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
            )

            // أسفل كل منتج: زر إضافة المنتج، وبعد إضافته يظهر علامة الـ (+) والـ (-) لزيادة ونقص الكمية
            if (!isInCart) {
              Button(
                onClick = { onQuantityChange(product, defaultUnit, 1) },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(38.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
              ) {
                Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "إضافة الصنف للتوريد +",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            } else {
              // بعد إضافته: علامات الـ (+) والـ (-) لزيادة ونقص الكمية أسفل المنتج مع خيار تبديل الوحدة
              val currentUnit = if (cartonQty > 0) "كرتونة" else "قطعة"
              val currentCount = if (currentUnit == "كرتونة") cartonQty else pieceQty

              Surface(
                shape = RoundedCornerShape(8.dp),
                color = EmeraldPrimary.copy(alpha = 0.12f),
                border = BorderStroke(1.dp, EmeraldPrimary)
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = "مضاف للتوريد ✓",
                      fontSize = 11.5.sp,
                      fontWeight = FontWeight.Bold,
                      color = EmeraldPrimary
                    )
                  }

                  // عداد الكمية (+ / -) بالوحدة المحددة من الخارج
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                  ) {
                    IconButton(
                      onClick = { onQuantityChange(product, defaultUnit, -1) },
                      modifier = Modifier.size(32.dp)
                    ) {
                      Icon(Icons.Default.Remove, contentDescription = "تقليل الكمية", tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                    }

                    val currentQty = purchaseCart.find { it.product.id == product.id && it.unitType == defaultUnit }?.quantity ?: (cartonQty + pieceQty)
                    Surface(
                      shape = RoundedCornerShape(6.dp),
                      color = EmeraldPrimary
                    ) {
                      Text(
                        text = "$currentQty $defaultUnit",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                      )
                    }

                    IconButton(
                      onClick = { onQuantityChange(product, defaultUnit, 1) },
                      modifier = Modifier.size(32.dp)
                    ) {
                      Icon(Icons.Default.Add, contentDescription = "زيادة الكمية", tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                    }
                  }
                }
              }
            }
          }
        }
      }

      if (filteredProducts.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(30.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("لا توجد أصناف تطابق هذا البحث", color = MaterialTheme.colorScheme.onSurfaceVariant)
              Spacer(modifier = Modifier.height(8.dp))
              OutlinedButton(onClick = onAddNewProductDialog) {
                Text("إضافة كصنف جديد الآن")
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))
    val totalQty = purchaseCart.sumOf { it.quantity }
    Button(
      onClick = onClose,
      modifier = Modifier
        .fillMaxWidth()
        .height(42.dp),
      shape = RoundedCornerShape(10.dp),
      colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
    ) {
      Text(
        text = if (totalQty > 0) "✓ تم الاختيار ($totalQty صنف بالتوريد) • إغلاق" else "إغلاق نافذة الأصناف",
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp
      )
    }
  }
}

// -----------------------------------------------------------------------------
// نافذة إتمام فاتورة التوريد والسداد وتحديد طريقة الدفع (كاش / آجل / جزئي)
// -----------------------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimplePurchasesCheckoutSheet(
  viewModel: WholesaleViewModel,
  purchaseCart: List<PurchaseCartItem>,
  suppliers: List<Supplier>,
  selectedSupplier: Supplier?,
  paidAmount: Double?,
  paymentType: PaymentType,
  cartTotal: Double,
  previousBalance: Double,
  grandTotalDue: Double,
  onAddNewSupplier: () -> Unit,
  onClose: () -> Unit
) {
  var paidText by remember { mutableStateOf(paidAmount?.toString() ?: "") }
  var validationError by remember { mutableStateOf<String?>(null) }

  val remainingDebt = remember(cartTotal, paymentType, paidAmount) {
    when (paymentType) {
      PaymentType.CASH -> 0.0
      PaymentType.CREDIT -> cartTotal
      PaymentType.PARTIAL -> {
        val p = paidAmount ?: cartTotal
        (cartTotal - p).coerceAtLeast(0.0)
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "إتمام فاتورة التوريد (${purchaseCart.size} صنف)",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      IconButton(onClick = onClose) {
        Icon(Icons.Default.Close, contentDescription = "إغلاق")
      }
    }

    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

    // طريقة الدفع
    Text("طريقة سداد فاتورة التوريد:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
    Spacer(modifier = Modifier.height(4.dp))

    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
      PaymentType.values().forEachIndexed { idx, type ->
        val label = when (type) {
          PaymentType.CASH -> "نقداً كاش"
          PaymentType.CREDIT -> "آجل للمورد"
          PaymentType.PARTIAL -> "دفع جزئي"
        }
        SegmentedButton(
          selected = paymentType == type,
          onClick = {
            viewModel.setPurchasePaymentType(type)
            validationError = null
          },
          shape = SegmentedButtonDefaults.itemShape(index = idx, count = PaymentType.values().size)
        ) {
          Text(label, fontSize = 12.sp, fontWeight = if (paymentType == type) FontWeight.Bold else FontWeight.Normal)
        }
      }
    }

    // تنبيه بحالة الدفع
    Surface(
      shape = RoundedCornerShape(10.dp),
      color = when (paymentType) {
        PaymentType.CASH -> EmeraldPrimary.copy(alpha = 0.08f)
        PaymentType.CREDIT -> AmberPrimary.copy(alpha = 0.12f)
        PaymentType.PARTIAL -> Color(0xFF1976D2).copy(alpha = 0.08f)
      },
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 6.dp)
    ) {
      Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = if (paymentType == PaymentType.CREDIT && selectedSupplier == null) Icons.Default.Warning else Icons.Default.Info,
          contentDescription = null,
          tint = when (paymentType) {
            PaymentType.CASH -> EmeraldPrimary
            PaymentType.CREDIT -> if (selectedSupplier == null) MaterialTheme.colorScheme.error else AmberPrimary
            PaymentType.PARTIAL -> Color(0xFF1976D2)
          },
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
          when (paymentType) {
            PaymentType.CASH -> {
              Text(
                text = "دفع كاش بالكامل: سيتم خصم (${String.format(Locale.ENGLISH, "%.2f ج.م", cartTotal)}) من الخزينة فوراً لسداد التوريد.",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = EmeraldPrimary
              )
            }
            PaymentType.CREDIT -> {
              if (selectedSupplier == null) {
                Text(
                  text = "تنبيه: للشراء بالآجل، يجب اختيار مورد أو تسجيل مورد جديد لتقييد المبلغ كمديونية مستحقة له.",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.error
                )
              } else {
                Text(
                  text = "شراء آجل على حساب [${selectedSupplier.name}]. مستحق له: ${String.format(Locale.ENGLISH, "%.2f ج.م", cartTotal)}",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = AmberPrimary
                )
              }
            }
            PaymentType.PARTIAL -> {
              Text(
                text = "دفع جزئي: أدخل المبلغ المدفوع نقداً للمورد من الخزينة، والباقي سيُسجل كدين مستحق له.",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1976D2)
              )
            }
          }
        }
      }
    }

    if (paymentType == PaymentType.PARTIAL) {
      OutlinedTextField(
        value = paidText,
        onValueChange = {
          paidText = it
          viewModel.setPurchasePaidAmount(it.toDoubleOrNull())
        },
        label = { Text("المبلغ المدفوع كاش للمورد (ج.م) *", fontSize = 11.sp) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 2.dp),
        shape = RoundedCornerShape(10.dp)
      )
    }

    validationError?.let { err ->
      Text(
        text = err,
        color = MaterialTheme.colorScheme.error,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        modifier = Modifier.padding(vertical = 2.dp)
      )
    }

    // ملخص الحساب المالي (إجمالي المشتريات + رصيد المورد السابق = إجمالي المستحق)
    Surface(
      shape = RoundedCornerShape(12.dp),
      color = MaterialTheme.colorScheme.surfaceVariant,
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 6.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("صافي الفاتورة الحالية:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.2f ج.م", cartTotal),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
        }

        if (paymentType == PaymentType.PARTIAL || paymentType == PaymentType.CREDIT) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("المتبقي كدين للمورد:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
              text = String.format(Locale.ENGLISH, "%.2f ج.م", remainingDebt),
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = AmberPrimary
            )
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("رصيد المورد السابق:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.2f ج.م", previousBalance),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (previousBalance > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
          )
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 3.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "إجمالي المستحق النهائي للمورد:",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 13.sp
          )
          Text(
            text = String.format(Locale.ENGLISH, "%.2f ج.م", grandTotalDue),
            fontSize = 17.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (grandTotalDue > 0) AmberPrimary else EmeraldPrimary
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // أزرار التحكم
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      OutlinedButton(
        onClick = { viewModel.clearPurchaseCart() },
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.weight(1f)
      ) {
        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("مسح")
      }

      Button(
        onClick = {
          if ((paymentType == PaymentType.CREDIT || paymentType == PaymentType.PARTIAL) && selectedSupplier == null) {
            validationError = "برجاء اختيار مورد لتقييد المبلغ الآجل في حسابه"
            return@Button
          }
          validationError = null
          viewModel.completePurchase {
            onClose()
          }
        },
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
        modifier = Modifier.weight(1.8f)
      ) {
        Icon(Icons.Default.Check, contentDescription = null)
        Spacer(modifier = Modifier.width(6.dp))
        Text("حفظ واعتماد التوريد 🖨️", fontWeight = FontWeight.Bold, fontSize = 13.sp)
      }
    }
  }
}

// -----------------------------------------------------------------------------
// سجل فواتير المشتريات السابقة
// -----------------------------------------------------------------------------
@Composable
fun PurchasesInvoicesHistoryView(
  viewModel: WholesaleViewModel,
  onEditInPos: ((Invoice) -> Unit)? = null
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val purchaseInvoices by viewModel.purchaseInvoices.collectAsStateWithLifecycle()
  val products by viewModel.products.collectAsStateWithLifecycle()
  val customers by viewModel.customers.collectAsStateWithLifecycle()
  val suppliers by viewModel.suppliers.collectAsStateWithLifecycle()

  var search by remember { mutableStateOf("") }
  var filterPaymentType by remember { mutableStateOf<PaymentType?>(null) }

  var inspectingInvoice by remember { mutableStateOf<Invoice?>(null) }
  var editingInvoiceData by remember { mutableStateOf<Pair<Invoice, List<InvoiceItem>>?>(null) }
  var deletingInvoice by remember { mutableStateOf<Invoice?>(null) }

  val filtered = remember(purchaseInvoices, search, filterPaymentType) {
    purchaseInvoices.filter { inv ->
      val matchesSearch = inv.partyName.contains(search, ignoreCase = true) ||
          inv.invoiceNumber.contains(search, ignoreCase = true)
      val matchesType = filterPaymentType == null || inv.paymentType == filterPaymentType
      matchesSearch && matchesType
    }
  }

  val totalPurchasesAmount = remember(purchaseInvoices) { purchaseInvoices.sumOf { it.totalAmount } }
  val totalPaidCash = remember(purchaseInvoices) { purchaseInvoices.sumOf { it.paidAmount } }
  val totalRemainingCredit = remember(purchaseInvoices) { purchaseInvoices.sumOf { it.remainingAmount } }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(14.dp)
  ) {
    // شريط إحصائي مالي
    Surface(
      shape = RoundedCornerShape(12.dp),
      color = MaterialTheme.colorScheme.surfaceVariant,
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 10.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("إجمالي المشتريات", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.1f ج.م", totalPurchasesAmount),
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.primary
          )
        }
        HorizontalDivider(modifier = Modifier.height(28.dp).width(1.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("المدفوع كاش", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.1f ج.م", totalPaidCash),
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = EmeraldPrimary
          )
        }
        HorizontalDivider(modifier = Modifier.height(28.dp).width(1.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("الآجل للموردين", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.1f ج.م", totalRemainingCredit),
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = if (totalRemainingCredit > 0) AmberPrimary else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    // مربع البحث
    OutlinedTextField(
      value = search,
      onValueChange = { search = it },
      placeholder = { Text("بحث باسم المورد أو رقم الفاتورة...", fontSize = 12.sp) },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
      trailingIcon = {
        if (search.isNotEmpty()) {
          IconButton(onClick = { search = "" }) {
            Icon(Icons.Default.Clear, contentDescription = "مسح", modifier = Modifier.size(16.dp))
          }
        }
      },
      modifier = Modifier.fillMaxWidth(),
      singleLine = true,
      shape = RoundedCornerShape(10.dp)
    )

    Spacer(modifier = Modifier.height(8.dp))

    // فلاتر الدفع
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      FilterChip(
        selected = filterPaymentType == null,
        onClick = { filterPaymentType = null },
        label = { Text("الكل (${purchaseInvoices.size})", fontSize = 11.sp) }
      )
      FilterChip(
        selected = filterPaymentType == PaymentType.CASH,
        onClick = { filterPaymentType = PaymentType.CASH },
        label = { Text("كاش", fontSize = 11.sp) }
      )
      FilterChip(
        selected = filterPaymentType == PaymentType.CREDIT,
        onClick = { filterPaymentType = PaymentType.CREDIT },
        label = { Text("آجل (شكك)", fontSize = 11.sp) }
      )
      FilterChip(
        selected = filterPaymentType == PaymentType.PARTIAL,
        onClick = { filterPaymentType = PaymentType.PARTIAL },
        label = { Text("جزئي", fontSize = 11.sp) }
      )
    }

    Spacer(modifier = Modifier.height(8.dp))

    // قائمة الفواتير
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      items(filtered, key = { it.id }) { invoice ->
        PurchaseInvoiceHistoryCard(
          invoice = invoice,
          onCardClick = { inspectingInvoice = invoice },
          onInspect = { inspectingInvoice = invoice },
          onEdit = {
            if (onEditInPos != null) {
              onEditInPos(invoice)
            } else {
              scope.launch {
                val items = viewModel.getInvoiceItems(invoice.id)
                editingInvoiceData = Pair(invoice, items)
              }
            }
          },
          onDelete = { deletingInvoice = invoice },
          onPrintReceipt = { viewModel.reopenInvoiceReceipt(invoice) }
        )
      }

      if (filtered.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(40.dp),
            contentAlignment = Alignment.Center
          ) {
            Text("لا توجد فواتير مشتريات مسجلة تطابق البحث", color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }
  }

  // Inspect invoice dialog
  inspectingInvoice?.let { inv ->
    InvoiceDetailsDialog(
      invoice = inv,
      onDismiss = { inspectingInvoice = null },
      onPrintReceipt = {
        viewModel.reopenInvoiceReceipt(inv)
      },
      onEditInvoice = { invoiceToEdit, itemsToEdit ->
        inspectingInvoice = null
        if (onEditInPos != null) {
          onEditInPos(invoiceToEdit)
        } else {
          editingInvoiceData = Pair(invoiceToEdit, itemsToEdit)
        }
      },
      onDeleteInvoice = { invoiceToDelete ->
        inspectingInvoice = null
        deletingInvoice = invoiceToDelete
      },
      loadItems = { id -> viewModel.getInvoiceItems(id) }
    )
  }

  // Edit invoice dialog
  editingInvoiceData?.let { (oldInv, items) ->
    EditInvoiceFullDialog(
      invoice = oldInv,
      initialItems = items,
      allProducts = products,
      allCustomers = customers,
      allSuppliers = suppliers,
      onDismiss = { editingInvoiceData = null },
      onSave = { updatedInvoice, newItems ->
        viewModel.updateInvoiceWithItems(oldInv, updatedInvoice, newItems) {
          Toast.makeText(context, "تم حفظ تعديلات فاتورة المشتريات وتحديث المخزن والحساب بنجاح", Toast.LENGTH_SHORT).show()
        }
        editingInvoiceData = null
      }
    )
  }

  // Delete invoice dialog
  deletingInvoice?.let { inv ->
    DeleteInvoiceConfirmDialog(
      invoice = inv,
      onConfirm = {
        viewModel.deleteInvoice(inv) {
          Toast.makeText(context, "تم حذف فاتورة المشتريات واسترجاع أرصدة المخزن والحساب بنجاح", Toast.LENGTH_SHORT).show()
        }
        deletingInvoice = null
      },
      onDismiss = { deletingInvoice = null }
    )
  }
}

@Composable
fun PurchaseInvoiceHistoryCard(
  invoice: Invoice,
  onCardClick: () -> Unit,
  onInspect: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  onPrintReceipt: () -> Unit
) {
  val isCash = invoice.paymentType == PaymentType.CASH
  val isCredit = invoice.paymentType == PaymentType.CREDIT
  val isPartial = invoice.paymentType == PaymentType.PARTIAL

  val timeFormatted = remember(invoice.timestamp) {
    SimpleDateFormat("yyyy-MM-dd  hh:mm a", Locale.ENGLISH).format(Date(invoice.timestamp))
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onCardClick() },
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), shape = CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.LocalShipping, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(text = invoice.partyName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(text = "${invoice.invoiceNumber} • $timeFormatted", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }

        Surface(
          shape = RoundedCornerShape(6.dp),
          color = when {
            isCash -> EmeraldPrimary.copy(alpha = 0.12f)
            isCredit -> AmberPrimary.copy(alpha = 0.12f)
            else -> Color(0xFF1976D2).copy(alpha = 0.12f)
          }
        ) {
          Text(
            text = when {
              isCash -> "كاش مسدد"
              isCredit -> "آجل للمورد"
              else -> "سداد جزئي"
            },
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = when {
              isCash -> EmeraldPrimary
              isCredit -> AmberPrimary
              else -> Color(0xFF1976D2)
            },
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
          )
        }
      }

      HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "قيمة التوريد: ${String.format(Locale.ENGLISH, "%.2f ج.م", invoice.totalAmount)}",
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp
        )
        if (invoice.remainingAmount > 0) {
          Text(
            text = "المتبقي للمورد: ${String.format(Locale.ENGLISH, "%.2f ج.م", invoice.remainingAmount)}",
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.error
          )
        } else {
          Text(
            text = "مسددة بالكامل",
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = EmeraldPrimary
          )
        }
      }

      val grandDue = if (invoice.grandTotalDue > 0) invoice.grandTotalDue else (invoice.previousBalance + invoice.remainingAmount)
      if (invoice.previousBalance > 0 || grandDue > 0) {
        Spacer(modifier = Modifier.height(4.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "رصيد المورد السابق: ${String.format(Locale.ENGLISH, "%.2f ج.م", invoice.previousBalance)}",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = "إجمالي مستحقاته: ${String.format(Locale.ENGLISH, "%.2f ج.م", grandDue)}",
            fontSize = 12.sp,
            fontWeight = FontWeight.ExtraBold,
            color = AmberPrimary
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // أزرار العمليات المباشرة على الفاتورة: تفاصيل، تعديل، حذف، طباعة
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Button(
          onClick = onInspect,
          modifier = Modifier.weight(1.1f),
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
          contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
        ) {
          Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("تفاصيل", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
          onClick = onEdit,
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
        ) {
          Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp), tint = AmberPrimary)
          Spacer(modifier = Modifier.width(4.dp))
          Text("تعديل", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AmberPrimary)
        }

        OutlinedButton(
          onClick = onDelete,
          modifier = Modifier.weight(0.9f),
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
        ) {
          Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.error)
          Spacer(modifier = Modifier.width(4.dp))
          Text("حذف", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
        }

        Button(
          onClick = onPrintReceipt,
          modifier = Modifier.weight(1.1f),
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
        ) {
          Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
          Spacer(modifier = Modifier.width(4.dp))
          Text("طباعة", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    }
  }
}
