package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Customer
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItem
import com.example.data.model.InvoiceType
import com.example.data.model.PaymentType
import com.example.data.model.Product
import com.example.data.model.Supplier
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldPrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// -----------------------------------------------------------------------------
// 1. نافذة تفاصيل الفاتورة مع إمكانية التعديل والحذف والطباعة
// -----------------------------------------------------------------------------
@Composable
fun InvoiceDetailsDialog(
  invoice: Invoice,
  onDismiss: () -> Unit,
  onPrintReceipt: () -> Unit,
  onEditInvoice: (Invoice, List<InvoiceItem>) -> Unit,
  onDeleteInvoice: (Invoice) -> Unit,
  loadItems: suspend (Long) -> List<InvoiceItem>
) {
  var items by remember { mutableStateOf<List<InvoiceItem>?>(null) }
  var isLoading by remember { mutableStateOf(true) }
  var showDeleteConfirm by remember { mutableStateOf(false) }

  LaunchedEffect(invoice.id) {
    isLoading = true
    items = loadItems(invoice.id)
    isLoading = false
  }

  val isSale = invoice.type == InvoiceType.SALE
  val timeFormatted = remember(invoice.timestamp) {
    SimpleDateFormat("yyyy-MM-dd  hh:mm a", Locale.ENGLISH).format(Date(invoice.timestamp))
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .fillMaxHeight(0.90f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(16.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(40.dp)
                .background(
                  if (isSale) EmeraldPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                  shape = CircleShape
                ),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                if (isSale) Icons.Default.Receipt else Icons.Default.LocalShipping,
                contentDescription = null,
                tint = if (isSale) EmeraldPrimary else MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (isSale) "تفاصيل فاتورة بيع (${invoice.invoiceNumber})" else "تفاصيل فاتورة توريد (${invoice.invoiceNumber})",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp
              )
              Text(
                text = "$timeFormatted • ${if (isSale) "العميل: " else "المورد: "}${invoice.partyName}",
                fontSize = 11.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

        if (isLoading) {
          Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = EmeraldPrimary)
          }
        } else {
          val invoiceItemList = items ?: emptyList()

          LazyColumn(
            modifier = Modifier
              .weight(1f)
              .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // Party & Payment summary card
            item {
              Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
              ) {
                Column(modifier = Modifier.padding(12.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(
                      text = if (isSale) "العميل: ${invoice.partyName}" else "المورد: ${invoice.partyName}",
                      fontWeight = FontWeight.Bold,
                      fontSize = 13.sp
                    )
                    Surface(
                      shape = RoundedCornerShape(6.dp),
                      color = when (invoice.paymentType) {
                        PaymentType.CASH -> EmeraldPrimary.copy(alpha = 0.15f)
                        PaymentType.CREDIT -> AmberPrimary.copy(alpha = 0.15f)
                        PaymentType.PARTIAL -> Color(0xFF1976D2).copy(alpha = 0.15f)
                      }
                    ) {
                      Text(
                        text = when (invoice.paymentType) {
                          PaymentType.CASH -> "كاش مسدد بالكامل"
                          PaymentType.CREDIT -> "آجل بالكامل على الحساب"
                          PaymentType.PARTIAL -> "دفع جزئي (مقدم + آجل)"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (invoice.paymentType) {
                          PaymentType.CASH -> EmeraldPrimary
                          PaymentType.CREDIT -> AmberPrimary
                          PaymentType.PARTIAL -> Color(0xFF1976D2)
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                      )
                    }
                  }

                  Spacer(modifier = Modifier.height(4.dp))
                  if (invoice.notes.isNotBlank()) {
                    Text(text = "ملاحظات: ${invoice.notes}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
              }
            }

            // Items list header
            item {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(top = 4.dp, bottom = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text("الأصناف والبنود المسجلة (${invoiceItemList.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("الكمية • السعر • الإجمالي", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            // Items
            items(invoiceItemList) { itm ->
              Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(text = itm.productName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(
                      text = "${itm.quantity} ${itm.unitType} (إجمالي ${itm.totalPieces} قطعة)",
                      fontSize = 11.sp,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                  Column(horizontalAlignment = Alignment.End) {
                    Text(
                      text = String.format(Locale.ENGLISH, "%.2f ج.م", itm.totalPrice),
                      fontWeight = FontWeight.ExtraBold,
                      fontSize = 13.sp,
                      color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                      text = "سعر الوحدة: ${String.format(Locale.ENGLISH, "%.2f", itm.unitPrice)}",
                      fontSize = 10.sp,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }
              }
            }

            // Totals breakdown card
            item {
              Spacer(modifier = Modifier.height(4.dp))
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("إجمالي الفاتورة:", fontSize = 12.sp)
                    Text(String.format(Locale.ENGLISH, "%.2f ج.م", invoice.totalAmount), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                  }
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("المدفوع نقداً (كاش):", fontSize = 12.sp)
                    Text(String.format(Locale.ENGLISH, "%.2f ج.م", invoice.paidAmount), fontWeight = FontWeight.Bold, color = EmeraldPrimary, fontSize = 13.sp)
                  }
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("المتبقي آجل على الحساب:", fontSize = 12.sp)
                    Text(
                      text = String.format(Locale.ENGLISH, "%.2f ج.م", invoice.remainingAmount),
                      fontWeight = FontWeight.Bold,
                      color = if (invoice.remainingAmount > 0) MaterialTheme.colorScheme.error else EmeraldPrimary,
                      fontSize = 13.sp
                    )
                  }
                  if (invoice.previousBalance > 0 || invoice.grandTotalDue > 0) {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                      Text("إجمالي مستحق الحساب السابق والحالي:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                      Text(
                        String.format(Locale.ENGLISH, "%.2f ج.م", if (invoice.grandTotalDue > 0) invoice.grandTotalDue else (invoice.previousBalance + invoice.remainingAmount)),
                        fontWeight = FontWeight.ExtraBold,
                        color = AmberPrimary,
                        fontSize = 14.sp
                      )
                    }
                  }
                }
              }
            }
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

        // Action Buttons Row: Print, Edit, Delete
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Print button
          Button(
            onClick = onPrintReceipt,
            modifier = Modifier.weight(1.2f),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
          ) {
            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("طباعة 🖨️", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          // Edit button
          Button(
            onClick = {
              val currentItems = items ?: emptyList()
              onEditInvoice(invoice, currentItems)
            },
            modifier = Modifier.weight(1.3f),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AmberPrimary)
          ) {
            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("تعديل كامل ✏️", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          // Delete button
          Button(
            onClick = { showDeleteConfirm = true },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
          ) {
            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("حذف 🗑️", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }

  if (showDeleteConfirm) {
    DeleteInvoiceConfirmDialog(
      invoice = invoice,
      onConfirm = {
        showDeleteConfirm = false
        onDeleteInvoice(invoice)
        onDismiss()
      },
      onDismiss = { showDeleteConfirm = false }
    )
  }
}

// -----------------------------------------------------------------------------
// 2. تأكيد حذف الفاتورة مع التنبيه بإلغاء التأثير المالي والمخزني
// -----------------------------------------------------------------------------
@Composable
fun DeleteInvoiceConfirmDialog(
  invoice: Invoice,
  onConfirm: () -> Unit,
  onDismiss: () -> Unit
) {
  val isSale = invoice.type == InvoiceType.SALE
  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(36.dp))
    },
    title = {
      Text(
        text = if (isSale) "تأكيد حذف فاتورة المبيعات" else "تأكيد حذف فاتورة المشتريات",
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("هل أنت متأكد من حذف الفاتورة رقم (${invoice.invoiceNumber}) نهائياً؟", fontWeight = FontWeight.Bold)
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.error.copy(alpha = 0.08f),
          modifier = Modifier.padding(vertical = 4.dp)
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
              text = if (isSale)
                "✓ سيتم إعادة أصناف وبضاعة الفاتورة إلى رصيد المخزن فوراً."
              else
                "✓ سيتم خصم الكميات الموردة من رصيد المخزن فوراً.",
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.error
            )
            if (invoice.remainingAmount > 0) {
              Text(
                text = if (isSale)
                  "✓ سيتم إلغاء المديونية (${String.format(Locale.ENGLISH, "%.2f", invoice.remainingAmount)} ج.م) من حساب العميل ${invoice.partyName}."
                else
                  "✓ سيتم إلغاء المستحق (${String.format(Locale.ENGLISH, "%.2f", invoice.remainingAmount)} ج.م) من حساب المورد ${invoice.partyName}.",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.error
              )
            }
            Text("✓ سيتم إلغاء القيد المحاسبي وحركة الفاتورة بالكامل.", fontSize = 11.sp, color = Color.Gray)
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onConfirm,
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
      ) {
        Text("نعم، حذف الفاتورة الآن", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) {
        Text("إلغاء")
      }
    }
  )
}

// -----------------------------------------------------------------------------
// 3. نافذة التعديل الكامل للفاتورة (Full Invoice Edit Dialog)
// -----------------------------------------------------------------------------
@Composable
fun EditInvoiceFullDialog(
  invoice: Invoice,
  initialItems: List<InvoiceItem>,
  allProducts: List<Product>,
  allCustomers: List<Customer>,
  allSuppliers: List<Supplier>,
  onDismiss: () -> Unit,
  onSave: (Invoice, List<InvoiceItem>) -> Unit
) {
  val context = LocalContext.current
  val isSale = invoice.type == InvoiceType.SALE

  // Editable items state
  val editableItems = remember {
    mutableStateListOf<InvoiceItem>().apply { addAll(initialItems) }
  }

  // Selected party
  var selectedPartyId by remember { mutableStateOf(invoice.partyId) }
  var selectedPartyName by remember { mutableStateOf(invoice.partyName) }

  // Payment settings
  var paymentType by remember { mutableStateOf(invoice.paymentType) }
  var discountText by remember { mutableStateOf(invoice.discount.toString()) }
  var paidAmountText by remember { mutableStateOf(invoice.paidAmount.toString()) }

  // Product picker sheet for adding items
  var showAddProductSheet by remember { mutableStateOf(false) }

  // Calculations
  val subtotal = remember(editableItems.toList()) {
    editableItems.sumOf { it.totalPrice }
  }
  val discount = discountText.toDoubleOrNull() ?: 0.0
  val totalAmount = (subtotal - discount).coerceAtLeast(0.0)

  val paidAmount = when (paymentType) {
    PaymentType.CASH -> totalAmount
    PaymentType.CREDIT -> 0.0
    PaymentType.PARTIAL -> (paidAmountText.toDoubleOrNull() ?: 0.0).coerceIn(0.0, totalAmount)
  }
  val remainingAmount = (totalAmount - paidAmount).coerceAtLeast(0.0)

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth(0.96f)
        .fillMaxHeight(0.92f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(14.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Edit, contentDescription = null, tint = AmberPrimary)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "تعديل فاتورة ${if (isSale) "مبيعات" else "توريد"} (${invoice.invoiceNumber})",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
              )
              Text(
                text = "تعديل الأصناف والكميات والأسعار والحساب",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إلغاء")
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Party selection row
          item {
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(
                  text = if (isSale) "العميل الحالي: $selectedPartyName" else "المورد الحالي: $selectedPartyName",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp
                )
                Text(
                  text = "يمكنك تغيير الطرف أو تركه كما هو",
                  fontSize = 10.5.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }

          // Add Product button row
          item {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text("أصناف الفاتورة (${editableItems.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
              Button(
                onClick = { showAddProductSheet = true },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
              ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("إضافة صنف للفاتورة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }
          }

          // Items editor list
          itemsIndexed(editableItems) { idx, item ->
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(item.productName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                  IconButton(
                    onClick = { editableItems.removeAt(idx) },
                    modifier = Modifier.size(28.dp)
                  ) {
                    Icon(Icons.Default.Delete, contentDescription = "حذف الصنف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                  }
                }

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  // Unit selection chip (كرتونة / علبة)
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                    modifier = Modifier.clickable {
                      val newUnit = if (item.unitType == "كرتونة") "قطعة" else "كرتونة"
                      val prod = allProducts.find { it.id == item.productId }
                      val newPrice = if (isSale) {
                        if (newUnit == "كرتونة") (prod?.cartonWholesalePrice ?: item.unitPrice) else (prod?.pieceRetailPrice ?: item.unitPrice)
                      } else {
                        if (newUnit == "كرتونة") (prod?.cartonCostPrice ?: item.unitPrice) else (prod?.pieceCostPrice ?: item.unitPrice)
                      }
                      val newTotalPieces = if (newUnit == "كرتونة") item.quantity * item.piecesPerCarton else item.quantity
                      editableItems[idx] = item.copy(
                        unitType = newUnit,
                        unitPrice = newPrice,
                        totalPieces = newTotalPieces,
                        totalPrice = item.quantity * newPrice
                      )
                    }
                  ) {
                    Text(
                      text = "${item.unitType} 🔁",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.primary,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                    )
                  }

                  // Quantity (+ / -)
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                      .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(6.dp))
                      .border(1.dp, Color.LightGray, RoundedCornerShape(6.dp))
                  ) {
                    IconButton(
                      onClick = {
                        val newQty = item.quantity - 1
                        if (newQty <= 0) {
                          editableItems.removeAt(idx)
                        } else {
                          val totalP = if (item.unitType == "كرتونة") newQty * item.piecesPerCarton else newQty
                          editableItems[idx] = item.copy(
                            quantity = newQty,
                            totalPieces = totalP,
                            totalPrice = newQty * item.unitPrice
                          )
                        }
                      },
                      modifier = Modifier.size(28.dp)
                    ) {
                      Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(14.dp))
                    }

                    Text(
                      text = "${item.quantity}",
                      fontWeight = FontWeight.Bold,
                      fontSize = 12.sp,
                      modifier = Modifier.padding(horizontal = 6.dp)
                    )

                    IconButton(
                      onClick = {
                        val newQty = item.quantity + 1
                        val totalP = if (item.unitType == "كرتونة") newQty * item.piecesPerCarton else newQty
                        editableItems[idx] = item.copy(
                          quantity = newQty,
                          totalPieces = totalP,
                          totalPrice = newQty * item.unitPrice
                        )
                      },
                      modifier = Modifier.size(28.dp)
                    ) {
                      Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                    }
                  }

                  // Price Input
                  var priceText by remember(item.unitPrice) { mutableStateOf(item.unitPrice.toString()) }
                  OutlinedTextField(
                    value = priceText,
                    onValueChange = { str ->
                      priceText = str
                      val p = str.toDoubleOrNull() ?: item.unitPrice
                      editableItems[idx] = item.copy(
                        unitPrice = p,
                        totalPrice = item.quantity * p
                      )
                    },
                    label = { Text("السعر", fontSize = 10.sp) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.width(90.dp)
                  )

                  // Line Total
                  Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                    Text(
                      text = String.format(Locale.ENGLISH, "%.2f ج.م", item.totalPrice),
                      fontWeight = FontWeight.ExtraBold,
                      fontSize = 12.sp,
                      color = MaterialTheme.colorScheme.primary
                    )
                  }
                }
              }
            }
          }

          if (editableItems.isEmpty()) {
              item {
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Text("لا توجد أصناف في الفاتورة! يرجى إضافة صنف واحد على الأقل", color = MaterialTheme.colorScheme.error)
                }
              }
            }

          // Payment details card
          item {
            Spacer(modifier = Modifier.height(4.dp))
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
              Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("خيارات الدفع وتحديث الحساب", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  FilterChip(
                    selected = paymentType == PaymentType.CASH,
                    onClick = { paymentType = PaymentType.CASH },
                    label = { Text("كاش بالكامل", fontSize = 11.sp) }
                  )
                  FilterChip(
                    selected = paymentType == PaymentType.CREDIT,
                    onClick = { paymentType = PaymentType.CREDIT },
                    label = { Text("آجل بالكامل", fontSize = 11.sp) }
                  )
                  FilterChip(
                    selected = paymentType == PaymentType.PARTIAL,
                    onClick = { paymentType = PaymentType.PARTIAL },
                    label = { Text("دفع جزئي", fontSize = 11.sp) }
                  )
                }

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  OutlinedTextField(
                    value = discountText,
                    onValueChange = { discountText = it },
                    label = { Text("الخصم (ج.م)", fontSize = 11.sp) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f)
                  )

                  if (paymentType == PaymentType.PARTIAL) {
                    OutlinedTextField(
                      value = paidAmountText,
                      onValueChange = { paidAmountText = it },
                      label = { Text("المدفوع نقداً (ج.م)", fontSize = 11.sp) },
                      singleLine = true,
                      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                      modifier = Modifier.weight(1f)
                    )
                  }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("الإجمالي بعد الخصم:", fontWeight = FontWeight.Bold)
                  Text(String.format(Locale.ENGLISH, "%.2f ج.م", totalAmount), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("المدفوع كاش:")
                  Text(String.format(Locale.ENGLISH, "%.2f ج.م", paidAmount), fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("المتبقي آجل على الحساب:")
                  Text(
                    String.format(Locale.ENGLISH, "%.2f ج.م", remainingAmount),
                    fontWeight = FontWeight.Bold,
                    color = if (remainingAmount > 0) MaterialTheme.colorScheme.error else EmeraldPrimary
                  )
                }
              }
            }
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        // Save & Cancel Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("إلغاء")
          }

          Button(
            onClick = {
              if (editableItems.isEmpty()) {
                Toast.makeText(context, "يجب إضافة صنف واحد على الأقل للفاتورة", Toast.LENGTH_SHORT).show()
                return@Button
              }
              val totalCost = editableItems.sumOf { it.totalCost }
              val totalProfit = if (isSale) totalAmount - totalCost else 0.0

              val updatedInvoice = invoice.copy(
                subtotal = subtotal,
                discount = discount,
                totalAmount = totalAmount,
                paidAmount = paidAmount,
                remainingAmount = remainingAmount,
                paymentType = paymentType,
                totalCost = totalCost,
                totalProfit = totalProfit,
                grandTotalDue = invoice.previousBalance + remainingAmount,
                notes = if (remainingAmount > 0) "فاتورة معدلة • متبقي آجل: $remainingAmount" else "فاتورة معدلة • مسددة بالكامل"
              )
              onSave(updatedInvoice, editableItems.toList())
              onDismiss()
            },
            modifier = Modifier.weight(2f),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
          ) {
            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("حفظ التعديلات وتحديث المخزن والرصيد", fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }
        }
      }
    }
  }

  // Sub-dialog: Add product to this invoice
  if (showAddProductSheet) {
    EditInvoiceAddProductDialog(
      products = allProducts,
      isSale = isSale,
      onAdd = { product, unit, qty, price ->
        val piecesPerCarton = if (product.piecesPerCarton > 0) product.piecesPerCarton else 1
        val totalPieces = if (unit == "كرتونة") qty * piecesPerCarton else qty
        val unitCost = if (unit == "كرتونة") product.cartonCostPrice else product.pieceCostPrice
        val totalCost = totalPieces * (if (unit == "كرتونة") product.cartonCostPrice / piecesPerCarton else product.pieceCostPrice)
        val totalPrice = qty * price
        val itemProfit = if (isSale) totalPrice - totalCost else 0.0

        val existingIdx = editableItems.indexOfFirst { it.productId == product.id && it.unitType == unit }
        if (existingIdx >= 0) {
          val exist = editableItems[existingIdx]
          val newQty = exist.quantity + qty
          val newTotPieces = if (unit == "كرتونة") newQty * piecesPerCarton else newQty
          editableItems[existingIdx] = exist.copy(
            quantity = newQty,
            totalPieces = newTotPieces,
            totalPrice = newQty * price,
            totalCost = newTotPieces * (if (unit == "كرتونة") product.cartonCostPrice / piecesPerCarton else product.pieceCostPrice)
          )
        } else {
          editableItems.add(
            InvoiceItem(
              productId = product.id,
              productName = product.name,
              unitType = unit,
              quantity = qty,
              piecesPerCarton = piecesPerCarton,
              totalPieces = totalPieces,
              unitPrice = price,
              unitCost = unitCost,
              totalPrice = totalPrice,
              totalCost = totalCost,
              itemProfit = itemProfit
            )
          )
        }
        showAddProductSheet = false
      },
      onDismiss = { showAddProductSheet = false }
    )
  }
}

// -----------------------------------------------------------------------------
// 4. اختيار صنف لإضافته إلى الفاتورة الجاري تعديلها
// -----------------------------------------------------------------------------
@Composable
fun EditInvoiceAddProductDialog(
  products: List<Product>,
  isSale: Boolean,
  onAdd: (Product, String, Int, Double) -> Unit,
  onDismiss: () -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }
  val filtered = remember(products, searchQuery) {
    if (searchQuery.isBlank()) products
    else products.filter {
      it.name.contains(searchQuery, ignoreCase = true) || it.barcode.contains(searchQuery)
    }
  }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(14.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .fillMaxHeight(0.85f)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("إضافة صنف للفاتورة", fontWeight = FontWeight.Bold, fontSize = 14.sp)
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إلغاء")
          }
        }

        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text("ابحث بالاسم أو الباركود...") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true,
          shape = RoundedCornerShape(8.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          items(filtered) { prod ->
            Card(
              shape = RoundedCornerShape(8.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(prod.name, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                  Text(
                    text = "المخزن: ${prod.stockDisplayString()}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  val cartonPrice = if (isSale) prod.cartonWholesalePrice else prod.cartonCostPrice
                  val piecePrice = if (isSale) prod.pieceRetailPrice else prod.pieceCostPrice

                  Button(
                    onClick = { onAdd(prod, "كرتونة", 1, cartonPrice) },
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(6.dp)
                  ) {
                    Text("+ كرتونة", fontSize = 10.5.sp)
                  }

                  OutlinedButton(
                    onClick = { onAdd(prod, "قطعة", 1, piecePrice) },
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(6.dp)
                  ) {
                    Text("+ علبة", fontSize = 10.5.sp)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
