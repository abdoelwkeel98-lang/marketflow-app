package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Customer
import com.example.data.model.PaymentTransaction
import com.example.data.model.Supplier
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import com.example.utils.TafqeetHelper
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickSanadVoucherDialog(
  customers: List<Customer>,
  suppliers: List<Supplier>,
  initialTypeIsReceipt: Boolean = true,
  onDismiss: () -> Unit,
  onIssueReceiptVoucher: (Customer, Double, String, (PaymentTransaction) -> Unit) -> Unit,
  onIssuePaymentVoucher: (Supplier, Double, String, (PaymentTransaction) -> Unit) -> Unit
) {
  val context = LocalContext.current
  var selectedTab by remember { mutableIntStateOf(if (initialTypeIsReceipt) 0 else 1) }

  // Customer selection for Receipt Voucher
  var selectedCustomer by remember { mutableStateOf(customers.firstOrNull()) }
  var customerDropdownExpanded by remember { mutableStateOf(false) }

  // Supplier selection for Payment Voucher
  var selectedSupplier by remember { mutableStateOf(suppliers.firstOrNull()) }
  var supplierDropdownExpanded by remember { mutableStateOf(false) }

  var amountText by remember { mutableStateOf("") }
  var notesText by remember { mutableStateOf("") }
  var paymentMethod by remember { mutableStateOf("نقداً (خزينة الصندوق)") }
  var isSubmitting by remember { mutableStateOf(false) }

  val parsedAmount = amountText.toDoubleOrNull() ?: 0.0
  val prevBalance = if (selectedTab == 0) selectedCustomer?.currentBalance ?: 0.0 else selectedSupplier?.currentBalance ?: 0.0
  val balanceAfter = (prevBalance - parsedAmount).coerceAtLeast(0.0)
  val tafqeetPreview = if (parsedAmount > 0.0) {
    TafqeetHelper.convertToArabicWords(parsedAmount)
  } else {
    "أدخل المبلغ لتوليد التفقيط بالكلمات تلقائياً"
  }

  val activeAccent = if (selectedTab == 0) EmeraldPrimary else OrangePrimary

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .padding(vertical = 16.dp),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(10.dp)
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {

        // Top Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(activeAccent)
            .padding(horizontal = 16.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = CircleShape,
              color = Color.White.copy(alpha = 0.2f),
              modifier = Modifier.size(34.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  Icons.Default.Receipt,
                  contentDescription = null,
                  tint = Color.White,
                  modifier = Modifier.size(20.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "إصدار سند مالي رسمي (سند)",
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
              )
              Text(
                text = "سندات القبض والصرف الرسمية مع التفقيط التلقائي",
                fontSize = 10.sp,
                color = Color.White.copy(alpha = 0.85f)
              )
            }
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White)
          }
        }

        // Voucher Type Tabs
        TabRow(
          selectedTabIndex = selectedTab,
          containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          contentColor = activeAccent
        ) {
          Tab(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            text = {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("سند قبض (استلام نقدية)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
              }
            }
          )
          Tab(
            selected = selectedTab == 1,
            onClick = { selectedTab = 1 },
            text = {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = OrangePrimary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("سند صرف (دفع نقدية)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
              }
            }
          )
        }

        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f, fill = false)
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

          // Party Selection
          item {
            if (selectedTab == 0) {
              // Customers selection for Receipt Voucher
              Text("استلمنا من السيد / العميل:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
              ExposedDropdownMenuBox(
                expanded = customerDropdownExpanded,
                onExpandedChange = { customerDropdownExpanded = !customerDropdownExpanded }
              ) {
                OutlinedTextField(
                  value = selectedCustomer?.let { "${it.name} (مديونية: ${String.format(Locale.ENGLISH, "%.1f", it.currentBalance)} ج.م)" } ?: "اختر عميلاً...",
                  onValueChange = {},
                  readOnly = true,
                  trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = customerDropdownExpanded) },
                  modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor(),
                  shape = RoundedCornerShape(8.dp)
                )
                ExposedDropdownMenu(
                  expanded = customerDropdownExpanded,
                  onDismissRequest = { customerDropdownExpanded = false }
                ) {
                  customers.forEach { customer ->
                    DropdownMenuItem(
                      text = {
                        Column {
                          Text(customer.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                          Text(
                            "الرصيد الحالي: ${String.format(Locale.ENGLISH, "%.1f", customer.currentBalance)} ج.م",
                            fontSize = 11.sp,
                            color = if (customer.currentBalance > 0) OrangePrimary else Color.Gray
                          )
                        }
                      },
                      onClick = {
                        selectedCustomer = customer
                        customerDropdownExpanded = false
                      }
                    )
                  }
                }
              }
            } else {
              // Suppliers selection for Payment Voucher
              Text("يصرف إلى السيد / المورد:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
              ExposedDropdownMenuBox(
                expanded = supplierDropdownExpanded,
                onExpandedChange = { supplierDropdownExpanded = !supplierDropdownExpanded }
              ) {
                OutlinedTextField(
                  value = selectedSupplier?.let { "${it.name} (مستحقات: ${String.format(Locale.ENGLISH, "%.1f", it.currentBalance)} ج.م)" } ?: "اختر مورداً...",
                  onValueChange = {},
                  readOnly = true,
                  trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = supplierDropdownExpanded) },
                  modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor(),
                  shape = RoundedCornerShape(8.dp)
                )
                ExposedDropdownMenu(
                  expanded = supplierDropdownExpanded,
                  onDismissRequest = { supplierDropdownExpanded = false }
                ) {
                  suppliers.forEach { supplier ->
                    DropdownMenuItem(
                      text = {
                        Column {
                          Text(supplier.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                          Text(
                            "المستحق له: ${String.format(Locale.ENGLISH, "%.1f", supplier.currentBalance)} ج.م",
                            fontSize = 11.sp,
                            color = if (supplier.currentBalance > 0) EmeraldPrimary else Color.Gray
                          )
                        }
                      },
                      onClick = {
                        selectedSupplier = supplier
                        supplierDropdownExpanded = false
                      }
                    )
                  }
                }
              }
            }
          }

          // Amount field
          item {
            OutlinedTextField(
              value = amountText,
              onValueChange = { amountText = it },
              label = { Text("مبلغ السند المطلوب بالأرقام (ج.م)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(8.dp)
            )
          }

          // Live Balance Before & After Card
          item {
            Surface(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
              Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("الرصيد السابق قبل السند:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(String.format(Locale.ENGLISH, "%.2f ج.م", prevBalance), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("المبلغ المسدد بهذا السند:", fontSize = 11.sp, color = activeAccent)
                  Text(String.format(Locale.ENGLISH, "%.2f ج.م", parsedAmount), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = activeAccent)
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text(if (selectedTab == 0) "الرصيد المتبقي على العميل بعد السند:" else "الرصيد المتبقي للمورد بعد السند:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  Text(String.format(Locale.ENGLISH, "%.2f ج.م", balanceAfter), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = if (balanceAfter > 0) MaterialTheme.colorScheme.error else EmeraldPrimary)
                }
              }
            }
          }

          // Live Tafqeet Banner (Sanad Signature Feature)
          item {
            Surface(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(8.dp),
              color = activeAccent.copy(alpha = 0.08f),
              border = androidx.compose.foundation.BorderStroke(1.dp, activeAccent.copy(alpha = 0.3f))
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(
                  text = "المبلغ بالحروف والتفقيط المعتمد:",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = activeAccent
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                  text = tafqeetPreview,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = Color(0xFF1E293B)
                )
              }
            }
          }

          // Payment mode selection
          item {
            Text("طريقة السداد:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              listOf("نقداً (خزينة الصندوق)", "تحويل بنكي", "شيك", "محفظة كاش").forEach { mode ->
                val isSelected = paymentMethod == mode
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = if (isSelected) activeAccent else MaterialTheme.colorScheme.surfaceVariant,
                  modifier = Modifier
                    .weight(1f)
                    .clickable { paymentMethod = mode }
                ) {
                  Text(
                    text = mode,
                    fontSize = 10.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 2.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                  )
                }
              }
            }
          }

          // Notes / Reason
          item {
            OutlinedTextField(
              value = notesText,
              onValueChange = { notesText = it },
              label = { Text("وذلك مقابل / بيان السند (ملاحظات)") },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(8.dp)
            )
          }
        }

        // Bottom Action Button
        Surface(
          modifier = Modifier.fillMaxWidth(),
          tonalElevation = 6.dp,
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            OutlinedButton(
              onClick = onDismiss,
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(8.dp)
            ) {
              Text("إلغاء")
            }

            Button(
              onClick = {
                if (isSubmitting) return@Button
                if (parsedAmount <= 0) {
                  Toast.makeText(context, "يرجى إدخال مبلغ صحيح أكبر من الصفر", Toast.LENGTH_SHORT).show()
                  return@Button
                }

                if (selectedTab == 0) {
                  // Receipt Voucher
                  val cust = selectedCustomer
                  if (cust == null) {
                    Toast.makeText(context, "يرجى اختيار عميل لإصدار سند القبض", Toast.LENGTH_SHORT).show()
                    return@Button
                  }
                  isSubmitting = true
                  val notes = if (notesText.isNotBlank()) "$notesText - $paymentMethod" else "سداد دفعة من الحساب - $paymentMethod"
                  onIssueReceiptVoucher(cust, parsedAmount, notes) { createdTx ->
                    Toast.makeText(context, "تم إصدار سند القبض بنجاح وتحديث الحساب والخزينة", Toast.LENGTH_SHORT).show()
                  }
                } else {
                  // Payment Voucher
                  val sup = selectedSupplier
                  if (sup == null) {
                    Toast.makeText(context, "يرجى اختيار مورد لإصدار سند الصرف", Toast.LENGTH_SHORT).show()
                    return@Button
                  }
                  isSubmitting = true
                  val notes = if (notesText.isNotBlank()) "$notesText - $paymentMethod" else "سداد مستحقات توريد - $paymentMethod"
                  onIssuePaymentVoucher(sup, parsedAmount, notes) { createdTx ->
                    Toast.makeText(context, "تم إصدار سند الصرف بنجاح وخصم المبلغ من الخزينة", Toast.LENGTH_SHORT).show()
                  }
                }
              },
              enabled = !isSubmitting && parsedAmount > 0,
              modifier = Modifier.weight(2f),
              shape = RoundedCornerShape(8.dp),
              colors = ButtonDefaults.buttonColors(containerColor = activeAccent)
            ) {
              Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                if (isSubmitting) "جاري الإصدار..." else if (selectedTab == 0) "إصدار وحفظ سند القبض (SANAD)" else "إصدار وحفظ سند الصرف (SANAD)",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              )
            }
          }
        }
      }
    }
  }
}
