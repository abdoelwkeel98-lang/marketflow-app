package com.example.data

import com.example.data.dao.AppDao
import com.example.data.model.Account
import com.example.data.model.Customer
import com.example.data.model.Expense
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItem
import com.example.data.model.InvoiceType
import com.example.data.model.JournalEntry
import com.example.data.model.JournalLine
import com.example.data.model.PaymentTransaction
import com.example.data.model.PaymentType
import com.example.data.model.Product
import com.example.data.model.StockAudit
import com.example.data.model.StockAuditItem
import com.example.data.model.Supplier
import com.example.data.model.TransactionType
import com.example.data.model.Employee
import com.example.data.model.DelegateSyncLog
import kotlinx.coroutines.flow.Flow
import kotlin.math.abs

class WholesaleRepository(private val dao: AppDao) {

  // Products
  val allProducts: Flow<List<Product>> = dao.getAllProducts()

  suspend fun getProductById(id: Long) = dao.getProductById(id)
  suspend fun getProductByBarcode(barcode: String) = dao.getProductByBarcode(barcode)
  suspend fun insertProduct(product: Product) = dao.insertProduct(product)
  suspend fun updateProduct(product: Product) = dao.updateProduct(product)
  suspend fun deleteProduct(product: Product) = dao.deleteProduct(product)
  suspend fun updateStock(productId: Long, piecesDelta: Int) = dao.adjustProductStock(productId, piecesDelta)
  suspend fun updateProductCost(productId: Long, cartonCost: Double) = dao.updateProductCost(productId, cartonCost)

  // Recalculates WAC cost for all products based on chronological purchase invoices
  suspend fun recalculateAllProductsWac(): Int {
    val products = dao.getAllProductsSync()
    val allInvoices = dao.getAllInvoicesSync().filter { it.type == InvoiceType.PURCHASE }.sortedBy { it.timestamp }
    val allItems = dao.getAllInvoiceItemsSync()
    val invoiceItemMap = allItems.groupBy { it.invoiceId }

    var updatedCount = 0
    for (product in products) {
      val productPurchaseItems = mutableListOf<InvoiceItem>()
      for (inv in allInvoices) {
        val items = invoiceItemMap[inv.id] ?: emptyList()
        val match = items.filter { it.productId == product.id }
        productPurchaseItems.addAll(match)
      }

      if (productPurchaseItems.isNotEmpty()) {
        var runningPieces = 0
        var runningCost = product.pieceCostPrice
        for (item in productPurchaseItems) {
          val purchasedPieceCost = if (item.unitType == "كرتونة" && item.piecesPerCarton > 0) {
            item.unitPrice / item.piecesPerCarton
          } else {
            item.unitPrice
          }
          val newPieces = item.totalPieces
          val currentTotalCost = runningPieces * runningCost
          val newBatchCost = newPieces * purchasedPieceCost
          val totalCombinedPieces = runningPieces + newPieces
          if (totalCombinedPieces > 0) {
            runningCost = (currentTotalCost + newBatchCost) / totalCombinedPieces
          } else {
            runningCost = purchasedPieceCost
          }
          runningPieces += newPieces
        }
        val finalCartonCost = runningCost * product.piecesPerCarton
        dao.updateProductCost(product.id, finalCartonCost)
        updatedCount++
      }
    }
    return updatedCount
  }

  // Customers
  val allCustomers: Flow<List<Customer>> = dao.getAllCustomers()
  suspend fun getCustomerById(id: Long) = dao.getCustomerById(id)
  suspend fun insertCustomer(customer: Customer) = dao.insertCustomer(customer)
  suspend fun updateCustomer(customer: Customer) = dao.updateCustomer(customer)
  suspend fun deleteCustomer(customer: Customer) = dao.deleteCustomer(customer)

  // Suppliers
  val allSuppliers: Flow<List<Supplier>> = dao.getAllSuppliers()
  suspend fun getSupplierById(id: Long) = dao.getSupplierById(id)
  suspend fun insertSupplier(supplier: Supplier) = dao.insertSupplier(supplier)
  suspend fun updateSupplier(supplier: Supplier) = dao.updateSupplier(supplier)
  suspend fun deleteSupplier(supplier: Supplier) = dao.deleteSupplier(supplier)

  // Invoices & Items
  val allInvoices: Flow<List<Invoice>> = dao.getAllInvoices()
  val salesInvoices: Flow<List<Invoice>> = dao.getInvoicesByType(InvoiceType.SALE)
  val purchaseInvoices: Flow<List<Invoice>> = dao.getInvoicesByType(InvoiceType.PURCHASE)
  val allInvoiceItems: Flow<List<InvoiceItem>> = dao.getAllInvoiceItems()
  fun getInvoiceItems(invoiceId: Long): Flow<List<InvoiceItem>> = dao.getInvoiceItems(invoiceId)
  fun getInvoicesByParty(partyId: Long, type: InvoiceType) = dao.getInvoicesByParty(partyId, type)

  // Payments & Expenses
  val allTransactions: Flow<List<PaymentTransaction>> = dao.getAllTransactions()
  fun getTransactionsByParty(partyId: Long, type: TransactionType) = dao.getTransactionsByParty(partyId, type)
  val allExpenses: Flow<List<Expense>> = dao.getAllExpenses()

  // Stock Audits
  val allStockAudits: Flow<List<StockAudit>> = dao.getAllStockAudits()
  fun getStockAuditItems(auditId: Long) = dao.getStockAuditItems(auditId)

  // Double-Entry Accounting
  val allAccounts: Flow<List<Account>> = dao.getAllAccounts()
  val allJournalEntries: Flow<List<JournalEntry>> = dao.getAllJournalEntries()
  val allJournalLines: Flow<List<JournalLine>> = dao.getAllJournalLines()
  fun getJournalLinesForEntry(entryId: Long) = dao.getJournalLinesForEntry(entryId)
  fun getJournalLinesForAccount(code: String) = dao.getJournalLinesForAccount(code)
  suspend fun insertAccount(account: Account) = dao.insertAccount(account)

  // Complete Sales Flow with Perpetual Inventory & Double-Entry Journaling
  suspend fun completeSale(
    invoice: Invoice,
    items: List<InvoiceItem>
  ): Long {
    val invoiceId = dao.insertInvoice(invoice)
    val attachedItems = items.map { it.copy(invoiceId = invoiceId) }
    dao.insertInvoiceItems(attachedItems)

    // Deduct stock for sold items (Perpetual Inventory: تحديث فوري للأرصدة)
    for (item in attachedItems) {
      dao.adjustProductStock(item.productId, -item.totalPieces)
    }

    // Update customer debt balance if there is an unpaid remaining balance
    if (invoice.partyId > 0 && invoice.remainingAmount > 0) {
      dao.updateCustomerBalance(invoice.partyId, invoice.remainingAmount)
    }

    // Automatic Back-End Double-Entry Journal Entry (قيد اليومية المزدوج الآلي)
    val totalDebit = invoice.totalAmount + invoice.totalCost
    val totalCredit = invoice.totalAmount + invoice.totalCost
    val journalEntryId = dao.insertJournalEntry(
      JournalEntry(
        entryNumber = "JE-SALE-$invoiceId",
        timestamp = invoice.timestamp,
        description = "فاتورة بيع ${invoice.invoiceNumber} - ${invoice.partyName}",
        referenceType = "SALE",
        referenceId = invoiceId,
        totalDebit = totalDebit,
        totalCredit = totalCredit,
        isBalanced = true
      )
    )

    val journalLines = mutableListOf<JournalLine>()
    // 1. Debit Cash (الصندوق والخزينة) if cash received
    if (invoice.paidAmount > 0) {
      journalLines.add(
        JournalLine(
          entryId = journalEntryId,
          accountCode = "101",
          accountName = "الصندوق والخزينة النقدية",
          debit = invoice.paidAmount,
          credit = 0.0,
          notes = "مقبوض كاش من فاتورة ${invoice.invoiceNumber}"
        )
      )
    }
    // 2. Debit Accounts Receivable (العملاء والمدينون) if credit remainder
    if (invoice.remainingAmount > 0) {
      journalLines.add(
        JournalLine(
          entryId = journalEntryId,
          accountCode = "102",
          accountName = "العملاء والمدينون (حسابات السوق)",
          debit = invoice.remainingAmount,
          credit = 0.0,
          notes = "متبقي آجل على العميل ${invoice.partyName}"
        )
      )
    }
    // 3. Credit Sales Revenue (إيرادات المبيعات)
    journalLines.add(
      JournalLine(
        entryId = journalEntryId,
        accountCode = "401",
        accountName = "إيرادات مبيعات البضاعة",
        debit = 0.0,
        credit = invoice.totalAmount,
        notes = "إيراد مبيعات الفاتورة ${invoice.invoiceNumber}"
      )
    )
    // 4. Perpetual Inventory: Debit COGS & Credit Inventory
    if (invoice.totalCost > 0) {
      journalLines.add(
        JournalLine(
          entryId = journalEntryId,
          accountCode = "501",
          accountName = "تكلفة البضاعة المباعة (COGS)",
          debit = invoice.totalCost,
          credit = 0.0,
          notes = "تكلفة البضاعة المباعة وفق الجرد المستمر WAC"
        )
      )
      journalLines.add(
        JournalLine(
          entryId = journalEntryId,
          accountCode = "103",
          accountName = "مخزون البضاعة (نظام الجرد المستمر)",
          debit = 0.0,
          credit = invoice.totalCost,
          notes = "تخفيض بضاعة المخزن للمبيعات"
        )
      )
    }
    dao.insertJournalLines(journalLines)

    return invoiceId
  }

  // Complete Purchase Flow with Weighted Average Cost (WAC) & Double-Entry Journaling
  suspend fun completePurchase(
    invoice: Invoice,
    items: List<InvoiceItem>
  ): Long {
    val invoiceId = dao.insertInvoice(invoice)
    val attachedItems = items.map { it.copy(invoiceId = invoiceId) }
    dao.insertInvoiceItems(attachedItems)

    // Add stock for purchased items & recalculate cost using Weighted Average Cost (WAC)
    for (item in attachedItems) {
      val product = dao.getProductById(item.productId)
      if (product != null) {
        val existingPieces = product.totalPiecesInStock.coerceAtLeast(0)
        val existingTotalCost = existingPieces * product.pieceCostPrice
        val newPieces = item.totalPieces
        val purchasedPieceCost = if (item.unitType == "كرتونة" && item.piecesPerCarton > 0) {
          item.unitPrice / item.piecesPerCarton
        } else {
          item.unitPrice
        }
        val newCostTotal = newPieces * purchasedPieceCost
        val combinedPieces = existingPieces + newPieces
        val weightedPieceCost = if (combinedPieces > 0) {
          (existingTotalCost + newCostTotal) / combinedPieces
        } else {
          purchasedPieceCost
        }
        val weightedCartonCost = weightedPieceCost * product.piecesPerCarton

        // Update product stock and WAC cost
        dao.adjustProductStock(item.productId, item.totalPieces)
        dao.updateProductCost(item.productId, weightedCartonCost)
      } else {
        dao.adjustProductStock(item.productId, item.totalPieces)
      }
    }

    // Update supplier balance if remaining > 0 (نحن مدينون للمورد)
    if (invoice.partyId > 0 && invoice.remainingAmount > 0) {
      dao.updateSupplierBalance(invoice.partyId, invoice.remainingAmount)
    }

    // Automatic Back-End Double-Entry Journal Entry
    val journalEntryId = dao.insertJournalEntry(
      JournalEntry(
        entryNumber = "JE-PUR-$invoiceId",
        timestamp = invoice.timestamp,
        description = "فاتورة شراء وتوريد ${invoice.invoiceNumber} من ${invoice.partyName}",
        referenceType = "PURCHASE",
        referenceId = invoiceId,
        totalDebit = invoice.totalAmount,
        totalCredit = invoice.totalAmount,
        isBalanced = true
      )
    )

    val journalLines = mutableListOf<JournalLine>()
    // 1. Debit Merchandise Inventory (مخزون البضاعة) by total purchase
    journalLines.add(
      JournalLine(
        entryId = journalEntryId,
        accountCode = "103",
        accountName = "مخزون البضاعة (نظام الجرد المستمر)",
        debit = invoice.totalAmount,
        credit = 0.0,
        notes = "إضافة مشتريات بضاعة للمخزن بالمتوسط المترجح WAC"
      )
    )
    // 2. Credit Cash (الصندوق والخزينة) for cash paid
    if (invoice.paidAmount > 0) {
      journalLines.add(
        JournalLine(
          entryId = journalEntryId,
          accountCode = "101",
          accountName = "الصندوق والخزينة النقدية",
          debit = 0.0,
          credit = invoice.paidAmount,
          notes = "سداد نقدي كاش للمورد ${invoice.partyName}"
        )
      )
    }
    // 3. Credit Accounts Payable (الموردون والدائنون) for credit balance
    if (invoice.remainingAmount > 0) {
      journalLines.add(
        JournalLine(
          entryId = journalEntryId,
          accountCode = "201",
          accountName = "الموردون والدائنون (شركات التوزيع)",
          debit = 0.0,
          credit = invoice.remainingAmount,
          notes = "مستحق آجل للمورد ${invoice.partyName}"
        )
      )
    }
    dao.insertJournalLines(journalLines)

    return invoiceId
  }

  suspend fun getInvoiceItemsSync(invoiceId: Long): List<InvoiceItem> {
    return dao.getInvoiceItemsSync(invoiceId)
  }

  // Delete Invoice and Revert Its Full Inventory & Financial Effects
  suspend fun deleteInvoice(invoice: Invoice) {
    val items = dao.getInvoiceItemsSync(invoice.id)
    if (invoice.type == InvoiceType.SALE) {
      // 1. Revert inventory (add back sold pieces)
      for (item in items) {
        dao.adjustProductStock(item.productId, item.totalPieces)
      }
      // 2. Revert customer debt
      if (invoice.partyId > 0 && invoice.remainingAmount > 0) {
        dao.updateCustomerBalance(invoice.partyId, -invoice.remainingAmount)
      }
    } else {
      // 1. Revert inventory (deduct purchased pieces)
      for (item in items) {
        dao.adjustProductStock(item.productId, -item.totalPieces)
      }
      // 2. Revert supplier credit
      if (invoice.partyId > 0 && invoice.remainingAmount > 0) {
        dao.updateSupplierBalance(invoice.partyId, -invoice.remainingAmount)
      }
    }
    // Delete items, journal entries, and invoice
    dao.deleteInvoiceItemsByInvoiceId(invoice.id)
    dao.deleteJournalEntriesByReference(invoice.id, invoice.type.name)
    dao.deleteInvoice(invoice)
  }

  // Edit Invoice Fully and Apply New Inventory & Financial Balances
  suspend fun updateInvoiceWithItems(
    oldInvoice: Invoice,
    newInvoice: Invoice,
    newItems: List<InvoiceItem>
  ) {
    // --- Step 1: Revert Old Invoice Effects ---
    val oldItems = dao.getInvoiceItemsSync(oldInvoice.id)
    if (oldInvoice.type == InvoiceType.SALE) {
      for (item in oldItems) {
        dao.adjustProductStock(item.productId, item.totalPieces)
      }
      if (oldInvoice.partyId > 0 && oldInvoice.remainingAmount > 0) {
        dao.updateCustomerBalance(oldInvoice.partyId, -oldInvoice.remainingAmount)
      }
    } else {
      for (item in oldItems) {
        dao.adjustProductStock(item.productId, -item.totalPieces)
      }
      if (oldInvoice.partyId > 0 && oldInvoice.remainingAmount > 0) {
        dao.updateSupplierBalance(oldInvoice.partyId, -oldInvoice.remainingAmount)
      }
    }
    dao.deleteInvoiceItemsByInvoiceId(oldInvoice.id)
    dao.deleteJournalEntriesByReference(oldInvoice.id, oldInvoice.type.name)

    // --- Step 2: Apply New Invoice Effects ---
    val attachedItems = newItems.map { it.copy(invoiceId = oldInvoice.id) }
    dao.insertInvoiceItems(attachedItems)

    if (newInvoice.type == InvoiceType.SALE) {
      for (item in attachedItems) {
        dao.adjustProductStock(item.productId, -item.totalPieces)
      }
      if (newInvoice.partyId > 0 && newInvoice.remainingAmount > 0) {
        dao.updateCustomerBalance(newInvoice.partyId, newInvoice.remainingAmount)
      }
    } else {
      for (item in attachedItems) {
        dao.adjustProductStock(item.productId, item.totalPieces)
      }
      if (newInvoice.partyId > 0 && newInvoice.remainingAmount > 0) {
        dao.updateSupplierBalance(newInvoice.partyId, newInvoice.remainingAmount)
      }
    }

    val updatedInv = newInvoice.copy(id = oldInvoice.id)
    dao.updateInvoice(updatedInv)

    // --- Step 3: Insert Updated Journal Entry ---
    val totalDebit = updatedInv.totalAmount + updatedInv.totalCost
    val totalCredit = updatedInv.totalAmount + updatedInv.totalCost
    val refType = if (updatedInv.type == InvoiceType.SALE) "SALE" else "PURCHASE"
    val journalEntryId = dao.insertJournalEntry(
      JournalEntry(
        entryNumber = "JE-EDIT-$refType-${updatedInv.id}",
        timestamp = updatedInv.timestamp,
        description = "تعديل فاتورة ${updatedInv.invoiceNumber} - ${updatedInv.partyName}",
        referenceType = refType,
        referenceId = updatedInv.id,
        totalDebit = totalDebit,
        totalCredit = totalCredit,
        isBalanced = true
      )
    )

    val journalLines = mutableListOf<JournalLine>()
    if (updatedInv.type == InvoiceType.SALE) {
      if (updatedInv.paidAmount > 0) {
        journalLines.add(
          JournalLine(entryId = journalEntryId, accountCode = "101", accountName = "الصندوق والخزينة النقدية", debit = updatedInv.paidAmount, credit = 0.0, notes = "مقبوض كاش معدل")
        )
      }
      if (updatedInv.remainingAmount > 0) {
        journalLines.add(
          JournalLine(entryId = journalEntryId, accountCode = "102", accountName = "العملاء والمدينون (حسابات السوق)", debit = updatedInv.remainingAmount, credit = 0.0, notes = "متبقي آجل معدل")
        )
      }
      journalLines.add(
        JournalLine(entryId = journalEntryId, accountCode = "401", accountName = "إيرادات مبيعات البضاعة", debit = 0.0, credit = updatedInv.totalAmount, notes = "إيراد مبيعات معدل")
      )
      if (updatedInv.totalCost > 0) {
        journalLines.add(
          JournalLine(entryId = journalEntryId, accountCode = "501", accountName = "تكلفة البضاعة المباعة (COGS)", debit = updatedInv.totalCost, credit = 0.0, notes = "تكلفة مباعة معدلة")
        )
        journalLines.add(
          JournalLine(entryId = journalEntryId, accountCode = "103", accountName = "مخزون البضاعة (نظام الجرد المستمر)", debit = 0.0, credit = updatedInv.totalCost, notes = "تخفيض بضاعة معدل")
        )
      }
    } else {
      journalLines.add(
        JournalLine(entryId = journalEntryId, accountCode = "103", accountName = "مخزون البضاعة (نظام الجرد المستمر)", debit = updatedInv.totalAmount, credit = 0.0, notes = "بضاعة مشتراة معدلة")
      )
      if (updatedInv.paidAmount > 0) {
        journalLines.add(
          JournalLine(entryId = journalEntryId, accountCode = "101", accountName = "الصندوق والخزينة النقدية", debit = 0.0, credit = updatedInv.paidAmount, notes = "مدفوع كاش معدل")
        )
      }
      if (updatedInv.remainingAmount > 0) {
        journalLines.add(
          JournalLine(entryId = journalEntryId, accountCode = "201", accountName = "الموردون والدائنون (التزامات التوريد)", debit = 0.0, credit = updatedInv.remainingAmount, notes = "مستحق آجل معدل")
        )
      }
    }
    dao.insertJournalLines(journalLines)
  }

  // Record Customer Payment Receipt (سند قبض من عميل لسداد دينه)
  suspend fun recordCustomerPayment(
    customerId: Long,
    customerName: String,
    amount: Double,
    notes: String
  ): Long {
    val tx = PaymentTransaction(
      type = TransactionType.CUSTOMER_PAYMENT,
      partyId = customerId,
      partyName = customerName,
      amount = amount,
      notes = notes,
      timestamp = System.currentTimeMillis()
    )
    val txId = dao.insertTransaction(tx)
    // Reduce customer debt
    dao.updateCustomerBalance(customerId, -amount)

    // Double-Entry: Debit Cash 101, Credit Customers 102
    val entryId = dao.insertJournalEntry(
      JournalEntry(
        entryNumber = "JE-RCPT-$txId",
        timestamp = tx.timestamp,
        description = "سند قبض نقدية من العميل $customerName",
        referenceType = "CUSTOMER_PAYMENT",
        referenceId = txId,
        totalDebit = amount,
        totalCredit = amount,
        isBalanced = true
      )
    )
    dao.insertJournalLines(
      listOf(
        JournalLine(entryId = entryId, accountCode = "101", accountName = "الصندوق والخزينة النقدية", debit = amount, credit = 0.0, notes = "تحصيل نقدية بالدرج من $customerName"),
        JournalLine(entryId = entryId, accountCode = "102", accountName = "العملاء والمدينون (حسابات السوق)", debit = 0.0, credit = amount, notes = "تخفيض مديونية العميل $customerName")
      )
    )

    return txId
  }

  // Record Supplier Payment Voucher (سند صرف للمورد لسداد مستحقاته)
  suspend fun recordSupplierPayment(
    supplierId: Long,
    supplierName: String,
    amount: Double,
    notes: String
  ): Long {
    val tx = PaymentTransaction(
      type = TransactionType.SUPPLIER_PAYMENT,
      partyId = supplierId,
      partyName = supplierName,
      amount = amount,
      notes = notes,
      timestamp = System.currentTimeMillis()
    )
    val txId = dao.insertTransaction(tx)
    // Reduce supplier balance
    dao.updateSupplierBalance(supplierId, -amount)

    // Double-Entry: Debit Suppliers 201, Credit Cash 101
    val entryId = dao.insertJournalEntry(
      JournalEntry(
        entryNumber = "JE-PAY-$txId",
        timestamp = tx.timestamp,
        description = "سند صرف وسداد مستحقات للمورد $supplierName",
        referenceType = "SUPPLIER_PAYMENT",
        referenceId = txId,
        totalDebit = amount,
        totalCredit = amount,
        isBalanced = true
      )
    )
    dao.insertJournalLines(
      listOf(
        JournalLine(entryId = entryId, accountCode = "201", accountName = "الموردون والدائنون (شركات التوزيع)", debit = amount, credit = 0.0, notes = "سداد دفعة من رصيد المورد $supplierName"),
        JournalLine(entryId = entryId, accountCode = "101", accountName = "الصندوق والخزينة النقدية", debit = 0.0, credit = amount, notes = "صرف نقدية من الخزينة")
      )
    )

    return txId
  }

  // Record Cash Deposit into Treasury (إيداع نقدية في الخزينة / تغذية الصندوق / رأس مال)
  suspend fun recordCashDeposit(
    amount: Double,
    source: String,
    notes: String,
    timestamp: Long = System.currentTimeMillis()
  ): Long {
    val tx = PaymentTransaction(
      type = TransactionType.CASH_DEPOSIT,
      partyId = 0L,
      partyName = source.ifBlank { "إيداع وتغذية الخزينة" },
      amount = amount,
      notes = notes,
      timestamp = timestamp
    )
    val txId = dao.insertTransaction(tx)

    // Double-Entry: Debit Cash 101, Credit Equity / Capital 301
    val entryId = dao.insertJournalEntry(
      JournalEntry(
        entryNumber = "JE-DEP-$txId",
        timestamp = tx.timestamp,
        description = "إيداع وتغذية نقدية بالخزينة: $source",
        referenceType = "CASH_DEPOSIT",
        referenceId = txId,
        totalDebit = amount,
        totalCredit = amount,
        isBalanced = true
      )
    )
    dao.insertJournalLines(
      listOf(
        JournalLine(entryId = entryId, accountCode = "101", accountName = "الصندوق والخزينة النقدية", debit = amount, credit = 0.0, notes = "إيداع نقدية بالخزينة: $notes"),
        JournalLine(entryId = entryId, accountCode = "301", accountName = "رأس المال وجاري الشركاء والتمويل", debit = 0.0, credit = amount, notes = "تمويل وتغذية الخزينة بالسيولة")
      )
    )

    return txId
  }

  // Record Cash Withdrawal from Treasury (سحب نقدية من الخزينة)
  suspend fun recordCashWithdrawal(
    amount: Double,
    destination: String,
    notes: String,
    timestamp: Long = System.currentTimeMillis()
  ): Long {
    val tx = PaymentTransaction(
      type = TransactionType.CASH_WITHDRAWAL,
      partyId = 0L,
      partyName = destination.ifBlank { "سحب نقدية من الخزينة" },
      amount = amount,
      notes = notes,
      timestamp = timestamp
    )
    val txId = dao.insertTransaction(tx)

    // Double-Entry: Debit Drawings/Bank 302, Credit Cash 101
    val entryId = dao.insertJournalEntry(
      JournalEntry(
        entryNumber = "JE-WDR-$txId",
        timestamp = tx.timestamp,
        description = "سحب نقدية من الخزينة: $destination",
        referenceType = "CASH_WITHDRAWAL",
        referenceId = txId,
        totalDebit = amount,
        totalCredit = amount,
        isBalanced = true
      )
    )
    dao.insertJournalLines(
      listOf(
        JournalLine(entryId = entryId, accountCode = "302", accountName = "المسحوبات الشخصية والتحويلات", debit = amount, credit = 0.0, notes = "سحب نقدي: $notes"),
        JournalLine(entryId = entryId, accountCode = "101", accountName = "الصندوق والخزينة النقدية", debit = 0.0, credit = amount, notes = "صرف نقدية مسحوبة من الخزينة")
      )
    )

    return txId
  }

  // Insert Operating Expense with Double-Entry Journaling
  suspend fun insertExpense(expense: Expense): Long {
    val expenseId = dao.insertExpense(expense)

    // Double-Entry: Debit Operating Expenses 502, Credit Cash 101
    val entryId = dao.insertJournalEntry(
      JournalEntry(
        entryNumber = "JE-EXP-$expenseId",
        timestamp = expense.timestamp,
        description = "مصروف تشغيلي: ${expense.category} - ${expense.recipient}",
        referenceType = "EXPENSE",
        referenceId = expenseId,
        totalDebit = expense.amount,
        totalCredit = expense.amount,
        isBalanced = true
      )
    )
    dao.insertJournalLines(
      listOf(
        JournalLine(entryId = entryId, accountCode = "502", accountName = "المصروفات العمومية والتشغيلية", debit = expense.amount, credit = 0.0, notes = "${expense.category}: ${expense.notes}"),
        JournalLine(entryId = entryId, accountCode = "101", accountName = "الصندوق والخزينة النقدية", debit = 0.0, credit = expense.amount, notes = "صرف مصروفات من الخزينة")
      )
    )

    return expenseId
  }

  suspend fun deleteExpense(expense: Expense) = dao.deleteExpense(expense)

  // Execute Stock Audit & Settlement (حفظ الجرد وتسوية رصيد المخزن)
  suspend fun recordStockAudit(
    title: String,
    notes: String,
    items: List<StockAuditItem>,
    applyToInventory: Boolean = true
  ): Long {
    val totalDiffValue = items.sumOf { it.diffCostValue }
    val audit = StockAudit(
      title = title,
      totalDiscrepancyValue = totalDiffValue,
      notes = notes,
      auditDate = System.currentTimeMillis()
    )
    val auditId = dao.insertStockAudit(audit)
    val attachedItems = items.map { it.copy(auditId = auditId) }
    dao.insertStockAuditItems(attachedItems)

    if (applyToInventory) {
      // Overwrite actual inventory count
      for (item in attachedItems) {
        dao.setProductStock(item.productId, item.actualQuantity)
      }

      // Record double-entry for stock discrepancy if value != 0
      if (abs(totalDiffValue) > 0.001) {
        val entryId = dao.insertJournalEntry(
          JournalEntry(
            entryNumber = "JE-AUDIT-$auditId",
            timestamp = audit.auditDate,
            description = "تسوية تسوية جرد مخزني: $title",
            referenceType = "AUDIT",
            referenceId = auditId,
            totalDebit = abs(totalDiffValue),
            totalCredit = abs(totalDiffValue),
            isBalanced = true
          )
        )
        if (totalDiffValue < 0) {
          // Deficit: Debit 503 (Discrepancy Expense), Credit 103 (Inventory reduction)
          dao.insertJournalLines(
            listOf(
              JournalLine(entryId = entryId, accountCode = "503", accountName = "فروقات وتسويات عجز المخزون", debit = abs(totalDiffValue), credit = 0.0, notes = "تسوية عجز جرد فعلي بالمخزن"),
              JournalLine(entryId = entryId, accountCode = "103", accountName = "مخزون البضاعة (نظام الجرد المستمر)", debit = 0.0, credit = abs(totalDiffValue), notes = "تخفيض رصيد المخزون للعجز")
            )
          )
        } else {
          // Surplus: Debit 103 (Inventory addition), Credit 503 (Gain from discrepancy)
          dao.insertJournalLines(
            listOf(
              JournalLine(entryId = entryId, accountCode = "103", accountName = "مخزون البضاعة (نظام الجرد المستمر)", debit = totalDiffValue, credit = 0.0, notes = "زيادة رصيد المخزون للزيادة الفعلية"),
              JournalLine(entryId = entryId, accountCode = "503", accountName = "فروقات وتسويات عجز المخزون", debit = 0.0, credit = totalDiffValue, notes = "أرباح تسوية زيادة جرد المخزن")
            )
          )
        }
      }
    }
    return auditId
  }

  // Employees & Delegate Management
  val allEmployees: Flow<List<Employee>> = dao.getAllEmployees()
  val activeDelegates: Flow<List<Employee>> = dao.getActiveDelegates()
  val allSyncLogs: Flow<List<DelegateSyncLog>> = dao.getAllSyncLogs()
  val pendingSyncInvoices: Flow<List<Invoice>> = dao.getPendingSyncInvoices()

  suspend fun insertEmployee(employee: Employee) = dao.insertEmployee(employee)
  suspend fun updateEmployee(employee: Employee) = dao.updateEmployee(employee)
  suspend fun deleteEmployee(employee: Employee) = dao.deleteEmployee(employee)
  suspend fun getEmployeeById(id: Long) = dao.getEmployeeById(id)
  suspend fun insertSyncLog(log: DelegateSyncLog) = dao.insertSyncLog(log)
  suspend fun getPendingSyncInvoicesSync() = dao.getPendingSyncInvoicesSync()
  suspend fun markInvoicesAsSynced(ids: List<Long>) = dao.markInvoicesAsSynced(ids)

  suspend fun clearAllDataToFreshState() {
    dao.clearAllDataToFreshState()
  }
}

