package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Customer
import com.example.data.model.Invoice
import com.example.data.model.PaymentTransaction
import com.example.data.model.Supplier
import com.example.data.model.TransactionType
import com.example.ui.WholesaleViewModel
import com.example.ui.components.QuickSanadVoucherDialog
import com.example.ui.components.VoucherReceiptDialog
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import com.example.utils.StatementExportHelper
import com.example.utils.TafqeetHelper
import com.example.utils.VoucherExportHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AccountsScreen(
  viewModel: WholesaleViewModel,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val tabs = listOf("حسابات العملاء", "حسابات الموردين", "سجل السندات (سند)")

  Column(modifier = modifier.fillMaxSize()) {
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = MaterialTheme.colorScheme.surface
    ) {
      tabs.forEachIndexed { index, title ->
        Tab(
          selected = selectedTab == index,
          onClick = { selectedTab = index },
          text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        )
      }
    }

    when (selectedTab) {
      0 -> CustomersTab(viewModel = viewModel)
      1 -> SuppliersTab(viewModel = viewModel)
      2 -> SanadVouchersTab(viewModel = viewModel)
    }
  }
}

@Composable
fun CustomersTab(viewModel: WholesaleViewModel) {
  val context = LocalContext.current
  val profile by viewModel.businessProfile.collectAsStateWithLifecycle()
  val customers by viewModel.customers.collectAsStateWithLifecycle()
  val salesInvoices by viewModel.salesInvoices.collectAsStateWithLifecycle()
  val transactions by viewModel.transactions.collectAsStateWithLifecycle()

  var searchQuery by remember { mutableStateOf("") }
  var showAddEditDialog by remember { mutableStateOf<Customer?>(null) }
  var showPaymentDialog by remember { mutableStateOf<Customer?>(null) }
  var showStatementForCustomer by remember { mutableStateOf<Customer?>(null) }
  var showPrintStatementForCustomer by remember { mutableStateOf<Customer?>(null) }
  var showPrintAllDebtsDialog by remember { mutableStateOf(false) }

  val filtered = remember(customers, searchQuery) {
    customers.filter { it.name.contains(searchQuery, ignoreCase = true) || it.phone.contains(searchQuery) }
  }

  val totalDebts = remember(customers) {
    customers.sumOf { it.currentBalance.coerceAtLeast(0.0) }
  }

  Box(modifier = Modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // Total Debts Header Card with direct print and share buttons
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("إجمالي ديون العملاء بالسوق:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f ج.م", totalDebts),
                  fontSize = 20.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary
                )
              }
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.primary
              ) {
                Text(
                  text = "${customers.size} عميل",
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                  color = MaterialTheme.colorScheme.onPrimary,
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Button(
                onClick = { showPrintAllDebtsDialog = true },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("طباعة كشف مديونيات العملاء", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
              }

              OutlinedButton(
                onClick = {
                  StatementExportHelper.shareDebtSummaryWhatsApp(
                    context = context,
                    isCustomer = true,
                    customers = customers,
                    businessName = profile.businessName
                  )
                },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(15.dp), tint = EmeraldPrimary)
                Spacer(modifier = Modifier.width(4.dp))
                Text("واتساب", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
              }
            }
          }
        }
      }

      // Search Bar
      item {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text("بحث عن عميل بالاسم أو الهاتف...") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )
      }

      // Customers List
      items(filtered, key = { it.id }) { customer ->
        CustomerCard(
          customer = customer,
          onRecordPayment = { showPaymentDialog = customer },
          onViewStatement = { showStatementForCustomer = customer },
          onPrintStatement = { showPrintStatementForCustomer = customer },
          onEdit = { showAddEditDialog = customer },
          onDelete = { viewModel.deleteCustomer(customer) }
        )
      }

      if (filtered.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(40.dp),
            contentAlignment = Alignment.Center
          ) {
            Text("لا يوجد عملاء مطابقين للبحث", color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }

    // Add FAB
    FloatingActionButton(
      onClick = { showAddEditDialog = Customer(name = "") },
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(16.dp),
      containerColor = MaterialTheme.colorScheme.primary,
      contentColor = Color.White
    ) {
      Icon(Icons.Default.Add, contentDescription = "إضافة عميل")
    }

    // Customer Add/Edit Dialog
    showAddEditDialog?.let { cust ->
      CustomerEditDialog(
        initial = cust,
        onDismiss = { showAddEditDialog = null },
        onSave = { saved ->
          viewModel.saveCustomer(saved)
          showAddEditDialog = null
        }
      )
    }

    var previewVoucher by remember { mutableStateOf<PaymentTransaction?>(null) }

    // Payment Receipt Dialog (سند قبض دفعة)
    showPaymentDialog?.let { cust ->
      PaymentVoucherDialog(
        partyName = cust.name,
        currentBalance = cust.currentBalance,
        isCustomer = true,
        onDismiss = { showPaymentDialog = null },
        onConfirm = { amount, notes ->
          viewModel.recordCustomerPayment(cust, amount, notes) { createdTx ->
            previewVoucher = createdTx
          }
          showPaymentDialog = null
        }
      )
    }

    // Official Sanad Receipt Voucher Dialog
    previewVoucher?.let { tx ->
      VoucherReceiptDialog(
        transaction = tx,
        businessName = profile.businessName,
        onDismiss = { previewVoucher = null }
      )
    }

    // Statement Dialog (كشف حساب عميل مع واتساب وطباعة)
    showStatementForCustomer?.let { cust ->
      PartyStatementDialog(
        partyId = cust.id,
        partyName = cust.name,
        partyPhone = cust.phone,
        currentBalance = cust.currentBalance,
        isCustomer = true,
        viewModel = viewModel,
        onDismiss = { showStatementForCustomer = null }
      )
    }

    // Direct Print Statement Dialog for specific customer
    showPrintStatementForCustomer?.let { cust ->
      val partyInvoices = remember(salesInvoices, cust.id) { salesInvoices.filter { it.partyId == cust.id } }
      val partyPayments = remember(transactions, cust.id) { transactions.filter { it.partyId == cust.id && it.type == TransactionType.CUSTOMER_PAYMENT } }
      PrintStatementSelectionDialog(
        partyName = cust.name,
        partyPhone = cust.phone,
        isCustomer = true,
        currentBalance = cust.currentBalance,
        invoices = partyInvoices,
        payments = partyPayments,
        viewModel = viewModel,
        onDismiss = { showPrintStatementForCustomer = null }
      )
    }

    // Direct Print All Debts Report Dialog
    if (showPrintAllDebtsDialog) {
      PrintDebtSummaryDialog(
        isCustomer = true,
        customers = customers,
        suppliers = emptyList(),
        viewModel = viewModel,
        onDismiss = { showPrintAllDebtsDialog = false }
      )
    }
  }
}

@Composable
fun CustomerCard(
  customer: Customer,
  onRecordPayment: () -> Unit,
  onViewStatement: () -> Unit,
  onPrintStatement: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit
) {
  val hasDebt = customer.currentBalance > 0

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(customer.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
          if (customer.phone.isNotEmpty()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(13.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
              Spacer(modifier = Modifier.width(4.dp))
              Text(customer.phone, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
          if (customer.address.isNotEmpty()) {
            Text(customer.address, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }

        Row {
          IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
          }
          IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("الرصيد / المديونية الحالية:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.2f ج.م", customer.currentBalance),
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = if (hasDebt) MaterialTheme.colorScheme.error else EmeraldPrimary
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
          // Direct Print Statement button on Customer Card
          OutlinedButton(
            onClick = onPrintStatement,
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.Print, contentDescription = "طباعة", modifier = Modifier.size(14.dp), tint = OrangePrimary)
            Spacer(modifier = Modifier.width(4.dp))
            Text("طباعة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          OutlinedButton(
            onClick = onViewStatement,
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("كشف حساب", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = onRecordPayment,
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("سند قبض", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun SuppliersTab(viewModel: WholesaleViewModel) {
  val context = LocalContext.current
  val profile by viewModel.businessProfile.collectAsStateWithLifecycle()
  val suppliers by viewModel.suppliers.collectAsStateWithLifecycle()
  val purchaseInvoices by viewModel.purchaseInvoices.collectAsStateWithLifecycle()
  val transactions by viewModel.transactions.collectAsStateWithLifecycle()

  var searchQuery by remember { mutableStateOf("") }
  var showAddEditDialog by remember { mutableStateOf<Supplier?>(null) }
  var showPaymentDialog by remember { mutableStateOf<Supplier?>(null) }
  var showStatementForSupplier by remember { mutableStateOf<Supplier?>(null) }
  var showPrintStatementForSupplier by remember { mutableStateOf<Supplier?>(null) }
  var showPrintAllPayablesDialog by remember { mutableStateOf(false) }

  val filtered = remember(suppliers, searchQuery) {
    suppliers.filter { it.name.contains(searchQuery, ignoreCase = true) || it.company.contains(searchQuery, ignoreCase = true) }
  }

  val totalPayables = remember(suppliers) {
    suppliers.sumOf { it.currentBalance.coerceAtLeast(0.0) }
  }

  Box(modifier = Modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // Total Payables Header Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("إجمالي مستحقات الموردين (التزامات):", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f ج.م", totalPayables),
                  fontSize = 20.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.error
                )
              }
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.primary
              ) {
                Text(
                  text = "${suppliers.size} مورد",
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Button(
                onClick = { showPrintAllPayablesDialog = true },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("طباعة كشف مستحقات الموردين", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
              }

              OutlinedButton(
                onClick = {
                  StatementExportHelper.shareDebtSummaryWhatsApp(
                    context = context,
                    isCustomer = false,
                    suppliers = suppliers,
                    businessName = profile.businessName
                  )
                },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(15.dp), tint = EmeraldPrimary)
                Spacer(modifier = Modifier.width(4.dp))
                Text("واتساب", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
              }
            }
          }
        }
      }

      // Search Bar
      item {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text("بحث عن مورد أو شركة...") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )
      }

      // Suppliers List
      items(filtered, key = { it.id }) { supplier ->
        SupplierCard(
          supplier = supplier,
          onRecordPayment = { showPaymentDialog = supplier },
          onViewStatement = { showStatementForSupplier = supplier },
          onPrintStatement = { showPrintStatementForSupplier = supplier },
          onEdit = { showAddEditDialog = supplier },
          onDelete = { viewModel.deleteSupplier(supplier) }
        )
      }

      if (filtered.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(40.dp),
            contentAlignment = Alignment.Center
          ) {
            Text("لا يوجد موردين مطابقين للبحث", color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }

    // Add FAB
    FloatingActionButton(
      onClick = { showAddEditDialog = Supplier(name = "") },
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(16.dp),
      containerColor = MaterialTheme.colorScheme.primary,
      contentColor = Color.White
    ) {
      Icon(Icons.Default.Add, contentDescription = "إضافة مورد")
    }

    // Supplier Add/Edit Dialog
    showAddEditDialog?.let { sup ->
      SupplierEditDialog(
        initial = sup,
        onDismiss = { showAddEditDialog = null },
        onSave = { saved ->
          viewModel.saveSupplier(saved)
          showAddEditDialog = null
        }
      )
    }

    var previewVoucher by remember { mutableStateOf<PaymentTransaction?>(null) }

    // Payment Voucher Dialog (سند صرف دفعة)
    showPaymentDialog?.let { sup ->
      PaymentVoucherDialog(
        partyName = sup.name,
        currentBalance = sup.currentBalance,
        isCustomer = false,
        onDismiss = { showPaymentDialog = null },
        onConfirm = { amount, notes ->
          viewModel.recordSupplierPayment(sup, amount, notes) { createdTx ->
            previewVoucher = createdTx
          }
          showPaymentDialog = null
        }
      )
    }

    // Official Sanad Payment Voucher Dialog
    previewVoucher?.let { tx ->
      VoucherReceiptDialog(
        transaction = tx,
        businessName = profile.businessName,
        onDismiss = { previewVoucher = null }
      )
    }

    // Statement Dialog (كشف حساب مورد)
    showStatementForSupplier?.let { sup ->
      PartyStatementDialog(
        partyId = sup.id,
        partyName = sup.name,
        partyPhone = sup.phone,
        currentBalance = sup.currentBalance,
        isCustomer = false,
        viewModel = viewModel,
        onDismiss = { showStatementForSupplier = null }
      )
    }

    // Direct Print Statement Dialog for specific supplier
    showPrintStatementForSupplier?.let { sup ->
      val partyInvoices = remember(purchaseInvoices, sup.id) { purchaseInvoices.filter { it.partyId == sup.id } }
      val partyPayments = remember(transactions, sup.id) { transactions.filter { it.partyId == sup.id && it.type == TransactionType.SUPPLIER_PAYMENT } }
      PrintStatementSelectionDialog(
        partyName = sup.name,
        partyPhone = sup.phone,
        isCustomer = false,
        currentBalance = sup.currentBalance,
        invoices = partyInvoices,
        payments = partyPayments,
        viewModel = viewModel,
        onDismiss = { showPrintStatementForSupplier = null }
      )
    }

    // Direct Print All Payables Report Dialog
    if (showPrintAllPayablesDialog) {
      PrintDebtSummaryDialog(
        isCustomer = false,
        customers = emptyList(),
        suppliers = suppliers,
        viewModel = viewModel,
        onDismiss = { showPrintAllPayablesDialog = false }
      )
    }
  }
}

@Composable
fun SupplierCard(
  supplier: Supplier,
  onRecordPayment: () -> Unit,
  onViewStatement: () -> Unit,
  onPrintStatement: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(supplier.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
          if (supplier.company.isNotEmpty()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Storefront, contentDescription = null, modifier = Modifier.size(13.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
              Spacer(modifier = Modifier.width(4.dp))
              Text(supplier.company, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
          if (supplier.phone.isNotEmpty()) {
            Text(supplier.phone, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }

        Row {
          IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
          }
          IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("المستحق للمورد (له):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.2f ج.م", supplier.currentBalance),
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = if (supplier.currentBalance > 0) MaterialTheme.colorScheme.error else EmeraldPrimary
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
          // Direct Print Statement button on Supplier Card
          OutlinedButton(
            onClick = onPrintStatement,
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.Print, contentDescription = "طباعة", modifier = Modifier.size(14.dp), tint = OrangePrimary)
            Spacer(modifier = Modifier.width(4.dp))
            Text("طباعة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          OutlinedButton(
            onClick = onViewStatement,
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("كشف حساب", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = onRecordPayment,
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("سند صرف", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun CustomerEditDialog(
  initial: Customer,
  onDismiss: () -> Unit,
  onSave: (Customer) -> Unit
) {
  var name by remember { mutableStateOf(initial.name) }
  var phone by remember { mutableStateOf(initial.phone) }
  var address by remember { mutableStateOf(initial.address) }
  var creditLimit by remember { mutableStateOf(if (initial.creditLimit > 0) initial.creditLimit.toString() else "") }
  var notes by remember { mutableStateOf(initial.notes) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (initial.id == 0L) "إضافة عميل جديد" else "تعديل بيانات العميل",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("اسم العميل / المحل *") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it },
          label = { Text("رقم الهاتف") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = address,
          onValueChange = { address = it },
          label = { Text("العنوان أو المنطقة") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = creditLimit,
          onValueChange = { creditLimit = it },
          label = { Text("الحد الائتماني المسموح به (ج.م)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("ملاحظات") },
          maxLines = 2,
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              if (name.isBlank()) return@Button
              onSave(
                initial.copy(
                  name = name.trim(),
                  phone = phone.trim(),
                  address = address.trim(),
                  creditLimit = creditLimit.toDoubleOrNull() ?: 0.0,
                  notes = notes.trim()
                )
              )
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

@Composable
fun SupplierEditDialog(
  initial: Supplier,
  onDismiss: () -> Unit,
  onSave: (Supplier) -> Unit
) {
  var name by remember { mutableStateOf(initial.name) }
  var company by remember { mutableStateOf(initial.company) }
  var phone by remember { mutableStateOf(initial.phone) }
  var notes by remember { mutableStateOf(initial.notes) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (initial.id == 0L) "إضافة مورد جديد" else "تعديل بيانات المورد",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("اسم المورد أو المندوب *") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = company,
          onValueChange = { company = it },
          label = { Text("اسم الشركة / المصنع / التوكيل") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it },
          label = { Text("رقم الهاتف") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("ملاحظات") },
          maxLines = 2,
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              if (name.isBlank()) return@Button
              onSave(
                initial.copy(
                  name = name.trim(),
                  company = company.trim(),
                  phone = phone.trim(),
                  notes = notes.trim()
                )
              )
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

@Composable
fun PaymentVoucherDialog(
  partyName: String,
  currentBalance: Double,
  isCustomer: Boolean,
  onDismiss: () -> Unit,
  onConfirm: (amount: Double, notes: String) -> Unit
) {
  var amountText by remember { mutableStateOf("") }
  var notes by remember { mutableStateOf("") }
  var isSubmitting by remember { mutableStateOf(false) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text(
          text = if (isCustomer) "سند قبض دفعة من عميل" else "سند صرف دفعة لمورد",
          fontWeight = FontWeight.Bold,
          fontSize = 16.sp
        )
        Text(
          text = "الطرف: $partyName",
          fontWeight = FontWeight.SemiBold,
          fontSize = 14.sp,
          color = MaterialTheme.colorScheme.primary
        )

        OutlinedTextField(
          value = amountText,
          onValueChange = { amountText = it },
          label = { Text("المبلغ المدفوع (ج.م) *") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        val parsedAmt = amountText.toDoubleOrNull() ?: 0.0
        val balanceAfter = (currentBalance - parsedAmt).coerceAtLeast(0.0)

        // Live Balance Before & After Card
        Surface(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("الرصيد السابق قبل السند:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(String.format(Locale.ENGLISH, "%.2f ج.م", currentBalance), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("المبلغ المسدد بهذا السند:", fontSize = 11.sp, color = if (isCustomer) EmeraldPrimary else OrangePrimary)
              Text(String.format(Locale.ENGLISH, "%.2f ج.م", parsedAmt), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isCustomer) EmeraldPrimary else OrangePrimary)
            }
            HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text(if (isCustomer) "الرصيد المتبقي على العميل:" else "الرصيد المتبقي للمورد:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              Text(String.format(Locale.ENGLISH, "%.2f ج.م", balanceAfter), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = if (balanceAfter > 0) MaterialTheme.colorScheme.error else EmeraldPrimary)
            }
          }
        }

        if (parsedAmt > 0.0) {
          Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(6.dp),
            color = if (isCustomer) EmeraldPrimary.copy(alpha = 0.08f) else OrangePrimary.copy(alpha = 0.08f),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (isCustomer) EmeraldPrimary.copy(alpha = 0.3f) else OrangePrimary.copy(alpha = 0.3f))
          ) {
            Text(
              text = TafqeetHelper.convertToArabicWords(parsedAmt),
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              color = if (isCustomer) EmeraldPrimary else OrangePrimary,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
            )
          }
        }

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("البيان / ملاحظات السداد") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              if (isSubmitting) return@Button
              val amt = amountText.toDoubleOrNull() ?: 0.0
              if (amt > 0) {
                isSubmitting = true
                onConfirm(amt, notes.trim())
              }
            },
            enabled = !isSubmitting && parsedAmt > 0,
            colors = ButtonDefaults.buttonColors(
              containerColor = if (isCustomer) EmeraldPrimary else MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.weight(1f)
          ) {
            Text(if (isSubmitting) "جاري التسجيل..." else "تسجيل السند والخصم", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

@Composable
fun PartyStatementDialog(
  partyId: Long,
  partyName: String,
  partyPhone: String,
  currentBalance: Double,
  isCustomer: Boolean,
  viewModel: WholesaleViewModel,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val salesInvoices by viewModel.salesInvoices.collectAsStateWithLifecycle()
  val purchaseInvoices by viewModel.purchaseInvoices.collectAsStateWithLifecycle()
  val transactions by viewModel.transactions.collectAsStateWithLifecycle()

  val partyInvoices = remember(salesInvoices, purchaseInvoices, partyId) {
    if (isCustomer) {
      salesInvoices.filter { it.partyId == partyId }
    } else {
      purchaseInvoices.filter { it.partyId == partyId }
    }
  }

  val partyPayments = remember(transactions, partyId) {
    transactions.filter {
      it.partyId == partyId && if (isCustomer) {
        it.type == com.example.data.model.TransactionType.CUSTOMER_PAYMENT
      } else {
        it.type == com.example.data.model.TransactionType.SUPPLIER_PAYMENT
      }
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .clip(RoundedCornerShape(18.dp)),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        // Dialog Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.ReceiptLong,
              contentDescription = null,
              tint = if (isCustomer) EmeraldPrimary else MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = if (isCustomer) "كشف حساب عميل" else "كشف حساب مورد",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
              )
              Text(
                text = "$partyName ${if (partyPhone.isNotBlank()) "• $partyPhone" else ""}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Balance Banner
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (currentBalance > 0) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f) else EmeraldPrimary.copy(alpha = 0.15f)
          )
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = if (isCustomer) "إجمالي المديونية المستحقة على العميل:" else "إجمالي المستحق الواجب سداده للمورد:",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = String.format(Locale.ENGLISH, "%.2f ج.م", currentBalance),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = if (currentBalance > 0) MaterialTheme.colorScheme.error else EmeraldPrimary
              )
            }

            Surface(
              shape = RoundedCornerShape(6.dp),
              color = if (currentBalance > 0) MaterialTheme.colorScheme.error else EmeraldPrimary
            ) {
              Text(
                text = if (currentBalance > 0) "غير مسدد بالكامل" else "الحساب خالص",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(10.dp))

        // Invoices and Payments List
        LazyColumn(
          modifier = Modifier
            .weight(1f, fill = false)
            .fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          item {
            Text("الفواتير وحركات التوريد السابقة (${partyInvoices.size}):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          if (partyInvoices.isEmpty()) {
            item {
              Text("لا توجد فواتير مسجلة لهذا الحساب.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          } else {
            items(partyInvoices) { inv ->
              val invDate = SimpleDateFormat("dd/MM/yyyy - hh:mm a", Locale("ar")).format(Date(inv.timestamp))
              Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(8.dp)
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Text(inv.invoiceNumber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(invDate, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                  Column(horizontalAlignment = Alignment.End) {
                    Text(
                      text = String.format(Locale.ENGLISH, "%.2f ج.م", inv.totalAmount),
                      fontWeight = FontWeight.Bold,
                      fontSize = 12.sp
                    )
                    Text(
                      text = "مسدد: ${inv.paidAmount} | آجل: ${inv.remainingAmount}",
                      fontSize = 10.sp,
                      color = if (inv.remainingAmount > 0) MaterialTheme.colorScheme.error else EmeraldPrimary
                    )
                  }
                }
              }
            }
          }

          item {
            Spacer(modifier = Modifier.height(6.dp))
            Text("سندات السداد والتحصيل النقدي (${partyPayments.size}):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          if (partyPayments.isEmpty()) {
            item {
              Text("لا توجد سندات دفع مسجلة.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          } else {
            items(partyPayments) { payment ->
              val payDate = SimpleDateFormat("dd/MM/yyyy - hh:mm a", Locale("ar")).format(Date(payment.timestamp))
              Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = EmeraldPrimary.copy(alpha = 0.08f)),
                shape = RoundedCornerShape(8.dp)
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Text(if (isCustomer) "سند قبض نقدية" else "سند صرف وسداد", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                    Text(payDate, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (payment.notes.isNotBlank()) {
                      Text(payment.notes, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                  }
                  Text(
                    text = String.format(Locale.ENGLISH, "%.2f ج.م", payment.amount),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = EmeraldPrimary
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        var showPrintPicker by remember { mutableStateOf(false) }
        val profile by viewModel.businessProfile.collectAsStateWithLifecycle()

        // Action Buttons: Real Printing (All Printers), PDF Share & WhatsApp
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Button(
            onClick = { showPrintPicker = true },
            colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
            modifier = Modifier.weight(1.1f),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("طباعة الكشف", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          OutlinedButton(
            onClick = {
              StatementExportHelper.shareStatementPdf(
                context = context,
                partyName = partyName,
                partyPhone = partyPhone,
                isCustomer = isCustomer,
                currentBalance = currentBalance,
                invoices = partyInvoices,
                payments = partyPayments,
                businessName = profile.businessName,
                businessPhone = profile.contactPhone,
                businessAddress = profile.address,
                pageSizeType = "A4"
              )
            },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(15.dp), tint = Color(0xFF0284C7))
            Spacer(modifier = Modifier.width(4.dp))
            Text("مشاركة PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = {
              val statementText = viewModel.getPartyStatementText(partyId, isCustomer)
              val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "كشف حساب: $partyName")
                putExtra(Intent.EXTRA_TEXT, statementText)
              }
              context.startActivity(Intent.createChooser(shareIntent, "مشاركة كشف الحساب عبر واتساب"))
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            modifier = Modifier.weight(1.1f),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("واتساب", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          IconButton(
            onClick = {
              val statementText = viewModel.getPartyStatementText(partyId, isCustomer)
              val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
              clipboard.setPrimaryClip(ClipData.newPlainText("Statement", statementText))
              Toast.makeText(context, "تم نسخ كشف الحساب للحافظة", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.size(34.dp)
          ) {
            Icon(Icons.Default.ContentCopy, contentDescription = "نسخ كشف الحساب", modifier = Modifier.size(18.dp))
          }
        }

        if (showPrintPicker) {
          PrintStatementSelectionDialog(
            partyName = partyName,
            partyPhone = partyPhone,
            isCustomer = isCustomer,
            currentBalance = currentBalance,
            invoices = partyInvoices,
            payments = partyPayments,
            viewModel = viewModel,
            onDismiss = { showPrintPicker = false }
          )
        }
      }
    }
  }
}

@Composable
fun SanadVouchersTab(
  viewModel: WholesaleViewModel,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val transactions by viewModel.transactions.collectAsStateWithLifecycle()
  val customers by viewModel.customers.collectAsStateWithLifecycle()
  val suppliers by viewModel.suppliers.collectAsStateWithLifecycle()
  val businessProfile by viewModel.businessProfile.collectAsStateWithLifecycle()

  var selectedFilter by remember { mutableIntStateOf(0) } // 0: الكل, 1: سندات قبض, 2: سندات صرف
  var searchQuery by remember { mutableStateOf("") }

  var showQuickVoucherDialog by remember { mutableStateOf(false) }
  var previewVoucher by remember { mutableStateOf<PaymentTransaction?>(null) }

  val filteredTransactions = remember(transactions, selectedFilter, searchQuery) {
    transactions
      .filter { tx ->
        when (selectedFilter) {
          1 -> tx.type == TransactionType.CUSTOMER_PAYMENT
          2 -> tx.type == TransactionType.SUPPLIER_PAYMENT
          else -> true
        }
      }
      .filter { tx ->
        val voucherNo = VoucherExportHelper.getVoucherNumber(tx)
        searchQuery.isBlank() ||
          tx.partyName.contains(searchQuery, ignoreCase = true) ||
          voucherNo.contains(searchQuery, ignoreCase = true) ||
          tx.notes.contains(searchQuery, ignoreCase = true)
      }
      .sortedByDescending { it.timestamp }
  }

  val totalReceipts = remember(transactions) {
    transactions.filter { it.type == TransactionType.CUSTOMER_PAYMENT }.sumOf { it.amount }
  }
  val totalPayments = remember(transactions) {
    transactions.filter { it.type == TransactionType.SUPPLIER_PAYMENT }.sumOf { it.amount }
  }

  Box(modifier = modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 14.dp),
      contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // Header Banner
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "سجل السندات المالية (سند)",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onPrimaryContainer
              )
              Text(
                text = "إصدار وإدارة سندات القبض والصرف الرسمية",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
              )
            }
            Button(
              onClick = { showQuickVoucherDialog = true },
              colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
              shape = RoundedCornerShape(8.dp)
            ) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("سند جديد +", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
          }
        }
      }

      // Summary Cards
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = EmeraldPrimary.copy(alpha = 0.08f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.3f))
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("المقبوضات (قبض)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = String.format(Locale.ENGLISH, "%.1f %s", totalReceipts, businessProfile.currency),
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = EmeraldPrimary
              )
              Text(
                text = "${transactions.count { it.type == TransactionType.CUSTOMER_PAYMENT }} سند قبض معتمد",
                fontSize = 10.sp,
                color = Color.Gray
              )
            }
          }

          Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = OrangePrimary.copy(alpha = 0.08f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, OrangePrimary.copy(alpha = 0.3f))
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = OrangePrimary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("المدفوعات (صرف)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = OrangePrimary)
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = String.format(Locale.ENGLISH, "%.1f %s", totalPayments, businessProfile.currency),
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = OrangePrimary
              )
              Text(
                text = "${transactions.count { it.type == TransactionType.SUPPLIER_PAYMENT }} سند صرف معتمد",
                fontSize = 10.sp,
                color = Color.Gray
              )
            }
          }
        }
      }

      // Search Field
      item {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text("بحث برقم السند، أو اسم العميل/المورد...") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(onClick = { searchQuery = "" }) {
                Icon(Icons.Default.Close, contentDescription = "مسح")
              }
            }
          },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )
      }

      // Filter Chips
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf("الكل (${transactions.size})", "سندات القبض", "سندات الصرف").forEachIndexed { index, label ->
            FilterChip(
              selected = selectedFilter == index,
              onClick = { selectedFilter = index },
              label = { Text(label, fontSize = 11.sp, fontWeight = if (selectedFilter == index) FontWeight.Bold else FontWeight.Normal) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = if (index == 1) EmeraldPrimary else if (index == 2) OrangePrimary else MaterialTheme.colorScheme.primary,
                selectedLabelColor = Color.White
              )
            )
          }
        }
      }

      // Vouchers List
      if (filteredTransactions.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center
            ) {
              Icon(Icons.Default.Receipt, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
              Spacer(modifier = Modifier.height(8.dp))
              Text("لا توجد سندات مطابقة", fontWeight = FontWeight.Bold, color = Color.Gray)
              Spacer(modifier = Modifier.height(4.dp))
              Text("اضغط على زر (سند جديد) لإنشاء سند قبض أو صرف رسمي", fontSize = 11.sp, color = Color.Gray)
            }
          }
        }
      } else {
        items(filteredTransactions, key = { it.id }) { tx ->
          SanadVoucherItemCard(
            transaction = tx,
            currency = businessProfile.currency,
            onCardClick = { previewVoucher = tx },
            onPrintClick = { VoucherExportHelper.printVoucher(context, tx, businessProfile.businessName) },
            onShareClick = { VoucherExportHelper.shareVoucherViaWhatsApp(context, tx, businessName = businessProfile.businessName) }
          )
        }
      }
    }

    FloatingActionButton(
      onClick = { showQuickVoucherDialog = true },
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(16.dp),
      containerColor = EmeraldPrimary,
      contentColor = Color.White
    ) {
      Row(modifier = Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Add, contentDescription = null)
        Spacer(modifier = Modifier.width(6.dp))
        Text("سند جديد", fontWeight = FontWeight.Bold, fontSize = 13.sp)
      }
    }

    if (showQuickVoucherDialog) {
      QuickSanadVoucherDialog(
        customers = customers,
        suppliers = suppliers,
        onDismiss = { showQuickVoucherDialog = false },
        onIssueReceiptVoucher = { cust, amt, notes, onDone ->
          viewModel.recordCustomerPayment(cust, amt, notes) { createdTx ->
            showQuickVoucherDialog = false
            previewVoucher = createdTx
            onDone(createdTx)
          }
        },
        onIssuePaymentVoucher = { sup, amt, notes, onDone ->
          viewModel.recordSupplierPayment(sup, amt, notes) { createdTx ->
            showQuickVoucherDialog = false
            previewVoucher = createdTx
            onDone(createdTx)
          }
        }
      )
    }

    previewVoucher?.let { tx ->
      VoucherReceiptDialog(
        transaction = tx,
        businessName = businessProfile.businessName,
        businessPhone = businessProfile.contactPhone,
        currency = businessProfile.currency,
        onDismiss = { previewVoucher = null }
      )
    }
  }
}

@Composable
fun SanadVoucherItemCard(
  transaction: PaymentTransaction,
  currency: String,
  onCardClick: () -> Unit,
  onPrintClick: () -> Unit,
  onShareClick: () -> Unit
) {
  val isReceipt = transaction.type == TransactionType.CUSTOMER_PAYMENT
  val voucherNo = VoucherExportHelper.getVoucherNumber(transaction)
  val voucherTitle = VoucherExportHelper.getVoucherTitle(transaction)
  val accentColor = if (isReceipt) EmeraldPrimary else OrangePrimary
  val dateStr = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")).format(Date(transaction.timestamp))
  val tafqeetShort = TafqeetHelper.convertToArabicWords(transaction.amount)

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onCardClick),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = accentColor.copy(alpha = 0.15f)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                if (isReceipt) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(voucherTitle, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = accentColor)
            }
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = voucherNo,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = Color.DarkGray
          )
        }
        Text(text = dateStr, fontSize = 10.sp, color = Color.Gray)
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = transaction.partyName,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = tafqeetShort,
            fontSize = 10.sp,
            color = Color.Gray,
            maxLines = 1
          )
        }

        Text(
          text = String.format(Locale.ENGLISH, "%.2f %s", transaction.amount, currency),
          fontWeight = FontWeight.Black,
          fontSize = 17.sp,
          color = accentColor
        )
      }

      if (transaction.notes.isNotBlank()) {
        Text(
          text = "البيان: ${transaction.notes}",
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "طريقة السداد: نقداً (الصندوق)",
          fontSize = 10.sp,
          color = Color.Gray
        )

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          IconButton(onClick = onPrintClick, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Print, contentDescription = "طباعة", modifier = Modifier.size(18.dp), tint = accentColor)
          }
          IconButton(onClick = onShareClick, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Share, contentDescription = "مشاركة", modifier = Modifier.size(18.dp), tint = EmeraldPrimary)
          }
          IconButton(onClick = onCardClick, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Description, contentDescription = "معاينة", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
          }
        }
      }
    }
  }
}

/**
 * نافذة سريعة لاختيار نوع الطابعة (A4، حراري 80mm، حراري 58mm) ومشاركة PDF لكشف الحساب
 */
@Composable
fun PrintStatementSelectionDialog(
  partyName: String,
  partyPhone: String,
  isCustomer: Boolean,
  currentBalance: Double,
  invoices: List<Invoice>,
  payments: List<PaymentTransaction>,
  viewModel: WholesaleViewModel,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val profile by viewModel.businessProfile.collectAsStateWithLifecycle()

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .clip(RoundedCornerShape(18.dp)),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Print, contentDescription = null, tint = OrangePrimary)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = if (isCustomer) "طباعة كشف حساب عميل" else "طباعة كشف حساب مورد",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
              )
              Text(
                text = "$partyName ${if (partyPhone.isNotBlank()) "• $partyPhone" else ""}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = if (currentBalance > 0) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f) else EmeraldPrimary.copy(alpha = 0.12f)),
          shape = RoundedCornerShape(10.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (isCustomer) "إجمالي المديونية المستحقة:" else "إجمالي المستحق للمورد:",
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium
            )
            Text(
              text = String.format(Locale.ENGLISH, "%.2f ج.م", currentBalance),
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp,
              color = if (currentBalance > 0) MaterialTheme.colorScheme.error else EmeraldPrimary
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))
        Text("اختر نوع الطباعة المناسب لك:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        // 1. A4
        OutlinedButton(
          onClick = {
            StatementExportHelper.printStatementViaSystem(
              context = context,
              partyName = partyName,
              partyPhone = partyPhone,
              isCustomer = isCustomer,
              currentBalance = currentBalance,
              invoices = invoices,
              payments = payments,
              businessName = profile.businessName,
              businessPhone = profile.contactPhone,
              businessAddress = profile.address,
              printerType = "A4"
            )
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Text("طباعة رسمية A4 (طابعات ليزر وعادية / PDF)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 2. 80mm
        OutlinedButton(
          onClick = {
            StatementExportHelper.printStatementViaSystem(
              context = context,
              partyName = partyName,
              partyPhone = partyPhone,
              isCustomer = isCustomer,
              currentBalance = currentBalance,
              invoices = invoices,
              payments = payments,
              businessName = profile.businessName,
              businessPhone = profile.contactPhone,
              businessAddress = profile.address,
              printerType = "حراري 80mm"
            )
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(18.dp), tint = OrangePrimary)
          Spacer(modifier = Modifier.width(8.dp))
          Text("طباعة بون حراري 80mm (طابعات بلوتوث وفواتير)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 3. 58mm
        OutlinedButton(
          onClick = {
            StatementExportHelper.printStatementViaSystem(
              context = context,
              partyName = partyName,
              partyPhone = partyPhone,
              isCustomer = isCustomer,
              currentBalance = currentBalance,
              invoices = invoices,
              payments = payments,
              businessName = profile.businessName,
              businessPhone = profile.contactPhone,
              businessAddress = profile.address,
              printerType = "حراري 58mm"
            )
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color(0xFF6366F1))
          Spacer(modifier = Modifier.width(8.dp))
          Text("طباعة بون حراري 58mm (أجهزة كاشير محمولة)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 4. Share PDF
        OutlinedButton(
          onClick = {
            StatementExportHelper.shareStatementPdf(
              context = context,
              partyName = partyName,
              partyPhone = partyPhone,
              isCustomer = isCustomer,
              currentBalance = currentBalance,
              invoices = invoices,
              payments = payments,
              businessName = profile.businessName,
              businessPhone = profile.contactPhone,
              businessAddress = profile.address,
              pageSizeType = "A4"
            )
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color(0xFF0284C7))
          Spacer(modifier = Modifier.width(8.dp))
          Text("مشاركة كشف الحساب كملف PDF", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 5. WhatsApp Text
        Button(
          onClick = {
            val statementText = viewModel.getPartyStatementText(if (isCustomer) invoices.firstOrNull()?.partyId ?: 0L else payments.firstOrNull()?.partyId ?: 0L, isCustomer)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
              type = "text/plain"
              putExtra(Intent.EXTRA_SUBJECT, "كشف حساب: $partyName")
              putExtra(Intent.EXTRA_TEXT, statementText)
            }
            context.startActivity(Intent.createChooser(shareIntent, "إرسال كشف الحساب عبر واتساب"))
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("إرسال كشف الحساب عبر واتساب (نص منسق)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

/**
 * نافذة طباعة كشف المديونيات الإجمالي للعملاء أو مستحقات الموردين لجميع أنواع الطابعات
 */
@Composable
fun PrintDebtSummaryDialog(
  isCustomer: Boolean,
  customers: List<Customer>,
  suppliers: List<Supplier>,
  viewModel: WholesaleViewModel,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val profile by viewModel.businessProfile.collectAsStateWithLifecycle()
  val total = if (isCustomer) customers.sumOf { it.currentBalance.coerceAtLeast(0.0) } else suppliers.sumOf { it.currentBalance.coerceAtLeast(0.0) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .clip(RoundedCornerShape(18.dp)),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Print, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = if (isCustomer) "طباعة كشف مديونيات العملاء الإجمالي" else "طباعة كشف مستحقات الموردين الإجمالي",
                fontWeight = FontWeight.Bold,
                fontSize = 14.5.sp
              )
              Text(
                text = "${if (isCustomer) customers.size else suppliers.size} أطراف مسجلة • إجمالي: ${String.format(Locale.ENGLISH, "%.2f ج.م", total)}",
                fontSize = 11.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        Spacer(modifier = Modifier.height(14.dp))
        Text("اختر طريقة وطابع التقرير:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        // 1. A4
        OutlinedButton(
          onClick = {
            StatementExportHelper.printDebtSummaryViaSystem(
              context = context,
              isCustomer = isCustomer,
              customers = customers,
              suppliers = suppliers,
              businessName = profile.businessName,
              businessPhone = profile.contactPhone,
              printerType = "A4"
            )
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Text("طباعة تقرير A4 (جدول شامل وحفظ PDF)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 2. 80mm
        OutlinedButton(
          onClick = {
            StatementExportHelper.printDebtSummaryViaSystem(
              context = context,
              isCustomer = isCustomer,
              customers = customers,
              suppliers = suppliers,
              businessName = profile.businessName,
              businessPhone = profile.contactPhone,
              printerType = "حراري 80mm"
            )
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(18.dp), tint = OrangePrimary)
          Spacer(modifier = Modifier.width(8.dp))
          Text("طباعة تقرير بون حراري 80mm", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 3. 58mm
        OutlinedButton(
          onClick = {
            StatementExportHelper.printDebtSummaryViaSystem(
              context = context,
              isCustomer = isCustomer,
              customers = customers,
              suppliers = suppliers,
              businessName = profile.businessName,
              businessPhone = profile.contactPhone,
              printerType = "حراري 58mm"
            )
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color(0xFF6366F1))
          Spacer(modifier = Modifier.width(8.dp))
          Text("طباعة تقرير بون حراري 58mm", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 4. Share PDF
        OutlinedButton(
          onClick = {
            StatementExportHelper.shareDebtSummaryPdf(
              context = context,
              isCustomer = isCustomer,
              customers = customers,
              suppliers = suppliers,
              businessName = profile.businessName,
              businessPhone = profile.contactPhone,
              pageSizeType = "A4"
            )
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color(0xFF0284C7))
          Spacer(modifier = Modifier.width(8.dp))
          Text("مشاركة التقرير كملف PDF", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 5. WhatsApp Text
        Button(
          onClick = {
            StatementExportHelper.shareDebtSummaryWhatsApp(
              context = context,
              isCustomer = isCustomer,
              customers = customers,
              suppliers = suppliers,
              businessName = profile.businessName
            )
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("إرسال ملخص المديونيات عبر واتساب", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

