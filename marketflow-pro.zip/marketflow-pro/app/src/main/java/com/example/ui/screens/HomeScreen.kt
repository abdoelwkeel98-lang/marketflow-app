package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.WholesaleTab
import com.example.ui.WholesaleViewModel
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.NavyPrimaryDark
import com.example.ui.theme.CoralRed

/**
 * الواجهة الرئيسية (Dashboard)
 * شاشة بسيطة ومريحة وسريعة تحتوي فقط على أزرار الوصول المباشر للأقسام الثمانية
 * (مبيعات، مشتريات، عملاء، موردون، مخزن، خزينة، مصروفات، تقارير)
 * بدون عرض أي أرقام أو إحصائيات بداخلها، متوافقة ومتقنة تماماً في الوضعين الداكن والفاتح.
 */
@Composable
fun HomeScreen(
  viewModel: WholesaleViewModel,
  onNavigateToTab: (WholesaleTab) -> Unit,
  modifier: Modifier = Modifier
) {
  val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f

  // Dynamic high-contrast accents tuned for Dark and Light modes
  val salesAccent = if (isDark) Color(0xFF34D399) else EmeraldPrimary
  val purchasesAccent = if (isDark) Color(0xFF60A5FA) else Color(0xFF2563EB)
  val customersAccent = if (isDark) Color(0xFF2DD4BF) else Color(0xFF0D9488)
  val suppliersAccent = if (isDark) Color(0xFFFBBF24) else Color(0xFFD97706)
  val warehouseAccent = if (isDark) Color(0xFFA78BFA) else Color(0xFF7C3AED)
  val cashflowAccent = if (isDark) Color(0xFF4ADE80) else Color(0xFF047857)
  val expensesAccent = if (isDark) Color(0xFFF87171) else Color(0xFFDC2626)
  val reportsAccent = if (isDark) Color(0xFF818CF8) else Color(0xFF4338CA)

  val profile by viewModel.businessProfile.collectAsStateWithLifecycle()

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // بطاقة الموظف النشط وقفل الشاشة البيومتري
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.6f else 0.8f)),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isDark) 1.dp else 2.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = CircleShape,
              color = if (profile.deviceRole == "DELEGATE") OrangePrimary else NavyPrimaryDark,
              modifier = Modifier.size(42.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = if (profile.deviceRole == "DELEGATE") Icons.Default.TwoWheeler else Icons.Default.Fingerprint,
                  contentDescription = null,
                  tint = Color.White,
                  modifier = Modifier.size(24.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "الموظف: ${profile.activeEmployeeName}",
                  fontWeight = FontWeight.ExtraBold,
                  fontSize = 13.5.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = EmeraldPrimary.copy(alpha = 0.15f)
                ) {
                  Text(
                    text = profile.activeEmployeeRole,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
              Text(
                text = "تم التحقق الأمني بنجاح • الصلاحيات مفعلة طبقاً لطلب المدير",
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Button(
            onClick = {
              viewModel.setScreenLocked(true)
            },
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CoralRed)
          ) {
            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("قفل الشاشة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // عنوان بسيط لأزرار الوصول المباشر للأقسام
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 4.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "أقسام النظام الرئيسية",
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
          color = MaterialTheme.colorScheme.onSurface
        )
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.surfaceVariant
        ) {
          Text(
            text = "وصول مباشر",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }
    }

    // -------------------------------------------------------------------------
    // الصف 1: (1) مبيعات  &  (2) مشتريات
    // -------------------------------------------------------------------------
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        DirectNavCard(
          title = "المبيعات",
          subtitle = "فواتير البيع ونقاط البيع السريعة",
          icon = Icons.Default.PointOfSale,
          accentColor = salesAccent,
          isDark = isDark,
          modifier = Modifier.weight(1f),
          onClick = { onNavigateToTab(WholesaleTab.SALES) }
        )

        DirectNavCard(
          title = "المشتريات",
          subtitle = "فواتير الشراء والتوريد للمخزن",
          icon = Icons.Default.LocalShipping,
          accentColor = purchasesAccent,
          isDark = isDark,
          modifier = Modifier.weight(1f),
          onClick = { onNavigateToTab(WholesaleTab.PURCHASES) }
        )
      }
    }

    // -------------------------------------------------------------------------
    // الصف 2: (3) عملاء  &  (4) موردون
    // -------------------------------------------------------------------------
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        DirectNavCard(
          title = "العملاء",
          subtitle = "حسابات ومديونيات العملاء",
          icon = Icons.Default.People,
          accentColor = customersAccent,
          isDark = isDark,
          modifier = Modifier.weight(1f),
          onClick = { onNavigateToTab(WholesaleTab.ACCOUNTS) }
        )

        DirectNavCard(
          title = "الموردون",
          subtitle = "حسابات ومستحقات الموردين",
          icon = Icons.Default.Storefront,
          accentColor = suppliersAccent,
          isDark = isDark,
          modifier = Modifier.weight(1f),
          onClick = { onNavigateToTab(WholesaleTab.ACCOUNTS) }
        )
      }
    }

    // -------------------------------------------------------------------------
    // الصف 3: (5) مخزن  &  (6) خزينة
    // -------------------------------------------------------------------------
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        DirectNavCard(
          title = "المخزن",
          subtitle = "الأصناف وجرد المستودع",
          icon = Icons.Default.Inventory2,
          accentColor = warehouseAccent,
          isDark = isDark,
          modifier = Modifier.weight(1f),
          onClick = { onNavigateToTab(WholesaleTab.WAREHOUSE) }
        )

        DirectNavCard(
          title = "الخزينة",
          subtitle = "حركة النقدية وسندات الصندوق",
          icon = Icons.Default.AccountBalanceWallet,
          accentColor = cashflowAccent,
          isDark = isDark,
          modifier = Modifier.weight(1f),
          onClick = { onNavigateToTab(WholesaleTab.CASHFLOW) }
        )
      }
    }

    // -------------------------------------------------------------------------
    // الصف 4: (7) مصروفات  &  (8) تقارير
    // -------------------------------------------------------------------------
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        DirectNavCard(
          title = "المصروفات",
          subtitle = "تسجيل ومتابعة بنود المصاريف",
          icon = Icons.Default.MoneyOff,
          accentColor = expensesAccent,
          isDark = isDark,
          modifier = Modifier.weight(1f),
          onClick = { onNavigateToTab(WholesaleTab.CASHFLOW) }
        )

        DirectNavCard(
          title = "التقارير",
          subtitle = "القوائم المالية وميزان المراجعة",
          icon = Icons.Default.Analytics,
          accentColor = reportsAccent,
          isDark = isDark,
          modifier = Modifier.weight(1f),
          onClick = { onNavigateToTab(WholesaleTab.REPORTS) }
        )
      }
    }
  }
}

/**
 * زر وبطاقة الوصول المباشر
 * تصميم نقي، فخم، ومريح بنقرة واحدة مباشرة للقسم المحدد بدون أرقام
 */
@Composable
private fun DirectNavCard(
  title: String,
  subtitle: String,
  icon: ImageVector,
  accentColor: Color,
  isDark: Boolean,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .clickable { onClick() },
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.6f else 0.8f)),
    elevation = CardDefaults.cardElevation(defaultElevation = if (isDark) 1.dp else 2.5.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Icon Container with soft accent background
        Box(
          modifier = Modifier
            .size(46.dp)
            .background(accentColor.copy(alpha = if (isDark) 0.22f else 0.12f), shape = RoundedCornerShape(12.dp)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(24.dp)
          )
        }

        // Navigation Pill
        Surface(
          shape = CircleShape,
          color = accentColor.copy(alpha = if (isDark) 0.18f else 0.08f),
          modifier = Modifier.size(28.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowForward,
              contentDescription = "فتح القسم",
              tint = accentColor,
              modifier = Modifier.size(14.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Section Title (Primary Text: #1A202C / onSurface)
      Text(
        text = title,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 16.sp,
        color = MaterialTheme.colorScheme.onSurface
      )

      Spacer(modifier = Modifier.height(4.dp))

      // Description (Secondary Text: #8C9DAE / onSurfaceVariant)
      Text(
        text = subtitle,
        fontSize = 11.5.sp,
        fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp,
        minLines = 2,
        maxLines = 2
      )
    }
  }
}
