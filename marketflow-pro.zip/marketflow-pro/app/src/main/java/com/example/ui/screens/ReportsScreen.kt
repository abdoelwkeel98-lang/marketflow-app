package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.LocalAtm
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Search
import com.example.data.model.Customer
import com.example.data.model.Expense
import com.example.data.model.Invoice
import com.example.data.model.InvoiceType
import com.example.data.model.Product
import com.example.data.model.Supplier
import com.example.ui.DebtAgingStat
import com.example.ui.ExpenseCategoryStat
import com.example.ui.ProfitReportData
import com.example.ui.ReportPeriod
import com.example.ui.SalesTrendPoint
import com.example.ui.TopProductStat
import com.example.ui.WholesaleViewModel
import com.example.ui.screens.reports.DetailedPurchasesReportsView
import com.example.ui.screens.reports.DetailedSalesReportsView
import com.example.ui.screens.reports.DetailedProfitReportsView
import com.example.utils.ReportExportHelper
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Image
import com.example.ui.components.ReportPeriodSelectorBar
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReportsScreen(
  viewModel: WholesaleViewModel,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val report by viewModel.profitReport.collectAsStateWithLifecycle()
  val selectedPeriod by viewModel.selectedReportPeriod.collectAsStateWithLifecycle()
  val expenses by viewModel.expenses.collectAsStateWithLifecycle()
  val topProducts by viewModel.topSellingProducts.collectAsStateWithLifecycle()
  val expensesByCategory by viewModel.expensesByCategory.collectAsStateWithLifecycle()
  val debtAgingList by viewModel.debtAgingList.collectAsStateWithLifecycle()
  val salesTrendList by viewModel.salesTrendList.collectAsStateWithLifecycle()
  val customers by viewModel.customers.collectAsStateWithLifecycle()
  val suppliers by viewModel.suppliers.collectAsStateWithLifecycle()
  val products by viewModel.products.collectAsStateWithLifecycle()
  val lowStockList by viewModel.lowStockProducts.collectAsStateWithLifecycle()
  val salesInvoices by viewModel.salesInvoices.collectAsStateWithLifecycle()
  val purchaseInvoices by viewModel.purchaseInvoices.collectAsStateWithLifecycle()
  val invoiceItems by viewModel.invoiceItems.collectAsStateWithLifecycle()
  val businessProfile by viewModel.businessProfile.collectAsStateWithLifecycle()

  var selectedSubTab by remember { mutableStateOf<Int?>(null) }

  var showAddExpenseDialog by remember { mutableStateOf(false) }
  var showExportReportDialog by remember { mutableStateOf(false) }
  var collectingDebtForCustomer by remember { mutableStateOf<Customer?>(null) }

  // العودة لقائمة المربعات بالزر الخلفي للجهاز
  BackHandler(enabled = selectedSubTab != null) {
    selectedSubTab = null
  }

  if (selectedSubTab == null) {
    // -------------------------------------------------------------------------
    // الواجهة الرئيسية للتقارير: مربعات مثل الشاشة الرئيسية (مبيعات، مشتريات، أرباح، إلخ)
    // -------------------------------------------------------------------------
    LazyColumn(
      modifier = modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // شريط العنوان وفلتر الفترة وتصدير التقرير
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "مركز التقارير والتحليلات المالية",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "اختر القسم المطلوب لعرض تفاصيله الكاملة",
                  fontSize = 11.5.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }

              Button(
                onClick = { showExportReportDialog = true },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تصدير التقرير", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // فلاتر الفترة الزمنية وتحديد يوم مخصص أو مدة معينة
            ReportPeriodSelectorBar(
              viewModel = viewModel,
              modifier = Modifier.fillMaxWidth(),
              showLabel = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            // شريط الملخص المالي السريع (مبيعات، مشتريات، أرباح)
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 10.dp, horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                  Text("المبيعات", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(
                    text = "${String.format(Locale.ENGLISH, "%.1f", report.totalSales)} ${businessProfile.currency}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary
                  )
                }

                Box(modifier = Modifier.height(28.dp).width(1.dp).background(MaterialTheme.colorScheme.outlineVariant))

                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                  Text("المشتريات", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(
                    text = "${String.format(Locale.ENGLISH, "%.1f", report.totalPurchases)} ${businessProfile.currency}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF2563EB)
                  )
                }

                Box(modifier = Modifier.height(28.dp).width(1.dp).background(MaterialTheme.colorScheme.outlineVariant))

                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                  Text("صافي الأرباح", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(
                    text = "${String.format(Locale.ENGLISH, "%.1f", report.netProfit)} ${businessProfile.currency}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (report.netProfit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
                  )
                }
              }
            }
          }
        }
      }

      // الصف 1: المبيعات & المشتريات
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          ReportNavCard(
            title = "المبيعات",
            subtitle = "فواتير البيع والأصناف والعملاء",
            icon = Icons.Default.PointOfSale,
            accentColor = EmeraldPrimary,
            liveStat = "${String.format(Locale.ENGLISH, "%.1f", report.totalSales)} ${businessProfile.currency}",
            modifier = Modifier.weight(1f),
            onClick = { selectedSubTab = 1 }
          )

          ReportNavCard(
            title = "المشتريات",
            subtitle = "فواتير الشراء والتوريد والموردين",
            icon = Icons.Default.LocalShipping,
            accentColor = Color(0xFF2563EB),
            liveStat = "${String.format(Locale.ENGLISH, "%.1f", report.totalPurchases)} ${businessProfile.currency}",
            modifier = Modifier.weight(1f),
            onClick = { selectedSubTab = 2 }
          )
        }
      }

      // الصف 2: الأرباح والدخل & المؤشرات والرسوم
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          ReportNavCard(
            title = "الأرباح والدخل",
            subtitle = "قائمة الدخل P&L وهوامش الربح",
            icon = Icons.Default.AttachMoney,
            accentColor = Color(0xFF059669),
            liveStat = "${String.format(Locale.ENGLISH, "%.1f", report.netProfit)} ${businessProfile.currency}",
            modifier = Modifier.weight(1f),
            onClick = { selectedSubTab = 7 }
          )

          ReportNavCard(
            title = "المؤشرات والرسوم",
            subtitle = "منحنى المبيعات والرسوم التفاعلية",
            icon = Icons.Default.Analytics,
            accentColor = Color(0xFF4338CA),
            liveStat = "رسوم ومخططات",
            modifier = Modifier.weight(1f),
            onClick = { selectedSubTab = 0 }
          )
        }
      }

      // الصف 3: جرد المخزون & الخزينة والدرج
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          ReportNavCard(
            title = "جرد وتقييم المخزون",
            subtitle = "تقييم البضاعة والنواقص ورأس المال",
            icon = Icons.Default.Inventory2,
            accentColor = Color(0xFF7C3AED),
            liveStat = "${products.size} صنف بالمخزن",
            modifier = Modifier.weight(1f),
            onClick = { selectedSubTab = 4 }
          )

          ReportNavCard(
            title = "الخزينة والمصروفات",
            subtitle = "حركة السيولة والدرج والورديات",
            icon = Icons.Default.AccountBalanceWallet,
            accentColor = Color(0xFF047857),
            liveStat = "الصندوق والمصاريف",
            modifier = Modifier.weight(1f),
            onClick = { selectedSubTab = 5 }
          )
        }
      }

      // الصف 4: الأكثر مبيعاً & كشف أعمار الديون
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          ReportNavCard(
            title = "الأكثر مبيعاً وربحية",
            subtitle = "ترتيب الأصناف الأكثر طلباً وربحاً",
            icon = Icons.Default.Star,
            accentColor = Color(0xFFD97706),
            liveStat = "${topProducts.size} صنف رائد",
            modifier = Modifier.weight(1f),
            onClick = { selectedSubTab = 3 }
          )

          ReportNavCard(
            title = "كشف أعمار الديون",
            subtitle = "مديونيات العملاء ومواعيد التحصيل",
            icon = Icons.Default.People,
            accentColor = Color(0xFFDC2626),
            liveStat = "${debtAgingList.size} عميل مديون",
            modifier = Modifier.weight(1f),
            onClick = { selectedSubTab = 6 }
          )
        }
      }

      // الصف 5: ميزان المراجعة & قيود اليومية
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          ReportNavCard(
            title = "ميزان المراجعة",
            subtitle = "أرصدة الحسابات ومطابقة الأرصدة",
            icon = Icons.Default.AccountBalance,
            accentColor = Color(0xFF0284C7),
            liveStat = "القوائم المحاسبية",
            modifier = Modifier.weight(1f),
            onClick = { selectedSubTab = 8 }
          )

          ReportNavCard(
            title = "قيود اليومية",
            subtitle = "سجل اليومية العامة والقيود الآلية",
            icon = Icons.Default.ReceiptLong,
            accentColor = Color(0xFF6B7280),
            liveStat = "سجل القيود",
            modifier = Modifier.weight(1f),
            onClick = { selectedSubTab = 9 }
          )
        }
      }
    }
  } else {
    // -------------------------------------------------------------------------
    // عند الضغط على أي مربع: عرض البيانات مع شريط علوي للرجوع وتغيير الفترة
    // -------------------------------------------------------------------------
    Column(modifier = modifier.fillMaxSize()) {
      Surface(
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              OutlinedButton(
                onClick = { selectedSubTab = null },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.height(34.dp)
              ) {
                Icon(
                  Icons.AutoMirrored.Filled.ArrowForward,
                  contentDescription = "رجوع",
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("قائمة التقارير", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }

              Spacer(modifier = Modifier.width(10.dp))

              Text(
                text = when (selectedSubTab) {
                  0 -> "المؤشرات والرسوم"
                  1 -> "تقارير المبيعات"
                  2 -> "تقارير المشتريات"
                  3 -> "الأكثر مبيعاً وربحية"
                  4 -> "جرد وتقييم المخزون"
                  5 -> "حركة الخزينة والدرج"
                  6 -> "كشف أعمار الديون"
                  7 -> "قائمة الدخل والأرباح"
                  8 -> "ميزان المراجعة"
                  9 -> "قيود اليومية"
                  else -> "التقرير"
                },
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }

            Button(
              onClick = { showExportReportDialog = true },
              shape = RoundedCornerShape(8.dp),
              colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
              modifier = Modifier.height(34.dp)
            ) {
              Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("تصدير", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }

          // فلاتر الفترة الزمنية (تظهر في الأقسام الأخرى حيث فلاتر المبيعات والمشتريات مدمجة بداخلها)
          if (selectedSubTab != 1 && selectedSubTab != 2) {
            ReportPeriodSelectorBar(
              viewModel = viewModel,
              modifier = Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 12.dp, bottom = 8.dp),
              showLabel = false
            )
          }
        }
      }

      // محتوى التقرير المختار
      when (selectedSubTab) {
        0 -> ExecutiveChartsTab(
          report = report,
          trendPoints = salesTrendList,
          topProducts = topProducts,
          salesInvoices = salesInvoices,
          products = products,
          currency = businessProfile.currency,
          onNavigateToTopProducts = { selectedSubTab = 3 },
          onNavigateToInventory = { selectedSubTab = 4 }
        )
        1 -> DetailedSalesReportsView(
          viewModel = viewModel,
          salesInvoices = salesInvoices,
          invoiceItems = invoiceItems,
          products = products,
          customers = customers,
          period = selectedPeriod,
          currency = businessProfile.currency
        )
        2 -> DetailedPurchasesReportsView(
          viewModel = viewModel,
          purchaseInvoices = purchaseInvoices,
          invoiceItems = invoiceItems,
          products = products,
          suppliers = suppliers,
          period = selectedPeriod,
          currency = businessProfile.currency
        )
        3 -> TopProductsTab(
          topProducts = topProducts
        )
        4 -> InventoryValuationReportTab(
          products = products,
          lowStockList = lowStockList,
          currency = businessProfile.currency
        )
        5 -> CashFlowDrawerTab(
          report = report,
          expenses = expenses,
          onAddExpense = { showAddExpenseDialog = true },
          onDeleteExpense = { viewModel.deleteExpense(it) }
        )
        6 -> DebtAgingTab(
          report = report,
          debtList = debtAgingList,
          customers = customers,
          onCollectDebt = { cust -> collectingDebtForCustomer = cust }
        )
        7 -> DetailedProfitReportsView(
          viewModel = viewModel,
          report = report,
          salesInvoices = salesInvoices,
          invoiceItems = invoiceItems,
          products = products,
          customers = customers,
          expenses = expenses,
          expensesByCategory = expensesByCategory,
          topProducts = topProducts,
          currency = businessProfile.currency,
          onAddExpense = { showAddExpenseDialog = true }
        )
        8 -> TrialBalanceTab(
          viewModel = viewModel
        )
        9 -> JournalEntriesTab(
          viewModel = viewModel
        )
      }
    }
  }

  // Add Expense Dialog
  if (showAddExpenseDialog) {
    AddExpenseDialog(
      onDismiss = { showAddExpenseDialog = false },
      onSave = { category, amount, recipient, notes ->
        viewModel.addExpense(category, amount, recipient, notes)
        showAddExpenseDialog = false
      }
    )
  }

  // Export Report Dialog
  if (showExportReportDialog) {
    ExportReportDialog(
      report = report,
      period = selectedPeriod,
      topProducts = topProducts,
      expensesByCategory = expensesByCategory,
      businessName = businessProfile.businessName,
      phone = businessProfile.contactPhone,
      address = businessProfile.address,
      onDismiss = { showExportReportDialog = false }
    )
  }

  // Collect Customer Debt Dialog
  collectingDebtForCustomer?.let { customer ->
    CollectCustomerPaymentDialog(
      customer = customer,
      onDismiss = { collectingDebtForCustomer = null },
      onConfirm = { amt, notes ->
        viewModel.recordCustomerPayment(customer, amt, notes)
        collectingDebtForCustomer = null
        Toast.makeText(context, "تم تسجيل سند القبض وتحديث الخزينة وحساب العميل بنجاح", Toast.LENGTH_SHORT).show()
      }
    )
  }
}

/**
 * زر ومربع التقرير المباشر (مثل بطاقات الشاشة الرئيسية)
 */
@Composable
private fun ReportNavCard(
  title: String,
  subtitle: String,
  icon: ImageVector,
  accentColor: Color,
  liveStat: String? = null,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .clickable { onClick() },
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(46.dp)
            .background(accentColor.copy(alpha = 0.12f), shape = RoundedCornerShape(12.dp)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(24.dp)
          )
        }

        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowForward,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
          modifier = Modifier.size(18.dp)
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = title,
        fontWeight = FontWeight.Bold,
        fontSize = 15.sp,
        color = MaterialTheme.colorScheme.onSurface
      )

      Spacer(modifier = Modifier.height(3.dp))

      Text(
        text = subtitle,
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )

      if (!liveStat.isNullOrEmpty()) {
        Spacer(modifier = Modifier.height(8.dp))
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = accentColor.copy(alpha = 0.1f)
        ) {
          Text(
            text = liveStat,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = accentColor,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }
    }
  }
}

// ================= TAB 0: EXECUTIVE CHARTS & DASHBOARD =================

@Composable
fun ExecutiveChartsTab(
  report: ProfitReportData,
  trendPoints: List<SalesTrendPoint>,
  topProducts: List<TopProductStat>,
  salesInvoices: List<Invoice>,
  products: List<Product>,
  currency: String,
  onNavigateToTopProducts: () -> Unit,
  onNavigateToInventory: () -> Unit
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Hero Profit Banner Card
    item {
      HeroProfitCard(report = report)
    }

    // Graphical Bar Chart
    item {
      SalesAndProfitBarChart(trendPoints = trendPoints)
    }

    // Weekly Sales Comparison Chart Card
    item {
      WeeklySalesChartCard(salesInvoices = salesInvoices, currency = currency)
    }

    // Primary KPI Grid
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          KpiCard(
            title = "إجمالي المبيعات",
            value = String.format(Locale.ENGLISH, "%.2f ج.م", report.totalSales),
            subtitle = "${report.salesCount} فاتورة بيع",
            icon = Icons.Default.ShoppingBag,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f)
          )
          KpiCard(
            title = "تكلفة البضاعة المباعة COGS",
            value = String.format(Locale.ENGLISH, "%.2f ج.م", report.totalSalesCost),
            subtitle = "تكلفة التوريد والشراء",
            icon = Icons.Default.ReceiptLong,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          KpiCard(
            title = "مجمل أرباح المبيعات",
            value = String.format(Locale.ENGLISH, "%.2f ج.م", report.grossProfit),
            subtitle = "قبل خصم المصروفات",
            icon = Icons.Default.TrendingUp,
            color = EmeraldPrimary,
            modifier = Modifier.weight(1f)
          )
          KpiCard(
            title = "إجمالي المصروفات",
            value = String.format(Locale.ENGLISH, "%.2f ج.م", report.totalExpenses),
            subtitle = "إيجار، كهرباء، رواتب، نقل",
            icon = Icons.Default.AttachMoney,
            color = MaterialTheme.colorScheme.error,
            modifier = Modifier.weight(1f)
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          KpiCard(
            title = "المشتريات والتوريد",
            value = String.format(Locale.ENGLISH, "%.2f ج.م", report.totalPurchases),
            subtitle = "${report.purchasesCount} فاتورة توريد",
            icon = Icons.Default.AccountBalance,
            color = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.weight(1f)
          )
          KpiCard(
            title = "نسبة صافي الربح",
            value = String.format(Locale.ENGLISH, "%.1f%%", report.profitMarginPercent),
            subtitle = "صافي الربح ÷ المبيعات",
            icon = Icons.Default.Percent,
            color = if (report.profitMarginPercent >= 5.0) EmeraldPrimary else MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    // Inventory & Perpetual System Quick Card
    item {
      val totalCost = remember(products) { products.sumOf { it.totalPiecesInStock * it.pieceCostPrice } }
      val totalRetail = remember(products) { products.sumOf { it.totalPiecesInStock * it.pieceRetailPrice } }
      val expectedProfit = (totalRetail - totalCost).coerceAtLeast(0.0)

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onNavigateToInventory() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Inventory2, contentDescription = null, tint = OrangePrimary, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("تقييم المخزون ونظام الجرد المستمر", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = EmeraldPrimary.copy(alpha = 0.15f)
            ) {
              Text(
                text = "جرد مستمر WAC ✓",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldPrimary,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text("قيمة البضاعة بالتكلفة:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = String.format(Locale.ENGLISH, "%.1f %s", totalCost, currency),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
            Column {
              Text("قيمة البضاعة بالقطاعي:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = String.format(Locale.ENGLISH, "%.1f %s", totalRetail, currency),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = EmeraldPrimary
              )
            }
            Column {
              Text("الربح المتوقع:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = String.format(Locale.ENGLISH, "+%.1f %s", expectedProfit, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = EmeraldPrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("فتح كشف وجرد المخزون الشامل", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = OrangePrimary)
            Spacer(modifier = Modifier.width(4.dp))
            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = OrangePrimary, modifier = Modifier.size(14.dp))
          }
        }
      }
    }

    // Payment Distribution Card (نقدي vs آجل)
    item {
      PaymentMethodDistributionCard(report = report)
    }

    // Top Selling Products Quick Preview
    item {
      TopProductsPreviewCard(
        topProducts = topProducts,
        onViewAll = onNavigateToTopProducts
      )
    }

    // Balance Sheet & Working Capital Position
    item {
      FinancialPositionCard(report = report)
    }
  }
}

// ================= WEEKLY SALES BAR CHART =================

@Composable
fun WeeklySalesChartCard(
  salesInvoices: List<Invoice>,
  currency: String
) {
  val dayLabels = listOf("السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة")
  val weeklyAmounts = remember(salesInvoices) {
    val amounts = DoubleArray(7) { 0.0 }
    val now = System.currentTimeMillis()
    val dayMillis = 86400000L

    for (i in 0 until 7) {
      val targetDayStart = now - (6 - i) * dayMillis
      val targetDayEnd = targetDayStart + dayMillis
      val daySales = salesInvoices.filter {
        it.type == InvoiceType.SALE && it.timestamp in targetDayStart..targetDayEnd
      }.sumOf { it.totalAmount }

      amounts[i] = daySales
    }
    amounts
  }

  val maxAmount = (weeklyAmounts.maxOrNull() ?: 1.0).coerceAtLeast(100.0)

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "رسم بياني: مبيعات الأسبوع",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
          )
          Text(
            text = "مقارنة حركة المبيعات اليومية للأسبوع الحالي",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        Text(
          text = "أعلى يوم: ${String.format(Locale.ENGLISH, "%.0f %s", maxAmount, currency)}",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = OrangePrimary
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(140.dp)
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val barWidth = size.width / (weeklyAmounts.size * 1.8f)
          val spacing = (size.width - (barWidth * weeklyAmounts.size)) / (weeklyAmounts.size + 1)

          weeklyAmounts.forEachIndexed { index, amount ->
            val barHeight = ((amount / maxAmount) * (size.height - 24.dp.toPx())).toFloat()
            val left = spacing + index * (barWidth + spacing)
            val top = size.height - barHeight - 20.dp.toPx()

            drawRoundRect(
              color = Color(0xFFF1F5F9),
              topLeft = Offset(left, 0f),
              size = Size(barWidth, size.height - 20.dp.toPx()),
              cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
            )

            val isPeak = amount == maxAmount
            drawRoundRect(
              brush = Brush.verticalGradient(
                colors = if (isPeak) {
                  listOf(Color(0xFFEA580C), Color(0xFFDC2626))
                } else {
                  listOf(Color(0xFFFB923C), Color(0xFFEA580C))
                }
              ),
              topLeft = Offset(left, top),
              size = Size(barWidth, barHeight),
              cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
            )
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        dayLabels.forEach { label ->
          Text(
            text = label,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.weight(1f)
          )
        }
      }
    }
  }
}

// ================= TAB 1: INVENTORY VALUATION & PERPETUAL SYSTEM =================

@Composable
fun InventoryValuationReportTab(
  products: List<Product>,
  lowStockList: List<Product>,
  currency: String
) {
  val context = LocalContext.current
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("الكل") }

  val categories = remember(products) {
    listOf("الكل") + products.map { it.category }.distinct()
  }

  val filteredProducts = remember(products, searchQuery, selectedCategory) {
    products.filter { prod ->
      val matchesSearch = prod.name.contains(searchQuery, ignoreCase = true) ||
        prod.barcode.contains(searchQuery, ignoreCase = true)
      val matchesCat = selectedCategory == "الكل" || prod.category == selectedCategory
      matchesSearch && matchesCat
    }
  }

  val totalInventoryCost = remember(products) {
    products.sumOf { it.totalPiecesInStock * it.pieceCostPrice }
  }
  val totalInventoryRetail = remember(products) {
    products.sumOf { it.totalPiecesInStock * it.pieceRetailPrice }
  }
  val totalInventoryWholesale = remember(products) {
    products.sumOf { it.totalPiecesInStock * it.pieceWholesalePrice }
  }
  val expectedStockProfit = (totalInventoryRetail - totalInventoryCost).coerceAtLeast(0.0)
  val expectedStockMarginPercent = if (totalInventoryRetail > 0) (expectedStockProfit / totalInventoryRetail) * 100.0 else 0.0

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Perpetual Inventory Engine Status Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = CircleShape,
                color = EmeraldPrimary.copy(alpha = 0.15f),
                modifier = Modifier.size(34.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(Icons.Default.AccountBalance, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                }
              }
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text("المحرك المحاسبي ونظام الجرد المستمر", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("تحديث آلي فوري للمخزن وتكلفة COGS مع كل حركة بيع وشراء", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            Surface(
              shape = RoundedCornerShape(6.dp),
              color = EmeraldPrimary.copy(alpha = 0.15f)
            ) {
              Text(
                text = "جرد مستمر نشط ✓",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldPrimary,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              modifier = Modifier.weight(1f)
            ) {
              Column(modifier = Modifier.padding(8.dp)) {
                Text("الجرد المستمر", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                Text("تسجيل COGS لحظياً بالقيود", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              modifier = Modifier.weight(1f)
            ) {
              Column(modifier = Modifier.padding(8.dp)) {
                Text("المتوسط المترجح", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = OrangePrimary)
                Text("WAC معاد احتساب التكلفة", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              modifier = Modifier.weight(1f)
            ) {
              Column(modifier = Modifier.padding(8.dp)) {
                Text("قيد مزدوج آلي", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("ربط بالميزان اليومي", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }
      }
    }

    // 2. Inventory Valuation Hero Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("تقييم بضاعة المخزن الإجمالية", fontWeight = FontWeight.Bold, fontSize = 16.sp)
              Text("إجمالي قيمة البضاعة ورأس المال المرصود", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = OrangePrimary.copy(alpha = 0.15f)
            ) {
              Text(
                text = "${products.size} صنف مسجل",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = OrangePrimary,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // 2x2 Valuation Grid
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Surface(
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(12.dp),
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text("قيمة المخزون بالتكلفة (COGS)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f %s", totalInventoryCost, currency),
                  fontWeight = FontWeight.ExtraBold,
                  fontSize = 16.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text("رأس المال في البضاعة", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            Surface(
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(12.dp),
              color = EmeraldPrimary.copy(alpha = 0.12f)
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text("قيمة المخزون بالقطاعي", fontSize = 11.sp, color = EmeraldPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f %s", totalInventoryRetail, currency),
                  fontWeight = FontWeight.ExtraBold,
                  fontSize = 16.sp,
                  color = EmeraldPrimary
                )
                Text("الإيراد المتوقع عند البيع قطاعي", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Surface(
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(12.dp),
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text("قيمة المخزون بسعر الجملة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f %s", totalInventoryWholesale, currency),
                  fontWeight = FontWeight.Bold,
                  fontSize = 15.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text("القيمة الإجمالية لتجار الجملة", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            Surface(
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(12.dp),
              color = EmeraldPrimary.copy(alpha = 0.15f)
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text("الربح الإجمالي المتوقع", fontSize = 11.sp, color = EmeraldPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = String.format(Locale.ENGLISH, "+%.2f %s", expectedStockProfit, currency),
                  fontWeight = FontWeight.ExtraBold,
                  fontSize = 15.sp,
                  color = EmeraldPrimary
                )
                Text(
                  text = "متوسط هامش الربح: " + String.format(Locale.ENGLISH, "%.1f%%", expectedStockMarginPercent),
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  color = EmeraldPrimary
                )
              }
            }
          }
        }
      }
    }

    // 3. Quick Export & Share Inventory Report
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Button(
          onClick = {
            val text = buildString {
              appendLine("📊 تقرير تقييم وجرد المخزون الشامل")
              appendLine("التاريخ: ${SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.ENGLISH).format(Date())}")
              appendLine("إجمالي عدد الأصناف: ${products.size}")
              appendLine("قيمة المخزون بالتكلفة: ${String.format(Locale.ENGLISH, "%.2f", totalInventoryCost)} $currency")
              appendLine("قيمة المخزون بالقطاعي: ${String.format(Locale.ENGLISH, "%.2f", totalInventoryRetail)} $currency")
              appendLine("قيمة المخزون بالجملة: ${String.format(Locale.ENGLISH, "%.2f", totalInventoryWholesale)} $currency")
              appendLine("الربح المتوقع: ${String.format(Locale.ENGLISH, "%.2f", expectedStockProfit)} $currency (${String.format(Locale.ENGLISH, "%.1f%%", expectedStockMarginPercent)})")
              appendLine("عدد النواقص: ${lowStockList.size} صنف")
              appendLine("-----------------------------------")
              appendLine("تفاصيل الأصناف:")
              products.forEach { p ->
                val costTotal = p.totalPiecesInStock * p.pieceCostPrice
                appendLine("- ${p.name} [${p.category}]: رصيد ${p.stockDisplayString()} | تكلفة ${String.format(Locale.ENGLISH, "%.1f", p.pieceCostPrice)} | بيع ${String.format(Locale.ENGLISH, "%.1f", p.pieceRetailPrice)} | إجمالي تكلفة ${String.format(Locale.ENGLISH, "%.1f", costTotal)}")
              }
            }
            val intent = Intent(Intent.ACTION_SEND).apply {
              type = "text/plain"
              putExtra(Intent.EXTRA_TEXT, text)
            }
            context.startActivity(Intent.createChooser(intent, "مشاركة تقرير المخزون"))
          },
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
        ) {
          Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("مشاركة تقرير الجرد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
          onClick = {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = "إجمالي بضاعة المخزن بالتكلفة: $totalInventoryCost $currency | بالقطاعي: $totalInventoryRetail $currency | الأرباح المتوقعة: $expectedStockProfit $currency"
            clipboard.setPrimaryClip(ClipData.newPlainText("Inventory Summary", text))
            Toast.makeText(context, "تم نسخ ملخص المخزون للحافظة", Toast.LENGTH_SHORT).show()
          },
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("نسخ الملخص", fontSize = 12.sp)
        }
      }
    }

    // 4. Low Stock Alert Section (if any)
    if (lowStockList.isNotEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = CrimsonRed.copy(alpha = 0.08f)),
          border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRed.copy(alpha = 0.3f))
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(Icons.Default.Warning, contentDescription = null, tint = CrimsonRed, modifier = Modifier.size(20.dp))
              Text("أصناف أوشكت على النفاد (${lowStockList.size} صنف)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CrimsonRed)
            }
            Spacer(modifier = Modifier.height(8.dp))
            lowStockList.take(5).forEach { prod ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(prod.name, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                  Text("حد التنبيه: ${prod.minStockAlert} قطعة", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = CrimsonRed.copy(alpha = 0.15f)
                ) {
                  Text(
                    text = "متبقي: ${prod.totalPiecesInStock} قطعة",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CrimsonRed,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
            }
          }
        }
      }
    }

    // 5. Search & Filter Bar
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("كشف تفصيلي بالأصناف وأرصدتها", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text("${filteredProducts.size} من أصل ${products.size}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }

      Spacer(modifier = Modifier.height(6.dp))

      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text("بحث باسم الصنف أو الباركود...", fontSize = 12.sp) },
        shape = RoundedCornerShape(10.dp),
        singleLine = true,
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
            }
          }
        }
      )

      if (categories.size > 2) {
        Spacer(modifier = Modifier.height(6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(categories) { cat ->
            FilterChip(
              selected = selectedCategory == cat,
              onClick = { selectedCategory = cat },
              label = { Text(cat, fontSize = 10.sp) }
            )
          }
        }
      }
    }

    // 6. Product Item Cards with Full Cost & Stock Valuation Breakdown
    items(filteredProducts, key = { it.id }) { product ->
      val itemTotalCost = product.totalPiecesInStock * product.pieceCostPrice
      val itemTotalRetail = product.totalPiecesInStock * product.pieceRetailPrice

      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(product.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
              Text("الفئة: ${product.category} • كرتونة: ${product.piecesPerCarton} قطعة", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = if (product.totalPiecesInStock <= product.minStockAlert) CrimsonRed.copy(alpha = 0.15f) else EmeraldPrimary.copy(alpha = 0.15f)
            ) {
              Text(
                text = product.stockDisplayString(),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (product.totalPiecesInStock <= product.minStockAlert) CrimsonRed else EmeraldPrimary,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text("سعر التكلفة:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text("${String.format(Locale.ENGLISH, "%.2f", product.pieceCostPrice)} $currency", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Column {
              Text("سعر الجملة:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text("${String.format(Locale.ENGLISH, "%.2f", product.pieceWholesalePrice)} $currency", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Column {
              Text("سعر القطاعي:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text("${String.format(Locale.ENGLISH, "%.2f", product.pieceRetailPrice)} $currency", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = EmeraldPrimary)
            }
            Column {
              Text("إجمالي التكلفة:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text("${String.format(Locale.ENGLISH, "%.1f", itemTotalCost)} $currency", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = OrangePrimary)
            }
          }
        }
      }
    }
  }
}

// ================= TAB 1: INCOME STATEMENT (P&L) =================

@Composable
fun IncomeStatementTab(
  report: ProfitReportData,
  expensesByCategory: List<ExpenseCategoryStat>,
  onAddExpense: () -> Unit
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("قائمة الدخل والأرباح والخسائر الشاملة", fontWeight = FontWeight.Bold, fontSize = 15.sp)
              Text("بيان محاسبي معتمد لإيرادات وتكاليف السوبرماركت", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = EmeraldPrimary.copy(alpha = 0.15f)
            ) {
              Text(
                text = "هامش ربح: " + String.format(Locale.ENGLISH, "%.1f%%", report.profitMarginPercent),
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = EmeraldPrimary,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          HorizontalDivider()
          Spacer(modifier = Modifier.height(10.dp))

          // 1. Sales Revenue
          IncomeStatementRow(
            label = "1. إجمالي إيرادات المبيعات",
            amount = report.totalSales + report.totalDiscount,
            percentage = 100.0,
            color = MaterialTheme.colorScheme.primary,
            isHeader = true
          )
          if (report.totalDiscount > 0) {
            IncomeStatementRow(
              label = "    (-) خصومات مسموح بها للعملاء",
              amount = -report.totalDiscount,
              percentage = (report.totalDiscount / (report.totalSales + report.totalDiscount)) * 100.0,
              color = MaterialTheme.colorScheme.error
            )
          }
          IncomeStatementRow(
            label = "    (=) صافي إيرادات المبيعات",
            amount = report.totalSales,
            percentage = 100.0,
            color = MaterialTheme.colorScheme.primary,
            isBold = true
          )

          Spacer(modifier = Modifier.height(8.dp))
          HorizontalDivider()
          Spacer(modifier = Modifier.height(8.dp))

          // 2. Cost of Goods Sold (COGS)
          val cogsPct = if (report.totalSales > 0) (report.totalSalesCost / report.totalSales) * 100.0 else 0.0
          IncomeStatementRow(
            label = "2. (-) تكلفة البضاعة المباعة (COGS)",
            amount = -report.totalSalesCost,
            percentage = cogsPct,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            isHeader = true
          )

          Spacer(modifier = Modifier.height(8.dp))
          HorizontalDivider()
          Spacer(modifier = Modifier.height(8.dp))

          // 3. Gross Profit
          val grossMargin = if (report.totalSales > 0) (report.grossProfit / report.totalSales) * 100.0 else 0.0
          IncomeStatementRow(
            label = "3. (=) مجمل الربح من المبيعات",
            amount = report.grossProfit,
            percentage = grossMargin,
            color = EmeraldPrimary,
            isBold = true,
            isLarge = true
          )

          Spacer(modifier = Modifier.height(8.dp))
          HorizontalDivider()
          Spacer(modifier = Modifier.height(8.dp))

          // 4. Operating Expenses
          val expPct = if (report.totalSales > 0) (report.totalExpenses / report.totalSales) * 100.0 else 0.0
          IncomeStatementRow(
            label = "4. (-) إجمالي المصروفات التشغيلية",
            amount = -report.totalExpenses,
            percentage = expPct,
            color = MaterialTheme.colorScheme.error,
            isHeader = true
          )

          // Sub-itemized categories
          expensesByCategory.forEach { catStat ->
            IncomeStatementRow(
              label = "    • ${catStat.category}",
              amount = -catStat.totalAmount,
              percentage = if (report.totalSales > 0) (catStat.totalAmount / report.totalSales) * 100.0 else 0.0,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          if (report.totalAuditDiscrepancy != 0.0) {
            Spacer(modifier = Modifier.height(8.dp))
            IncomeStatementRow(
              label = "5. تسويات عجز / زيادة الجرد المخزني",
              amount = report.totalAuditDiscrepancy,
              percentage = 0.0,
              color = if (report.totalAuditDiscrepancy < 0) MaterialTheme.colorScheme.error else EmeraldPrimary
            )
          }

          Spacer(modifier = Modifier.height(10.dp))
          HorizontalDivider(thickness = 2.dp, color = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.height(10.dp))

          // 6. Net Profit
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .background(
                if (report.netProfit >= 0) EmeraldPrimary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.error.copy(alpha = 0.1f),
                RoundedCornerShape(8.dp)
              )
              .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("صافي الربح النهائي (Net Profit):", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
              Text("بعد خصم كافة التكاليف والمصروفات", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = String.format(Locale.ENGLISH, "%.2f ج.م", report.netProfit),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 17.sp,
                color = if (report.netProfit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
              )
              Text(
                text = String.format(Locale.ENGLISH, "هامش صافي: %.1f%%", report.profitMarginPercent),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (report.netProfit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
              )
            }
          }
        }
      }
    }

    // Expense Breakdown Section
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("توزيع بنود المصروفات التشغيلية", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Button(
          onClick = onAddExpense,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("إضافة مصروف", fontSize = 12.sp)
        }
      }
    }

    if (expensesByCategory.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
            Text("لا توجد بنود مصروفات في هذه الفترة", color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }

    items(expensesByCategory) { catStat ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(catStat.category, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(
              text = String.format(Locale.ENGLISH, "%.2f ج.م (%.1f%%)", catStat.totalAmount, catStat.percentage),
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.error,
              fontSize = 13.sp
            )
          }
          Spacer(modifier = Modifier.height(6.dp))
          LinearProgressIndicator(
            progress = { (catStat.percentage / 100f).toFloat().coerceIn(0f, 1f) },
            modifier = Modifier
              .fillMaxWidth()
              .height(6.dp)
              .clip(RoundedCornerShape(3.dp)),
            color = MaterialTheme.colorScheme.error,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
          )
        }
      }
    }
  }
}

// ================= TAB 2: TOP PRODUCTS =================

@Composable
fun TopProductsTab(
  topProducts: List<TopProductStat>
) {
  var sortByProfit by remember { mutableStateOf(false) }

  val sortedProducts = remember(topProducts, sortByProfit) {
    if (sortByProfit) {
      topProducts.sortedByDescending { it.totalProfit }
    } else {
      topProducts.sortedByDescending { it.totalRevenue }
    }
  }

  val maxMetric = remember(sortedProducts, sortByProfit) {
    if (sortByProfit) {
      sortedProducts.maxOfOrNull { it.totalProfit.coerceAtLeast(1.0) } ?: 1.0
    } else {
      sortedProducts.maxOfOrNull { it.totalRevenue.coerceAtLeast(1.0) } ?: 1.0
    }
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("ترتيب الأصناف والسلع الأكثر مبيعاً", fontWeight = FontWeight.Bold, fontSize = 15.sp)
          Text("${topProducts.size} صنف تم بيعه خلال هذه الفترة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // Toggle Sort Filter
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          FilterChip(
            selected = !sortByProfit,
            onClick = { sortByProfit = false },
            label = { Text("الأعلى إيراداً", fontSize = 11.sp) }
          )
          FilterChip(
            selected = sortByProfit,
            onClick = { sortByProfit = true },
            label = { Text("الأعلى ربحاً", fontSize = 11.sp) }
          )
        }
      }
    }

    if (sortedProducts.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
            Text("لا توجد مبيعات أصناف مسجلة في هذه الفترة المحددة", color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }

    items(sortedProducts.take(30)) { prodStat ->
      val rank = sortedProducts.indexOf(prodStat) + 1
      val medalColor = when (rank) {
        1 -> AmberPrimary
        2 -> Color(0xFFC0C0C0)
        3 -> Color(0xFFCD7F32)
        else -> MaterialTheme.colorScheme.primaryContainer
      }

      val metricVal = if (sortByProfit) prodStat.totalProfit else prodStat.totalRevenue
      val progress = (metricVal / maxMetric).toFloat().coerceIn(0f, 1f)

      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = CircleShape,
                color = medalColor,
                modifier = Modifier.size(28.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Text(
                    text = "#$rank",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (rank <= 3) Color.White else MaterialTheme.colorScheme.onPrimaryContainer
                  )
                }
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(prodStat.productName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                  text = "قسم: ${prodStat.category} • تم بيع ${prodStat.totalQuantitySold} ${prodStat.unitName}",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = String.format(Locale.ENGLISH, "%.2f ج.م", prodStat.totalRevenue),
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                text = String.format(Locale.ENGLISH, "ربح: +%.2f ج.م", prodStat.totalProfit),
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = EmeraldPrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
              .fillMaxWidth()
              .height(6.dp)
              .clip(RoundedCornerShape(3.dp)),
            color = if (sortByProfit) EmeraldPrimary else MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
          )
        }
      }
    }
  }
}

// ================= TAB 3: DEBT AGING & RECEIVABLES =================

@Composable
fun DebtAgingTab(
  report: ProfitReportData,
  debtList: List<DebtAgingStat>,
  customers: List<Customer>,
  onCollectDebt: (Customer) -> Unit
) {
  val customerMap = remember(customers) { customers.associateBy { it.id } }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Executive Debt Summary Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = OrangePrimary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("موقف الديون وأعمار المستحقات بالسوق", fontWeight = FontWeight.Bold, fontSize = 14.sp)
          }

          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Surface(
              color = EmeraldPrimary.copy(alpha = 0.12f),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f)
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text("ديون لنا عند العملاء:", fontSize = 11.sp, color = EmeraldPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f ج.م", report.totalCustomerDebts),
                  fontSize = 15.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = EmeraldPrimary
                )
              }
            }

            Surface(
              color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f)
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text("مستحقات علينا للموردين:", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f ج.م", report.totalSupplierDebts),
                  fontSize = 15.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = MaterialTheme.colorScheme.error
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          val netMarketBalance = report.totalCustomerDebts - report.totalSupplierDebts
          Text(
            text = String.format(
              Locale.ENGLISH,
              "صافي الموقف الائتماني بالسوق: %+.2f ج.م (%s)",
              netMarketBalance,
              if (netMarketBalance >= 0) "فائض مستحقات لنا" else "التزامات مستحقة علينا"
            ),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (netMarketBalance >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
          )
        }
      }
    }

    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("قائمة العملاء المدينين الأكثر تأخراً", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text("${debtList.size} عميل مدين", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }

    if (debtList.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
            Text("لا توجد ديون مستحقة على العملاء حالياً ✓", color = EmeraldPrimary, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    items(debtList, key = { it.customerId }) { debt ->
      val customerObj = customerMap[debt.customerId]
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(debt.customerName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
              Spacer(modifier = Modifier.width(6.dp))
              Surface(
                shape = RoundedCornerShape(4.dp),
                color = when (debt.overdueLevel) {
                  "تجاوز الحد الائتماني" -> MaterialTheme.colorScheme.error
                  "مديونية كبرى" -> OrangePrimary
                  else -> EmeraldPrimary.copy(alpha = 0.8f)
                }
              ) {
                Text(
                  text = debt.overdueLevel,
                  color = Color.White,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
              }
            }
            if (debt.phone.isNotEmpty()) {
              Text("هاتف: ${debt.phone}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (debt.creditLimit > 0) {
              Text("الحد الائتماني: ${String.format(Locale.ENGLISH, "%.0f", debt.creditLimit)} ج.م", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }

          Column(horizontalAlignment = Alignment.End) {
            Text(
              text = String.format(Locale.ENGLISH, "%.2f ج.م", debt.currentDebt),
              fontWeight = FontWeight.ExtraBold,
              fontSize = 14.sp,
              color = MaterialTheme.colorScheme.error
            )
            Spacer(modifier = Modifier.height(4.dp))
            if (customerObj != null) {
              Button(
                onClick = { onCollectDebt(customerObj) },
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(28.dp)
              ) {
                Text("تحصيل مبلغ", fontSize = 10.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }
}

// ================= TAB 4: CASH FLOW & DRAWER =================

@Composable
fun CashFlowDrawerTab(
  report: ProfitReportData,
  expenses: List<Expense>,
  onAddExpense: () -> Unit,
  onDeleteExpense: (Expense) -> Unit
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      CashDrawerCard(report = report)
    }

    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("سجل المصروفات النثرية والتشغيلية", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Button(
          onClick = onAddExpense,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("إضافة مصروف", fontSize = 12.sp)
        }
      }
    }

    if (expenses.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
            Text("لا توجد مصروفات مسجلة في هذا السجل", color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }

    items(expenses, key = { it.id }) { expense ->
      val dateStr = SimpleDateFormat("yyyy/MM/dd", Locale("ar")).format(Date(expense.timestamp))
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(expense.category, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            if (expense.notes.isNotEmpty()) {
              Text(expense.notes, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("المستلم: ${if (expense.recipient.isNotEmpty()) expense.recipient else "بدون"} • $dateStr", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = String.format(Locale.ENGLISH, "%.2f ج.م", expense.amount),
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.error,
              fontSize = 14.sp
            )
            Spacer(modifier = Modifier.width(4.dp))
            IconButton(onClick = { onDeleteExpense(expense) }, modifier = Modifier.size(28.dp)) {
              Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
            }
          }
        }
      }
    }
  }
}

// ================= CUSTOM CHARTS & GRAPHICAL COMPONENTS =================

@Composable
fun SalesAndProfitBarChart(
  trendPoints: List<SalesTrendPoint>,
  modifier: Modifier = Modifier
) {
  if (trendPoints.isEmpty()) {
    return
  }

  val maxVal = remember(trendPoints) {
    val m = trendPoints.maxOfOrNull { maxOf(it.sales, it.purchases, it.profit) } ?: 1.0
    if (m <= 0) 1.0 else m * 1.15
  }

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("المخطط البياني لحركة المبيعات والأرباح والتوريد", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
          ChartLegendItem(color = MaterialTheme.colorScheme.primary, text = "المبيعات")
          ChartLegendItem(color = EmeraldPrimary, text = "الأرباح")
          ChartLegendItem(color = AmberPrimary, text = "التوريد")
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      val primaryColor = MaterialTheme.colorScheme.primary
      val profitColor = EmeraldPrimary
      val purchaseColor = AmberPrimary
      val gridColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(175.dp)
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val width = size.width
          val height = size.height - 30.dp.toPx()
          val stepX = width / trendPoints.size.coerceAtLeast(1)
          val barWidth = (stepX * 0.22f).coerceIn(8.dp.toPx(), 22.dp.toPx())

          // Horizontal grid lines
          for (i in 0..2) {
            val y = height * (i / 2f)
            drawLine(
              color = gridColor,
              start = Offset(0f, y),
              end = Offset(width, y),
              strokeWidth = 1.dp.toPx()
            )
          }

          trendPoints.forEachIndexed { index, point ->
            val centerX = (index * stepX) + (stepX / 2f)

            // Sales bar
            val salesH = ((point.sales / maxVal) * height).toFloat().coerceAtLeast(3f)
            drawRoundRect(
              color = primaryColor,
              topLeft = Offset(centerX - barWidth * 1.5f, height - salesH),
              size = Size(barWidth, salesH),
              cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
            )

            // Profit bar
            val profitH = ((point.profit.coerceAtLeast(0.0) / maxVal) * height).toFloat().coerceAtLeast(3f)
            drawRoundRect(
              color = profitColor,
              topLeft = Offset(centerX - barWidth * 0.4f, height - profitH),
              size = Size(barWidth, profitH),
              cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
            )

            // Purchases bar
            val purchaseH = ((point.purchases / maxVal) * height).toFloat().coerceAtLeast(3f)
            drawRoundRect(
              color = purchaseColor,
              topLeft = Offset(centerX + barWidth * 0.7f, height - purchaseH),
              size = Size(barWidth, purchaseH),
              cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
            )
          }
        }

        // Labels at bottom
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.BottomCenter),
          horizontalArrangement = Arrangement.SpaceAround
        ) {
          trendPoints.forEach { pt ->
            Text(
              text = pt.label,
              fontSize = 10.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }
    }
  }
}

@Composable
fun ChartLegendItem(color: Color, text: String) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Box(
      modifier = Modifier
        .size(8.dp)
        .background(color, CircleShape)
    )
    Spacer(modifier = Modifier.width(3.dp))
    Text(text, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
  }
}

@Composable
fun PaymentMethodDistributionCard(report: ProfitReportData) {
  val total = (report.cashSalesAmount + report.creditSalesAmount + report.partialSalesAmount).coerceAtLeast(0.01)
  val cashRatio = (report.cashSalesAmount / total).toFloat().coerceIn(0f, 1f)
  val creditRatio = (report.creditSalesAmount / total).toFloat().coerceIn(0f, 1f)
  val partialRatio = (report.partialSalesAmount / total).toFloat().coerceIn(0f, 1f)

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text("توزيع طرق سداد المبيعات (كاش vs آجل)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
      Spacer(modifier = Modifier.height(10.dp))

      // Multi-segment progress bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .height(10.dp)
          .clip(RoundedCornerShape(5.dp))
      ) {
        if (cashRatio > 0f) {
          Box(
            modifier = Modifier
              .weight(cashRatio.coerceAtLeast(0.01f))
              .background(EmeraldPrimary)
          )
        }
        if (creditRatio > 0f) {
          Box(
            modifier = Modifier
              .weight(creditRatio.coerceAtLeast(0.01f))
              .background(OrangePrimary)
          )
        }
        if (partialRatio > 0f) {
          Box(
            modifier = Modifier
              .weight(partialRatio.coerceAtLeast(0.01f))
              .background(MaterialTheme.colorScheme.tertiary)
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).background(EmeraldPrimary, CircleShape))
            Spacer(modifier = Modifier.width(4.dp))
            Text("نقداً (كاش):", fontSize = 11.sp)
          }
          Text(
            text = String.format(Locale.ENGLISH, "%.1f ج.م (%d)", report.cashSalesAmount, report.cashSalesCount),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = EmeraldPrimary
          )
        }

        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).background(OrangePrimary, CircleShape))
            Spacer(modifier = Modifier.width(4.dp))
            Text("آجل (بالحساب):", fontSize = 11.sp)
          }
          Text(
            text = String.format(Locale.ENGLISH, "%.1f ج.م (%d)", report.creditSalesAmount, report.creditSalesCount),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = OrangePrimary
          )
        }

        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).background(MaterialTheme.colorScheme.tertiary, CircleShape))
            Spacer(modifier = Modifier.width(4.dp))
            Text("دفع جزئي:", fontSize = 11.sp)
          }
          Text(
            text = String.format(Locale.ENGLISH, "%.1f ج.م (%d)", report.partialSalesAmount, report.partialSalesCount),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.tertiary
          )
        }
      }
    }
  }
}

@Composable
fun TopProductsPreviewCard(
  topProducts: List<TopProductStat>,
  onViewAll: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Star, contentDescription = null, tint = AmberPrimary, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("أعلى الأصناف مبيعاً وتحقيقاً للأرباح", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Text(
          text = "عرض الكل",
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.primary,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.clickable { onViewAll() }
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      if (topProducts.isEmpty()) {
        Text("لا توجد مبيعات أصناف حتى الآن في هذه الفترة", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
      } else {
        topProducts.take(3).forEachIndexed { idx, prod ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("${idx + 1}. ${prod.productName}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(
              text = String.format(Locale.ENGLISH, "%.1f ج.م (ربح: +%.1f)", prod.totalRevenue, prod.totalProfit),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = EmeraldPrimary
            )
          }
        }
      }
    }
  }
}

@Composable
fun IncomeStatementRow(
  label: String,
  amount: Double,
  percentage: Double,
  color: Color,
  isHeader: Boolean = false,
  isBold: Boolean = false,
  isLarge: Boolean = false
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = if (isHeader) 4.dp else 2.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = label,
      fontWeight = if (isHeader || isBold) FontWeight.Bold else FontWeight.Normal,
      fontSize = if (isLarge) 14.sp else 12.sp,
      color = if (isHeader) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
      if (percentage > 0) {
        Text(
          text = String.format(Locale.ENGLISH, "%.1f%%", percentage),
          fontSize = 10.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.width(8.dp))
      }
      Text(
        text = String.format(Locale.ENGLISH, "%.2f ج.م", amount),
        fontWeight = if (isBold || isHeader) FontWeight.Bold else FontWeight.Normal,
        fontSize = if (isLarge) 14.sp else 12.sp,
        color = color
      )
    }
  }
}

// ================= HERO PROFIT & FINANCIAL POSITION CARDS =================

@Composable
fun HeroProfitCard(report: ProfitReportData) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (report.netProfit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
    )
  ) {
    Column(modifier = Modifier.padding(18.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("صافي الأرباح المحققة (Net Profit)", color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
        Surface(
          color = Color.White.copy(alpha = 0.2f),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(
            text = "هامش ربح: " + String.format(Locale.ENGLISH, "%.1f%%", report.profitMarginPercent),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = String.format(Locale.ENGLISH, "%.2f ج.م", report.netProfit),
        color = Color.White,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 28.sp
      )

      Spacer(modifier = Modifier.height(10.dp))
      HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "إجمالي أرباح البيع: " + String.format(Locale.ENGLISH, "%.2f ج.م", report.grossProfit),
          color = Color.White.copy(alpha = 0.9f),
          fontSize = 12.sp
        )
        Text(
          text = "خصم مصروفات: " + String.format(Locale.ENGLISH, "%.2f ج.م", report.totalExpenses),
          color = Color.White.copy(alpha = 0.9f),
          fontSize = 12.sp
        )
      }
    }
  }
}

@Composable
fun KpiCard(
  title: String,
  value: String,
  subtitle: String,
  icon: ImageVector,
  color: Color,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box(
          modifier = Modifier
            .size(30.dp)
            .background(color.copy(alpha = 0.12f), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
        }
      }
      Spacer(modifier = Modifier.height(6.dp))
      Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = color)
      Spacer(modifier = Modifier.height(2.dp))
      Text(subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}

@Composable
fun CashDrawerCard(report: ProfitReportData) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.LocalAtm, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Text("حركة الخزينة والدرج (الكاش الفعلي)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Text(
          text = String.format(Locale.ENGLISH, "الرصيد: %.2f ج.م", report.cashDrawerBalance),
          fontWeight = FontWeight.Bold,
          color = if (report.cashDrawerBalance >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error,
          fontSize = 14.sp
        )
      }

      Spacer(modifier = Modifier.height(10.dp))
      HorizontalDivider()
      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(14.dp))
            Text("المقبوضات النقدية (داخل):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Text("• مبيعات كاش: " + String.format(Locale.ENGLISH, "%.1f", report.cashInSales), fontSize = 11.sp)
          Text("• تحصيل من عملاء: " + String.format(Locale.ENGLISH, "%.1f", report.cashInCustomerPayments), fontSize = 11.sp)
        }

        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(14.dp))
            Text("المدفوعات النقدية (خارج):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Text("• مشتريات كاش: " + String.format(Locale.ENGLISH, "%.1f", report.cashOutPurchases), fontSize = 11.sp)
          Text("• سداد موردين: " + String.format(Locale.ENGLISH, "%.1f", report.cashOutSupplierPayments), fontSize = 11.sp)
          Text("• مصروفات: " + String.format(Locale.ENGLISH, "%.1f", report.totalExpenses), fontSize = 11.sp)
        }
      }
    }
  }
}

@Composable
fun FinancialPositionCard(report: ProfitReportData) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text("المركز المالي الشامل لسوبر ماركت الجملة", fontWeight = FontWeight.Bold, fontSize = 14.sp)
      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("قيمة بضاعة المخزن (بسعر التكلفة):", fontSize = 12.sp)
        Text(
          text = String.format(Locale.ENGLISH, "%.2f ج.م", report.totalInventoryCostValue),
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary,
          fontSize = 12.sp
        )
      }
      Spacer(modifier = Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("ديون ومستحقات على العملاء (لنا بالسوق):", fontSize = 12.sp)
        Text(
          text = String.format(Locale.ENGLISH, "%.2f ج.م", report.totalCustomerDebts),
          fontWeight = FontWeight.Bold,
          color = EmeraldPrimary,
          fontSize = 12.sp
        )
      }
      Spacer(modifier = Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("مستحقات والتزامات للموردين (علينا):", fontSize = 12.sp)
        Text(
          text = String.format(Locale.ENGLISH, "%.2f ج.م", report.totalSupplierDebts),
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.error,
          fontSize = 12.sp
        )
      }

      val netWorkingCapital = report.totalInventoryCostValue + report.totalCustomerDebts - report.totalSupplierDebts
      Spacer(modifier = Modifier.height(8.dp))
      HorizontalDivider()
      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("صافي رأس المال المتداول العامل:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(
          text = String.format(Locale.ENGLISH, "%.2f ج.م", netWorkingCapital),
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp,
          color = MaterialTheme.colorScheme.primary
        )
      }
    }
  }
}

// ================= DIALOGS =================

@Composable
fun ExportReportDialog(
  report: ProfitReportData,
  period: ReportPeriod,
  topProducts: List<TopProductStat>,
  expensesByCategory: List<ExpenseCategoryStat> = emptyList(),
  businessName: String = "الوكيل لتجارة المواد الغذائية",
  phone: String = "",
  address: String = "",
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val dateStr = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.ENGLISH).format(Date())

  val summaryText = buildString {
    appendLine("══════════════════════════════════")
    appendLine("📊 التقرير المالي لسوبر ماركت الجملة ($businessName)")
    appendLine("الفترة: ${period.label} | التاريخ: $dateStr")
    appendLine("══════════════════════════════════")
    appendLine("• إجمالي المبيعات: ${String.format(Locale.ENGLISH, "%.2f", report.totalSales)} ج.م (${report.salesCount} فاتورة)")
    appendLine("• تكلفة البضاعة المباعة (WAC): ${String.format(Locale.ENGLISH, "%.2f", report.totalSalesCost)} ج.م")
    appendLine("• مجمل أرباح البيع: ${String.format(Locale.ENGLISH, "%.2f", report.grossProfit)} ج.م")
    appendLine("• إجمالي المصروفات التشغيلية: ${String.format(Locale.ENGLISH, "%.2f", report.totalExpenses)} ج.م")
    appendLine("• صافي الأرباح المحققة: ${String.format(Locale.ENGLISH, "%.2f", report.netProfit)} ج.م")
    appendLine("• نسبة هامش الربح: ${String.format(Locale.ENGLISH, "%.1f%%", report.profitMarginPercent)}")
    appendLine("──────────────────────────────────")
    appendLine("💵 حركة السيولة والخزينة:")
    appendLine("• رصيد الخزينة والدرج: ${String.format(Locale.ENGLISH, "%.2f", report.cashDrawerBalance)} ج.م")
    appendLine("• المقبوضات النقدية: ${String.format(Locale.ENGLISH, "%.2f", report.cashInSales + report.cashInCustomerPayments)} ج.م")
    appendLine("• المدفوعات النقدية: ${String.format(Locale.ENGLISH, "%.2f", report.cashOutPurchases + report.cashOutSupplierPayments + report.totalExpenses)} ج.م")
    appendLine("──────────────────────────────────")
    appendLine("📦 الموقف المالي العام ورأس المال:")
    appendLine("• بضاعة المخزن بالتكلفة: ${String.format(Locale.ENGLISH, "%.2f", report.totalInventoryCostValue)} ج.م")
    appendLine("• ديون لنا عند العملاء: ${String.format(Locale.ENGLISH, "%.2f", report.totalCustomerDebts)} ج.م")
    appendLine("• ديون علينا للموردين: ${String.format(Locale.ENGLISH, "%.2f", report.totalSupplierDebts)} ج.م")
    if (topProducts.isNotEmpty()) {
      appendLine("──────────────────────────────────")
      appendLine("🏆 أعلى الأصناف مبيعاً:")
      topProducts.take(3).forEachIndexed { i, p ->
        appendLine("${i + 1}. ${p.productName} - ${String.format(Locale.ENGLISH, "%.1f", p.totalRevenue)} ج.م")
      }
    }
    appendLine("══════════════════════════════════")
  }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.95f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Description, contentDescription = null, tint = EmeraldPrimary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("طباعة وتصدير التقرير المالي", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // معاينة التقرير النصي
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.surfaceVariant,
          modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
        ) {
          LazyColumn(modifier = Modifier.padding(10.dp)) {
            item {
              Text(
                text = summaryText,
                fontSize = 11.sp,
                lineHeight = 16.sp
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // الصف 1: الطباعة المباشرة ومشاركة PDF
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = {
              ReportExportHelper.printReportViaSystem(
                context = context,
                report = report,
                period = period,
                businessName = businessName,
                phone = phone,
                address = address,
                topProducts = topProducts,
                expensesByCategory = expensesByCategory,
                customTitle = "التقرير المالي وقائمة الأرباح والدخل"
              )
            },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(6.dp))
            Text("طباعة ورقية", fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = {
              val pdfFile = ReportExportHelper.generateFinancialReportPdf(
                context = context,
                report = report,
                period = period,
                businessName = businessName,
                phone = phone,
                address = address,
                topProducts = topProducts,
                expensesByCategory = expensesByCategory,
                customTitle = "التقرير المالي وقائمة الأرباح والدخل"
              )
              ReportExportHelper.shareFile(
                context = context,
                file = pdfFile,
                mimeType = "application/pdf",
                title = "مشاركة التقرير المالي PDF"
              )
            },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("مشاركة PDF", fontWeight = FontWeight.Bold)
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // الصف 2: مشاركة كصورة ومشاركة نصية
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val imgFile = ReportExportHelper.generateFinancialReportImage(
                context = context,
                report = report,
                period = period,
                businessName = businessName,
                topProducts = topProducts,
                customTitle = "التقرير المالي وقائمة الأرباح والدخل"
              )
              ReportExportHelper.shareFile(
                context = context,
                file = imgFile,
                mimeType = "image/png",
                title = "مشاركة صورة التقرير المالي"
              )
            },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("مشاركة صورة", fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = {
              val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, summaryText)
                type = "text/plain"
              }
              val shareIntent = Intent.createChooser(sendIntent, "مشاركة التقرير المالي عبر")
              context.startActivity(shareIntent)
            },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("واتساب / نص", fontWeight = FontWeight.Bold)
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // زر نسخ النص للحافظة
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.Center
        ) {
          OutlinedButton(
            onClick = {
              val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
              val clip = ClipData.newPlainText("Financial Report", summaryText)
              clipboard.setPrimaryClip(clip)
              Toast.makeText(context, "تم نسخ التقرير المالي إلى الحافظة بنجاح ✓", Toast.LENGTH_SHORT).show()
            },
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)
          ) {
            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("نسخ النص إلى الحافظة", fontSize = 11.sp)
          }
        }
      }
    }
  }
}

@Composable
fun CollectCustomerPaymentDialog(
  customer: Customer,
  onDismiss: () -> Unit,
  onConfirm: (amount: Double, notes: String) -> Unit
) {
  var amountStr by remember { mutableStateOf(if (customer.currentBalance > 0) customer.currentBalance.toString() else "") }
  var notes by remember { mutableStateOf("دفعة سداد حساب من العميل") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(0.95f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("سند قبض نقدي (تحصيل دين)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(customer.name, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        HorizontalDivider()

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.error.copy(alpha = 0.1f),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("إجمالي مديونية العميل الحالية:", fontSize = 12.sp)
            Text(
              text = String.format(Locale.ENGLISH, "%.2f ج.م", customer.currentBalance),
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.error,
              fontSize = 13.sp
            )
          }
        }

        OutlinedTextField(
          value = amountStr,
          onValueChange = { amountStr = it },
          label = { Text("المبلغ المحصل نقداً (ج.م) *") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("البيان والملاحظات") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val amt = amountStr.toDoubleOrNull() ?: 0.0
              if (amt > 0) {
                onConfirm(amt, notes.trim())
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            modifier = Modifier.weight(1f)
          ) {
            Text("تأكيد القبض وإيداع الخزينة", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

@Composable
fun AddExpenseDialog(
  onDismiss: () -> Unit,
  onSave: (category: String, amount: Double, recipient: String, notes: String) -> Unit
) {
  val defaultCategories = listOf(
    "إيجار المحل والمخزن",
    "كهرباء ومياه وتبريد",
    "مرتبات وأجور عمال",
    "نقل ومشالات وبضاعة",
    "صيانة ومعدات",
    "نثريات وضيافة وأدوات نظافة"
  )

  var category by remember { mutableStateOf(defaultCategories[0]) }
  var showCategoryMenu by remember { mutableStateOf(false) }
  var amountText by remember { mutableStateOf("") }
  var recipient by remember { mutableStateOf("") }
  var notes by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("إضافة بند مصروف جديد", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        // Category Selector
        Box {
          OutlinedButton(
            onClick = { showCategoryMenu = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("البند:")
              Text(category, fontWeight = FontWeight.Bold)
            }
          }

          DropdownMenu(
            expanded = showCategoryMenu,
            onDismissRequest = { showCategoryMenu = false }
          ) {
            defaultCategories.forEach { cat ->
              DropdownMenuItem(
                text = { Text(cat) },
                onClick = {
                  category = cat
                  showCategoryMenu = false
                }
              )
            }
          }
        }

        OutlinedTextField(
          value = amountText,
          onValueChange = { amountText = it },
          label = { Text("المبلغ (ج.م) *") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = recipient,
          onValueChange = { recipient = it },
          label = { Text("المستلم (اختياري)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("ملاحظات وبيان المصروف") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val amt = amountText.toDoubleOrNull() ?: 0.0
              if (amt > 0) {
                onSave(category, amt, recipient.trim(), notes.trim())
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            modifier = Modifier.weight(1f)
          ) {
            Text("تسجيل المصروف", fontWeight = FontWeight.Bold)
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}
