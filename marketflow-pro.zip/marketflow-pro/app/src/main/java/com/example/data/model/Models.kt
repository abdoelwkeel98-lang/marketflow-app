package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val barcode: String = "",
  val category: String = "عام",
  val unitName: String = "قطعة",        // e.g. قطعة, علبة, كيس, زجاجة
  val cartonName: String = "كرتونة",    // e.g. كرتونة, صندوق, باكت
  val piecesPerCarton: Int = 12,       // عدد القطع في الكرتونة
  val cartonCostPrice: Double = 0.0,    // سعر شراء الكرتونة
  val cartonWholesalePrice: Double = 0.0, // سعر بيع الكرتونة جملة
  val cartonSemiWholesalePrice: Double = 0.0, // سعر بيع الكرتونة نصف جملة
  val pieceWholesalePrice: Double = 0.0,  // سعر بيع القطعة جملة
  val pieceRetailPrice: Double = 0.0,     // سعر بيع القطعة قطاعي للمستهلك
  val totalPiecesInStock: Int = 0,      // إجمالي الرصيد بالمخزن بالقطع
  val minStockAlert: Int = 24,          // حد التنبيه بنقص المخزون بالقطع
  val createdAt: Long = System.currentTimeMillis()
) {
  // Helpers to display stock as Cartons + remaining pieces
  val cartonsInStock: Int get() = if (piecesPerCarton > 0) totalPiecesInStock / piecesPerCarton else 0
  val remainingPiecesInStock: Int get() = if (piecesPerCarton > 0) totalPiecesInStock % piecesPerCarton else totalPiecesInStock
  val pieceCostPrice: Double get() = if (piecesPerCarton > 0) cartonCostPrice / piecesPerCarton else 0.0

  fun stockDisplayString(): String {
    return if (piecesPerCarton > 1) {
      if (cartonsInStock > 0 && remainingPiecesInStock > 0) {
        "$cartonsInStock $cartonName و $remainingPiecesInStock $unitName"
      } else if (cartonsInStock > 0) {
        "$cartonsInStock $cartonName"
      } else {
        "$remainingPiecesInStock $unitName"
      }
    } else {
      "$totalPiecesInStock $unitName"
    }
  }
}

@Entity(tableName = "customers")
data class Customer(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val phone: String = "",
  val address: String = "",
  val creditLimit: Double = 0.0,
  val currentBalance: Double = 0.0, // موجب = العميل مدين لنا بالمبلغ (عليه فلوس)
  val notes: String = "",
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "suppliers")
data class Supplier(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val phone: String = "",
  val company: String = "",
  val currentBalance: Double = 0.0, // موجب = نحن مدينون للمورد (له فلوس)
  val notes: String = "",
  val createdAt: Long = System.currentTimeMillis()
)

enum class InvoiceType {
  SALE,     // فاتورة بيع
  PURCHASE  // فاتورة شراء من مورد
}

enum class PaymentType {
  CASH,     // نقدي كاش
  CREDIT,   // آجل بالكامل
  PARTIAL   // جزء كاش وجزء آجل
}

@Entity(tableName = "invoices")
data class Invoice(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val invoiceNumber: String,
  val type: InvoiceType,
  val partyId: Long = 0,        // Customer ID if SALE, Supplier ID if PURCHASE, 0 if cash walk-in
  val partyName: String = "عميل نقدي",
  val timestamp: Long = System.currentTimeMillis(),
  val subtotal: Double = 0.0,
  val discount: Double = 0.0,
  val totalAmount: Double = 0.0,
  val paidAmount: Double = 0.0,
  val remainingAmount: Double = 0.0,
  val paymentType: PaymentType = PaymentType.CASH,
  val totalCost: Double = 0.0,       // For sales: total cost of items sold
  val totalProfit: Double = 0.0,     // totalAmount - totalCost
  val previousBalance: Double = 0.0, // رصيد سابق للعميل أو المورد قبل الفاتورة
  val grandTotalDue: Double = 0.0,   // إجمالي الحساب الكلي المستحق بعد الفاتورة (previousBalance + remainingAmount)
  val notes: String = "",
  // Delegate & Employee Tagging
  val employeeId: Long = 0L,
  val employeeName: String = "",
  val isDelegateInvoice: Boolean = false,
  val syncStatus: String = "SYNCED", // "SYNCED", "PENDING_SYNC"
  val delegateDeviceId: String = ""
)

@Entity(
  tableName = "invoice_items",
  foreignKeys = [
    ForeignKey(
      entity = Invoice::class,
      parentColumns = ["id"],
      childColumns = ["invoiceId"],
      onDelete = ForeignKey.CASCADE
    )
  ],
  indices = [Index("invoiceId"), Index("productId")]
)
data class InvoiceItem(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val invoiceId: Long = 0,
  val productId: Long = 0,
  val productName: String,
  val unitType: String,              // "كرتونة" أو "قطعة"
  val quantity: Int,                 // كمية الكراتين أو القطع
  val piecesPerCarton: Int,
  val totalPieces: Int,              // إجمالي القطع الفعلية
  val unitPrice: Double,             // سعر البيع أو الشراء للوحدة المحددة
  val unitCost: Double,              // سعر التكلفة للوحدة المحددة
  val totalPrice: Double,            // quantity * unitPrice
  val totalCost: Double,             // totalPieces * (cost per piece)
  val itemProfit: Double = 0.0       // totalPrice - totalCost (للبيع)
)

enum class TransactionType {
  CUSTOMER_PAYMENT, // سند قبض من عميل (سداد مديونية)
  SUPPLIER_PAYMENT, // سند صرف لمورد (سداد مستحقات)
  CASH_DEPOSIT,     // إيداع نقدية بالخزينة (تغذية الخزينة / رأس مال / تمويل)
  CASH_WITHDRAWAL   // سحب نقدي من الخزينة
}

@Entity(tableName = "payment_transactions")
data class PaymentTransaction(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val type: TransactionType,
  val partyId: Long,
  val partyName: String,
  val amount: Double,
  val notes: String = "",
  val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "expenses")
data class Expense(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val category: String,             // إيجار، كهرباء، مرتبات، مشالات، نثريات
  val amount: Double,
  val recipient: String = "",       // المستلم
  val notes: String = "",
  val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "stock_audits")
data class StockAudit(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val auditDate: Long = System.currentTimeMillis(),
  val title: String = "جرد مخزني",
  val totalDiscrepancyValue: Double = 0.0, // القيمة المالية للعجز أو الزيادة
  val notes: String = ""
)

@Entity(
  tableName = "stock_audit_items",
  foreignKeys = [
    ForeignKey(
      entity = StockAudit::class,
      parentColumns = ["id"],
      childColumns = ["auditId"],
      onDelete = ForeignKey.CASCADE
    )
  ],
  indices = [Index("auditId")]
)
data class StockAuditItem(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val auditId: Long = 0,
  val productId: Long,
  val productName: String,
  val systemQuantity: Int,     // الكمية المسجلة بالنظام (بالقطع)
  val actualQuantity: Int,     // الكمية الفعلية عند العد (بالقطع)
  val diffQuantity: Int,       // actual - system
  val unitPieceCost: Double,
  val diffCostValue: Double    // diffQuantity * unitPieceCost
)

// ==========================================
// Double-Entry Accounting & Financial Models
// ==========================================

@Entity(tableName = "accounts")
data class Account(
  @PrimaryKey val code: String,          // e.g. "101", "102", "103", "201", "301", "401", "501", "502", "503"
  val name: String,                      // e.g. "الصندوق والخزينة النقدية"
  val category: String,                  // "أصول متداولة", "خصوم متداولة", "حقوق ملكية", "إيرادات", "تكلفة المبيعات", "مصروفات تشغيلية"
  val normalBalance: String = "DEBIT",    // "DEBIT" (مدين) or "CREDIT" (دائن)
  val initialBalance: Double = 0.0,
  val description: String = ""
)

@Entity(tableName = "journal_entries")
data class JournalEntry(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val entryNumber: String,              // e.g. "JE-240925-001"
  val timestamp: Long = System.currentTimeMillis(),
  val description: String,               // بيان القيد
  val referenceType: String = "MANUAL",  // SALE, PURCHASE, CUSTOMER_PAYMENT, SUPPLIER_PAYMENT, EXPENSE, AUDIT
  val referenceId: Long = 0L,
  val totalDebit: Double = 0.0,
  val totalCredit: Double = 0.0,
  val isBalanced: Boolean = true
)

@Entity(
  tableName = "journal_lines",
  foreignKeys = [
    ForeignKey(
      entity = JournalEntry::class,
      parentColumns = ["id"],
      childColumns = ["entryId"],
      onDelete = ForeignKey.CASCADE
    )
  ],
  indices = [Index("entryId"), Index("accountCode")]
)
data class JournalLine(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val entryId: Long = 0,
  val accountCode: String,
  val accountName: String,
  val debit: Double = 0.0,
  val credit: Double = 0.0,
  val notes: String = ""
)

// UI models for Trial Balance & Ledger
data class TrialBalanceRow(
  val accountCode: String,
  val accountName: String,
  val category: String,
  val normalBalance: String,
  val totalDebit: Double,
  val totalCredit: Double,
  val netDebitBalance: Double,
  val netCreditBalance: Double
)

data class GeneralLedgerEntry(
  val timestamp: Long,
  val entryNumber: String,
  val description: String,
  val debit: Double,
  val credit: Double,
  val runningBalance: Double
)

// ==========================================
// Multi-Employee & Delegate System Models
// ==========================================

@Entity(tableName = "employees")
data class Employee(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val phone: String = "",
  val pinCode: String = "1234",
  val role: String = "كاشير", // "مدير عام", "كاشير", "مندوب مبيعات", "محاسب", "أمين مخزن"
  val isDelegate: Boolean = false, // مندوب مبيعات وتوزيع ميداني
  val isActive: Boolean = true,
  // Permissions (صلاحيات مخصصة يحددها المدير)
  val canSell: Boolean = true,
  val canViewCostPrice: Boolean = false,
  val canViewProfits: Boolean = false,
  val canGiveDiscount: Boolean = true,
  val canManualPriceOverride: Boolean = false,
  val canPurchase: Boolean = false,
  val canManageWarehouse: Boolean = false,
  val canManageCustomers: Boolean = true,
  val canCollectCash: Boolean = true,
  val canDeleteInvoice: Boolean = false,
  val canAccessReports: Boolean = false,
  val canAccessSettings: Boolean = false,
  val pairingCode: String = "",
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "delegate_sync_logs")
data class DelegateSyncLog(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val timestamp: Long = System.currentTimeMillis(),
  val delegateName: String,
  val delegateId: Long = 0L,
  val invoicesCount: Int = 0,
  val totalSalesAmount: Double = 0.0,
  val status: String = "SUCCESS", // "SUCCESS", "PENDING", "FAILED"
  val syncType: String = "AUTO_CLOUD", // "AUTO_CLOUD", "OFFLINE_PACKAGE", "LOCAL_NET"
  val notes: String = ""
)


