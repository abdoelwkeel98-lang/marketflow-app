package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.WholesaleRepository
import com.example.data.dao.AppDao
import com.example.utils.BackupManager
import com.example.utils.DelegateSyncManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.example.data.model.Account
import com.example.data.model.Customer
import com.example.data.model.DelegateSyncLog
import com.example.data.model.Employee
import com.example.data.model.Expense
import com.example.data.model.GeneralLedgerEntry
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItem
import com.example.data.model.InvoiceType
import com.example.data.model.JournalEntry
import com.example.data.model.JournalLine
import com.example.data.model.PaymentTransaction
import com.example.data.model.PaymentType
import com.example.data.model.Product
import com.example.data.model.StockAudit
import com.example.data.model.StockAuditItem
import com.example.data.model.Supplier
import com.example.data.model.TrialBalanceRow
import com.example.data.settings.BusinessPreferences
import com.example.data.settings.BusinessProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class PriceTier(val label: String) {
  WHOLESALE("سعر جملة"),
  SEMI_WHOLESALE("نصف جملة"),
  RETAIL("سعر قطاعي")
}

data class CartItem(
  val product: Product,
  val unitType: String = "علبة", // "علبة" (الأساسية للمبيعات) or "كرتونة"
  val priceTier: PriceTier = PriceTier.WHOLESALE,
  val quantity: Int = 1,
  val customPrice: Double? = null
) {
  val unitPrice: Double get() = customPrice ?: when {
    unitType == "كرتونة" -> when (priceTier) {
      PriceTier.WHOLESALE -> if (product.cartonWholesalePrice > 0.0) product.cartonWholesalePrice else (product.pieceRetailPrice * product.piecesPerCarton)
      PriceTier.SEMI_WHOLESALE -> if (product.cartonSemiWholesalePrice > 0.0) product.cartonSemiWholesalePrice else if (product.cartonWholesalePrice > 0.0) product.cartonWholesalePrice else (product.pieceRetailPrice * product.piecesPerCarton)
      PriceTier.RETAIL -> if (product.pieceRetailPrice > 0.0 && product.piecesPerCarton > 0) product.pieceRetailPrice * product.piecesPerCarton else product.cartonWholesalePrice
    }
    else -> when (priceTier) {
      PriceTier.WHOLESALE -> if (product.pieceWholesalePrice > 0.0) product.pieceWholesalePrice else if (product.piecesPerCarton > 0 && product.cartonWholesalePrice > 0.0) product.cartonWholesalePrice / product.piecesPerCarton else product.pieceRetailPrice
      PriceTier.SEMI_WHOLESALE -> if (product.piecesPerCarton > 0 && product.cartonSemiWholesalePrice > 0.0) product.cartonSemiWholesalePrice / product.piecesPerCarton else if (product.pieceWholesalePrice > 0.0) product.pieceWholesalePrice else product.pieceRetailPrice
      PriceTier.RETAIL -> if (product.pieceRetailPrice > 0.0) product.pieceRetailPrice else if (product.piecesPerCarton > 0 && product.cartonWholesalePrice > 0.0) product.cartonWholesalePrice / product.piecesPerCarton else 0.0
    }
  }

  val unitCostPrice: Double get() = if (unitType == "كرتونة") product.cartonCostPrice else product.pieceCostPrice
  val isSellingAtLoss: Boolean get() = unitPrice < unitCostPrice
  val lossPerUnit: Double get() = (unitCostPrice - unitPrice).coerceAtLeast(0.0)
  val marginPercent: Double get() = if (unitCostPrice > 0) ((unitPrice - unitCostPrice) / unitCostPrice) * 100.0 else 0.0

  val totalPieces: Int get() = if (unitType == "كرتونة") quantity * product.piecesPerCarton else quantity
  val totalPrice: Double get() = quantity * unitPrice
  val totalCost: Double get() = totalPieces * product.pieceCostPrice
  val itemProfit: Double get() = totalPrice - totalCost
}

data class PurchaseCartItem(
  val product: Product,
  val unitType: String = "كرتونة",
  val quantity: Int = 1,
  val unitCostPrice: Double
) {
  val totalPieces: Int get() = if (unitType == "كرتونة") quantity * product.piecesPerCarton else quantity
  val totalPrice: Double get() = quantity * unitCostPrice
}

enum class ReportPeriod(val label: String) {
  TODAY("اليوم"),
  YESTERDAY("أمس"),
  CUSTOM_DAY("يوم مخصص"),
  CUSTOM_RANGE("مدة معينة"),
  THIS_WEEK("هذا الأسبوع"),
  THIS_MONTH("هذا الشهر"),
  THIS_YEAR("هذا العام"),
  ALL_TIME("الكل")
}

data class TopProductStat(
  val productId: Long,
  val productName: String,
  val category: String,
  val totalQuantitySold: Int,
  val totalRevenue: Double,
  val totalCost: Double,
  val totalProfit: Double,
  val unitName: String
)

data class ExpenseCategoryStat(
  val category: String,
  val totalAmount: Double,
  val count: Int,
  val percentage: Double
)

data class DebtAgingStat(
  val customerId: Long,
  val customerName: String,
  val phone: String,
  val currentDebt: Double,
  val creditLimit: Double,
  val overdueLevel: String
)

data class SalesTrendPoint(
  val label: String,
  val sales: Double,
  val profit: Double,
  val purchases: Double
)

data class ProfitReportData(
  val totalSales: Double = 0.0,
  val totalSalesCost: Double = 0.0,
  val grossProfit: Double = 0.0,
  val totalExpenses: Double = 0.0,
  val netProfit: Double = 0.0,
  val profitMarginPercent: Double = 0.0,
  val totalPurchases: Double = 0.0,
  val cashInSales: Double = 0.0,
  val cashInCustomerPayments: Double = 0.0,
  val cashInDeposits: Double = 0.0,         // إيداعات نقدية وتغذية الخزينة
  val cashOutPurchases: Double = 0.0,
  val cashOutSupplierPayments: Double = 0.0,
  val cashOutWithdrawals: Double = 0.0,     // مسحوبات نقدية من الخزينة
  val cashDrawerBalance: Double = 0.0, // الرصيد النقدي الفعلي بالخزينة
  val totalInventoryCostValue: Double = 0.0, // إجمالي قيمة بضاعة المخزن بالتكلفة WAC
  val totalCustomerDebts: Double = 0.0,     // إجمالي ديون العملاء
  val totalSupplierDebts: Double = 0.0,     // إجمالي مستحقات الموردين
  val salesCount: Int = 0,
  val purchasesCount: Int = 0,
  val cashSalesAmount: Double = 0.0,
  val creditSalesAmount: Double = 0.0,
  val partialSalesAmount: Double = 0.0,
  val cashSalesCount: Int = 0,
  val creditSalesCount: Int = 0,
  val partialSalesCount: Int = 0,
  val totalDiscount: Double = 0.0,
  val totalAuditDiscrepancy: Double = 0.0
)

class WholesaleViewModel(application: Application) : AndroidViewModel(application) {

  private val appDao: AppDao
  private val repository: WholesaleRepository
  val businessPreferences = BusinessPreferences(application)
  val businessProfile: StateFlow<BusinessProfile> = businessPreferences.profile

  init {
    val db = AppDatabase.getDatabase(application, viewModelScope)
    appDao = db.appDao()
    repository = WholesaleRepository(appDao)
    viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
      try {
        AppDatabase.populateInitialData(appDao)
        checkAndPerformDailyAutoBackup()
      } catch (e: Exception) {
        android.util.Log.e("WholesaleVM", "Error populating initial data", e)
      }
    }
  }

  // Repository Streams
  val products: StateFlow<List<Product>> = repository.allProducts
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val customers: StateFlow<List<Customer>> = repository.allCustomers
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val suppliers: StateFlow<List<Supplier>> = repository.allSuppliers
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val salesInvoices: StateFlow<List<Invoice>> = repository.salesInvoices
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val purchaseInvoices: StateFlow<List<Invoice>> = repository.purchaseInvoices
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val invoiceItems: StateFlow<List<InvoiceItem>> = repository.allInvoiceItems
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val transactions: StateFlow<List<PaymentTransaction>> = repository.allTransactions
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val expenses: StateFlow<List<Expense>> = repository.allExpenses
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val stockAudits: StateFlow<List<StockAudit>> = repository.allStockAudits
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Employees & Delegates Streams
  val allEmployees: StateFlow<List<Employee>> = repository.allEmployees
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val activeDelegates: StateFlow<List<Employee>> = repository.activeDelegates
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val delegateSyncLogs: StateFlow<List<DelegateSyncLog>> = repository.allSyncLogs
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val pendingSyncInvoices: StateFlow<List<Invoice>> = repository.pendingSyncInvoices
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // حالة قفل الشاشة والتحقق الأمني بالبصمة / PIN للموظف
  private val _isScreenLocked = MutableStateFlow(true)
  val isScreenLocked: StateFlow<Boolean> = _isScreenLocked.asStateFlow()

  fun setScreenLocked(locked: Boolean) {
    _isScreenLocked.value = locked
  }

  // --- Double-Entry Accounting Streams (دليل الحسابات وقيود اليومية) ---
  val accounts: StateFlow<List<Account>> = repository.allAccounts
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val journalEntries: StateFlow<List<JournalEntry>> = repository.allJournalEntries
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val journalLines: StateFlow<List<JournalLine>> = repository.allJournalLines
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Trial Balance (ميزان المراجعة بالمجاميع والأرصدة)
  val trialBalance: StateFlow<List<TrialBalanceRow>> = combine(accounts, journalLines) { accts, lines ->
    val linesByAccount = lines.groupBy { it.accountCode }
    accts.map { account ->
      val accLines = linesByAccount[account.code] ?: emptyList()
      val totalDebit = accLines.sumOf { it.debit }
      val totalCredit = accLines.sumOf { it.credit }
      val diff = totalDebit - totalCredit
      val netDebit = if (account.normalBalance == "DEBIT") {
        if (diff > 0) diff else 0.0
      } else {
        if (diff > 0) diff else 0.0
      }
      val netCredit = if (account.normalBalance == "CREDIT") {
        if (diff < 0) -diff else 0.0
      } else {
        if (diff < 0) -diff else 0.0
      }
      TrialBalanceRow(
        accountCode = account.code,
        accountName = account.name,
        category = account.category,
        normalBalance = account.normalBalance,
        totalDebit = totalDebit,
        totalCredit = totalCredit,
        netDebitBalance = netDebit,
        netCreditBalance = netCredit
      )
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val trialBalanceTotals: StateFlow<Pair<Double, Double>> = trialBalance.combine(MutableStateFlow(Unit)) { rows, _ ->
    val sumDebit = rows.sumOf { it.totalDebit }
    val sumCredit = rows.sumOf { it.totalCredit }
    Pair(sumDebit, sumCredit)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Pair(0.0, 0.0))

  val isTrialBalanceBalanced: StateFlow<Boolean> = trialBalanceTotals.combine(MutableStateFlow(Unit)) { totals, _ ->
    kotlin.math.abs(totals.first - totals.second) < 0.01
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

  // Low Stock Alert (نواقص المخزن)
  val lowStockProducts: StateFlow<List<Product>> = products
    .combine(MutableStateFlow(Unit)) { list, _ ->
      list.filter { it.totalPiecesInStock <= it.minStockAlert }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // --- SALES CART STATE ---
  private val _salesCart = MutableStateFlow<List<CartItem>>(emptyList())
  val salesCart: StateFlow<List<CartItem>> = _salesCart.asStateFlow()

  private val _selectedCustomer = MutableStateFlow<Customer?>(null)
  val selectedCustomer: StateFlow<Customer?> = _selectedCustomer.asStateFlow()

  private val _saleDiscount = MutableStateFlow(0.0)
  val saleDiscount: StateFlow<Double> = _saleDiscount.asStateFlow()

  private val _salePaidAmount = MutableStateFlow<Double?>(null) // null = full payment
  val salePaidAmount: StateFlow<Double?> = _salePaidAmount.asStateFlow()

  private val _salePaymentType = MutableStateFlow(PaymentType.CASH)
  val salePaymentType: StateFlow<PaymentType> = _salePaymentType.asStateFlow()

  // Last Completed Invoice for receipt dialog
  private val _lastCompletedInvoice = MutableStateFlow<Pair<Invoice, List<InvoiceItem>>?>(null)
  val lastCompletedInvoice: StateFlow<Pair<Invoice, List<InvoiceItem>>?> = _lastCompletedInvoice.asStateFlow()

  // --- PURCHASES CART STATE ---
  private val _purchaseCart = MutableStateFlow<List<PurchaseCartItem>>(emptyList())
  val purchaseCart: StateFlow<List<PurchaseCartItem>> = _purchaseCart.asStateFlow()

  private val _selectedSupplier = MutableStateFlow<Supplier?>(null)
  val selectedSupplier: StateFlow<Supplier?> = _selectedSupplier.asStateFlow()

  private val _purchasePaidAmount = MutableStateFlow<Double?>(null)
  val purchasePaidAmount: StateFlow<Double?> = _purchasePaidAmount.asStateFlow()

  private val _purchasePaymentType = MutableStateFlow(PaymentType.CASH)
  val purchasePaymentType: StateFlow<PaymentType> = _purchasePaymentType.asStateFlow()

  // In-Place Invoice Editing States (فتح وتعديل الفاتورة في شاشة المبيعات/المشتريات الأساسية)
  private val _editingSaleInvoice = MutableStateFlow<Invoice?>(null)
  val editingSaleInvoice: StateFlow<Invoice?> = _editingSaleInvoice.asStateFlow()

  private val _editingPurchaseInvoice = MutableStateFlow<Invoice?>(null)
  val editingPurchaseInvoice: StateFlow<Invoice?> = _editingPurchaseInvoice.asStateFlow()

  // Report Filter State
  private val _selectedReportPeriod = MutableStateFlow(ReportPeriod.TODAY)
  val selectedReportPeriod: StateFlow<ReportPeriod> = _selectedReportPeriod.asStateFlow()

  private val _customDayTimestamp = MutableStateFlow(System.currentTimeMillis())
  val customDayTimestamp: StateFlow<Long> = _customDayTimestamp.asStateFlow()

  private val _customDateRange = MutableStateFlow(
    Pair(System.currentTimeMillis() - 6 * 86400000L, System.currentTimeMillis())
  )
  val customDateRange: StateFlow<Pair<Long, Long>> = _customDateRange.asStateFlow()

  fun setReportPeriod(period: ReportPeriod) {
    _selectedReportPeriod.value = period
  }

  fun setCustomDay(timestamp: Long) {
    _customDayTimestamp.value = timestamp
    _selectedReportPeriod.value = ReportPeriod.CUSTOM_DAY
  }

  fun setCustomDateRange(startTimestamp: Long, endTimestamp: Long) {
    _customDateRange.value = Pair(startTimestamp, endTimestamp)
    _selectedReportPeriod.value = ReportPeriod.CUSTOM_RANGE
  }

  // Computed Financial Report
  val profitReport: StateFlow<ProfitReportData> = combine(
    repository.allInvoices,
    repository.allExpenses,
    repository.allTransactions,
    combine(repository.allProducts, repository.allCustomers, repository.allSuppliers) { prods, custs, sups ->
      Triple(prods, custs, sups)
    },
    combine(_selectedReportPeriod, _customDayTimestamp, _customDateRange, repository.allStockAudits) { period, customDay, customRange, audits ->
      Triple(period, Pair(customDay, customRange), audits)
    }
  ) { invoices, expensesList, txList, tripleData, filterTriple ->
    val (productList, customerList, supplierList) = tripleData
    val (period, customPair, audits) = filterTriple
    val (customDay, customRange) = customPair
    calculateReport(invoices, expensesList, txList, productList, customerList, supplierList, audits, period, customDay, customRange)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ProfitReportData())

  // Top Selling & Most Profitable Products
  val topSellingProducts: StateFlow<List<TopProductStat>> = combine(
    repository.salesInvoices,
    repository.allInvoiceItems,
    repository.allProducts,
    combine(_selectedReportPeriod, _customDayTimestamp, _customDateRange) { p, d, r -> Triple(p, d, r) }
  ) { sales, items, prodList, (period, customDay, customRange) ->
    val (startTs, endTs) = getPeriodDateRange(period, customDay, customRange)
    val periodSales = sales.filter { it.timestamp in startTs..endTs }
    val validInvoiceIds = periodSales.map { it.id }.toSet()
    val periodItems = items.filter { it.invoiceId in validInvoiceIds }

    val prodMap = prodList.associateBy { it.id }
    periodItems.groupBy { it.productId }.map { (pId, pItems) ->
      val prod = prodMap[pId]
      val pName = prod?.name ?: pItems.firstOrNull()?.productName ?: "صنف"
      val cat = prod?.category ?: "عام"
      val qtySold = pItems.sumOf { it.totalPieces }
      val rev = pItems.sumOf { it.totalPrice }
      val cost = pItems.sumOf { it.totalCost }
      val profit = pItems.sumOf { it.itemProfit }
      val unit = prod?.unitName ?: "قطعة"
      TopProductStat(
        productId = pId,
        productName = pName,
        category = cat,
        totalQuantitySold = qtySold,
        totalRevenue = rev,
        totalCost = cost,
        totalProfit = profit,
        unitName = unit
      )
    }.sortedByDescending { it.totalRevenue }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Expense Categories Breakdown
  val expensesByCategory: StateFlow<List<ExpenseCategoryStat>> = combine(
    repository.allExpenses,
    combine(_selectedReportPeriod, _customDayTimestamp, _customDateRange) { p, d, r -> Triple(p, d, r) }
  ) { expenseList, (period, customDay, customRange) ->
    val (startTs, endTs) = getPeriodDateRange(period, customDay, customRange)
    val filtered = expenseList.filter { it.timestamp in startTs..endTs }
    val totalAll = filtered.sumOf { it.amount }

    filtered.groupBy { it.category }.map { (cat, list) ->
      val sum = list.sumOf { it.amount }
      val pct = if (totalAll > 0) (sum / totalAll) * 100.0 else 0.0
      ExpenseCategoryStat(
        category = cat,
        totalAmount = sum,
        count = list.size,
        percentage = pct
      )
    }.sortedByDescending { it.totalAmount }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Debt Aging Breakdown
  val debtAgingList: StateFlow<List<DebtAgingStat>> = repository.allCustomers.combine(MutableStateFlow(Unit)) { customers, _ ->
    customers.filter { it.currentBalance > 0 }
      .sortedByDescending { it.currentBalance }
      .map { c ->
        val level = when {
          c.creditLimit > 0 && c.currentBalance > c.creditLimit -> "تجاوز الحد الائتماني"
          c.currentBalance >= 5000.0 -> "مديونية كبرى"
          else -> "ضمن الرصيد الائتماني"
        }
        DebtAgingStat(
          customerId = c.id,
          customerName = c.name,
          phone = c.phone,
          currentDebt = c.currentBalance,
          creditLimit = c.creditLimit,
          overdueLevel = level
        )
      }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Trend Points for Bar Chart
  val salesTrendList: StateFlow<List<SalesTrendPoint>> = combine(
    repository.salesInvoices,
    repository.purchaseInvoices,
    _selectedReportPeriod
  ) { sales, purchases, period ->
    calculateTrendPoints(sales, purchases, period)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // ================= SALES CART ACTIONS =================

  fun addToSalesCart(product: Product, unitType: String = "علبة", tier: PriceTier = PriceTier.WHOLESALE) {
    val current = _salesCart.value.toMutableList()
    val index = current.indexOfFirst { it.product.id == product.id && it.unitType == unitType && it.priceTier == tier }
    if (index >= 0) {
      val existing = current[index]
      current[index] = existing.copy(quantity = existing.quantity + 1)
    } else {
      current.add(CartItem(product = product, unitType = unitType, priceTier = tier, quantity = 1))
    }
    _salesCart.value = current
  }

  fun changeSalesCartQuantity(product: Product, unitType: String, delta: Int, tier: PriceTier = PriceTier.WHOLESALE) {
    val current = _salesCart.value.toMutableList()
    val index = current.indexOfFirst { it.product.id == product.id && it.unitType == unitType }
    if (index >= 0) {
      val existing = current[index]
      val newQty = existing.quantity + delta
      if (newQty <= 0) {
        current.removeAt(index)
      } else {
        current[index] = existing.copy(quantity = newQty)
      }
      _salesCart.value = current
    } else if (delta > 0) {
      current.add(CartItem(product = product, unitType = unitType, priceTier = tier, quantity = delta))
      _salesCart.value = current
    }
  }

  fun updateCartItemQuantity(index: Int, newQuantity: Int) {
    if (newQuantity <= 0) {
      removeFromSalesCart(index)
      return
    }
    val current = _salesCart.value.toMutableList()
    if (index in current.indices) {
      current[index] = current[index].copy(quantity = newQuantity)
      _salesCart.value = current
    }
  }

  fun updateCartItemUnitType(index: Int, newUnitType: String) {
    val current = _salesCart.value.toMutableList()
    if (index in current.indices) {
      current[index] = current[index].copy(unitType = newUnitType)
      _salesCart.value = current
    }
  }

  fun updateCartItemTier(index: Int, newTier: PriceTier) {
    val current = _salesCart.value.toMutableList()
    if (index in current.indices) {
      current[index] = current[index].copy(priceTier = newTier)
      _salesCart.value = current
    }
  }

  fun updateCartItemCustomPrice(index: Int, price: Double?) {
    val current = _salesCart.value.toMutableList()
    if (index in current.indices) {
      current[index] = current[index].copy(customPrice = price)
      _salesCart.value = current
    }
  }

  fun removeFromSalesCart(index: Int) {
    val current = _salesCart.value.toMutableList()
    if (index in current.indices) {
      current.removeAt(index)
      _salesCart.value = current
    }
  }

  fun clearSalesCart() {
    _salesCart.value = emptyList()
    _selectedCustomer.value = null
    _saleDiscount.value = 0.0
    _salePaidAmount.value = null
    _salePaymentType.value = when (businessProfile.value.salesDefaultPaymentType) {
      "آجل" -> PaymentType.CREDIT
      "دفع جزئي" -> PaymentType.PARTIAL
      else -> PaymentType.CASH
    }
  }

  fun selectCustomer(customer: Customer?) {
    _selectedCustomer.value = customer
  }

  fun setSaleDiscount(discount: Double) {
    _saleDiscount.value = discount.coerceAtLeast(0.0)
  }

  fun setSalePaymentType(type: PaymentType) {
    _salePaymentType.value = type
  }

  fun setSalePaidAmount(amount: Double?) {
    _salePaidAmount.value = amount
  }

  fun completeSale(
    customTimestamp: Long? = null,
    invoiceNotes: String? = null,
    onSuccess: (Invoice) -> Unit,
    onError: ((String) -> Unit)? = null
  ) {
    val items = _salesCart.value
    if (items.isEmpty()) {
      onError?.invoke("سلة الفاتورة فارغة، يرجى إضافة أصناف أولاً")
      return
    }

    // فحص إلزام اختيار عميل إذا كان مفعلاً في الإعدادات
    if (businessProfile.value.salesRequireCustomerSelection && _selectedCustomer.value == null) {
      onError?.invoke("إعدادات النظام تلزم باختيار عميل مسجل لكل فاتورة مبيعات.")
      return
    }

    // فحص منع البيع بالسالب إذا كان الخيار مفعلاً في الإعدادات
    if (businessProfile.value.salesPreventNegativeStock) {
      val negativeItem = items.firstOrNull { it.totalPieces > it.product.totalPiecesInStock }
      if (negativeItem != null) {
        val available = negativeItem.product.totalPiecesInStock
        val requested = negativeItem.totalPieces
        onError?.invoke("الكمية المطلوبة من [${negativeItem.product.name}] ($requested قطعة) أكبر من المتوفر في المخزن ($available قطعة) وإعدادات النظام تمنع البيع بالسالب.")
        return
      }
    }

    val allowBelowCost = businessProfile.value.salesAllowSellingBelowCost

    // 1. Validation: Disallow selling any item below its purchase cost if not allowed by settings
    val lossItem = items.firstOrNull { it.isSellingAtLoss }
    if (lossItem != null && !allowBelowCost) {
      val diff = lossItem.lossPerUnit
      val msg = "غير مسموح بالبيع بسعر أقل من سعر الشراء! الصنف [${lossItem.product.name}] سعر البيع (${String.format(Locale.ENGLISH, "%.2f", lossItem.unitPrice)} ج.م) أقل من سعر تكلفة الشراء (${String.format(Locale.ENGLISH, "%.2f", lossItem.unitCostPrice)} ج.م) بمقدار (${String.format(Locale.ENGLISH, "%.2f", diff)} ج.م)"
      onError?.invoke(msg)
      return
    }

    val subtotal = items.sumOf { it.totalPrice }
    val discount = _saleDiscount.value
    val totalAmount = (subtotal - discount).coerceAtLeast(0.0)
    val totalCost = items.sumOf { it.totalCost }

    // 2. Validation: Total discount cannot cause net invoice to drop below total purchase cost if not allowed
    if (totalAmount < totalCost && !allowBelowCost) {
      val diff = totalCost - totalAmount
      val msg = "غير مسموح بإتمام البيع بخسارة! صافي الفاتورة بعد الخصم (${String.format(Locale.ENGLISH, "%.2f", totalAmount)} ج.م) أقل من إجمالي سعر تكلفة الشراء (${String.format(Locale.ENGLISH, "%.2f", totalCost)} ج.م) بمقدار (${String.format(Locale.ENGLISH, "%.2f", diff)} ج.م)"
      onError?.invoke(msg)
      return
    }

    viewModelScope.launch {
      val totalProfit = totalAmount - totalCost

      val paymentType = _salePaymentType.value
      val paidAmount = when (paymentType) {
        PaymentType.CASH -> {
          val customPaid = _salePaidAmount.value
          if (customPaid != null && customPaid < totalAmount && businessProfile.value.salesAllowSellingBelowInvoiceTotal) {
            customPaid
          } else {
            totalAmount
          }
        }
        PaymentType.CREDIT -> 0.0
        PaymentType.PARTIAL -> (_salePaidAmount.value ?: totalAmount).coerceIn(0.0, totalAmount)
      }
      val remainingAmount = (totalAmount - paidAmount).coerceAtLeast(0.0)

      val partyId = _selectedCustomer.value?.id ?: 0L
      val partyName = _selectedCustomer.value?.name ?: businessProfile.value.salesDefaultCustomerName
      val prevBalance = _selectedCustomer.value?.currentBalance ?: 0.0
      val grandTotal = prevBalance + remainingAmount

      val editingInv = _editingSaleInvoice.value
      val invNumber = editingInv?.invoiceNumber ?: "INV-${SimpleDateFormat("yyMMdd-HHmmss", Locale.ENGLISH).format(Date())}"

      val defaultNote = if (remainingAmount > 0) "متبقي آجل: $remainingAmount • إجمالي الحساب: $grandTotal" else "مسددة بالكامل"

      val profile = businessProfile.value
      val isDelegateMode = profile.deviceRole == "DELEGATE"
      val empId = if (isDelegateMode && profile.delegateEmployeeId > 0) profile.delegateEmployeeId else profile.activeEmployeeId
      val empName = if (isDelegateMode && profile.delegateEmployeeName.isNotBlank()) profile.delegateEmployeeName else profile.activeEmployeeName

      val invoice = Invoice(
        id = editingInv?.id ?: 0L,
        invoiceNumber = invNumber,
        type = InvoiceType.SALE,
        partyId = partyId,
        partyName = partyName,
        timestamp = customTimestamp ?: (editingInv?.timestamp ?: System.currentTimeMillis()),
        subtotal = subtotal,
        discount = discount,
        totalAmount = totalAmount,
        paidAmount = paidAmount,
        remainingAmount = remainingAmount,
        paymentType = paymentType,
        totalCost = totalCost,
        totalProfit = totalProfit,
        previousBalance = prevBalance,
        grandTotalDue = grandTotal,
        notes = if (invoiceNotes.isNullOrBlank()) defaultNote else "$invoiceNotes ($defaultNote)",
        employeeId = empId,
        employeeName = empName,
        isDelegateInvoice = isDelegateMode,
        syncStatus = if (isDelegateMode) "PENDING_SYNC" else "SYNCED"
      )

      val invoiceItems = items.map { item ->
        InvoiceItem(
          productId = item.product.id,
          productName = item.product.name,
          unitType = item.unitType,
          quantity = item.quantity,
          piecesPerCarton = item.product.piecesPerCarton,
          totalPieces = item.totalPieces,
          unitPrice = item.unitPrice,
          unitCost = item.unitCostPrice,
          totalPrice = item.totalPrice,
          totalCost = item.totalCost,
          itemProfit = item.itemProfit
        )
      }

      if (editingInv != null) {
        repository.updateInvoiceWithItems(editingInv, invoice, invoiceItems)
        _editingSaleInvoice.value = null
        _lastCompletedInvoice.value = Pair(invoice, invoiceItems)
        clearSalesCart()
        onSuccess(invoice)
      } else {
        val id = repository.completeSale(invoice, invoiceItems)
        val savedInvoice = invoice.copy(id = id)
        _lastCompletedInvoice.value = Pair(savedInvoice, invoiceItems)
        clearSalesCart()
        onSuccess(savedInvoice)
      }
    }
  }

  fun loadSaleInvoiceForEditing(invoice: Invoice, onLoaded: () -> Unit = {}) {
    viewModelScope.launch {
      val items = repository.getInvoiceItemsSync(invoice.id)
      _editingSaleInvoice.value = invoice
      val cust = if (invoice.partyId > 0) customers.value.find { it.id == invoice.partyId } else null
      _selectedCustomer.value = cust
      _saleDiscount.value = invoice.discount
      _salePaidAmount.value = invoice.paidAmount
      _salePaymentType.value = invoice.paymentType

      val cartItems = items.map { itm ->
        val prod = products.value.find { it.id == itm.productId } ?: Product(
          id = itm.productId,
          name = itm.productName,
          piecesPerCarton = itm.piecesPerCarton
        )
        CartItem(
          product = prod,
          unitType = itm.unitType,
          priceTier = PriceTier.WHOLESALE,
          customPrice = itm.unitPrice,
          quantity = itm.quantity
        )
      }
      _salesCart.value = cartItems
      onLoaded()
    }
  }

  fun cancelEditingSaleInvoice() {
    _editingSaleInvoice.value = null
    clearSalesCart()
  }

  fun getCartLossWarning(): String? {
    val items = _salesCart.value
    val lossItem = items.firstOrNull { it.isSellingAtLoss }
    if (lossItem != null) {
      val diff = lossItem.lossPerUnit
      return "⚠️ الصنف [${lossItem.product.name}] يُباع بأقل من سعر الشراء بمقدار ${String.format(Locale.ENGLISH, "%.2f", diff)} ج.م (سعر الشراء: ${String.format(Locale.ENGLISH, "%.2f", lossItem.unitCostPrice)} ج.م)"
    }
    val subtotal = items.sumOf { it.totalPrice }
    val totalAmount = (subtotal - _saleDiscount.value).coerceAtLeast(0.0)
    val totalCost = items.sumOf { it.totalCost }
    if (totalAmount < totalCost) {
      val diff = totalCost - totalAmount
      return "⚠️ الخصم الممنوح كبير ويجعل الفاتورة خاسرة بمقدار ${String.format(Locale.ENGLISH, "%.2f", diff)} ج.م عن سعر تكلفة الشراء!"
    }
    return null
  }

  fun dismissLastInvoice() {
    _lastCompletedInvoice.value = null
  }

  // ================= PURCHASES CART ACTIONS =================

  fun addToPurchaseCart(product: Product, unitType: String = "كرتونة", cost: Double = 0.0) {
    val defaultCost = if (unitType == "كرتونة") {
      if (product.cartonCostPrice > 0.0) product.cartonCostPrice else if (product.piecesPerCarton > 0 && product.pieceCostPrice > 0.0) product.pieceCostPrice * product.piecesPerCarton else product.pieceCostPrice
    } else {
      if (product.pieceCostPrice > 0.0) product.pieceCostPrice else if (product.piecesPerCarton > 0 && product.cartonCostPrice > 0.0) product.cartonCostPrice / product.piecesPerCarton else product.cartonCostPrice
    }
    val initialCost = if (cost > 0.0) cost else defaultCost
    val current = _purchaseCart.value.toMutableList()
    val index = current.indexOfFirst { it.product.id == product.id && it.unitType == unitType }
    if (index >= 0) {
      val existing = current[index]
      current[index] = existing.copy(quantity = existing.quantity + 1)
    } else {
      current.add(PurchaseCartItem(product = product, unitType = unitType, quantity = 1, unitCostPrice = initialCost))
    }
    _purchaseCart.value = current
  }

  fun changePurchaseCartQuantity(product: Product, unitType: String, delta: Int, cost: Double = 0.0) {
    val defaultCost = if (unitType == "كرتونة") {
      if (product.cartonCostPrice > 0.0) product.cartonCostPrice else if (product.piecesPerCarton > 0 && product.pieceCostPrice > 0.0) product.pieceCostPrice * product.piecesPerCarton else product.pieceCostPrice
    } else {
      if (product.pieceCostPrice > 0.0) product.pieceCostPrice else if (product.piecesPerCarton > 0 && product.cartonCostPrice > 0.0) product.cartonCostPrice / product.piecesPerCarton else product.cartonCostPrice
    }
    val initialCost = if (cost > 0.0) cost else defaultCost
    val current = _purchaseCart.value.toMutableList()
    val index = current.indexOfFirst { it.product.id == product.id && it.unitType == unitType }
    if (index >= 0) {
      val existing = current[index]
      val newQty = existing.quantity + delta
      if (newQty <= 0) {
        current.removeAt(index)
      } else {
        current[index] = existing.copy(quantity = newQty)
      }
      _purchaseCart.value = current
    } else if (delta > 0) {
      current.add(PurchaseCartItem(product = product, unitType = unitType, quantity = delta, unitCostPrice = initialCost))
      _purchaseCart.value = current
    }
  }

  fun updatePurchaseItemQuantity(index: Int, newQuantity: Int) {
    if (newQuantity <= 0) {
      removeFromPurchaseCart(index)
      return
    }
    val current = _purchaseCart.value.toMutableList()
    if (index in current.indices) {
      current[index] = current[index].copy(quantity = newQuantity)
      _purchaseCart.value = current
    }
  }

  fun updatePurchaseItemCost(index: Int, newCost: Double) {
    val current = _purchaseCart.value.toMutableList()
    if (index in current.indices) {
      current[index] = current[index].copy(unitCostPrice = newCost)
      _purchaseCart.value = current
    }
  }

  fun updatePurchaseItemUnit(index: Int, unitType: String) {
    val current = _purchaseCart.value.toMutableList()
    if (index in current.indices) {
      val item = current[index]
      val defaultCost = if (unitType == "كرتونة") {
        if (item.product.cartonCostPrice > 0.0) item.product.cartonCostPrice else if (item.product.piecesPerCarton > 0 && item.product.pieceCostPrice > 0.0) item.product.pieceCostPrice * item.product.piecesPerCarton else item.product.pieceCostPrice
      } else {
        if (item.product.pieceCostPrice > 0.0) item.product.pieceCostPrice else if (item.product.piecesPerCarton > 0 && item.product.cartonCostPrice > 0.0) item.product.cartonCostPrice / item.product.piecesPerCarton else item.product.cartonCostPrice
      }
      current[index] = item.copy(unitType = unitType, unitCostPrice = defaultCost)
      _purchaseCart.value = current
    }
  }

  fun removeFromPurchaseCart(index: Int) {
    val current = _purchaseCart.value.toMutableList()
    if (index in current.indices) {
      current.removeAt(index)
      _purchaseCart.value = current
    }
  }

  fun clearPurchaseCart() {
    _purchaseCart.value = emptyList()
    _selectedSupplier.value = null
    _purchasePaidAmount.value = null
    _purchasePaymentType.value = PaymentType.CASH
  }

  fun selectSupplier(supplier: Supplier?) {
    _selectedSupplier.value = supplier
  }

  fun setPurchasePaymentType(type: PaymentType) {
    _purchasePaymentType.value = type
  }

  fun setPurchasePaidAmount(amount: Double?) {
    _purchasePaidAmount.value = amount
  }

  fun completePurchase(onSuccess: (Invoice) -> Unit) {
    val items = _purchaseCart.value
    if (items.isEmpty()) return

    viewModelScope.launch {
      val totalAmount = items.sumOf { it.totalPrice }
      val paymentType = _purchasePaymentType.value
      val paidAmount = when (paymentType) {
        PaymentType.CASH -> totalAmount
        PaymentType.CREDIT -> 0.0
        PaymentType.PARTIAL -> (_purchasePaidAmount.value ?: totalAmount).coerceIn(0.0, totalAmount)
      }
      val remainingAmount = (totalAmount - paidAmount).coerceAtLeast(0.0)
      val partyId = _selectedSupplier.value?.id ?: 0L
      val partyName = _selectedSupplier.value?.name ?: "مورد نقدي"
      val prevBalance = _selectedSupplier.value?.currentBalance ?: 0.0
      val grandTotal = prevBalance + remainingAmount

      val editingInv = _editingPurchaseInvoice.value
      val purNumber = editingInv?.invoiceNumber ?: "PUR-${SimpleDateFormat("yyMMdd-HHmmss", Locale.ENGLISH).format(Date())}"

      val invoice = Invoice(
        id = editingInv?.id ?: 0L,
        invoiceNumber = purNumber,
        type = InvoiceType.PURCHASE,
        partyId = partyId,
        partyName = partyName,
        timestamp = editingInv?.timestamp ?: System.currentTimeMillis(),
        subtotal = totalAmount,
        discount = 0.0,
        totalAmount = totalAmount,
        paidAmount = paidAmount,
        remainingAmount = remainingAmount,
        paymentType = paymentType,
        totalCost = totalAmount,
        totalProfit = 0.0,
        previousBalance = prevBalance,
        grandTotalDue = grandTotal,
        notes = "توريد مخزن - متبقي للمورد: $remainingAmount • إجمالي مستحقاته: $grandTotal"
      )

      val invoiceItems = items.map { item ->
        InvoiceItem(
          productId = item.product.id,
          productName = item.product.name,
          unitType = item.unitType,
          quantity = item.quantity,
          piecesPerCarton = item.product.piecesPerCarton,
          totalPieces = item.totalPieces,
          unitPrice = item.unitCostPrice,
          unitCost = item.unitCostPrice,
          totalPrice = item.totalPrice,
          totalCost = item.totalPrice,
          itemProfit = 0.0
        )
      }

      if (editingInv != null) {
        repository.updateInvoiceWithItems(editingInv, invoice, invoiceItems)
        _editingPurchaseInvoice.value = null
        _lastCompletedInvoice.value = Pair(invoice, invoiceItems)
        clearPurchaseCart()
        onSuccess(invoice)
      } else {
        val id = repository.completePurchase(invoice, invoiceItems)
        val savedInvoice = invoice.copy(id = id)
        _lastCompletedInvoice.value = Pair(savedInvoice, invoiceItems)
        clearPurchaseCart()
        onSuccess(savedInvoice)
      }
    }
  }

  fun loadPurchaseInvoiceForEditing(invoice: Invoice, onLoaded: () -> Unit = {}) {
    viewModelScope.launch {
      val items = repository.getInvoiceItemsSync(invoice.id)
      _editingPurchaseInvoice.value = invoice
      val supp = if (invoice.partyId > 0) suppliers.value.find { it.id == invoice.partyId } else null
      _selectedSupplier.value = supp
      _purchasePaidAmount.value = invoice.paidAmount
      _purchasePaymentType.value = invoice.paymentType

      val cartItems = items.map { itm ->
        val prod = products.value.find { it.id == itm.productId } ?: Product(
          id = itm.productId,
          name = itm.productName,
          piecesPerCarton = itm.piecesPerCarton
        )
        PurchaseCartItem(
          product = prod,
          unitType = itm.unitType,
          quantity = itm.quantity,
          unitCostPrice = itm.unitPrice
        )
      }
      _purchaseCart.value = cartItems
      onLoaded()
    }
  }

  fun cancelEditingPurchaseInvoice() {
    _editingPurchaseInvoice.value = null
    clearPurchaseCart()
  }

  fun reopenInvoiceReceipt(invoice: Invoice) {
    viewModelScope.launch {
      val items = repository.getInvoiceItems(invoice.id).firstOrNull() ?: emptyList()
      _lastCompletedInvoice.value = Pair(invoice, items)
    }
  }

  suspend fun getInvoiceItems(invoiceId: Long): List<InvoiceItem> {
    return repository.getInvoiceItemsSync(invoiceId)
  }

  fun deleteInvoice(invoice: Invoice, onComplete: (() -> Unit)? = null) {
    viewModelScope.launch {
      repository.deleteInvoice(invoice)
      onComplete?.invoke()
    }
  }

  fun updateInvoiceWithItems(
    oldInvoice: Invoice,
    newInvoice: Invoice,
    newItems: List<InvoiceItem>,
    onComplete: (() -> Unit)? = null
  ) {
    viewModelScope.launch {
      repository.updateInvoiceWithItems(oldInvoice, newInvoice, newItems)
      onComplete?.invoke()
    }
  }

  // ================= PRODUCT CRUD =================

  fun saveProduct(product: Product, onComplete: ((Product) -> Unit)? = null) {
    viewModelScope.launch {
      val saved = if (product.id == 0L) {
        val id = repository.insertProduct(product)
        product.copy(id = id)
      } else {
        repository.updateProduct(product)
        product
      }
      onComplete?.invoke(saved)
    }
  }

  fun deleteProduct(product: Product) {
    viewModelScope.launch {
      repository.deleteProduct(product)
    }
  }

  fun quickAdjustStock(
    product: Product,
    deltaPieces: Int,
    reason: String = "تسوية رصيد مخزني سريعة",
    onComplete: (() -> Unit)? = null
  ) {
    viewModelScope.launch {
      val actualPieces = (product.totalPiecesInStock + deltaPieces).coerceAtLeast(0)
      val actualDelta = actualPieces - product.totalPiecesInStock
      val auditItem = StockAuditItem(
        productId = product.id,
        productName = product.name,
        systemQuantity = product.totalPiecesInStock,
        actualQuantity = actualPieces,
        diffQuantity = actualDelta,
        unitPieceCost = product.pieceCostPrice,
        diffCostValue = actualDelta * product.pieceCostPrice
      )
      repository.recordStockAudit(
        title = "تسوية سريعة: ${product.name}",
        notes = reason,
        items = listOf(auditItem),
        applyToInventory = true
      )
      onComplete?.invoke()
    }
  }

  fun updateProductWacCost(productId: Long, newCartonCost: Double, onComplete: (() -> Unit)? = null) {
    viewModelScope.launch {
      repository.updateProductCost(productId, newCartonCost)
      onComplete?.invoke()
    }
  }

  fun recalculateAllProductsWac(onComplete: ((Int) -> Unit)? = null) {
    viewModelScope.launch {
      val count = repository.recalculateAllProductsWac()
      onComplete?.invoke(count)
    }
  }

  // ================= CUSTOMER CRUD & PAYMENTS =================

  private val isSavingCustomer = java.util.concurrent.atomic.AtomicBoolean(false)
  private val isSavingSupplier = java.util.concurrent.atomic.AtomicBoolean(false)
  private var lastPaymentTimestamp: Long = 0L
  private var lastPaymentKey: String = ""

  fun saveCustomer(customer: Customer, onComplete: ((Customer) -> Unit)? = null) {
    if (customer.id == 0L) {
      if (!isSavingCustomer.compareAndSet(false, true)) {
        return
      }
    }
    viewModelScope.launch {
      try {
        if (customer.id == 0L) {
          val cleanName = customer.name.trim()
          val existing = customers.value.find { it.name.trim().equals(cleanName, ignoreCase = true) }
          if (existing != null) {
            onComplete?.invoke(existing)
            return@launch
          }
        }
        val saved = if (customer.id == 0L) {
          val id = repository.insertCustomer(customer.copy(name = customer.name.trim()))
          customer.copy(id = id, name = customer.name.trim())
        } else {
          repository.updateCustomer(customer.copy(name = customer.name.trim()))
          customer.copy(name = customer.name.trim())
        }
        onComplete?.invoke(saved)
      } finally {
        if (customer.id == 0L) {
          isSavingCustomer.set(false)
        }
      }
    }
  }

  fun deleteCustomer(customer: Customer) {
    viewModelScope.launch {
      repository.deleteCustomer(customer)
    }
  }

  fun recordCustomerPayment(
    customer: Customer,
    amount: Double,
    notes: String,
    onComplete: ((PaymentTransaction) -> Unit)? = null
  ) {
    val now = System.currentTimeMillis()
    val paymentKey = "CUST_${customer.id}_${amount}"
    if (now - lastPaymentTimestamp < 1200L && lastPaymentKey == paymentKey) {
      // Prevent duplicate double submission
      return
    }
    lastPaymentTimestamp = now
    lastPaymentKey = paymentKey

    val balanceAfter = (customer.currentBalance - amount).coerceAtLeast(0.0)
    val enrichedNotes = if (notes.contains("الرصيد بعد السند")) notes else {
      if (notes.isBlank()) "سداد دفعة من الحساب (الرصيد بعد السند: ${String.format(Locale.ENGLISH, "%.2f", balanceAfter)} ج.م)"
      else "$notes (الرصيد بعد السند: ${String.format(Locale.ENGLISH, "%.2f", balanceAfter)} ج.م)"
    }

    viewModelScope.launch {
      val txId = repository.recordCustomerPayment(
        customerId = customer.id,
        customerName = customer.name,
        amount = amount,
        notes = enrichedNotes
      )
      val tx = PaymentTransaction(
        id = txId,
        type = com.example.data.model.TransactionType.CUSTOMER_PAYMENT,
        partyId = customer.id,
        partyName = customer.name,
        amount = amount,
        notes = enrichedNotes,
        timestamp = now
      )
      onComplete?.invoke(tx)
    }
  }

  // ================= SUPPLIER CRUD & PAYMENTS =================

  fun saveSupplier(supplier: Supplier, onComplete: ((Supplier) -> Unit)? = null) {
    if (supplier.id == 0L) {
      if (!isSavingSupplier.compareAndSet(false, true)) {
        return
      }
    }
    viewModelScope.launch {
      try {
        if (supplier.id == 0L) {
          val cleanName = supplier.name.trim()
          val existing = suppliers.value.find { it.name.trim().equals(cleanName, ignoreCase = true) }
          if (existing != null) {
            onComplete?.invoke(existing)
            return@launch
          }
        }
        val saved = if (supplier.id == 0L) {
          val id = repository.insertSupplier(supplier.copy(name = supplier.name.trim()))
          supplier.copy(id = id, name = supplier.name.trim())
        } else {
          repository.updateSupplier(supplier.copy(name = supplier.name.trim()))
          supplier.copy(name = supplier.name.trim())
        }
        onComplete?.invoke(saved)
      } finally {
        if (supplier.id == 0L) {
          isSavingSupplier.set(false)
        }
      }
    }
  }

  fun deleteSupplier(supplier: Supplier) {
    viewModelScope.launch {
      repository.deleteSupplier(supplier)
    }
  }

  fun recordSupplierPayment(
    supplier: Supplier,
    amount: Double,
    notes: String,
    onComplete: ((PaymentTransaction) -> Unit)? = null
  ) {
    val now = System.currentTimeMillis()
    val paymentKey = "SUP_${supplier.id}_${amount}"
    if (now - lastPaymentTimestamp < 1200L && lastPaymentKey == paymentKey) {
      // Prevent duplicate double submission
      return
    }
    lastPaymentTimestamp = now
    lastPaymentKey = paymentKey

    val balanceAfter = (supplier.currentBalance - amount).coerceAtLeast(0.0)
    val enrichedNotes = if (notes.contains("الرصيد بعد السند")) notes else {
      if (notes.isBlank()) "سداد مستحقات توريد (الرصيد بعد السند: ${String.format(Locale.ENGLISH, "%.2f", balanceAfter)} ج.م)"
      else "$notes (الرصيد بعد السند: ${String.format(Locale.ENGLISH, "%.2f", balanceAfter)} ج.م)"
    }

    viewModelScope.launch {
      val txId = repository.recordSupplierPayment(
        supplierId = supplier.id,
        supplierName = supplier.name,
        amount = amount,
        notes = enrichedNotes
      )
      val tx = PaymentTransaction(
        id = txId,
        type = com.example.data.model.TransactionType.SUPPLIER_PAYMENT,
        partyId = supplier.id,
        partyName = supplier.name,
        amount = amount,
        notes = enrichedNotes,
        timestamp = now
      )
      onComplete?.invoke(tx)
    }
  }

  // ================= EXPENSES =================

  fun insertExpense(expense: Expense) {
    viewModelScope.launch {
      repository.insertExpense(expense)
    }
  }

  fun addExpense(category: String, amount: Double, recipient: String, notes: String) {
    viewModelScope.launch {
      repository.insertExpense(
        Expense(
          category = category,
          amount = amount,
          recipient = recipient,
          notes = notes,
          timestamp = System.currentTimeMillis()
        )
      )
    }
  }

  fun deleteExpense(expense: Expense) {
    viewModelScope.launch {
      repository.deleteExpense(expense)
    }
  }

  // ================= STOCK AUDIT (الجرد المخزني والتسويات) =================

  fun performStockAudit(
    title: String,
    notes: String,
    auditItems: List<StockAuditItem>,
    applyToInventory: Boolean,
    onComplete: ((Long) -> Unit)? = null
  ) {
    viewModelScope.launch {
      val auditId = repository.recordStockAudit(title, notes, auditItems, applyToInventory)
      onComplete?.invoke(auditId)
    }
  }

  // ================= TREASURY CASH DEPOSITS & WITHDRAWALS =================

  fun recordCashDeposit(
    amount: Double,
    source: String,
    notes: String,
    customTimestamp: Long? = null,
    onComplete: ((Long) -> Unit)? = null
  ) {
    viewModelScope.launch {
      val id = repository.recordCashDeposit(
        amount = amount,
        source = source,
        notes = notes,
        timestamp = customTimestamp ?: System.currentTimeMillis()
      )
      onComplete?.invoke(id)
    }
  }

  fun recordCashWithdrawal(
    amount: Double,
    destination: String,
    notes: String,
    customTimestamp: Long? = null,
    onComplete: ((Long) -> Unit)? = null
  ) {
    viewModelScope.launch {
      val id = repository.recordCashWithdrawal(
        amount = amount,
        destination = destination,
        notes = notes,
        timestamp = customTimestamp ?: System.currentTimeMillis()
      )
      onComplete?.invoke(id)
    }
  }

  // ================= REPORT PERIOD =================

  private fun calculateReport(
    invoices: List<Invoice>,
    expensesList: List<Expense>,
    txList: List<PaymentTransaction>,
    productList: List<Product>,
    customerList: List<Customer>,
    supplierList: List<Supplier>,
    audits: List<StockAudit>,
    period: ReportPeriod,
    customDay: Long = _customDayTimestamp.value,
    customRange: Pair<Long, Long> = _customDateRange.value
  ): ProfitReportData {
    val (startTimestamp, endTimestamp) = getPeriodDateRange(period, customDay, customRange)

    val filteredSales = invoices.filter { it.type == InvoiceType.SALE && it.timestamp in startTimestamp..endTimestamp }
    val filteredPurchases = invoices.filter { it.type == InvoiceType.PURCHASE && it.timestamp in startTimestamp..endTimestamp }
    val filteredExpenses = expensesList.filter { it.timestamp in startTimestamp..endTimestamp }
    val filteredCustomerPayments = txList.filter { it.type == com.example.data.model.TransactionType.CUSTOMER_PAYMENT && it.timestamp in startTimestamp..endTimestamp }
    val filteredSupplierPayments = txList.filter { it.type == com.example.data.model.TransactionType.SUPPLIER_PAYMENT && it.timestamp in startTimestamp..endTimestamp }
    val filteredCashDeposits = txList.filter { it.type == com.example.data.model.TransactionType.CASH_DEPOSIT && it.timestamp in startTimestamp..endTimestamp }
    val filteredCashWithdrawals = txList.filter { it.type == com.example.data.model.TransactionType.CASH_WITHDRAWAL && it.timestamp in startTimestamp..endTimestamp }
    val filteredAudits = audits.filter { it.auditDate in startTimestamp..endTimestamp }

    val totalSales = filteredSales.sumOf { it.totalAmount }
    val totalSalesCost = filteredSales.sumOf { it.totalCost }
    val grossProfit = totalSales - totalSalesCost
    val totalExpenses = filteredExpenses.sumOf { it.amount }
    val netProfit = grossProfit - totalExpenses
    val margin = if (totalSales > 0) (netProfit / totalSales) * 100.0 else 0.0

    val totalPurchases = filteredPurchases.sumOf { it.totalAmount }

    // Cash movement for the drawer
    val cashInSales = filteredSales.sumOf { it.paidAmount }
    val cashInCustomerPayments = filteredCustomerPayments.sumOf { it.amount }
    val cashInDeposits = filteredCashDeposits.sumOf { it.amount }
    val cashOutPurchases = filteredPurchases.sumOf { it.paidAmount }
    val cashOutSupplierPayments = filteredSupplierPayments.sumOf { it.amount }
    val cashOutWithdrawals = filteredCashWithdrawals.sumOf { it.amount }

    val totalIn = cashInSales + cashInCustomerPayments + cashInDeposits
    val totalOut = cashOutPurchases + cashOutSupplierPayments + totalExpenses + cashOutWithdrawals
    val drawerBalance = totalIn - totalOut

    // Overall balances (current, not period-restricted)
    val inventoryCostValue = productList.sumOf { it.totalPiecesInStock * it.pieceCostPrice }
    val customerDebts = customerList.sumOf { it.currentBalance.coerceAtLeast(0.0) }
    val supplierDebts = supplierList.sumOf { it.currentBalance.coerceAtLeast(0.0) }

    // Sales payment type breakdowns
    val cashSales = filteredSales.filter { it.paymentType == PaymentType.CASH }
    val creditSales = filteredSales.filter { it.paymentType == PaymentType.CREDIT }
    val partialSales = filteredSales.filter { it.paymentType == PaymentType.PARTIAL }

    val totalDiscount = filteredSales.sumOf { it.discount }
    val totalAuditDiscrepancy = filteredAudits.sumOf { it.totalDiscrepancyValue }

    return ProfitReportData(
      totalSales = totalSales,
      totalSalesCost = totalSalesCost,
      grossProfit = grossProfit,
      totalExpenses = totalExpenses,
      netProfit = netProfit,
      profitMarginPercent = margin,
      totalPurchases = totalPurchases,
      cashInSales = cashInSales,
      cashInCustomerPayments = cashInCustomerPayments,
      cashInDeposits = cashInDeposits,
      cashOutPurchases = cashOutPurchases,
      cashOutSupplierPayments = cashOutSupplierPayments,
      cashOutWithdrawals = cashOutWithdrawals,
      cashDrawerBalance = drawerBalance,
      totalInventoryCostValue = inventoryCostValue,
      totalCustomerDebts = customerDebts,
      totalSupplierDebts = supplierDebts,
      salesCount = filteredSales.size,
      purchasesCount = filteredPurchases.size,
      cashSalesAmount = cashSales.sumOf { it.totalAmount },
      creditSalesAmount = creditSales.sumOf { it.totalAmount },
      partialSalesAmount = partialSales.sumOf { it.totalAmount },
      cashSalesCount = cashSales.size,
      creditSalesCount = creditSales.size,
      partialSalesCount = partialSales.size,
      totalDiscount = totalDiscount,
      totalAuditDiscrepancy = totalAuditDiscrepancy
    )
  }

  private fun calculateTrendPoints(
    sales: List<Invoice>,
    purchases: List<Invoice>,
    period: ReportPeriod
  ): List<SalesTrendPoint> {
    val cal = Calendar.getInstance()
    return when (period) {
      ReportPeriod.TODAY, ReportPeriod.YESTERDAY, ReportPeriod.CUSTOM_DAY -> {
        val (rangeStart, rangeEnd) = getPeriodDateRange(period, _customDayTimestamp.value, _customDateRange.value)
        val intervals = listOf(
          Triple("الصباح", 0, 11),
          Triple("الظهيرة", 12, 15),
          Triple("المساء", 16, 19),
          Triple("الليل", 20, 23)
        )
        val daySales = sales.filter { it.type == InvoiceType.SALE && it.timestamp in rangeStart..rangeEnd }
        val dayPurchases = purchases.filter { it.type == InvoiceType.PURCHASE && it.timestamp in rangeStart..rangeEnd }

        intervals.map { (label, startH, endH) ->
          val sSubset = daySales.filter {
            cal.timeInMillis = it.timestamp
            val h = cal.get(Calendar.HOUR_OF_DAY)
            h in startH..endH
          }
          val pSubset = dayPurchases.filter {
            cal.timeInMillis = it.timestamp
            val h = cal.get(Calendar.HOUR_OF_DAY)
            h in startH..endH
          }
          val sTotal = sSubset.sumOf { it.totalAmount }
          val sProfit = sSubset.sumOf { it.totalProfit }
          val pTotal = pSubset.sumOf { it.totalAmount }
          SalesTrendPoint(label, sTotal, sProfit, pTotal)
        }
      }
      ReportPeriod.CUSTOM_RANGE -> {
        val (rangeStart, rangeEnd) = getPeriodDateRange(period, _customDayTimestamp.value, _customDateRange.value)
        val diffDays = ((rangeEnd - rangeStart) / (1000 * 60 * 60 * 24)).toInt().coerceIn(1, 14)
        val step = ((rangeEnd - rangeStart) / diffDays).coerceAtLeast(1L)
        val df = SimpleDateFormat("MM/dd", Locale.ENGLISH)
        (0 until diffDays).map { i ->
          val pStart = rangeStart + (i * step)
          val pEnd = if (i == diffDays - 1) rangeEnd else pStart + step - 1
          val label = df.format(Date(pStart))
          val sSubset = sales.filter { it.type == InvoiceType.SALE && it.timestamp in pStart..pEnd }
          val pSubset = purchases.filter { it.type == InvoiceType.PURCHASE && it.timestamp in pStart..pEnd }
          SalesTrendPoint(
            label = label,
            sales = sSubset.sumOf { it.totalAmount },
            profit = sSubset.sumOf { it.totalProfit },
            purchases = pSubset.sumOf { it.totalAmount }
          )
        }
      }
      ReportPeriod.THIS_WEEK -> {
        val days = listOf("السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة")
        val weekStart = getStartTimestampForPeriod(ReportPeriod.THIS_WEEK)
        val weekSales = sales.filter { it.type == InvoiceType.SALE && it.timestamp >= weekStart }
        val weekPurchases = purchases.filter { it.type == InvoiceType.PURCHASE && it.timestamp >= weekStart }

        val dayMap = mapOf(
          Calendar.SATURDAY to "السبت",
          Calendar.SUNDAY to "الأحد",
          Calendar.MONDAY to "الإثنين",
          Calendar.TUESDAY to "الثلاثاء",
          Calendar.WEDNESDAY to "الأربعاء",
          Calendar.THURSDAY to "الخميس",
          Calendar.FRIDAY to "الجمعة"
        )

        days.map { dayName ->
          val sSubset = weekSales.filter {
            cal.timeInMillis = it.timestamp
            dayMap[cal.get(Calendar.DAY_OF_WEEK)] == dayName
          }
          val pSubset = weekPurchases.filter {
            cal.timeInMillis = it.timestamp
            dayMap[cal.get(Calendar.DAY_OF_WEEK)] == dayName
          }
          SalesTrendPoint(dayName, sSubset.sumOf { it.totalAmount }, sSubset.sumOf { it.totalProfit }, pSubset.sumOf { it.totalAmount })
        }
      }
      ReportPeriod.THIS_MONTH -> {
        val monthStart = getStartTimestampForPeriod(ReportPeriod.THIS_MONTH)
        val monthSales = sales.filter { it.type == InvoiceType.SALE && it.timestamp >= monthStart }
        val monthPurchases = purchases.filter { it.type == InvoiceType.PURCHASE && it.timestamp >= monthStart }

        (1..4).map { weekIndex ->
          val label = "أسبوع $weekIndex"
          val sSubset = monthSales.filter {
            cal.timeInMillis = it.timestamp
            val dayOfMonth = cal.get(Calendar.DAY_OF_MONTH)
            val w = ((dayOfMonth - 1) / 7) + 1
            w == weekIndex || (weekIndex == 4 && w > 4)
          }
          val pSubset = monthPurchases.filter {
            cal.timeInMillis = it.timestamp
            val dayOfMonth = cal.get(Calendar.DAY_OF_MONTH)
            val w = ((dayOfMonth - 1) / 7) + 1
            w == weekIndex || (weekIndex == 4 && w > 4)
          }
          SalesTrendPoint(label, sSubset.sumOf { it.totalAmount }, sSubset.sumOf { it.totalProfit }, pSubset.sumOf { it.totalAmount })
        }
      }
      ReportPeriod.THIS_YEAR, ReportPeriod.ALL_TIME -> {
        val months = listOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")
        val startTs = getStartTimestampForPeriod(period)
        val pSales = sales.filter { it.type == InvoiceType.SALE && it.timestamp >= startTs }
        val pPurchases = purchases.filter { it.type == InvoiceType.PURCHASE && it.timestamp >= startTs }

        val activeMonths = months.mapIndexed { idx, mName ->
          val sSubset = pSales.filter {
            cal.timeInMillis = it.timestamp
            cal.get(Calendar.MONTH) == idx
          }
          val pSubset = pPurchases.filter {
            cal.timeInMillis = it.timestamp
            cal.get(Calendar.MONTH) == idx
          }
          SalesTrendPoint(mName, sSubset.sumOf { it.totalAmount }, sSubset.sumOf { it.totalProfit }, pSubset.sumOf { it.totalAmount })
        }
        val currentMonth = Calendar.getInstance().get(Calendar.MONTH)
        val startIndex = (currentMonth - 4).coerceAtLeast(0)
        activeMonths.subList(startIndex, (currentMonth + 1).coerceAtMost(12))
      }
    }
  }

  fun getPeriodDateRange(
    period: ReportPeriod,
    customDay: Long = _customDayTimestamp.value,
    customRange: Pair<Long, Long> = _customDateRange.value
  ): Pair<Long, Long> {
    val cal = Calendar.getInstance()
    return when (period) {
      ReportPeriod.TODAY -> {
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        Pair(start, cal.timeInMillis)
      }
      ReportPeriod.YESTERDAY -> {
        cal.add(Calendar.DAY_OF_YEAR, -1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        Pair(start, cal.timeInMillis)
      }
      ReportPeriod.CUSTOM_DAY -> {
        cal.timeInMillis = customDay
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        Pair(start, cal.timeInMillis)
      }
      ReportPeriod.CUSTOM_RANGE -> {
        val s = minOf(customRange.first, customRange.second)
        val e = maxOf(customRange.first, customRange.second)
        cal.timeInMillis = s
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        cal.timeInMillis = e
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        Pair(start, cal.timeInMillis)
      }
      ReportPeriod.THIS_WEEK -> {
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
        Pair(cal.timeInMillis, Long.MAX_VALUE)
      }
      ReportPeriod.THIS_MONTH -> {
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        Pair(cal.timeInMillis, Long.MAX_VALUE)
      }
      ReportPeriod.THIS_YEAR -> {
        cal.set(Calendar.DAY_OF_YEAR, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        Pair(cal.timeInMillis, Long.MAX_VALUE)
      }
      ReportPeriod.ALL_TIME -> {
        Pair(0L, Long.MAX_VALUE)
      }
    }
  }

  fun getStartTimestampForPeriod(period: ReportPeriod): Long {
    return getPeriodDateRange(period).first
  }

  fun getStockAuditItems(auditId: Long): kotlinx.coroutines.flow.Flow<List<StockAuditItem>> {
    return repository.getStockAuditItems(auditId)
  }

  // ================= SETTINGS & BACKUP =================

  fun updateBusinessProfile(profile: BusinessProfile) {
    businessPreferences.updateProfile(profile)
  }

  fun selectCashbox(cashbox: String) {
    businessPreferences.setSelectedCashbox(cashbox)
  }

  fun setDarkMode(enabled: Boolean) {
    businessPreferences.setDarkMode(enabled)
  }

  fun setUserRole(role: String) {
    businessPreferences.setUserRole(role)
  }

  fun setLoggedIn(loggedIn: Boolean) {
    businessPreferences.setLoggedIn(loggedIn)
  }

  fun performBackup() {
    businessPreferences.recordBackup()
  }

  fun getBackupSummary(): String {
    val pCount = products.value.size
    val cCount = customers.value.size
    val sCount = suppliers.value.size
    val iCount = salesInvoices.value.size + purchaseInvoices.value.size
    val eCount = expenses.value.size
    return "نسخة احتياطية مكتملة تشمل $pCount صنف مخزني، $cCount عميل، $sCount مورد، $iCount فاتورة، $eCount عملية مصروفات."
  }

  fun getInvoiceItemsForInvoice(invoiceId: Long): List<InvoiceItem> {
    return invoiceItems.value.filter { it.invoiceId == invoiceId }
  }

  fun toggleCloudSync(enabled: Boolean) {
    val current = businessProfile.value
    updateBusinessProfile(current.copy(autoBackupEnabled = enabled))
  }

  fun toggleDarkMode(enabled: Boolean) {
    val current = businessProfile.value
    updateBusinessProfile(current.copy(isDarkMode = enabled))
  }

  fun updateUserRole(role: String) {
    val current = businessProfile.value
    updateBusinessProfile(current.copy(userRole = role))
  }

  fun updatePrinterSettings(printerType: String, bluetoothName: String, footerNote: String) {
    val current = businessProfile.value
    updateBusinessProfile(current.copy(printerType = printerType, bluetoothPrinterName = bluetoothName, receiptFooterNote = footerNote))
  }

  fun logout() {
    setLoggedIn(false)
  }

  fun getLedgerForAccount(accountCode: String): List<GeneralLedgerEntry> {
    val lines = journalLines.value.filter { it.accountCode == accountCode }
    val entriesMap = journalEntries.value.associateBy { it.id }
    val account = accounts.value.find { it.code == accountCode }
    val isDebitNormal = (account?.normalBalance ?: "DEBIT") == "DEBIT"

    var currentRunning = 0.0
    return lines.map { line ->
      val parentEntry = entriesMap[line.entryId]
      val change = if (isDebitNormal) (line.debit - line.credit) else (line.credit - line.debit)
      currentRunning += change
      GeneralLedgerEntry(
        timestamp = parentEntry?.timestamp ?: System.currentTimeMillis(),
        entryNumber = parentEntry?.entryNumber ?: "JE-${line.entryId}",
        description = parentEntry?.description ?: line.notes,
        debit = line.debit,
        credit = line.credit,
        runningBalance = currentRunning
      )
    }
  }

  fun getPartyStatementText(partyId: Long, isCustomer: Boolean): String {
    val business = businessProfile.value
    val dateStr = SimpleDateFormat("yyyy/MM/dd", Locale("ar")).format(Date())
    val sb = StringBuilder()
    sb.appendLine("📄 *كشف حساب مالي رسمي*")
    sb.appendLine("المؤسسة: ${business.businessName}")
    sb.appendLine("التاريخ: $dateStr")

    if (isCustomer) {
      val customer = customers.value.find { it.id == partyId }
      val partyName = customer?.name ?: "عميل"
      sb.appendLine("العميل: $partyName (هاتف: ${customer?.phone})")
      sb.appendLine("--------------------------------")
      val partyInvoices = salesInvoices.value.filter { it.partyId == partyId }
      val partyPayments = transactions.value.filter { it.partyId == partyId && it.type == com.example.data.model.TransactionType.CUSTOMER_PAYMENT }

      sb.appendLine("*الفواتير المسجلة:*")
      if (partyInvoices.isEmpty()) {
        sb.appendLine("لا توجد فواتير مبيعات سابقة.")
      } else {
        partyInvoices.forEach { inv ->
          val invDate = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).format(Date(inv.timestamp))
          sb.appendLine("• $invDate - فاتورة ${inv.invoiceNumber} | الإجمالي: ${inv.totalAmount} ج.م | مدفوع: ${inv.paidAmount} | متبقي: ${inv.remainingAmount}")
        }
      }

      sb.appendLine("\n*سندات القبض والسداد:*")
      if (partyPayments.isEmpty()) {
        sb.appendLine("لا توجد سندات سداد نقدية مسجلة.")
      } else {
        partyPayments.forEach { pay ->
          val payDate = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).format(Date(pay.timestamp))
          sb.appendLine("• $payDate - سند قبض: ${pay.amount} ج.م (${pay.notes})")
        }
      }

      sb.appendLine("--------------------------------")
      sb.appendLine("الرصيد المتبقي المستحق حالياً: *${customer?.currentBalance ?: 0.0} ج.م*")
    } else {
      val supplier = suppliers.value.find { it.id == partyId }
      val partyName = supplier?.name ?: "مورد"
      sb.appendLine("المورد: $partyName (${supplier?.company} - هاتف: ${supplier?.phone})")
      sb.appendLine("--------------------------------")
      val partyInvoices = purchaseInvoices.value.filter { it.partyId == partyId }
      val partyPayments = transactions.value.filter { it.partyId == partyId && it.type == com.example.data.model.TransactionType.SUPPLIER_PAYMENT }

      sb.appendLine("*فواتير التوريد والمشتريات:*")
      if (partyInvoices.isEmpty()) {
        sb.appendLine("لا توجد فواتير توريد سابقة.")
      } else {
        partyInvoices.forEach { inv ->
          val invDate = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).format(Date(inv.timestamp))
          sb.appendLine("• $invDate - فاتورة ${inv.invoiceNumber} | الإجمالي: ${inv.totalAmount} ج.م | مدفوع: ${inv.paidAmount} | متبقي: ${inv.remainingAmount}")
        }
      }

      sb.appendLine("\n*سندات الصرف المسددة:*")
      if (partyPayments.isEmpty()) {
        sb.appendLine("لا توجد سندات صرف مسجلة.")
      } else {
        partyPayments.forEach { pay ->
          val payDate = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).format(Date(pay.timestamp))
          sb.appendLine("• $payDate - سند صرف: ${pay.amount} ج.م (${pay.notes})")
        }
      }

      sb.appendLine("--------------------------------")
      sb.appendLine("إجمالي مستحقات المورد الحالية: *${supplier?.currentBalance ?: 0.0} ج.م*")
    }

    sb.appendLine("--------------------------------")
    sb.appendLine("شاكرين ومقدرين حسن تعاونكم الدائم 🙏")
    return sb.toString()
  }

  fun getTrialBalanceReportText(): String {
    val business = businessProfile.value
    val dateStr = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale("ar")).format(Date())
    val rows = trialBalance.value
    val totals = trialBalanceTotals.value
    val isBalanced = isTrialBalanceBalanced.value

    val sb = StringBuilder()
    sb.appendLine("⚖️ *ميزان المراجعة بالأرصدة والمجاميع*")
    sb.appendLine("المؤسسة: ${business.businessName}")
    sb.appendLine("التاريخ: $dateStr")
    sb.appendLine("حالة الاتزان: ${if (isBalanced) "متزن 100% (القيد المزدوج سليم)" else "غير متزن"}")
    sb.appendLine("--------------------------------")
    rows.forEach { row ->
      sb.appendLine("${row.accountCode} - ${row.accountName}")
      sb.appendLine("  مدين: ${row.totalDebit} | دائن: ${row.totalCredit} | رصيد: ${if (row.netDebitBalance > 0) "مدين ${row.netDebitBalance}" else "دائن ${row.netCreditBalance}"}")
    }
    sb.appendLine("--------------------------------")
    sb.appendLine("إجمالي الحركات المدينة: ${totals.first} ج.م")
    sb.appendLine("إجمالي الحركات الدائنة: ${totals.second} ج.م")
    sb.appendLine("الفارق: ${kotlin.math.abs(totals.first - totals.second)} ج.م")
    return sb.toString()
  }

  // ================= نظام النسخ الاحتياطي والاستعادة المتطور =================

  suspend fun checkAndPerformDailyAutoBackup() {
    val profile = businessProfile.value
    if (!profile.autoBackupEnabled) return
    val now = System.currentTimeMillis()
    val oneDay = 24 * 60 * 60 * 1000L
    if (now - profile.lastBackupTime >= oneDay) {
      try {
        val payload = BackupManager.createBackupPayload(appDao, profile)
        val result = BackupManager.saveBackup(getApplication(), payload, profile.backupFolderUri)
        if (result.success) {
          val summary = "نسخة احتياطية يومية (${result.fileSizeFormatted}) - ${result.dateFormatted}"
          businessPreferences.updateProfile(
            profile.copy(
              lastBackupTime = now,
              lastBackupFileName = BackupManager.BACKUP_FILE_NAME,
              lastBackupSizeFormatted = result.fileSizeFormatted,
              lastBackupSummary = summary
            )
          )
        }
      } catch (e: Exception) {
        android.util.Log.e("WholesaleVM", "Auto backup error", e)
      }
    }
  }

  fun performBackup(onResult: (BackupManager.BackupSaveResult) -> Unit) {
    viewModelScope.launch(Dispatchers.IO) {
      try {
        val profile = businessProfile.value
        val payload = BackupManager.createBackupPayload(appDao, profile)
        val result = BackupManager.saveBackup(getApplication(), payload, profile.backupFolderUri)
        if (result.success) {
          val now = System.currentTimeMillis()
          val summary = "نسخة احتياطية مكتملة (${result.fileSizeFormatted}) - ${result.dateFormatted}"
          businessPreferences.updateProfile(
            profile.copy(
              lastBackupTime = now,
              lastBackupFileName = BackupManager.BACKUP_FILE_NAME,
              lastBackupSizeFormatted = result.fileSizeFormatted,
              lastBackupSummary = summary
            )
          )
        }
        withContext(Dispatchers.Main) {
          onResult(result)
        }
      } catch (e: Exception) {
        withContext(Dispatchers.Main) {
          onResult(
            BackupManager.BackupSaveResult(
              success = false,
              filePathOrUri = "",
              dateFormatted = "",
              fileSizeFormatted = "",
              summaryText = "فشل إنشاء النسخة الاحتياطية",
              errorMessage = e.localizedMessage
            )
          )
        }
      }
    }
  }

  fun setBackupFolder(uri: android.net.Uri, displayName: String) {
    val profile = businessProfile.value
    businessPreferences.updateProfile(
      profile.copy(
        backupFolderUri = uri.toString(),
        backupFolderDisplayName = displayName
      )
    )
  }

  suspend fun getLatestBackupSummary(): BackupManager.BackupSummary? {
    return withContext(Dispatchers.IO) {
      BackupManager.getLatestBackupSummary(getApplication(), businessProfile.value.backupFolderUri)
    }
  }

  fun restoreFromBackup(backupJson: String, onComplete: (Boolean) -> Unit) {
    viewModelScope.launch(Dispatchers.IO) {
      val success = BackupManager.restoreFromBackupJson(appDao, backupJson)
      withContext(Dispatchers.Main) {
        onComplete(success)
      }
    }
  }

  fun createDatabaseBackupJson(): String {
    businessPreferences.recordBackup()
    return getBackupSummary()
  }

  fun restoreDefaultSampleData() {
    // Keeps database integrity
  }

  fun clearAllDataToFreshState(onComplete: () -> Unit = {}) {
    viewModelScope.launch(Dispatchers.IO) {
      repository.clearAllDataToFreshState()
      withContext(Dispatchers.Main) {
        onComplete()
      }
    }
  }

  // ================= EMPLOYEES & DELEGATE MANAGEMENT =================

  fun saveEmployee(employee: Employee, onComplete: () -> Unit = {}) {
    viewModelScope.launch(Dispatchers.IO) {
      if (employee.id > 0) {
        repository.updateEmployee(employee)
      } else {
        repository.insertEmployee(employee)
      }
      withContext(Dispatchers.Main) {
        onComplete()
      }
    }
  }

  fun deleteEmployee(employee: Employee, onComplete: () -> Unit = {}) {
    viewModelScope.launch(Dispatchers.IO) {
      repository.deleteEmployee(employee)
      withContext(Dispatchers.Main) {
        onComplete()
      }
    }
  }

  fun setActiveEmployee(employee: Employee) {
    val profile = businessProfile.value
    businessPreferences.updateProfile(
      profile.copy(
        activeEmployeeId = employee.id,
        activeEmployeeName = employee.name,
        activeEmployeeRole = employee.role,
        activeEmployeePin = employee.pinCode,
        userRole = employee.role,
        securityHideProfitsFromCashier = !employee.canViewProfits,
        securityRequireAdminPasswordForDelete = !employee.canDeleteInvoice,
        salesAllowManualPriceOverride = employee.canManualPriceOverride,
        delegateEmployeeId = if (employee.isDelegate) employee.id else profile.delegateEmployeeId,
        delegateEmployeeName = if (employee.isDelegate) employee.name else profile.delegateEmployeeName
      )
    )
  }

  fun setDeviceRole(role: String, syncKey: String, delegateId: Long = 0L, delegateName: String = "") {
    val profile = businessProfile.value
    businessPreferences.updateProfile(
      profile.copy(
        deviceRole = role,
        companySyncKey = syncKey,
        delegateEmployeeId = delegateId,
        delegateEmployeeName = delegateName
      )
    )
  }

  fun syncDelegateInvoicesNow(onResult: (DelegateSyncManager.SyncResult) -> Unit) {
    viewModelScope.launch(Dispatchers.IO) {
      val profile = businessProfile.value
      val result = DelegateSyncManager.performNetworkSync(getApplication(), appDao, profile)
      if (result.success) {
        val now = System.currentTimeMillis()
        businessPreferences.updateProfile(
          profile.copy(
            lastSyncTimestamp = now,
            lastSyncSummary = result.message
          )
        )
      }
      withContext(Dispatchers.Main) {
        onResult(result)
      }
    }
  }

  fun getDelegateOfflineSyncPayload(onPayload: (String) -> Unit) {
    viewModelScope.launch(Dispatchers.IO) {
      val profile = businessProfile.value
      val payload = DelegateSyncManager.buildDelegateSyncPayload(appDao, profile)
      withContext(Dispatchers.Main) {
        onPayload(payload)
      }
    }
  }

  fun importDelegateSyncPayload(payloadJson: String, onResult: (DelegateSyncManager.SyncResult) -> Unit) {
    viewModelScope.launch(Dispatchers.IO) {
      val profile = businessProfile.value
      val result = DelegateSyncManager.importDelegateSyncPayload(appDao, profile, payloadJson)
      if (result.success) {
        val now = System.currentTimeMillis()
        businessPreferences.updateProfile(
          profile.copy(
            lastSyncTimestamp = now,
            lastSyncSummary = result.message
          )
        )
      }
      withContext(Dispatchers.Main) {
        onResult(result)
      }
    }
  }
}
