package com.example.ui.components

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Textsms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItem
import com.example.data.model.InvoiceType
import com.example.data.model.PaymentType
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.ThermalInk
import com.example.ui.theme.ThermalPaper
import com.example.utils.InvoiceExportHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun InvoiceReceiptDialog(
  invoice: Invoice,
  items: List<InvoiceItem>,
  businessName: String = "الوكيل لتجارة المواد الغذائية",
  businessPhone: String = "01001234567",
  businessAddress: String = "القاهرة - سوق الجملة التجاري",
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val dateStr = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")).format(Date(invoice.timestamp))
  var selectedTab by remember { mutableIntStateOf(0) } // 0: A4 Formal, 1: POS Thermal
  var showPrintMenu by remember { mutableStateOf(false) }
  var showWhatsAppMenu by remember { mutableStateOf(false) }
  var showBluetoothMenu by remember { mutableStateOf(false) }

  val effectiveGrandDue = if (invoice.grandTotalDue > 0) {
    invoice.grandTotalDue
  } else {
    invoice.previousBalance + invoice.remainingAmount
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.96f)
        .imePadding()
        .clip(RoundedCornerShape(22.dp)),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 8.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = EmeraldPrimary,
              modifier = Modifier
                .size(24.dp)
                .padding(end = 6.dp)
            )
            Column {
              Text(
                text = if (invoice.type == InvoiceType.SALE) "فاتورة مبيعات معتمدة" else "فاتورة توريد مشتريات",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "رقم: #${invoice.invoiceNumber} • $dateStr",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Tab switcher
        TabRow(
          selectedTabIndex = selectedTab,
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
        ) {
          Tab(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            text = { Text("📑 الفاتورة الرسمية", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
          )
          Tab(
            selected = selectedTab == 1,
            onClick = { selectedTab = 1 },
            text = { Text("🧾 بون حراري POS", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Invoice Body Container
        Box(
          modifier = Modifier
            .weight(1f, fill = false)
            .fillMaxWidth()
            .height(360.dp)
        ) {
          if (selectedTab == 0) {
            // ================== TAB 0: FORMAL COMMERCIAL INVOICE ==================
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
              LazyColumn(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                // Header Details
                item {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Column {
                      Text(
                        text = if (invoice.type == InvoiceType.SALE) "حساب العميل:" else "حساب المورد:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                      Text(
                        text = invoice.partyName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                      )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                      Text(
                        text = "نوع المعاملة:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                      Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (invoice.paymentType) {
                          PaymentType.CASH -> EmeraldPrimary.copy(alpha = 0.15f)
                          PaymentType.CREDIT -> AmberPrimary.copy(alpha = 0.2f)
                          PaymentType.PARTIAL -> Color(0xFF1976D2).copy(alpha = 0.15f)
                        }
                      ) {
                        Text(
                          text = when (invoice.paymentType) {
                            PaymentType.CASH -> "نقداً كاش"
                            PaymentType.CREDIT -> "آجل بالكامل"
                            PaymentType.PARTIAL -> "دفع جزئي"
                          },
                          fontSize = 10.sp,
                          fontWeight = FontWeight.Bold,
                          color = when (invoice.paymentType) {
                            PaymentType.CASH -> EmeraldPrimary
                            PaymentType.CREDIT -> AmberPrimary
                            PaymentType.PARTIAL -> Color(0xFF1976D2)
                          },
                          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                      }
                    }
                  }
                  HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                }

                // Table Title
                item {
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(6.dp))
                      .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text("الصنف", fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.weight(1.6f))
                    Text("الكمية", fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    Text("السعر", fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    Text("الإجمالي", fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End)
                  }
                }

                // Items list
                items(items) { item ->
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(horizontal = 6.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(item.productName, fontSize = 11.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1.6f))
                    Text("${item.quantity} ${item.unitType}", fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    Text(String.format(Locale.ENGLISH, "%.1f", item.unitPrice), fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    Text(String.format(Locale.ENGLISH, "%.2f ج.م", item.totalPrice), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End)
                  }
                  HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                }

                // Financial Breakdown (Current + Previous + Grand Due)
                item {
                  Spacer(modifier = Modifier.height(4.dp))
                  Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Column(
                      modifier = Modifier.padding(10.dp),
                      verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                      SummaryRow("مجموع الأصناف:", String.format(Locale.ENGLISH, "%.2f ج.م", invoice.subtotal))
                      if (invoice.discount > 0) {
                        SummaryRow("الخصم التجاري:", String.format(Locale.ENGLISH, "- %.2f ج.م", invoice.discount), valueColor = Color.Red)
                      }
                      SummaryRow("صافي الفاتورة الحالية:", String.format(Locale.ENGLISH, "%.2f ج.م", invoice.totalAmount), isBold = true, valueColor = MaterialTheme.colorScheme.primary)
                      SummaryRow("المدفوع نقداً كاش:", String.format(Locale.ENGLISH, "%.2f ج.م", invoice.paidAmount))
                      if (invoice.remainingAmount > 0) {
                        SummaryRow("المتبقي من الفاتورة الحالية:", String.format(Locale.ENGLISH, "%.2f ج.م", invoice.remainingAmount), isBold = true, valueColor = AmberPrimary)
                      }

                      HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                      // Previous Balance (الرصيد السابق)
                      val prevLabel = if (invoice.type == InvoiceType.SALE) "الرصيد السابق للعميل:" else "الرصيد السابق للمورد:"
                      SummaryRow(prevLabel, String.format(Locale.ENGLISH, "%.2f ج.م", invoice.previousBalance), isBold = true)

                      // Grand Total Due (إجمالي الحساب المستحق الكلي بعد الفاتورة)
                      val grandLabel = if (invoice.type == InvoiceType.SALE) "إجمالي الحساب المستحق بعد الفاتورة:" else "إجمالي المستحق للمورد بعد الفاتورة:"
                      SummaryRow(
                        label = grandLabel,
                        value = String.format(Locale.ENGLISH, "%.2f ج.م", effectiveGrandDue),
                        isBold = true,
                        fontSize = 14.sp,
                        valueColor = if (invoice.type == InvoiceType.SALE) EmeraldPrimary else AmberPrimary
                      )
                    }
                  }
                }
              }
            }
          } else {
            // ================== TAB 1: POS THERMAL RECEIPT VIEW (58/80mm) ==================
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = ThermalPaper),
              elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
              LazyColumn(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                item {
                  Text(text = businessName, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = ThermalInk)
                  Text(text = if (invoice.type == InvoiceType.SALE) "* فاتورة مبيعات تجارية *" else "* فاتورة توريد مشتريات *", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = ThermalInk)
                  if (businessPhone.isNotBlank()) {
                    Text(text = "هاتف: $businessPhone", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = ThermalInk)
                  }
                  Text(text = "فاتورة: #${invoice.invoiceNumber}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = ThermalInk)
                  Text(text = "التاريخ: $dateStr", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = ThermalInk)
                  Text(text = "الطرف: ${invoice.partyName}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = ThermalInk)
                  Text(text = "--------------------------------", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = ThermalInk)
                }

                items(items) { itm ->
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(
                      text = "${itm.productName.take(16)} (${itm.quantity} ${itm.unitType})",
                      fontFamily = FontFamily.Monospace,
                      fontSize = 11.sp,
                      color = ThermalInk,
                      modifier = Modifier.weight(1f)
                    )
                    Text(
                      text = String.format(Locale.ENGLISH, "%.2f", itm.totalPrice),
                      fontFamily = FontFamily.Monospace,
                      fontWeight = FontWeight.Bold,
                      fontSize = 11.sp,
                      color = ThermalInk
                    )
                  }
                }

                item {
                  Text(text = "--------------------------------", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = ThermalInk)
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("مجموع الفاتورة:", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = ThermalInk)
                    Text(String.format(Locale.ENGLISH, "%.2f ج.م", invoice.subtotal), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = ThermalInk)
                  }
                  if (invoice.discount > 0) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                      Text("الخصم:", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.Red)
                      Text(String.format(Locale.ENGLISH, "-%.2f ج.م", invoice.discount), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.Red)
                    }
                  }
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("صافي الفاتورة:", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ThermalInk)
                    Text(String.format(Locale.ENGLISH, "%.2f ج.م", invoice.totalAmount), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ThermalInk)
                  }
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("المدفوع نقداً:", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = ThermalInk)
                    Text(String.format(Locale.ENGLISH, "%.2f ج.م", invoice.paidAmount), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = ThermalInk)
                  }
                  if (invoice.remainingAmount > 0) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                      Text("المتبقي آجل:", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Red)
                      Text(String.format(Locale.ENGLISH, "%.2f ج.م", invoice.remainingAmount), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Red)
                    }
                  }

                  Text(text = "--------------------------------", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = ThermalInk)
                  // Previous Balance & Total Grand Due in Thermal POS
                  val prevLabel = if (invoice.type == InvoiceType.SALE) "رصيد سابق:" else "مستحق سابق:"
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(prevLabel, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = ThermalInk)
                    Text(String.format(Locale.ENGLISH, "%.2f ج.م", invoice.previousBalance), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = ThermalInk)
                  }

                  val grandLabel = if (invoice.type == InvoiceType.SALE) "إجمالي الحساب المستحق:" else "إجمالي المستحق للمورد:"
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(grandLabel, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ThermalInk)
                    Text(String.format(Locale.ENGLISH, "%.2f ج.م", effectiveGrandDue), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ThermalInk)
                  }

                  Text(text = "================================", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = ThermalInk)
                  Text(text = "||||| |||||| |||| |||||||||||||", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ThermalInk)
                  Text(text = "شكراً لتعاملكم معنا - نتشرف بخدمتكم", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = ThermalInk)
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // ================== ALL PRINT & SHARE OPTIONS ==================
        Text(
          text = "خيارات الطباعة والمشاركة المباشرة:",
          fontWeight = FontWeight.Bold,
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(6.dp))

        // Action Buttons Row with Horizontal Scroll
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // 1. Print on Any Printer (PrintManager & Thermal POS)
          Box {
            Button(
              onClick = { showPrintMenu = true },
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
              shape = RoundedCornerShape(10.dp),
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) {
              Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("طباعة الفاتورة 🖨️", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            DropdownMenu(
              expanded = showPrintMenu,
              onDismissRequest = { showPrintMenu = false }
            ) {
              DropdownMenuItem(
                text = {
                  Column {
                    Text("طابعة عادية / شبكة / لاسلكية (A4 نظام أندرويد)", fontWeight = FontWeight.Bold)
                    Text("تدعم كافة أنواع الطابعات المتصلة بالجهاز أو الحفظ كـ PDF", fontSize = 10.sp, color = Color.Gray)
                  }
                },
                leadingIcon = { Icon(Icons.Default.Print, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                onClick = {
                  showPrintMenu = false
                  InvoiceExportHelper.printInvoiceViaSystem(context, invoice, items, businessName, businessPhone, businessAddress)
                }
              )
              DropdownMenuItem(
                text = {
                  Column {
                    Text("طابعة إيصالات حرارية وبونات (POS 58/80mm)", fontWeight = FontWeight.Bold)
                    Text("طباعة بون فوري مناسب لطابعات الكاشير والبلوتوث", fontSize = 10.sp, color = Color.Gray)
                  }
                },
                leadingIcon = { Icon(Icons.Default.Receipt, contentDescription = null, tint = OrangePrimary) },
                onClick = {
                  showPrintMenu = false
                  Toast.makeText(context, "جاري إعداد بون الطباعة الحرارية...", Toast.LENGTH_SHORT).show()
                  val img = InvoiceExportHelper.generateInvoiceImage(context, invoice, items, businessName, businessPhone, isThermalFormat = true)
                  InvoiceExportHelper.shareFile(context, img, "image/png", "بون حراري - فاتورة #${invoice.invoiceNumber}", specificPackage = "com.android.bluetooth")
                }
              )
            }
          }

          // 2. WhatsApp Send Options (Image, PDF, Text)
          Box {
            Button(
              onClick = { showWhatsAppMenu = true },
              colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
              shape = RoundedCornerShape(10.dp),
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) {
              Icon(Icons.Default.Textsms, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("واتساب 💬", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            DropdownMenu(
              expanded = showWhatsAppMenu,
              onDismissRequest = { showWhatsAppMenu = false }
            ) {
              DropdownMenuItem(
                text = {
                  Column {
                    Text("إرسال كـ صورة إلى واتساب 🖼️", fontWeight = FontWeight.Bold)
                    Text("صورة عالية الدقة واضحة للعميل أو المورد", fontSize = 10.sp, color = Color.Gray)
                  }
                },
                leadingIcon = { Icon(Icons.Default.Image, contentDescription = null, tint = Color(0xFF0288D1)) },
                onClick = {
                  showWhatsAppMenu = false
                  val img = InvoiceExportHelper.generateInvoiceImage(context, invoice, items, businessName, businessPhone, isThermalFormat = false)
                  InvoiceExportHelper.shareFile(context, img, "image/png", "فاتورة #${invoice.invoiceNumber}", specificPackage = "com.whatsapp")
                }
              )
              DropdownMenuItem(
                text = {
                  Column {
                    Text("إرسال كـ ملف PDF رسمي إلى واتساب 📄", fontWeight = FontWeight.Bold)
                    Text("مستند رسمي معتمد قابل للطباعة والحفظ", fontSize = 10.sp, color = Color.Gray)
                  }
                },
                leadingIcon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color(0xFFC62828)) },
                onClick = {
                  showWhatsAppMenu = false
                  val pdf = InvoiceExportHelper.generateInvoicePdf(context, invoice, items, businessName, businessPhone, businessAddress)
                  InvoiceExportHelper.shareFile(context, pdf, "application/pdf", "فاتورة #${invoice.invoiceNumber}", specificPackage = "com.whatsapp")
                }
              )
              DropdownMenuItem(
                text = {
                  Column {
                    Text("إرسال رسالة نصية بالبيانات والأصناف 📝", fontWeight = FontWeight.Bold)
                    Text("نص رسالة منسق بكافة بنود الفاتورة وإجمالي الحساب", fontSize = 10.sp, color = Color.Gray)
                  }
                },
                leadingIcon = { Icon(Icons.Default.Description, contentDescription = null, tint = EmeraldPrimary) },
                onClick = {
                  showWhatsAppMenu = false
                  val text = InvoiceExportHelper.formatWhatsAppText(invoice, items, businessName)
                  val sendIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    putExtra(android.content.Intent.EXTRA_TEXT, text)
                    type = "text/plain"
                    setPackage("com.whatsapp")
                  }
                  try {
                    context.startActivity(sendIntent)
                  } catch (e: Exception) {
                    val fallbackIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                      putExtra(android.content.Intent.EXTRA_TEXT, text)
                      type = "text/plain"
                    }
                    context.startActivity(android.content.Intent.createChooser(fallbackIntent, "إرسال الفاتورة عبر واتساب"))
                  }
                }
              )
            }
          }

          // 3. Bluetooth Direct Send (PDF & Thermal Image)
          Box {
            Button(
              onClick = { showBluetoothMenu = true },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0)), // Bluetooth Blue
              shape = RoundedCornerShape(10.dp),
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) {
              Icon(Icons.Default.Bluetooth, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("بلوتوث 📶", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            DropdownMenu(
              expanded = showBluetoothMenu,
              onDismissRequest = { showBluetoothMenu = false }
            ) {
              DropdownMenuItem(
                text = {
                  Column {
                    Text("إرسال ملف PDF عبر البلوتوث", fontWeight = FontWeight.Bold)
                    Text("نقل مباشر لجهاز العميل أو كمبيوتر المحل", fontSize = 10.sp, color = Color.Gray)
                  }
                },
                leadingIcon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color(0xFFC62828)) },
                onClick = {
                  showBluetoothMenu = false
                  val pdf = InvoiceExportHelper.generateInvoicePdf(context, invoice, items, businessName, businessPhone, businessAddress)
                  InvoiceExportHelper.shareFile(context, pdf, "application/pdf", "إرسال بلوتوث - فاتورة #${invoice.invoiceNumber}", specificPackage = "com.android.bluetooth")
                }
              )
              DropdownMenuItem(
                text = {
                  Column {
                    Text("إرسال بون حراري / صورة عبر البلوتوث", fontWeight = FontWeight.Bold)
                    Text("مناسب لطابعات البلوتوث المحمولة أو هواتف العملاء", fontSize = 10.sp, color = Color.Gray)
                  }
                },
                leadingIcon = { Icon(Icons.Default.Receipt, contentDescription = null, tint = OrangePrimary) },
                onClick = {
                  showBluetoothMenu = false
                  val img = InvoiceExportHelper.generateInvoiceImage(context, invoice, items, businessName, businessPhone, isThermalFormat = true)
                  InvoiceExportHelper.shareFile(context, img, "image/png", "بون حراري بلوتوث - فاتورة #${invoice.invoiceNumber}", specificPackage = "com.android.bluetooth")
                }
              )
            }
          }

          // 4. Share PDF File
          OutlinedButton(
            onClick = {
              val pdf = InvoiceExportHelper.generateInvoicePdf(context, invoice, items, businessName, businessPhone, businessAddress)
              InvoiceExportHelper.shareFile(context, pdf, "application/pdf", "فاتورة #${invoice.invoiceNumber}")
            },
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFFC62828))
            Spacer(modifier = Modifier.width(4.dp))
            Text("مشاركة PDF", fontSize = 12.sp)
          }

          // 5. Share Image (PNG)
          OutlinedButton(
            onClick = {
              val img = InvoiceExportHelper.generateInvoiceImage(context, invoice, items, businessName, businessPhone, isThermalFormat = false)
              InvoiceExportHelper.shareFile(context, img, "image/png", "صورة فاتورة #${invoice.invoiceNumber}")
            },
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF0288D1))
            Spacer(modifier = Modifier.width(4.dp))
            Text("مشاركة صورة", fontSize = 12.sp)
          }
        }
      }
    }
  }
}

@Composable
private fun SummaryRow(
  label: String,
  value: String,
  isBold: Boolean = false,
  fontSize: androidx.compose.ui.unit.TextUnit = 12.sp,
  valueColor: Color = Color.Unspecified
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(
      text = label,
      fontSize = fontSize,
      fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
      color = MaterialTheme.colorScheme.onSurface
    )
    Text(
      text = value,
      fontSize = fontSize,
      fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
      color = valueColor
    )
  }
}
