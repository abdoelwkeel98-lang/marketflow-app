package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Textsms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.PaymentTransaction
import com.example.data.model.TransactionType
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import com.example.utils.TafqeetHelper
import com.example.utils.VoucherExportHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VoucherReceiptDialog(
  transaction: PaymentTransaction,
  businessName: String = "الوكيل لتجارة المواد الغذائية",
  businessPhone: String = "",
  currency: String = "ج.م",
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val isReceipt = transaction.type == TransactionType.CUSTOMER_PAYMENT || transaction.type == TransactionType.CASH_DEPOSIT
  val voucherNo = VoucherExportHelper.getVoucherNumber(transaction)
  val voucherTitle = VoucherExportHelper.getVoucherTitle(transaction)
  val dateStr = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")).format(Date(transaction.timestamp))
  val tafqeetText = TafqeetHelper.convertToArabicWords(transaction.amount)

  val primaryAccent = if (isReceipt) EmeraldPrimary else OrangePrimary

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .padding(vertical = 16.dp),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(12.dp)
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {

        // Dialog Top Bar
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(primaryAccent)
            .padding(horizontal = 16.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = CircleShape,
              color = Color.White.copy(alpha = 0.2f),
              modifier = Modifier.size(34.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  Icons.Default.Receipt,
                  contentDescription = null,
                  tint = Color.White,
                  modifier = Modifier.size(20.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = voucherTitle,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
              )
              Text(
                text = "برنامج الوكيل لتجارة المواد الغذائية",
                fontSize = 10.sp,
                color = Color.White.copy(alpha = 0.85f)
              )
            }
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White)
          }
        }

        // Voucher Body inside scrollable area
        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f, fill = false)
            .padding(16.dp),
          contentPadding = PaddingValues(bottom = 12.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          // Official Paper Voucher View
          item {
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, primaryAccent.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA))
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                // Header with Store Name & Voucher Number
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Text(
                      text = businessName,
                      fontWeight = FontWeight.ExtraBold,
                      fontSize = 15.sp,
                      color = Color(0xFF1E293B)
                    )
                    if (businessPhone.isNotBlank()) {
                      Text(text = "هاتف: $businessPhone", fontSize = 11.sp, color = Color.Gray)
                    }
                  }

                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = primaryAccent.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, primaryAccent)
                  ) {
                    Column(
                      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                      horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                      Text(
                        text = voucherNo,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = primaryAccent,
                        fontFamily = FontFamily.Monospace
                      )
                      Text(
                        text = dateStr,
                        fontSize = 9.sp,
                        color = Color.DarkGray
                      )
                    }
                  }
                }

                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))

                // Amount Highlight Banner
                Surface(
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(8.dp),
                  color = primaryAccent.copy(alpha = 0.08f),
                  border = androidx.compose.foundation.BorderStroke(1.dp, primaryAccent.copy(alpha = 0.3f))
                ) {
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(
                      text = "المبلغ المطلوب:",
                      fontWeight = FontWeight.Bold,
                      fontSize = 13.sp,
                      color = Color(0xFF334155)
                    )
                    Text(
                      text = String.format(Locale.ENGLISH, "%.2f %s", transaction.amount, currency),
                      fontWeight = FontWeight.Black,
                      fontSize = 20.sp,
                      color = primaryAccent
                    )
                  }
                }

                // Party row
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.Top
                ) {
                  Text(
                    text = if (isReceipt) "استلمنا من:" else "يصرف إلى:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.width(90.dp)
                  )
                  Text(
                    text = transaction.partyName,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    color = Color(0xFF0F172A)
                  )
                }

                // Tafqeet row
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.Top
                ) {
                  Text(
                    text = "المبلغ كتابة:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.width(90.dp)
                  )
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFEFF6FF)
                  ) {
                    Text(
                      text = tafqeetText,
                      fontWeight = FontWeight.Bold,
                      fontSize = 12.sp,
                      color = Color(0xFF1E3A8A),
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                  }
                }

                // Payment mode
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = "طريقة السداد:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.width(90.dp)
                  )
                  Text(
                    text = "نقداً (خزينة الصندوق)",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                    color = Color(0xFF334155)
                  )
                }

                // Notes / Reason
                if (transaction.notes.isNotBlank()) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                  ) {
                    Text(
                      text = "البيان / ملاحظات:",
                      fontWeight = FontWeight.Bold,
                      fontSize = 12.sp,
                      color = Color.Gray,
                      modifier = Modifier.width(90.dp)
                    )
                    Text(
                      text = transaction.notes,
                      fontWeight = FontWeight.Normal,
                      fontSize = 12.sp,
                      color = Color(0xFF334155)
                    )
                  }
                }

                // Balance After Voucher Banner (الرصيد بعد هذا السند)
                val matchBal: String? = remember(transaction.notes) {
                  val match = Regex("""الرصيد بعد السند:\s*([\d.]+)\s*ج\.م""").find(transaction.notes)
                  match?.groupValues?.getOrNull(1)
                }

                Surface(
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(10.dp),
                  color = primaryAccent.copy(alpha = 0.08f),
                  border = androidx.compose.foundation.BorderStroke(1.5.dp, primaryAccent.copy(alpha = 0.4f))
                ) {
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(
                      text = if (isReceipt) "الرصيد المتبقي على العميل بعد هذا السند:" else "الرصيد المتبقي للمورد بعد هذا السند:",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color(0xFF1E293B)
                    )
                    val balText: String = if (matchBal != null) {
                      val d = matchBal.toDoubleOrNull() ?: 0.0
                      if (d <= 0.0) "خالص بالكامل (0.00 $currency) ✓" else "$matchBal $currency"
                    } else {
                      "تم الخصم وتحديث الرصيد"
                    }

                    Text(
                      text = balText,
                      fontSize = 14.sp,
                      fontWeight = FontWeight.Black,
                      color = if (matchBal == "0.00" || matchBal == "0.0") EmeraldPrimary else primaryAccent
                    )
                  }
                }

                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))

                // Signatures
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceAround
                ) {
                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                      text = if (isReceipt) "أمين الصندوق" else "المستلم",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(text = "...................", fontSize = 10.sp, color = Color.Gray)
                  }

                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                      text = "المحاسب",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(text = "...................", fontSize = 10.sp, color = Color.Gray)
                  }

                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                      text = "ختم المؤسسة",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(text = "[                ]", fontSize = 10.sp, color = Color.Gray)
                  }
                }
              }
            }
          }
        }

        // Action Buttons Row
        Surface(
          modifier = Modifier.fillMaxWidth(),
          tonalElevation = 6.dp,
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = {
                VoucherExportHelper.printVoucher(context, transaction, businessName)
              },
              modifier = Modifier.weight(1f),
              colors = ButtonDefaults.buttonColors(containerColor = primaryAccent)
            ) {
              Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("طباعة السند", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
              onClick = {
                VoucherExportHelper.shareVoucherPdf(context, transaction, businessName)
              },
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("مشاركة PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            IconButton(
              onClick = {
                VoucherExportHelper.shareVoucherViaWhatsApp(context, transaction, businessName = businessName)
              }
            ) {
              Icon(Icons.Default.Textsms, contentDescription = "واتساب", tint = EmeraldPrimary)
            }

            IconButton(
              onClick = {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("سند محاسبي", VoucherExportHelper.generateVoucherText(transaction, businessName))
                clipboard.setPrimaryClip(clip)
                Toast.makeText(context, "تم نسخ تفاصيل السند إلى الحافظة", Toast.LENGTH_SHORT).show()
              }
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = "نسخ", tint = Color.DarkGray)
            }
          }
        }
      }
    }
  }
}
