package com.example.ai

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.data.model.PaymentType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class ParsedItem(
  val productName: String,
  val quantity: Int,
  val unitType: String = "كرتونة", // "كرتونة" أو "قطعة"
  val unitPrice: Double? = null
)

data class ParsedTransactionResult(
  val type: String, // "SALE" or "PURCHASE"
  val partyName: String,
  val paymentType: PaymentType,
  val items: List<ParsedItem>,
  val notes: String
)

data class ReceiptExtractedItem(
  val name: String,
  val quantity: Int,
  val unit: String,
  val costPrice: Double,
  val total: Double
)

data class ParsedReceiptResult(
  val supplierName: String,
  val invoiceNumber: String,
  val totalAmount: Double,
  val items: List<ReceiptExtractedItem>
)

object GeminiSupermarketService {
  private const val TAG = "GeminiService"
  private const val MODEL_NAME = "gemini-3.5-flash"
  private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

  private val okHttpClient = OkHttpClient.Builder()
    .connectTimeout(30, TimeUnit.SECONDS)
    .readTimeout(45, TimeUnit.SECONDS)
    .writeTimeout(30, TimeUnit.SECONDS)
    .build()

  /**
   * Checks if Gemini API Key is configured.
   */
  fun isApiKeyAvailable(): Boolean {
    val key = BuildConfig.GEMINI_API_KEY
    return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
  }

  /**
   * Helper to make REST call to Gemini 3.5 Flash.
   */
  private suspend fun callGemini(jsonPayload: String): String? = withContext(Dispatchers.IO) {
    val apiKey = BuildConfig.GEMINI_API_KEY
    if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
      Log.w(TAG, "Gemini API key is not configured in Secrets panel.")
      return@withContext null
    }

    val url = "$BASE_URL/$MODEL_NAME:generateContent?key=$apiKey"
    val mediaType = "application/json; charset=utf-8".toMediaType()
    val requestBody = jsonPayload.toRequestBody(mediaType)

    val request = Request.Builder()
      .url(url)
      .post(requestBody)
      .build()

    try {
      val response = okHttpClient.newCall(request).execute()
      val responseString = response.body?.string()
      if (response.isSuccessful && !responseString.isNullOrBlank()) {
        val root = JSONObject(responseString)
        val candidates = root.optJSONArray("candidates")
        val content = candidates?.optJSONObject(0)?.optJSONObject("content")
        val parts = content?.optJSONArray("parts")
        return@withContext parts?.optJSONObject(0)?.optString("text")
      } else {
        Log.e(TAG, "Gemini error response code: ${response.code}, body: $responseString")
        return@withContext null
      }
    } catch (e: Exception) {
      Log.e(TAG, "Gemini call failed", e)
      return@withContext null
    }
  }

  /**
   * Voice / Text to Transaction Parser.
   * Understands Egyptian / Arabic retail terminology (بيع، توريد، كرتونة، على الحساب، كاش).
   */
  suspend fun parseTransactionCommand(
    commandText: String,
    availableProducts: List<String>,
    availableCustomers: List<String>,
    availableSuppliers: List<String>
  ): ParsedTransactionResult? {
    val prompt = """
      أنت نظام ذكي لمحاسبة السوبرماركت بالجملة. مهمتك تحليل الأمر المدخل بالصوت أو النص واستخراج تفاصيل الفاتورة بدقة.
      
      الأمر المدخل: "$commandText"
      
      الأصناف المسجلة في السوبرماركت:
      ${availableProducts.take(20).joinToString(", ")}
      
      العملاء المسجلين:
      ${availableCustomers.take(15).joinToString(", ")}
      
      الموردين المسجلين:
      ${availableSuppliers.take(15).joinToString(", ")}
      
      قم بالرد فقط بـ JSON صالح (بدون أي كود ماركداون إضافي):
      {
        "type": "SALE" أو "PURCHASE",
        "partyName": "اسم العميل أو المورد المستخرج أو 'عميل نقدي' إذا لم يحدد",
        "paymentType": "CASH" أو "CREDIT" أو "PARTIAL",
        "items": [
          {
            "productName": "اسم الصنف الأقرب من الأصناف المسجلة أو كما نطق",
            "quantity": 1,
            "unitType": "كرتونة" أو "قطعة"
          }
        ],
        "notes": "ملخص الفاتورة"
      }
    """.trimIndent()

    val payload = JSONObject().apply {
      put("contents", JSONArray().apply {
        put(JSONObject().apply {
          put("parts", JSONArray().apply {
            put(JSONObject().apply {
              put("text", prompt)
            })
          })
        })
      })
      put("generationConfig", JSONObject().apply {
        put("responseMimeType", "application/json")
        put("temperature", 0.1)
      })
    }.toString()

    val rawResponse = callGemini(payload) ?: return null
    return try {
      val cleanJson = rawResponse.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
      val obj = JSONObject(cleanJson)
      val type = obj.optString("type", "SALE")
      val partyName = obj.optString("partyName", if (type == "SALE") "عميل نقدي" else "مورد نقدي")
      val payTypeStr = obj.optString("paymentType", "CASH")
      val paymentType = when (payTypeStr) {
        "CREDIT" -> PaymentType.CREDIT
        "PARTIAL" -> PaymentType.PARTIAL
        else -> PaymentType.CASH
      }

      val itemsArr = obj.optJSONArray("items") ?: JSONArray()
      val items = mutableListOf<ParsedItem>()
      for (i in 0 until itemsArr.length()) {
        val itemObj = itemsArr.optJSONObject(i) ?: continue
        items.add(
          ParsedItem(
            productName = itemObj.optString("productName", "صنف"),
            quantity = itemObj.optInt("quantity", 1).coerceAtLeast(1),
            unitType = itemObj.optString("unitType", "كرتونة")
          )
        )
      }

      ParsedTransactionResult(
        type = type,
        partyName = partyName,
        paymentType = paymentType,
        items = items,
        notes = obj.optString("notes", commandText)
      )
    } catch (e: Exception) {
      Log.e(TAG, "Failed to parse JSON from Gemini", e)
      null
    }
  }

  /**
   * Receipt OCR Analyzer using Gemini Multimodal.
   */
  suspend fun analyzeReceiptImage(bitmap: Bitmap): ParsedReceiptResult? = withContext(Dispatchers.IO) {
    val byteArrayOutputStream = ByteArrayOutputStream()
    bitmap.compress(Bitmap.CompressFormat.JPEG, 85, byteArrayOutputStream)
    val base64Image = Base64.encodeToString(byteArrayOutputStream.toByteArray(), Base64.NO_WRAP)

    val prompt = """
      أنت خبير في قراءة فواتير المشتريات الورقية وتفريغ بيانات البضاعة للمخزن.
      اقرأ الصورة المرفقة واستخرج الأصناف والكميات وأسعار الشراء واسم المورد ورقم الفاتورة.
      
      قم بالرد فقط بـ JSON صالح (بدون ماركداون):
      {
        "supplierName": "اسم المورد أو الشركة إذا ظهرت في الفاتورة أو 'مورد عام'",
        "invoiceNumber": "رقم الفاتورة أو فراغ",
        "totalAmount": 0.0,
        "items": [
          {
            "name": "اسم الصنف",
            "quantity": 1,
            "unit": "كرتونة" أو "قطعة" أو "علبة",
            "costPrice": 0.0,
            "total": 0.0
          }
        ]
      }
    """.trimIndent()

    val payload = JSONObject().apply {
      put("contents", JSONArray().apply {
        put(JSONObject().apply {
          put("parts", JSONArray().apply {
            put(JSONObject().apply {
              put("text", prompt)
            })
            put(JSONObject().apply {
              put("inlineData", JSONObject().apply {
                put("mimeType", "image/jpeg")
                put("data", base64Image)
              })
            })
          })
        })
      })
      put("generationConfig", JSONObject().apply {
        put("responseMimeType", "application/json")
        put("temperature", 0.2)
      })
    }.toString()

    val rawResponse = callGemini(payload) ?: return@withContext null
    try {
      val cleanJson = rawResponse.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
      val obj = JSONObject(cleanJson)
      val supplierName = obj.optString("supplierName", "مورد عام")
      val invoiceNumber = obj.optString("invoiceNumber", "INV-${System.currentTimeMillis() % 10000}")
      val totalAmount = obj.optDouble("totalAmount", 0.0)

      val itemsArr = obj.optJSONArray("items") ?: JSONArray()
      val items = mutableListOf<ReceiptExtractedItem>()
      for (i in 0 until itemsArr.length()) {
        val itemObj = itemsArr.optJSONObject(i) ?: continue
        items.add(
          ReceiptExtractedItem(
            name = itemObj.optString("name", "صنف"),
            quantity = itemObj.optInt("quantity", 1).coerceAtLeast(1),
            unit = itemObj.optString("unit", "كرتونة"),
            costPrice = itemObj.optDouble("costPrice", 0.0),
            total = itemObj.optDouble("total", 0.0)
          )
        )
      }

      ParsedReceiptResult(
        supplierName = supplierName,
        invoiceNumber = invoiceNumber,
        totalAmount = totalAmount,
        items = items
      )
    } catch (e: Exception) {
      Log.e(TAG, "Receipt OCR parsing error", e)
      null
    }
  }

  /**
   * AI Business Advisor for Supermarket Owners.
   */
  suspend fun getBusinessInsights(
    metricsSummary: String
  ): String = withContext(Dispatchers.IO) {
    val prompt = """
      أنت مستشار مالي وتجاري محترف متخصص في تجارة السوبرماركت وتوزيع الجملة ونصف الجملة.
      بناءً على أرقام السوبرماركت الحالية أدناه، قدم 4 إلى 5 نصائح استراتيجية عملية ومباشرة ومحفزة لصاحب المحل باللغة العربية:
      (نصائح لتحسين دورة رأس المال، تسعير الجملة، تحصيل ديون العملاء، معالجة النواقص والأصناف بطيئة الحركة، وخفض المصروفات).
      
      الأرقام الحالية:
      $metricsSummary
      
      اجعل النصائح مرتبة بنقاط واضحة ومباشرة مع إيموجي مناسب لكل نقطة.
    """.trimIndent()

    val payload = JSONObject().apply {
      put("contents", JSONArray().apply {
        put(JSONObject().apply {
          put("parts", JSONArray().apply {
            put(JSONObject().apply {
              put("text", prompt)
            })
          })
        })
      })
      put("generationConfig", JSONObject().apply {
        put("temperature", 0.7)
      })
    }.toString()

    val response = callGemini(payload)
    response ?: "تعذر جلب نصائح المستشار الذكي حالياً. يرجى التأكد من اتصال الإنترنت وإعداد مفتاح Gemini API في لوحة الأسرار."
  }
}
