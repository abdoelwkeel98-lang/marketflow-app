package com.example.utils

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.Customer
import com.example.data.model.Invoice
import com.example.data.model.PaymentTransaction
import com.example.data.model.Supplier
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * محرك طباعة وتصدير كشوف حسابات العملاء والموردين الشامل:
 * - يدعم جميع أنواع الطابعات: A4، حراري 80mm، حراري 58mm، طابعات النظام عبر PrintManager
 * - إمكانية حفظ ومشاركة كشف الحساب بصيغة PDF عالية الدقة
 * - إمكانية إرسال كشف الحساب منسقاً بالكامل عبر واتساب
 * - طباعة كشف مديونيات العملاء الإجمالي وكشف مستحقات الموردين
 */
object StatementExportHelper {

  data class StatementMovement(
    val dateStr: String,
    val typeName: String,
    val referenceNo: String,
    val debit: Double, // مدين (فواتير على العميل / سداد للمورد)
    val credit: Double, // دائن (سداد من العميل / فواتير للمورد)
    val balance: Double, // رصيد تراكمي
    val notes: String = ""
  )

  /**
   * بناء قائمة الحركات المالية المرتبة زمنياً للطرف
   */
  fun buildMovements(
    isCustomer: Boolean,
    invoices: List<Invoice>,
    payments: List<PaymentTransaction>
  ): List<StatementMovement> {
    data class RawEntry(val time: Long, val isInvoice: Boolean, val inv: Invoice?, val tx: PaymentTransaction?)

    val allRaw = mutableListOf<RawEntry>()
    invoices.forEach { allRaw.add(RawEntry(it.timestamp, true, it, null)) }
    payments.forEach { allRaw.add(RawEntry(it.timestamp, false, null, it)) }
    allRaw.sortBy { it.time }

    val result = mutableListOf<StatementMovement>()
    var runningBalance = 0.0

    allRaw.forEach { entry ->
      val dateFormatted = SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH).format(Date(entry.time))
      if (entry.isInvoice && entry.inv != null) {
        val inv = entry.inv
        if (isCustomer) {
          // فاتورة بيع: تزيد مديونية العميل (مدين)
          runningBalance += inv.remainingAmount
          result.add(
            StatementMovement(
              dateStr = dateFormatted,
              typeName = "فاتورة بيع",
              referenceNo = inv.invoiceNumber,
              debit = inv.totalAmount,
              credit = inv.paidAmount,
              balance = runningBalance,
              notes = if (inv.paidAmount > 0) "مدفوع جزئي: ${inv.paidAmount}" else "آجل بالكامل"
            )
          )
        } else {
          // فاتورة شراء: تزيد مستحقات المورد (دائن)
          runningBalance += inv.remainingAmount
          result.add(
            StatementMovement(
              dateStr = dateFormatted,
              typeName = "فاتورة توريد",
              referenceNo = inv.invoiceNumber,
              debit = inv.paidAmount,
              credit = inv.totalAmount,
              balance = runningBalance,
              notes = if (inv.paidAmount > 0) "مسدد جزئي: ${inv.paidAmount}" else "آجل بالكامل"
            )
          )
        }
      } else if (!entry.isInvoice && entry.tx != null) {
        val tx = entry.tx
        if (isCustomer) {
          // سند قبض: يسدد من دين العميل (دائن)
          runningBalance -= tx.amount
          result.add(
            StatementMovement(
              dateStr = dateFormatted,
              typeName = "سند قبض نقدي",
              referenceNo = "REC-${tx.id}",
              debit = 0.0,
              credit = tx.amount,
              balance = runningBalance,
              notes = tx.notes.ifBlank { "دفعة نقدية مسددة" }
            )
          )
        } else {
          // سند صرف: نسدد للمورد (مدين)
          runningBalance -= tx.amount
          result.add(
            StatementMovement(
              dateStr = dateFormatted,
              typeName = "سند صرف وسداد",
              referenceNo = "PAY-${tx.id}",
              debit = tx.amount,
              credit = 0.0,
              balance = runningBalance,
              notes = tx.notes.ifBlank { "دفعة نقدية مسددة للمورد" }
            )
          )
        }
      }
    }
    return result
  }

  /**
   * إنشاء ملف PDF لكشف الحساب يدعم جميع المقاسات: A4، حراري 80mm، حراري 58mm
   */
  fun generateStatementPdf(
    context: Context,
    partyName: String,
    partyPhone: String,
    isCustomer: Boolean,
    currentBalance: Double,
    invoices: List<Invoice>,
    payments: List<PaymentTransaction>,
    businessName: String = "الوكيل لتجارة المواد الغذائية",
    businessPhone: String = "01001234567",
    businessAddress: String = "شارع السوق التجاري - القاهرة",
    pageSizeType: String = "A4"
  ): File {
    val dir = File(context.cacheDir, "statements").apply { mkdirs() }
    val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(Date())
    val safeName = partyName.replace("\\s+".toRegex(), "_").take(15)
    val file = File(dir, "STATEMENT_${safeName}_${timeStamp}.pdf")

    val movements = buildMovements(isCustomer, invoices, payments)
    val pdfDocument = PdfDocument()

    when (pageSizeType) {
      "حراري 80mm" -> renderThermal80Pdf(pdfDocument, partyName, partyPhone, isCustomer, currentBalance, movements, businessName, businessPhone, businessAddress)
      "حراري 58mm" -> renderThermal58Pdf(pdfDocument, partyName, partyPhone, isCustomer, currentBalance, movements, businessName, businessPhone, businessAddress)
      else -> renderA4Pdf(pdfDocument, partyName, partyPhone, isCustomer, currentBalance, movements, businessName, businessPhone, businessAddress)
    }

    val outputStream = FileOutputStream(file)
    pdfDocument.writeTo(outputStream)
    pdfDocument.close()
    outputStream.flush()
    outputStream.close()

    return file
  }

  /**
   * رسم كشف حساب مقاس A4 قياسي رسمي
   */
  private fun renderA4Pdf(
    pdfDocument: PdfDocument,
    partyName: String,
    partyPhone: String,
    isCustomer: Boolean,
    currentBalance: Double,
    movements: List<StatementMovement>,
    businessName: String,
    businessPhone: String,
    businessAddress: String
  ) {
    val pageWidth = 595
    val pageHeight = 842
    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas
    val paint = Paint().apply { isAntiAlias = true }

    // 1. ترويسة علوية فاخرة بلون الزمرد الداكن
    paint.color = Color.rgb(5, 150, 105)
    canvas.drawRect(0f, 0f, pageWidth.toFloat(), 85f, paint)

    paint.color = Color.WHITE
    paint.textSize = 20f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText(businessName, (pageWidth - 25).toFloat(), 38f, paint)

    paint.textSize = 11f
    paint.typeface = Typeface.DEFAULT
    val subtitle = if (isCustomer) "كشف حساب عميل مالي تفصيلي ومسحوبات الديون" else "كشف حساب مورد مالي تفصيلي ومستحقات التوريد"
    canvas.drawText(subtitle, (pageWidth - 25).toFloat(), 58f, paint)
    canvas.drawText("هاتف: $businessPhone  •  $businessAddress", (pageWidth - 25).toFloat(), 74f, paint)

    // تاريخ الطباعة على اليسار
    paint.textAlign = Paint.Align.LEFT
    paint.textSize = 10f
    val dateStr = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")).format(Date())
    canvas.drawText("تاريخ الاستخراج: $dateStr", 25f, 40f, paint)
    canvas.drawText("حالة السجل: نشط ومطابق", 25f, 58f, paint)

    // 2. بطاقة معلومات الطرف والرصيد الحالي
    var currentY = 105f
    val cardBg = Paint().apply {
      isAntiAlias = true
      color = Color.rgb(243, 244, 246)
    }
    canvas.drawRoundRect(RectF(25f, currentY, (pageWidth - 25).toFloat(), currentY + 65f), 10f, 10f, cardBg)

    paint.color = Color.rgb(17, 24, 39)
    paint.textSize = 13f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textAlign = Paint.Align.RIGHT
    val partyTitle = if (isCustomer) "اسم العميل: $partyName" else "اسم المورد: $partyName"
    canvas.drawText(partyTitle, (pageWidth - 40).toFloat(), currentY + 28f, paint)

    paint.textSize = 11f
    paint.typeface = Typeface.DEFAULT
    paint.color = Color.rgb(75, 85, 99)
    canvas.drawText("رقم الهاتف: ${if (partyPhone.isNotBlank()) partyPhone else "غير مسجل"}", (pageWidth - 40).toFloat(), currentY + 50f, paint)

    // مربع الرصيد المتبقي
    paint.textAlign = Paint.Align.LEFT
    paint.textSize = 10f
    paint.color = Color.rgb(55, 65, 81)
    val balanceLabel = if (isCustomer) "صافي المديونية المستحقة على العميل:" else "صافي المستحق الواجب سداده للمورد:"
    canvas.drawText(balanceLabel, 40f, currentY + 26f, paint)

    paint.textSize = 16f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.color = if (currentBalance > 0) Color.rgb(220, 38, 38) else Color.rgb(5, 150, 105)
    canvas.drawText(String.format(Locale.ENGLISH, "%.2f ج.م", currentBalance), 40f, currentY + 52f, paint)

    // 3. جدول الحركات المالية
    currentY += 85f
    paint.color = Color.rgb(17, 24, 39)
    paint.textSize = 13f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText("سجل الفواتير والحركات المالية وسندات الدفع:", (pageWidth - 25).toFloat(), currentY, paint)

    currentY += 12f
    // رأس الجدول
    val thBg = Paint().apply {
      isAntiAlias = true
      color = Color.rgb(30, 41, 59)
    }
    canvas.drawRoundRect(RectF(25f, currentY, (pageWidth - 25).toFloat(), currentY + 26f), 4f, 4f, thBg)

    paint.color = Color.WHITE
    paint.textSize = 10f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textAlign = Paint.Align.CENTER

    val colDateX = (pageWidth - 60).toFloat()
    val colTypeX = (pageWidth - 140).toFloat()
    val colRefX = (pageWidth - 225).toFloat()
    val colDebitX = (pageWidth - 315).toFloat()
    val colCreditX = (pageWidth - 405).toFloat()
    val colBalanceX = (pageWidth - 495).toFloat()

    canvas.drawText("التاريخ", colDateX, currentY + 17f, paint)
    canvas.drawText("نوع الحركة", colTypeX, currentY + 17f, paint)
    canvas.drawText("رقم المرجع", colRefX, currentY + 17f, paint)
    canvas.drawText(if (isCustomer) "مدين (فاتورة)" else "مدين (سداد)", colDebitX, currentY + 17f, paint)
    canvas.drawText(if (isCustomer) "دائن (سداد)" else "دائن (توريد)", colCreditX, currentY + 17f, paint)
    canvas.drawText("الرصيد", colBalanceX, currentY + 17f, paint)

    currentY += 28f

    // صفوف الجدول
    var rowIndex = 0
    var totalDebitSum = 0.0
    var totalCreditSum = 0.0

    movements.take(24).forEach { move ->
      totalDebitSum += move.debit
      totalCreditSum += move.credit

      if (rowIndex % 2 == 1) {
        paint.color = Color.rgb(248, 250, 252)
        canvas.drawRect(25f, currentY, (pageWidth - 25).toFloat(), currentY + 22f, paint)
      }

      paint.color = Color.rgb(30, 41, 59)
      paint.textSize = 9.5f
      paint.typeface = Typeface.DEFAULT
      paint.textAlign = Paint.Align.CENTER

      canvas.drawText(move.dateStr, colDateX, currentY + 15f, paint)
      canvas.drawText(move.typeName, colTypeX, currentY + 15f, paint)
      canvas.drawText(move.referenceNo, colRefX, currentY + 15f, paint)

      paint.color = if (move.debit > 0) Color.rgb(220, 38, 38) else Color.GRAY
      canvas.drawText(if (move.debit > 0) String.format(Locale.ENGLISH, "%.2f", move.debit) else "-", colDebitX, currentY + 15f, paint)

      paint.color = if (move.credit > 0) Color.rgb(5, 150, 105) else Color.GRAY
      canvas.drawText(if (move.credit > 0) String.format(Locale.ENGLISH, "%.2f", move.credit) else "-", colCreditX, currentY + 15f, paint)

      paint.color = Color.rgb(17, 24, 39)
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      canvas.drawText(String.format(Locale.ENGLISH, "%.2f", move.balance), colBalanceX, currentY + 15f, paint)

      currentY += 22f
      rowIndex++
    }

    if (movements.isEmpty()) {
      paint.color = Color.rgb(100, 116, 139)
      paint.textSize = 11f
      paint.textAlign = Paint.Align.CENTER
      canvas.drawText("لا توجد حركات مالية مسجلة في هذا الكشف حتى الآن.", (pageWidth / 2).toFloat(), currentY + 25f, paint)
      currentY += 40f
    }

    // خط فاصل أسفل الجدول
    paint.color = Color.rgb(203, 213, 225)
    canvas.drawLine(25f, currentY + 4f, (pageWidth - 25).toFloat(), currentY + 4f, paint)
    currentY += 15f

    // ملخص الإجماليات
    val sumBg = Paint().apply {
      isAntiAlias = true
      color = Color.rgb(236, 253, 245)
    }
    canvas.drawRoundRect(RectF(25f, currentY, (pageWidth - 25).toFloat(), currentY + 40f), 6f, 6f, sumBg)

    paint.color = Color.rgb(6, 78, 59)
    paint.textSize = 11f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText("المجموع الإجمالي للحركات المسجلة:", (pageWidth - 40).toFloat(), currentY + 25f, paint)

    paint.textAlign = Paint.Align.CENTER
    paint.textSize = 10f
    canvas.drawText("إجمالي المدين: ${String.format(Locale.ENGLISH, "%.2f", totalDebitSum)} ج.م", colDebitX, currentY + 25f, paint)
    canvas.drawText("إجمالي الدائن: ${String.format(Locale.ENGLISH, "%.2f", totalCreditSum)} ج.م", colCreditX, currentY + 25f, paint)

    paint.textAlign = Paint.Align.LEFT
    paint.textSize = 12f
    paint.color = if (currentBalance > 0) Color.rgb(220, 38, 38) else Color.rgb(5, 150, 105)
    canvas.drawText("الرصيد النهائي: ${String.format(Locale.ENGLISH, "%.2f ج.م", currentBalance)}", 40f, currentY + 25f, paint)

    // 4. توقيعات أسفل الصفحة
    val footerY = pageHeight - 70f
    paint.color = Color.rgb(148, 163, 184)
    canvas.drawLine(25f, footerY, (pageWidth - 25).toFloat(), footerY, paint)

    paint.color = Color.rgb(71, 85, 105)
    paint.textSize = 9.5f
    paint.typeface = Typeface.DEFAULT
    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText("توقيع المحاسب المسئول: _____________________", (pageWidth - 30).toFloat(), footerY + 25f, paint)

    paint.textAlign = Paint.Align.LEFT
    canvas.drawText("توقيع وختم الإدارة: _____________________", 30f, footerY + 25f, paint)

    paint.textAlign = Paint.Align.CENTER
    paint.textSize = 8.5f
    paint.color = Color.rgb(148, 163, 184)
    canvas.drawText("تم استخراج هذا الكشف آلياً بواسطة برنامج $businessName • لا يعتد به بدون توقيع وختم الإدارة", (pageWidth / 2).toFloat(), footerY + 50f, paint)

    pdfDocument.finishPage(page)
  }

  /**
   * رسم كشف حساب مقاس طابعة حرارية 80mm
   */
  private fun renderThermal80Pdf(
    pdfDocument: PdfDocument,
    partyName: String,
    partyPhone: String,
    isCustomer: Boolean,
    currentBalance: Double,
    movements: List<StatementMovement>,
    businessName: String,
    businessPhone: String,
    businessAddress: String
  ) {
    val pageWidth = 576 // 80mm width standard
    val pageHeight = (320 + movements.size * 26 + 180).coerceAtLeast(600)
    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas
    val paint = Paint().apply { isAntiAlias = true }

    var y = 35f

    // رأس الإيصال الحراري
    paint.textAlign = Paint.Align.CENTER
    paint.textSize = 22f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.color = Color.BLACK
    canvas.drawText(businessName, (pageWidth / 2).toFloat(), y, paint)

    y += 24f
    paint.textSize = 13f
    paint.typeface = Typeface.DEFAULT
    canvas.drawText(if (isCustomer) "=== كشف حساب عميل حراري ===" else "=== كشف حساب مورد حراري ===", (pageWidth / 2).toFloat(), y, paint)

    y += 18f
    paint.textSize = 11f
    canvas.drawText("هاتف: $businessPhone", (pageWidth / 2).toFloat(), y, paint)

    y += 18f
    val dateStr = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")).format(Date())
    canvas.drawText("التاريخ: $dateStr", (pageWidth / 2).toFloat(), y, paint)

    y += 16f
    paint.color = Color.DKGRAY
    canvas.drawText("------------------------------------------------------------", (pageWidth / 2).toFloat(), y, paint)

    y += 22f
    paint.color = Color.BLACK
    paint.textAlign = Paint.Align.RIGHT
    paint.textSize = 13f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("الطرف: $partyName", (pageWidth - 20).toFloat(), y, paint)

    if (partyPhone.isNotBlank()) {
      y += 18f
      paint.textSize = 11f
      paint.typeface = Typeface.DEFAULT
      canvas.drawText("الهاتف: $partyPhone", (pageWidth - 20).toFloat(), y, paint)
    }

    y += 16f
    paint.color = Color.DKGRAY
    paint.textAlign = Paint.Align.CENTER
    canvas.drawText("------------------------------------------------------------", (pageWidth / 2).toFloat(), y, paint)

    // رأس جدول الحركات
    y += 20f
    paint.color = Color.BLACK
    paint.textSize = 11f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

    canvas.drawText("التاريخ", (pageWidth - 60).toFloat(), y, paint)
    canvas.drawText("الحركة والمرجع", (pageWidth - 200).toFloat(), y, paint)
    canvas.drawText("المبلغ", (pageWidth - 360).toFloat(), y, paint)
    canvas.drawText("الرصيد", 70f, y, paint)

    y += 12f
    canvas.drawText("------------------------------------------------------------", (pageWidth / 2).toFloat(), y, paint)

    y += 18f
    paint.textSize = 10f
    paint.typeface = Typeface.DEFAULT

    movements.forEach { m ->
      canvas.drawText(m.dateStr, (pageWidth - 60).toFloat(), y, paint)
      canvas.drawText("${m.typeName} (${m.referenceNo})", (pageWidth - 200).toFloat(), y, paint)
      val amountStr = if (m.debit > 0) "+${m.debit}" else "-${m.credit}"
      canvas.drawText(amountStr, (pageWidth - 360).toFloat(), y, paint)
      canvas.drawText(String.format(Locale.ENGLISH, "%.2f", m.balance), 70f, y, paint)
      y += 22f
    }

    y += 10f
    canvas.drawText("============================================================", (pageWidth / 2).toFloat(), y, paint)

    // الرصيد النهائي الكبير
    y += 28f
    paint.textSize = 15f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    val dueTitle = if (isCustomer) "إجمالي المديونية المستحقة:" else "إجمالي المستحق للمورد:"
    canvas.drawText(dueTitle, (pageWidth / 2).toFloat(), y, paint)

    y += 28f
    paint.textSize = 24f
    canvas.drawText(String.format(Locale.ENGLISH, "%.2f ج.م", currentBalance), (pageWidth / 2).toFloat(), y, paint)

    y += 24f
    paint.textSize = 10f
    paint.typeface = Typeface.DEFAULT
    canvas.drawText("شكراً لتعاملكم معنا • بضاعة الوكيل بالجملة", (pageWidth / 2).toFloat(), y, paint)

    pdfDocument.finishPage(page)
  }

  /**
   * رسم كشف حساب مقاس طابعة حرارية 58mm (أجهزة كاشير محمولة)
   */
  private fun renderThermal58Pdf(
    pdfDocument: PdfDocument,
    partyName: String,
    partyPhone: String,
    isCustomer: Boolean,
    currentBalance: Double,
    movements: List<StatementMovement>,
    businessName: String,
    businessPhone: String,
    businessAddress: String
  ) {
    val pageWidth = 384 // 58mm standard width
    val pageHeight = (280 + movements.size * 28 + 160).coerceAtLeast(500)
    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas
    val paint = Paint().apply { isAntiAlias = true }

    var y = 30f

    paint.textAlign = Paint.Align.CENTER
    paint.textSize = 17f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText(businessName, (pageWidth / 2).toFloat(), y, paint)

    y += 20f
    paint.textSize = 11f
    paint.typeface = Typeface.DEFAULT
    canvas.drawText(if (isCustomer) "كشف حساب عميل (58mm)" else "كشف حساب مورد (58mm)", (pageWidth / 2).toFloat(), y, paint)

    y += 16f
    paint.textSize = 9.5f
    val dateStr = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale("ar")).format(Date())
    canvas.drawText(dateStr, (pageWidth / 2).toFloat(), y, paint)

    y += 14f
    canvas.drawText("------------------------------------------------", (pageWidth / 2).toFloat(), y, paint)

    y += 18f
    paint.textAlign = Paint.Align.RIGHT
    paint.textSize = 11f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("الطرف: $partyName", (pageWidth - 12).toFloat(), y, paint)

    if (partyPhone.isNotBlank()) {
      y += 16f
      paint.textSize = 9.5f
      paint.typeface = Typeface.DEFAULT
      canvas.drawText("الهاتف: $partyPhone", (pageWidth - 12).toFloat(), y, paint)
    }

    y += 14f
    paint.textAlign = Paint.Align.CENTER
    canvas.drawText("------------------------------------------------", (pageWidth / 2).toFloat(), y, paint)

    y += 16f
    paint.textSize = 9.5f
    movements.forEach { m ->
      paint.textAlign = Paint.Align.RIGHT
      paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      canvas.drawText("${m.dateStr} - ${m.typeName}", (pageWidth - 12).toFloat(), y, paint)

      paint.textAlign = Paint.Align.LEFT
      val amt = if (m.debit > 0) "+${m.debit}" else "-${m.credit}"
      canvas.drawText("$amt | رصيد: ${String.format(Locale.ENGLISH, "%.1f", m.balance)}", 12f, y, paint)

      y += 20f
    }

    y += 8f
    canvas.drawText("================================================", (pageWidth / 2).toFloat(), y, paint)

    y += 24f
    paint.textAlign = Paint.Align.CENTER
    paint.textSize = 12f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText(if (isCustomer) "المتبقي على العميل:" else "المستحق للمورد:", (pageWidth / 2).toFloat(), y, paint)

    y += 24f
    paint.textSize = 18f
    canvas.drawText(String.format(Locale.ENGLISH, "%.2f ج.م", currentBalance), (pageWidth / 2).toFloat(), y, paint)

    pdfDocument.finishPage(page)
  }

  /**
   * الطباعة المباشرة لكشف الحساب عبر PrintManager الخاص بنظام أندرويد
   * يدعم كل الطابعات المتصلة (WiFi / Bluetooth / USB / حفظ كـ PDF)
   */
  fun printStatementViaSystem(
    context: Context,
    partyName: String,
    partyPhone: String,
    isCustomer: Boolean,
    currentBalance: Double,
    invoices: List<Invoice>,
    payments: List<PaymentTransaction>,
    businessName: String = "الوكيل لتجارة المواد الغذائية",
    businessPhone: String = "01001234567",
    businessAddress: String = "شارع السوق التجاري - القاهرة",
    printerType: String = "A4"
  ) {
    try {
      val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
      if (printManager == null) {
        Toast.makeText(context, "خدمة الطباعة غير متوفرة في النظام", Toast.LENGTH_SHORT).show()
        return
      }

      val pdfFile = generateStatementPdf(
        context = context,
        partyName = partyName,
        partyPhone = partyPhone,
        isCustomer = isCustomer,
        currentBalance = currentBalance,
        invoices = invoices,
        payments = payments,
        businessName = businessName,
        businessPhone = businessPhone,
        businessAddress = businessAddress,
        pageSizeType = printerType
      )

      val docName = "كشف_حساب_${partyName.replace("\\s+".toRegex(), "_")}"
      val adapter = object : PrintDocumentAdapter() {
        override fun onLayout(
          oldAttributes: PrintAttributes?,
          newAttributes: PrintAttributes?,
          cancellationSignal: CancellationSignal?,
          callback: LayoutResultCallback?,
          extras: Bundle?
        ) {
          if (cancellationSignal?.isCanceled == true) {
            callback?.onLayoutCancelled()
            return
          }
          val info = PrintDocumentInfo.Builder("$docName.pdf")
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(1)
            .build()
          callback?.onLayoutFinished(info, true)
        }

        override fun onWrite(
          pages: Array<out PageRange>?,
          destination: ParcelFileDescriptor?,
          cancellationSignal: CancellationSignal?,
          callback: WriteResultCallback?
        ) {
          try {
            val input = FileInputStream(pdfFile)
            val output = FileOutputStream(destination?.fileDescriptor)
            input.copyTo(output)
            callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            input.close()
            output.close()
          } catch (e: Exception) {
            callback?.onWriteFailed(e.message)
          }
        }
      }

      val attributes = PrintAttributes.Builder().apply {
        if (printerType.contains("58")) {
          setMediaSize(PrintAttributes.MediaSize("ROLL_58MM", "Thermal 58mm", 2280, 8000))
        } else if (printerType.contains("80")) {
          setMediaSize(PrintAttributes.MediaSize("ROLL_80MM", "Thermal 80mm", 3150, 10000))
        } else {
          setMediaSize(PrintAttributes.MediaSize.ISO_A4)
        }
      }.build()

      printManager.print(docName, adapter, attributes)
    } catch (e: Exception) {
      Toast.makeText(context, "فشل بدء الطباعة: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
  }

  /**
   * مشاركة كشف الحساب كملف PDF
   */
  fun shareStatementPdf(
    context: Context,
    partyName: String,
    partyPhone: String,
    isCustomer: Boolean,
    currentBalance: Double,
    invoices: List<Invoice>,
    payments: List<PaymentTransaction>,
    businessName: String = "الوكيل لتجارة المواد الغذائية",
    businessPhone: String = "01001234567",
    businessAddress: String = "شارع السوق التجاري - القاهرة",
    pageSizeType: String = "A4"
  ) {
    try {
      val pdfFile = generateStatementPdf(
        context = context,
        partyName = partyName,
        partyPhone = partyPhone,
        isCustomer = isCustomer,
        currentBalance = currentBalance,
        invoices = invoices,
        payments = payments,
        businessName = businessName,
        businessPhone = businessPhone,
        businessAddress = businessAddress,
        pageSizeType = pageSizeType
      )

      val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", pdfFile)
      val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "كشف حساب: $partyName - $businessName")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
      val chooser = Intent.createChooser(intent, "إرسال كشف الحساب PDF إلى:")
      chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      context.startActivity(chooser)
    } catch (e: Exception) {
      Toast.makeText(context, "فشل مشاركة كشف الحساب: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
  }

  /**
   * إنشاء وطباعة كشف مديونيات العملاء الإجمالي بالسوق أو مستحقات الموردين
   */
  fun generateDebtSummaryPdf(
    context: Context,
    isCustomer: Boolean,
    customers: List<Customer> = emptyList(),
    suppliers: List<Supplier> = emptyList(),
    businessName: String = "الوكيل لتجارة المواد الغذائية",
    businessPhone: String = "01001234567",
    pageSizeType: String = "A4"
  ): File {
    val dir = File(context.cacheDir, "statements").apply { mkdirs() }
    val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(Date())
    val file = File(dir, if (isCustomer) "CUSTOMER_DEBTS_${timeStamp}.pdf" else "SUPPLIER_PAYABLES_${timeStamp}.pdf")

    val pdfDocument = PdfDocument()
    val pageWidth = if (pageSizeType.contains("58")) 384 else if (pageSizeType.contains("80")) 576 else 595
    val rowCount = if (isCustomer) customers.size else suppliers.size
    val pageHeight = if (pageSizeType == "A4") 842 else (260 + rowCount * 26 + 140).coerceAtLeast(600)

    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas
    val paint = Paint().apply { isAntiAlias = true }

    var y = 35f

    // ترويسة
    paint.color = Color.rgb(5, 150, 105)
    canvas.drawRect(0f, 0f, pageWidth.toFloat(), 75f, paint)

    paint.color = Color.WHITE
    paint.textSize = 18f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textAlign = Paint.Align.RIGHT
    canvas.drawText(businessName, (pageWidth - 20).toFloat(), 34f, paint)

    paint.textSize = 11f
    paint.typeface = Typeface.DEFAULT
    val title = if (isCustomer) "تقرير كشف مديونيات العملاء بالسوق والديون الآجلة" else "تقرير كشف مستحقات الموردين والشركات التوزيعية"
    canvas.drawText(title, (pageWidth - 20).toFloat(), 55f, paint)

    paint.textAlign = Paint.Align.LEFT
    paint.textSize = 10f
    val dateStr = SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH).format(Date())
    canvas.drawText("التاريخ: $dateStr", 20f, 45f, paint)

    y = 95f
    // رأس الجدول
    val thBg = Paint().apply {
      isAntiAlias = true
      color = Color.rgb(30, 41, 59)
    }
    canvas.drawRoundRect(RectF(15f, y, (pageWidth - 15).toFloat(), y + 26f), 4f, 4f, thBg)

    paint.color = Color.WHITE
    paint.textSize = 10.5f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textAlign = Paint.Align.CENTER

    val colIdxX = (pageWidth - 35).toFloat()
    val colNameX = (pageWidth - 150).toFloat()
    val colPhoneX = (pageWidth - 320).toFloat()
    val colDebtX = (pageWidth - 470).toFloat().coerceAtLeast(60f)

    canvas.drawText("م", colIdxX, y + 17f, paint)
    canvas.drawText(if (isCustomer) "اسم العميل" else "اسم المورد / الشركة", colNameX, y + 17f, paint)
    canvas.drawText("رقم الهاتف", colPhoneX, y + 17f, paint)
    canvas.drawText("الرصيد المستحق", colDebtX, y + 17f, paint)

    y += 28f

    var grandTotal = 0.0
    var index = 1

    if (isCustomer) {
      val sortedCust = customers.sortedByDescending { it.currentBalance }
      sortedCust.forEach { cust ->
        grandTotal += cust.currentBalance
        if (index % 2 == 1) {
          paint.color = Color.rgb(248, 250, 252)
          canvas.drawRect(15f, y, (pageWidth - 15).toFloat(), y + 22f, paint)
        }
        paint.color = Color.rgb(30, 41, 59)
        paint.textSize = 10f
        paint.typeface = Typeface.DEFAULT
        paint.textAlign = Paint.Align.CENTER

        canvas.drawText("$index", colIdxX, y + 15f, paint)
        canvas.drawText(cust.name.take(24), colNameX, y + 15f, paint)
        canvas.drawText(cust.phone.ifBlank { "-" }, colPhoneX, y + 15f, paint)

        paint.color = if (cust.currentBalance > 0) Color.rgb(220, 38, 38) else Color.rgb(5, 150, 105)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(String.format(Locale.ENGLISH, "%.2f ج.م", cust.currentBalance), colDebtX, y + 15f, paint)

        y += 22f
        index++
      }
    } else {
      val sortedSupp = suppliers.sortedByDescending { it.currentBalance }
      sortedSupp.forEach { sup ->
        grandTotal += sup.currentBalance
        if (index % 2 == 1) {
          paint.color = Color.rgb(248, 250, 252)
          canvas.drawRect(15f, y, (pageWidth - 15).toFloat(), y + 22f, paint)
        }
        paint.color = Color.rgb(30, 41, 59)
        paint.textSize = 10f
        paint.typeface = Typeface.DEFAULT
        paint.textAlign = Paint.Align.CENTER

        canvas.drawText("$index", colIdxX, y + 15f, paint)
        canvas.drawText("${sup.name} (${sup.company})".take(24), colNameX, y + 15f, paint)
        canvas.drawText(sup.phone.ifBlank { "-" }, colPhoneX, y + 15f, paint)

        paint.color = if (sup.currentBalance > 0) Color.rgb(220, 38, 38) else Color.rgb(5, 150, 105)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(String.format(Locale.ENGLISH, "%.2f ج.م", sup.currentBalance), colDebtX, y + 15f, paint)

        y += 22f
        index++
      }
    }

    y += 10f
    // سطر الإجمالي
    val sumBg = Paint().apply {
      isAntiAlias = true
      color = Color.rgb(254, 242, 242)
    }
    canvas.drawRoundRect(RectF(15f, y, (pageWidth - 15).toFloat(), y + 36f), 6f, 6f, sumBg)

    paint.color = Color.rgb(153, 27, 27)
    paint.textSize = 12f
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    paint.textAlign = Paint.Align.RIGHT
    val totalLabel = if (isCustomer) "إجمالي ديون السوق المستحقة على العملاء (${customers.size} عميل):" else "إجمالي المستحقات الواجب سدادها للموردين (${suppliers.size} مورد):"
    canvas.drawText(totalLabel, (pageWidth - 30).toFloat(), y + 23f, paint)

    paint.textAlign = Paint.Align.LEFT
    paint.textSize = 14f
    canvas.drawText(String.format(Locale.ENGLISH, "%.2f ج.م", grandTotal), 30f, y + 23f, paint)

    pdfDocument.finishPage(page)
    val outputStream = FileOutputStream(file)
    pdfDocument.writeTo(outputStream)
    pdfDocument.close()
    outputStream.flush()
    outputStream.close()

    return file
  }

  /**
   * طباعة كشف المديونيات الإجمالي عبر PrintManager
   */
  fun printDebtSummaryViaSystem(
    context: Context,
    isCustomer: Boolean,
    customers: List<Customer> = emptyList(),
    suppliers: List<Supplier> = emptyList(),
    businessName: String = "الوكيل لتجارة المواد الغذائية",
    businessPhone: String = "01001234567",
    printerType: String = "A4"
  ) {
    try {
      val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
      if (printManager == null) {
        Toast.makeText(context, "خدمة الطباعة غير متوفرة", Toast.LENGTH_SHORT).show()
        return
      }

      val pdfFile = generateDebtSummaryPdf(
        context = context,
        isCustomer = isCustomer,
        customers = customers,
        suppliers = suppliers,
        businessName = businessName,
        businessPhone = businessPhone,
        pageSizeType = printerType
      )

      val docName = if (isCustomer) "كشف_مديونيات_العملاء" else "كشف_مستحقات_الموردين"
      val adapter = object : PrintDocumentAdapter() {
        override fun onLayout(
          oldAttributes: PrintAttributes?,
          newAttributes: PrintAttributes?,
          cancellationSignal: CancellationSignal?,
          callback: LayoutResultCallback?,
          extras: Bundle?
        ) {
          if (cancellationSignal?.isCanceled == true) {
            callback?.onLayoutCancelled()
            return
          }
          val info = PrintDocumentInfo.Builder("$docName.pdf")
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(1)
            .build()
          callback?.onLayoutFinished(info, true)
        }

        override fun onWrite(
          pages: Array<out PageRange>?,
          destination: ParcelFileDescriptor?,
          cancellationSignal: CancellationSignal?,
          callback: WriteResultCallback?
        ) {
          try {
            val input = FileInputStream(pdfFile)
            val output = FileOutputStream(destination?.fileDescriptor)
            input.copyTo(output)
            callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            input.close()
            output.close()
          } catch (e: Exception) {
            callback?.onWriteFailed(e.message)
          }
        }
      }

      val attributes = PrintAttributes.Builder().apply {
        if (printerType.contains("58")) {
          setMediaSize(PrintAttributes.MediaSize("ROLL_58MM", "Thermal 58mm", 2280, 8000))
        } else if (printerType.contains("80")) {
          setMediaSize(PrintAttributes.MediaSize("ROLL_80MM", "Thermal 80mm", 3150, 10000))
        } else {
          setMediaSize(PrintAttributes.MediaSize.ISO_A4)
        }
      }.build()

      printManager.print(docName, adapter, attributes)
    } catch (e: Exception) {
      Toast.makeText(context, "فشل الطباعة: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
  }

  /**
   * مشاركة كشف المديونيات الإجمالي عبر ملف PDF
   */
  fun shareDebtSummaryPdf(
    context: Context,
    isCustomer: Boolean,
    customers: List<Customer> = emptyList(),
    suppliers: List<Supplier> = emptyList(),
    businessName: String = "الوكيل لتجارة المواد الغذائية",
    businessPhone: String = "01001234567",
    pageSizeType: String = "A4"
  ) {
    try {
      val pdfFile = generateDebtSummaryPdf(
        context = context,
        isCustomer = isCustomer,
        customers = customers,
        suppliers = suppliers,
        businessName = businessName,
        businessPhone = businessPhone,
        pageSizeType = pageSizeType
      )

      val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", pdfFile)
      val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, if (isCustomer) "كشف مديونيات العملاء - $businessName" else "كشف مستحقات الموردين - $businessName")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
      val chooser = Intent.createChooser(intent, "إرسال تقرير المديونيات PDF إلى:")
      chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      context.startActivity(chooser)
    } catch (e: Exception) {
      Toast.makeText(context, "فشل المشاركة: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
  }

  /**
   * مشاركة كشف المديونيات الإجمالي عبر نص واتساب منسق
   */
  fun shareDebtSummaryWhatsApp(
    context: Context,
    isCustomer: Boolean,
    customers: List<Customer> = emptyList(),
    suppliers: List<Supplier> = emptyList(),
    businessName: String = "الوكيل لتجارة المواد الغذائية"
  ) {
    val dateStr = SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH).format(Date())
    val sb = StringBuilder()
    sb.appendLine("📊 *تقرير مالي: ${if (isCustomer) "كشف مديونيات العملاء بالسوق" else "كشف مستحقات الموردين والشركات"}*")
    sb.appendLine("مؤسسة: *$businessName*")
    sb.appendLine("التاريخ: $dateStr")
    sb.appendLine("═══════════════════════════")

    var grandTotal = 0.0
    if (isCustomer) {
      val indebted = customers.filter { it.currentBalance > 0 }.sortedByDescending { it.currentBalance }
      if (indebted.isEmpty()) {
        sb.appendLine("لا توجد مديونيات مستحقة على أي عميل! الحسابات خالصة بالكامل.")
      } else {
        indebted.forEachIndexed { i, c ->
          grandTotal += c.currentBalance
          sb.appendLine("${i + 1}. *${c.name}* (هاتف: ${c.phone.ifBlank { "غير مسجل" }})")
          sb.appendLine("   المديونية: *${String.format(Locale.ENGLISH, "%.2f", c.currentBalance)} ج.م*")
        }
      }
    } else {
      val payable = suppliers.filter { it.currentBalance > 0 }.sortedByDescending { it.currentBalance }
      if (payable.isEmpty()) {
        sb.appendLine("لا توجد مستحقات قائمة للموردين! الحسابات خالصة بالكامل.")
      } else {
        payable.forEachIndexed { i, s ->
          grandTotal += s.currentBalance
          sb.appendLine("${i + 1}. *${s.name}* (${s.company}) - هاتف: ${s.phone.ifBlank { "غير مسجل" }}")
          sb.appendLine("   المستحق له: *${String.format(Locale.ENGLISH, "%.2f", s.currentBalance)} ج.م*")
        }
      }
    }

    sb.appendLine("═══════════════════════════")
    val totalLabel = if (isCustomer) "🔔 *إجمالي ديون السوق المستحقة على العملاء:*" else "🔔 *إجمالي المستحق الواجب سداده للموردين:*"
    sb.appendLine("$totalLabel *${String.format(Locale.ENGLISH, "%.2f", grandTotal)} ج.م*")

    val shareIntent = Intent(Intent.ACTION_SEND).apply {
      type = "text/plain"
      putExtra(Intent.EXTRA_SUBJECT, if (isCustomer) "كشف مديونيات العملاء" else "كشف مستحقات الموردين")
      putExtra(Intent.EXTRA_TEXT, sb.toString())
    }
    context.startActivity(Intent.createChooser(shareIntent, "إرسال التقرير عبر واتساب"))
  }
}
