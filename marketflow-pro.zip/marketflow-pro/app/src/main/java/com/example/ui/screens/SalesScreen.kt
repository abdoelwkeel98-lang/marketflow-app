package com.example.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import java.util.Calendar
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.rememberCoroutineScope
import com.example.data.model.Customer
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItem
import com.example.data.model.PaymentType
import com.example.data.model.Product
import com.example.data.model.Supplier
import com.example.ui.CartItem
import com.example.ui.PriceTier
import com.example.ui.WholesaleViewModel
import com.example.ui.components.AddEditCustomerDialog
import com.example.ui.components.AddEditProductDialog
import com.example.ui.components.InvoiceDetailsDialog
import com.example.ui.components.EditInvoiceFullDialog
import com.example.ui.components.DeleteInvoiceConfirmDialog
import com.example.ui.components.MultiEmployeeAndDelegateDialog
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * شاشة المبيعات البسيطة والاحترافية:
 * 1. زر إضافة منتج يفتح شريط وبحث المنتجات.
 * 2. نظام بيع (سعر جملة / سعر قطاعي) يفرق في السعر بدون إجبار على وحدة معينة (كرتونة أو قطعة).
 * 3. قائمة اختيار العميل مع شريط بحث مدمج للبحث بالاسم أو الهاتف.
 * 4. في أسفل الشاشة: يظهر إجمالي المبيعات، ورصيد العميل السابق، ومجموعهما في "إجمالي المطلوب".
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesScreen(
  viewModel: WholesaleViewModel,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val salesInvoices by viewModel.salesInvoices.collectAsStateWithLifecycle()

  Column(modifier = modifier.fillMaxSize()) {
    // تبويبان: (فاتورة المبيعات الحالية) و (سجل فواتير المبيعات)
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = MaterialTheme.colorScheme.surface,
      contentColor = MaterialTheme.colorScheme.primary
    ) {
      Tab(
        selected = selectedTab == 0,
        onClick = { selectedTab = 0 },
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PointOfSale, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("فاتورة المبيعات", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          }
        }
      )
      Tab(
        selected = selectedTab == 1,
        onClick = { selectedTab = 1 },
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("سجل الفواتير السابقة", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            if (salesInvoices.isNotEmpty()) {
              Spacer(modifier = Modifier.width(6.dp))
              Surface(
                shape = CircleShape,
                color = if (selectedTab == 1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
              ) {
                Text(
                  text = "${salesInvoices.size}",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (selectedTab == 1) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }
          }
        }
      )
    }

    if (selectedTab == 0) {
      SimpleSalesPosView(viewModel = viewModel)
    } else {
      SalesInvoicesHistoryView(
        viewModel = viewModel,
        onEditInPos = { invoice ->
          viewModel.loadSaleInvoiceForEditing(invoice) {
            selectedTab = 0
          }
        }
      )
    }
  }
}

// -----------------------------------------------------------------------------
// شاشة المبيعات البسيطة (Simple Sales POS View)
// -----------------------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimpleSalesPosView(viewModel: WholesaleViewModel) {
  val products by viewModel.products.collectAsStateWithLifecycle()
  val customers by viewModel.customers.collectAsStateWithLifecycle()
  val cartItems by viewModel.salesCart.collectAsStateWithLifecycle()
  val selectedCustomer by viewModel.selectedCustomer.collectAsStateWithLifecycle()
  val saleDiscount by viewModel.saleDiscount.collectAsStateWithLifecycle()
  val salePaidAmount by viewModel.salePaidAmount.collectAsStateWithLifecycle()
  val salePaymentType by viewModel.salePaymentType.collectAsStateWithLifecycle()
  val editingSaleInvoice by viewModel.editingSaleInvoice.collectAsStateWithLifecycle()

  val profile by viewModel.businessProfile.collectAsStateWithLifecycle()
  val context = LocalContext.current
  val scope = rememberCoroutineScope()

  // نظام التسعير: سعر جملة أو سعر قطاعي (يفرق في السعر وليس الوحدة)
  var isWholesalePriceMode by remember { mutableStateOf(true) }

  // الوحدة الأساسية تأتي مباشرة من الإعدادات (علبة افتراضياً)
  val defaultUnit = profile.salesDefaultUnit.ifBlank { "علبة" }

  // تنبيه محاولة إضافة صنف غير متوفر بالمخزن
  var outOfStockProductAttempt by remember { mutableStateOf<Pair<Product, String>?>(null) }

  // نوافذ البحث والإضافة
  var showProductSearchSheet by remember { mutableStateOf(false) }
  var showCustomerPickerSheet by remember { mutableStateOf(false) }
  var showAddProductDialog by remember { mutableStateOf(false) }
  var showAddCustomerDialog by remember { mutableStateOf(false) }
  var showSalesSettingsDialog by remember { mutableStateOf(false) }

  // عناصر إتمام العملية والسداد المباشر من نفس الشاشة
  var discountMode by remember { mutableStateOf(if (profile.salesDefaultDiscountType == "نسبة مئوية") "نسبة" else "مبلغ") }
  var discountInputText by remember { mutableStateOf(if (saleDiscount > 0) String.format(Locale.ENGLISH, "%.2f", saleDiscount) else "") }
  var cashTenderedText by remember { mutableStateOf("") }
  var partialPaidText by remember { mutableStateOf(salePaidAmount?.toString() ?: "") }
  var invoiceNotesText by remember { mutableStateOf("") }
  var validationError by remember { mutableStateOf<String?>(null) }
  var isSavingSale by remember { mutableStateOf(false) }

  // نافذة إدارة الموظفين والمناديب والمزامنة السريعة
  var showDelegateSyncDialog by remember { mutableStateOf(false) }
  val pendingSyncInvoices by viewModel.pendingSyncInvoices.collectAsStateWithLifecycle()

  // إحصائيات الفاتورة المعروضة
  val itemsCount = cartItems.size // العدد (عدد الأصناف المختلفة)
  val totalQuantity = remember(cartItems) { cartItems.sumOf { it.quantity } } // إجمالي الكمية

  // إجمالي المبيعات (صافي الفاتورة الحالية)
  val totalSalesAmount = remember(cartItems, saleDiscount) {
    val sub = cartItems.sumOf { it.totalPrice }
    (sub - saleDiscount).coerceAtLeast(0.0)
  }

  // رصيد العميل السابق
  val previousCustomerBalance = selectedCustomer?.currentBalance ?: 0.0

  // إجمالي المطلوب (إجمالي المبيعات + رصيد العميل السابق)
  val grandTotalDue = totalSalesAmount + previousCustomerBalance

  // دالة إتمام وحفظ الفاتورة من نفس الشاشة دون أي نوافذ منبثقة
  fun executeCompleteSaleInline() {
    if (cartItems.isEmpty()) {
      Toast.makeText(context, "الفاتورة فارغة، برجاء إضافة منتجات أولاً", Toast.LENGTH_SHORT).show()
      return
    }

    val subtotal = cartItems.sumOf { it.totalPrice }
    val netTotal = (subtotal - saleDiscount).coerceAtLeast(0.0)

    if (salePaymentType == PaymentType.CASH && !profile.salesAllowSellingBelowInvoiceTotal) {
      val t = cashTenderedText.toDoubleOrNull()
      if (t != null && t < netTotal) {
        validationError = "غير مسموح بالبيع بأقل من قيمة الفاتورة نقداً حسب إعدادات النظام"
        Toast.makeText(context, validationError!!, Toast.LENGTH_LONG).show()
        return
      }
    }

    if ((salePaymentType == PaymentType.CREDIT || salePaymentType == PaymentType.PARTIAL) && selectedCustomer == null) {
      validationError = "برجاء اختيار عميل لتقييد المبلغ الآجل في حسابه"
      Toast.makeText(context, validationError!!, Toast.LENGTH_LONG).show()
      return
    }

    validationError = null
    isSavingSale = true
    viewModel.completeSale(
      customTimestamp = null,
      invoiceNotes = invoiceNotesText.ifBlank { null },
      onSuccess = { inv ->
        isSavingSale = false
        Toast.makeText(context, "تم حفظ وإصدار فاتورة المبيعات بنجاح ✓ (${inv.invoiceNumber})", Toast.LENGTH_LONG).show()
        cashTenderedText = ""
        discountInputText = ""
        partialPaidText = ""
        invoiceNotesText = ""
      },
      onError = { err ->
        isSavingSale = false
        validationError = err
        Toast.makeText(context, err, Toast.LENGTH_LONG).show()
      }
    )
  }

  Box(modifier = Modifier.fillMaxSize()) {
    Column(modifier = Modifier.fillMaxSize()) {

      // شريط وضع التعديل (يظهر عند فتح فاتورة سابقة لتعديلها)
      if (editingSaleInvoice != null) {
        Surface(
          color = AmberPrimary.copy(alpha = 0.15f),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, AmberPrimary),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Icon(Icons.Default.Edit, contentDescription = null, tint = AmberPrimary, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(
                  text = "وضع تعديل فاتورة بيع (${editingSaleInvoice?.invoiceNumber})",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = AmberPrimary
                )
                Text(
                  text = "يمكنك تعديل أي صنف، كمية، سعر، خصم أو العميل ثم الحفظ",
                  fontSize = 10.5.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
            OutlinedButton(
              onClick = { viewModel.cancelEditingSaleInvoice() },
              shape = RoundedCornerShape(8.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
              Text("إلغاء التعديل", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
            }
          }
        }
      }

      // شريط وضع المندوب / الموظف النشط وحالة المزامنة
      Surface(
        color = if (profile.deviceRole == "DELEGATE") OrangePrimary.copy(alpha = 0.12f)
        else MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (profile.deviceRole == "DELEGATE") OrangePrimary.copy(alpha = 0.5f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 4.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(
              imageVector = if (profile.deviceRole == "DELEGATE") Icons.Default.TwoWheeler else Icons.Default.Person,
              contentDescription = null,
              tint = if (profile.deviceRole == "DELEGATE") OrangePrimary else MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Column {
              Text(
                text = if (profile.deviceRole == "DELEGATE") "وضع المندوب الميداني: ${profile.delegateEmployeeName.ifBlank { profile.activeEmployeeName }}"
                else "المستخدم النشط: ${profile.activeEmployeeName} (${profile.activeEmployeeRole})",
                fontWeight = FontWeight.Bold,
                fontSize = 11.5.sp,
                color = if (profile.deviceRole == "DELEGATE") OrangePrimary else MaterialTheme.colorScheme.primary
              )
              if (profile.deviceRole == "DELEGATE") {
                Text(
                  text = if (pendingSyncInvoices.isNotEmpty()) "⚠️ يوجد ${pendingSyncInvoices.size} فواتير معلقة تنتظر إرسالها للمدير"
                  else "الفواتير يتم حفظها بدون نت وتسمع تلقائياً فور الاتصال ✓",
                  fontSize = 10.sp,
                  color = if (pendingSyncInvoices.isNotEmpty()) Color(0xFFDC2626) else MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(
              onClick = { showDelegateSyncDialog = true },
              shape = RoundedCornerShape(8.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
              modifier = Modifier.height(28.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = if (profile.deviceRole == "DELEGATE") OrangePrimary else MaterialTheme.colorScheme.primary
              )
            ) {
              Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(13.dp))
              Spacer(modifier = Modifier.width(3.dp))
              Text("المزامنة والربط", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      // 1. شريط التحكم العلوي: اختيار العميل ونظام التسعير (سعر جملة / سعر قطاعي)
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 6.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          // السطر الأول: بطاقة العميل الحالية مع زر فتح البحث والاختيار
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier
                .weight(1f)
                .clickable { showCustomerPickerSheet = true }
            ) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .background(
                    if (selectedCustomer != null) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else Color.Gray.copy(alpha = 0.12f),
                    CircleShape
                  ),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.Person,
                  contentDescription = null,
                  tint = if (selectedCustomer != null) MaterialTheme.colorScheme.primary else Color.Gray,
                  modifier = Modifier.size(20.dp)
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(
                  text = selectedCustomer?.name ?: "عميل نقدي (كاش بدون حساب)",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
                if (selectedCustomer != null && selectedCustomer!!.currentBalance > 0) {
                  Text(
                    text = "رصيد سابق عليه: ${selectedCustomer!!.currentBalance} ج.م",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.Bold
                  )
                } else if (selectedCustomer != null) {
                  Text(
                    text = "حسابه خالص (0.00 ج.م)",
                    fontSize = 10.sp,
                    color = EmeraldPrimary,
                    fontWeight = FontWeight.SemiBold
                  )
                }
              }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = { showSalesSettingsDialog = true },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(
                  Icons.Default.Tune,
                  contentDescription = "إعدادات المبيعات",
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(20.dp)
                )
              }

              // زر سريع لفتح قائمة العملاء مع شريط البحث
              Button(
                onClick = { showCustomerPickerSheet = true },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                modifier = Modifier.height(32.dp)
              ) {
                Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (selectedCustomer != null) "تغيير العميل" else "اختيار عميل", fontSize = 11.sp)
              }

              OutlinedButton(
                onClick = { showAddCustomerDialog = true },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(32.dp)
              ) {
                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(13.dp))
                Spacer(modifier = Modifier.width(2.dp))
                Text("عميل جديد +", fontSize = 11.sp)
              }
            }
          }

          HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

          // السطر الثاني: نظام التسعير (يفرق في السعر فقط وليس الوحدة)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "نظام التسعير:",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "يغير السعر (جملة/قطاعي) لأي وحدة",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              FilterChip(
                selected = isWholesalePriceMode,
                onClick = {
                  isWholesalePriceMode = true
                  // تحديث فئة السعر لكل الأصناف دون المساس بالوحدة (كرتونة أو قطعة)
                  cartItems.forEachIndexed { idx, _ ->
                    viewModel.updateCartItemTier(idx, PriceTier.WHOLESALE)
                  }
                },
                label = {
                  Text(
                    "سعر جملة",
                    fontSize = 11.sp,
                    fontWeight = if (isWholesalePriceMode) FontWeight.Bold else FontWeight.Normal
                  )
                },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = EmeraldPrimary,
                  selectedLabelColor = Color.White
                )
              )

              FilterChip(
                selected = !isWholesalePriceMode,
                onClick = {
                  isWholesalePriceMode = false
                  // تحديث فئة السعر لكل الأصناف دون المساس بالوحدة (كرتونة أو قطعة)
                  cartItems.forEachIndexed { idx, _ ->
                    viewModel.updateCartItemTier(idx, PriceTier.RETAIL)
                  }
                },
                label = {
                  Text(
                    "سعر قطاعي",
                    fontSize = 11.sp,
                    fontWeight = if (!isWholesalePriceMode) FontWeight.Bold else FontWeight.Normal
                  )
                },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = MaterialTheme.colorScheme.primary,
                  selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                )
              )
            }
          }
        }
      }

      // 2. زر "إضافة منتج +" الرئيسي الواضح والمريح
      Button(
        onClick = { showProductSearchSheet = true },
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 4.dp)
          .height(48.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
      ) {
        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "إضافة منتج للفاتورة (بحث بالاسم أو الباركود) +",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold
        )
      }

      // 3. مساحة قائمة الأصناف المضافة داخل الفاتورة
      if (cartItems.isEmpty()) {
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .padding(24.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
          ) {
            Surface(
              shape = CircleShape,
              color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
              modifier = Modifier.size(64.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  Icons.Default.ShoppingCart,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(32.dp)
                )
              }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "الفاتورة فارغة حالياً",
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "اضغط على زر [إضافة منتج] أعلاه للبحث عن الأصناف وإضافتها",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(14.dp))
            Button(
              onClick = { showProductSearchSheet = true },
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("إضافة أول صنف للفاتورة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      } else {
        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
          contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 155.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          item {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "الأصناف المضافة (${cartItems.size} صنف)",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "مسح الكل",
                color = MaterialTheme.colorScheme.error,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { viewModel.clearSalesCart() }
              )
            }
          }

          itemsIndexed(cartItems) { index, item ->
            SimpleCartItemCard(
              item = item,
              onQuantityChange = { q -> viewModel.updateCartItemQuantity(index, q) },
              onUnitChange = { u -> viewModel.updateCartItemUnitType(index, u) },
              onTierChange = { t -> viewModel.updateCartItemTier(index, t) },
              onPriceChange = { p -> viewModel.updateCartItemCustomPrice(index, p) },
              onRemove = { viewModel.removeFromSalesCart(index) },
              allowManualPriceOverride = profile.salesAllowManualPriceOverride
            )
          }

          // -------------------------------------------------------------
          // قسم السداد والخصم وإتمام الفاتورة مباشرة في نفس الشاشة دون أي نوافذ منبثقة
          // -------------------------------------------------------------
          item {
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
              elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                // عنوان القسم
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Payment, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("بيانات السداد وطريقة الدفع", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                  }
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = EmeraldPrimary.copy(alpha = 0.12f)
                  ) {
                    Text(
                      text = "إتمام مباشر بشاشة واحدة ✓",
                      color = EmeraldPrimary,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                  }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

                // 1. قسم الخصم (مباشر على الشاشة)
                if (profile.salesEnableDiscount) {
                  Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text("الخصم على الفاتورة:", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilterChip(
                          selected = discountMode == "مبلغ",
                          onClick = {
                            discountMode = "مبلغ"
                            val subtotal = cartItems.sumOf { it.totalPrice }
                            val num = discountInputText.toDoubleOrNull() ?: 0.0
                            viewModel.setSaleDiscount(num.coerceIn(0.0, subtotal))
                          },
                          label = { Text("مبلغ (ج.م)", fontSize = 10.sp) },
                          modifier = Modifier.height(26.dp)
                        )
                        FilterChip(
                          selected = discountMode == "نسبة",
                          onClick = {
                            discountMode = "نسبة"
                            val subtotal = cartItems.sumOf { it.totalPrice }
                            val pct = discountInputText.toDoubleOrNull() ?: 0.0
                            val disc = (subtotal * (pct / 100.0)).coerceIn(0.0, subtotal)
                            viewModel.setSaleDiscount(disc)
                          },
                          label = { Text("نسبة (%)", fontSize = 10.sp) },
                          modifier = Modifier.height(26.dp)
                        )
                      }
                    }

                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                      OutlinedTextField(
                        value = discountInputText,
                        onValueChange = { input ->
                          discountInputText = input.filter { ch -> ch.isDigit() || ch == '.' }
                          val subtotal = cartItems.sumOf { it.totalPrice }
                          val parsed = discountInputText.toDoubleOrNull() ?: 0.0
                          if (discountMode == "نسبة") {
                            val disc = (subtotal * (parsed / 100.0)).coerceIn(0.0, subtotal)
                            viewModel.setSaleDiscount(disc)
                          } else {
                            viewModel.setSaleDiscount(parsed.coerceIn(0.0, subtotal))
                          }
                        },
                        placeholder = { Text("أدخل قيمة الخصم...", fontSize = 12.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        leadingIcon = { Icon(Icons.Default.Percent, contentDescription = null, modifier = Modifier.size(16.dp)) }
                      )
                      if (saleDiscount > 0.0) {
                        Surface(
                          shape = RoundedCornerShape(8.dp),
                          color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
                        ) {
                          Text(
                            text = "-${String.format(Locale.ENGLISH, "%.2f", saleDiscount)} ج.م",
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                          )
                        }
                      }
                    }
                  }

                  HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                }

                // 2. نوع الدفع (نقدي / آجل / دفع جزئي)
                Text("طريقة ونوع الدفع:", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  listOf(
                    Pair(PaymentType.CASH, "نقدي 💵"),
                    Pair(PaymentType.CREDIT, "آجل ⏳"),
                    Pair(PaymentType.PARTIAL, "دفع جزئي 🌓")
                  ).forEach { (type, label) ->
                    FilterChip(
                      selected = salePaymentType == type,
                      onClick = {
                        viewModel.setSalePaymentType(type)
                        validationError = null
                      },
                      label = { Text(label, fontSize = 11.sp, fontWeight = if (salePaymentType == type) FontWeight.Bold else FontWeight.Normal) },
                      colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = when (type) {
                          PaymentType.CASH -> EmeraldPrimary.copy(alpha = 0.2f)
                          PaymentType.CREDIT -> AmberPrimary.copy(alpha = 0.2f)
                          PaymentType.PARTIAL -> Color(0xFF1976D2).copy(alpha = 0.2f)
                        },
                        selectedLabelColor = when (type) {
                          PaymentType.CASH -> EmeraldPrimary
                          PaymentType.CREDIT -> AmberPrimary
                          PaymentType.PARTIAL -> Color(0xFF1976D2)
                        }
                      ),
                      modifier = Modifier.weight(1f)
                    )
                  }
                }

                // تفاصيل السداد حسب نوع الدفع
                when (salePaymentType) {
                  PaymentType.CASH -> {
                    val sub = cartItems.sumOf { it.totalPrice }
                    val net = (sub - saleDiscount).coerceAtLeast(0.0)
                    val tendered = cashTenderedText.toDoubleOrNull() ?: net
                    val changeDue = (tendered - net).coerceAtLeast(0.0)

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                      OutlinedTextField(
                        value = cashTenderedText,
                        onValueChange = { cashTenderedText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("المبلغ المستلم من العميل نقداً (ج.م)", fontSize = 11.sp) },
                        placeholder = { Text(String.format(Locale.ENGLISH, "%.2f", net), fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                      )

                      if (profile.salesEnableQuickPaymentButtons) {
                        Row(
                          modifier = Modifier.fillMaxWidth(),
                          horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                          listOf(50, 100, 200, 500).forEach { quickVal ->
                            Surface(
                              shape = RoundedCornerShape(6.dp),
                              color = MaterialTheme.colorScheme.surfaceVariant,
                              modifier = Modifier
                                .weight(1f)
                                .clickable {
                                  val currentVal = cashTenderedText.toDoubleOrNull() ?: 0.0
                                  cashTenderedText = (currentVal + quickVal).toInt().toString()
                                }
                            ) {
                              Text(
                                text = "+$quickVal",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 4.dp)
                              )
                            }
                          }
                          Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                            modifier = Modifier
                              .weight(1.2f)
                              .clickable { cashTenderedText = String.format(Locale.ENGLISH, "%.2f", net) }
                          ) {
                            Text(
                              text = "المبلغ بالضبط",
                              fontSize = 10.sp,
                              fontWeight = FontWeight.Bold,
                              color = MaterialTheme.colorScheme.primary,
                              textAlign = TextAlign.Center,
                              modifier = Modifier.padding(vertical = 4.dp)
                            )
                          }
                        }
                      }

                      if (cashTenderedText.isNotBlank()) {
                        Row(
                          modifier = Modifier.fillMaxWidth(),
                          horizontalArrangement = Arrangement.SpaceBetween,
                          verticalAlignment = Alignment.CenterVertically
                        ) {
                          Text("الباقي للعميل (الفكة):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                          Text(
                            text = String.format(Locale.ENGLISH, "%.2f ج.م", changeDue),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (changeDue > 0) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
                          )
                        }
                      }
                    }
                  }

                  PaymentType.PARTIAL -> {
                    val sub = cartItems.sumOf { it.totalPrice }
                    val net = (sub - saleDiscount).coerceAtLeast(0.0)
                    val paid = partialPaidText.toDoubleOrNull() ?: 0.0
                    val rem = (net - paid).coerceAtLeast(0.0)

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                      OutlinedTextField(
                        value = partialPaidText,
                        onValueChange = {
                          partialPaidText = it.filter { ch -> ch.isDigit() || ch == '.' }
                          viewModel.setSalePaidAmount(partialPaidText.toDoubleOrNull())
                        },
                        label = { Text("المبلغ المدفوع كاش الآن (ج.م) *", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                      )
                      Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Text("المتبقي كدين آجل على العميل:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                          text = String.format(Locale.ENGLISH, "%.2f ج.م", rem),
                          fontSize = 13.sp,
                          fontWeight = FontWeight.Bold,
                          color = AmberPrimary
                        )
                      }
                    }
                  }

                  PaymentType.CREDIT -> {
                    Surface(
                      shape = RoundedCornerShape(8.dp),
                      color = AmberPrimary.copy(alpha = 0.12f),
                      modifier = Modifier.fillMaxWidth()
                    ) {
                      Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = AmberPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                          text = if (selectedCustomer != null)
                            "سيتم ترحيل كامل الفاتورة (${String.format(Locale.ENGLISH, "%.2f ج.م", totalSalesAmount)}) كدين آجل على [${selectedCustomer!!.name}]"
                          else
                            "⚠️ تنبيه: يرجى اختيار عميل من أعلى الشاشة لتقييد المبلغ الآجل في حسابه",
                          fontSize = 11.sp,
                          color = if (selectedCustomer != null) AmberPrimary else MaterialTheme.colorScheme.error,
                          fontWeight = FontWeight.SemiBold
                        )
                      }
                    }
                  }
                }

                // 3. ملاحظات الفاتورة
                if (profile.salesEnableInvoiceNotes) {
                  OutlinedTextField(
                    value = invoiceNotesText,
                    onValueChange = { invoiceNotesText = it },
                    placeholder = { Text("ملاحظات خاصة بالفاتورة أو شروط التسليم (اختياري)...", fontSize = 11.5.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                  )
                }

                // رسائل الخطأ
                validationError?.let { err ->
                  Text(
                    text = err,
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold
                  )
                }

                // زر إتمام وحفظ الفاتورة المباشر
                Button(
                  onClick = { executeCompleteSaleInline() },
                  enabled = !isSavingSale,
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp),
                  shape = RoundedCornerShape(12.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                  if (isSavingSale) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("جاري حفظ وإصدار الفاتورة...", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                  } else {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("✓ إتمام وحفظ الفاتورة مباشرة 💾", fontSize = 13.5.sp, fontWeight = FontWeight.ExtraBold)
                  }
                }
              }
            }
          }
        }
      }
    }

    // -------------------------------------------------------------------------
    // 4. الشريط السفلي الثابت (يظهر إجمالي المبيعات، رصيد العميل السابق، وإجمالي المطلوب)
    // -------------------------------------------------------------------------
    Surface(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth(),
      shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
      color = MaterialTheme.colorScheme.surface,
      shadowElevation = 16.dp,
      border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 10.dp)
      ) {
        // سطر الإحصائيات السريعة: العدد، الكمية، نظام السعر
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // 1. العدد
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text("العدد: ", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("$itemsCount صنف", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          // 2. إجمالي الكمية
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text("إجمالي الكمية: ", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("$totalQuantity", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          // 3. نظام السعر
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (isWholesalePriceMode) EmeraldPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
          ) {
            Text(
              text = if (isWholesalePriceMode) "سعر جملة" else "سعر قطاعي",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = if (isWholesalePriceMode) EmeraldPrimary else MaterialTheme.colorScheme.primary,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // بطاقة الحساب المالي المدمجة (إجمالي المبيعات + رصيد العميل السابق = إجمالي المطلوب)
        Surface(
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            // 1. إجمالي المبيعات
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text("إجمالي المبيعات (الفاتورة الحالية):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = String.format(Locale.ENGLISH, "%.2f ج.م", totalSalesAmount),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
            }

            // 2. رصيد العميل السابق (يظهر تحت إجمالي المبيعات)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text("رصيد العميل السابق:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (selectedCustomer != null) {
                  Text(
                    text = " [${selectedCustomer!!.name}]",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                }
              }
              Text(
                text = String.format(Locale.ENGLISH, "%.2f ج.م", previousCustomerBalance),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (previousCustomerBalance > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
              )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 3.dp))

            // 3. إجمالي المطلوب (يتم جمع إجمالي المبيعات + رصيد العميل السابق)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "إجمالي المطلوب (شامل الحساب السابق):",
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = String.format(Locale.ENGLISH, "%.2f ج.م", grandTotalDue),
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (grandTotalDue > 0) AmberPrimary else MaterialTheme.colorScheme.primary
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // زر إتمام الفاتورة والسداد المباشر (بدون أي نوافذ منبثقة)
        Button(
          onClick = {
            if (cartItems.isNotEmpty()) {
              executeCompleteSaleInline()
            }
          },
          enabled = cartItems.isNotEmpty() && !isSavingSale,
          modifier = Modifier
            .fillMaxWidth()
            .height(44.dp),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = EmeraldPrimary,
            disabledContainerColor = Color.LightGray
          )
        ) {
          if (isSavingSale) {
            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            Spacer(modifier = Modifier.width(6.dp))
            Text("جاري الحفظ والإصدار...", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          } else {
            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (cartItems.isEmpty()) "أضف منتجات لإتمام الفاتورة" else "✓ إتمام وحفظ الفاتورة مباشرة 💾",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
          }
        }
      }
    }

    // -------------------------------------------------------------------------
    // نافذة اختيار العميل مع شريط بحث مدمج (Customer Picker with Search Bar)
    // -------------------------------------------------------------------------
    if (showCustomerPickerSheet) {
      ModalBottomSheet(
        onDismissRequest = { showCustomerPickerSheet = false },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
      ) {
        CustomerSearchAndPickerSheet(
          customers = customers,
          selectedCustomer = selectedCustomer,
          onSelectCustomer = { cust ->
            viewModel.selectCustomer(cust)
            showCustomerPickerSheet = false
          },
          onAddNewCustomerDialog = {
            showCustomerPickerSheet = false
            showAddCustomerDialog = true
          },
          onClose = { showCustomerPickerSheet = false }
        )
      }
    }

    // -------------------------------------------------------------------------
    // نافذة البحث عن المنتجات (تفتح عند الضغط على إضافة منتج)
    // -------------------------------------------------------------------------
    if (showProductSearchSheet) {
      ModalBottomSheet(
        onDismissRequest = { showProductSearchSheet = false },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
      ) {
        ProductSearchAndPickerSheet(
          products = products,
          salesCart = cartItems,
          isWholesalePriceMode = isWholesalePriceMode,
          defaultUnit = defaultUnit,
          onQuantityChange = { product, unitType, delta ->
            val tier = if (isWholesalePriceMode) PriceTier.WHOLESALE else PriceTier.RETAIL
            viewModel.changeSalesCartQuantity(product, unitType, delta, tier)
          },
          onOutOfStockAttempt = { product, unitType ->
            outOfStockProductAttempt = Pair(product, unitType)
          },
          onAddNewProductDialog = {
            showProductSearchSheet = false
            showAddProductDialog = true
          },
          onClose = { showProductSearchSheet = false }
        )
      }
    }

    // تنبيه إضافة صنف غير متوفر بالمخزن
    outOfStockProductAttempt?.let { (product, unitType) ->
      OutOfStockWarningDialog(
        product = product,
        unitType = unitType,
        onDismiss = { outOfStockProductAttempt = null },
        onAddStockAndAddToCart = { piecesToAdd ->
          val tier = if (isWholesalePriceMode) PriceTier.WHOLESALE else PriceTier.RETAIL
          viewModel.quickAdjustStock(product, piecesToAdd) {
            viewModel.changeSalesCartQuantity(product, unitType, 1, tier)
          }
          outOfStockProductAttempt = null
        },
        onAddAnyway = {
          val tier = if (isWholesalePriceMode) PriceTier.WHOLESALE else PriceTier.RETAIL
          viewModel.changeSalesCartQuantity(product, unitType, 1, tier)
          outOfStockProductAttempt = null
        }
      )
    }

    // إضافة صنف جديد
    if (showAddProductDialog) {
      AddEditProductDialog(
        showUnitTypeSelection = false,
        onDismiss = { showAddProductDialog = false },
        onSave = { newProd ->
          viewModel.saveProduct(newProd) { savedProduct ->
            val tier = if (isWholesalePriceMode) PriceTier.WHOLESALE else PriceTier.RETAIL
            val unit = defaultUnit
            viewModel.addToSalesCart(savedProduct, unitType = unit, tier = tier)
          }
          showAddProductDialog = false
        }
      )
    }

    // إضافة عميل جديد
    if (showAddCustomerDialog) {
      AddEditCustomerDialog(
        onDismiss = { showAddCustomerDialog = false },
        onSave = { newCustomer ->
          viewModel.saveCustomer(newCustomer) { savedCustomer ->
            viewModel.selectCustomer(savedCustomer)
          }
          showAddCustomerDialog = false
        }
      )
    }

    // نافذة إعدادات شاشة المبيعات والكاشير وتعديل الأسعار
    if (showSalesSettingsDialog) {
      SalesSettingsDialog(
        initial = profile,
        onDismiss = { showSalesSettingsDialog = false },
        onSave = { updated ->
          viewModel.updateBusinessProfile(updated)
          showSalesSettingsDialog = false
          Toast.makeText(context, "تم حفظ إعدادات شاشة المبيعات بنجاح ✓", Toast.LENGTH_SHORT).show()
        }
      )
    }

    // نافذة نظام الموظفين، المناديب، ومزامنة الفواتير
    if (showDelegateSyncDialog) {
      MultiEmployeeAndDelegateDialog(
        viewModel = viewModel,
        initial = profile,
        onDismiss = { showDelegateSyncDialog = false },
        onSaveProfile = { updated ->
          viewModel.updateBusinessProfile(updated)
          showDelegateSyncDialog = false
          Toast.makeText(context, "تم حفظ إعدادات الموظفين والمناديب والمزامنة ✓", Toast.LENGTH_SHORT).show()
        }
      )
    }
  }
}

// -----------------------------------------------------------------------------
// نافذة اختيار العميل مع شريط بحث (Customer Search & Picker Sheet)
// -----------------------------------------------------------------------------
@Composable
fun CustomerSearchAndPickerSheet(
  customers: List<Customer>,
  selectedCustomer: Customer?,
  onSelectCustomer: (Customer?) -> Unit,
  onAddNewCustomerDialog: () -> Unit,
  onClose: () -> Unit
) {
  var customerSearchQuery by remember { mutableStateOf("") }

  val filteredCustomers = remember(customers, customerSearchQuery) {
    customers.filter { cust ->
      cust.name.contains(customerSearchQuery, ignoreCase = true) ||
          cust.phone.contains(customerSearchQuery)
    }
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "اختيار عميل الفاتورة",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      IconButton(onClick = onClose) {
        Icon(Icons.Default.Close, contentDescription = "إغلاق")
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // شريط البحث الخاص بالعملاء
    OutlinedTextField(
      value = customerSearchQuery,
      onValueChange = { customerSearchQuery = it },
      placeholder = { Text("بحث عن عميل بالاسم أو رقم الهاتف...", fontSize = 13.sp) },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
      trailingIcon = {
        if (customerSearchQuery.isNotEmpty()) {
          IconButton(onClick = { customerSearchQuery = "" }) {
            Icon(Icons.Default.Clear, contentDescription = "مسح")
          }
        }
      },
      singleLine = true,
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp)
    )

    Spacer(modifier = Modifier.height(10.dp))

    // خيار عميل نقدي (كاش) وزر إضافة عميل جديد
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Button(
        onClick = { onSelectCustomer(null) },
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = if (selectedCustomer == null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
          contentColor = if (selectedCustomer == null) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
        ),
        modifier = Modifier.weight(1f)
      ) {
        Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("عميل نقدي (كاش)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
      }

      OutlinedButton(
        onClick = onAddNewCustomerDialog,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.weight(1f)
      ) {
        Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("إضافة عميل جديد +", fontSize = 12.sp, fontWeight = FontWeight.Bold)
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    Text(
      text = "قائمة العملاء المسجلين (${filteredCustomers.size}):",
      fontSize = 12.sp,
      fontWeight = FontWeight.SemiBold,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Spacer(modifier = Modifier.height(4.dp))

    // قائمة العملاء المطابقة للبحث
    LazyColumn(
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(max = 380.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      items(filteredCustomers, key = { it.id }) { customer ->
        val isSelected = selectedCustomer?.id == customer.id

        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelectCustomer(customer) },
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
          ),
          border = if (isSelected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Box(
                modifier = Modifier
                  .size(34.dp)
                  .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.Person,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(18.dp)
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = customer.name,
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp
                )
                if (customer.phone.isNotEmpty()) {
                  Text(
                    text = customer.phone,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }

            // شارة الرصيد السابق
            Column(horizontalAlignment = Alignment.End) {
              if (customer.currentBalance > 0) {
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
                ) {
                  Text(
                    text = "دين سابق: ${String.format(Locale.ENGLISH, "%.2f", customer.currentBalance)} ج.م",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              } else if (customer.currentBalance < 0) {
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = EmeraldPrimary.copy(alpha = 0.12f)
                ) {
                  Text(
                    text = "رصيد دائن: ${String.format(Locale.ENGLISH, "%.2f", -customer.currentBalance)} ج.م",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              } else {
                Text(
                  text = "الحساب: 0.00 ج.م",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }

      if (filteredCustomers.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(24.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("لا يوجد عميل يطابق هذا البحث", color = MaterialTheme.colorScheme.onSurfaceVariant)
              Spacer(modifier = Modifier.height(6.dp))
              OutlinedButton(onClick = onAddNewCustomerDialog) {
                Text("إضافة كعميل جديد الآن")
              }
            }
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// بطاقة الصنف المضاف في الفاتورة
// نظام التسعير (جملة/قطاعي) يغير السعر
// -----------------------------------------------------------------------------
@Composable
fun SimpleCartItemCard(
  item: CartItem,
  onQuantityChange: (Int) -> Unit,
  onUnitChange: (String) -> Unit = {},
  onTierChange: (PriceTier) -> Unit = {},
  onPriceChange: (Double) -> Unit = {},
  onRemove: () -> Unit,
  allowManualPriceOverride: Boolean = false
) {
  val isLoss = item.isSellingAtLoss

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    border = if (isLoss) BorderStroke(1.dp, MaterialTheme.colorScheme.error) else null
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = item.product.name,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Spacer(modifier = Modifier.height(2.dp))
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
            ) {
              Text(
                text = "سعر الوحدة: " + String.format(Locale.ENGLISH, "%.2f ج.م", item.unitPrice),
                fontSize = 11.5.sp,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
              )
            }
            Text(
              text = "• التكلفة: " + String.format(Locale.ENGLISH, "%.2f ج.م", item.unitCostPrice),
              fontSize = 10.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        // أزرار التحكم بالكمية (+ / -)
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
              .size(32.dp)
              .clickable { onQuantityChange(item.quantity - 1) }
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Default.Remove, contentDescription = "تقليل", modifier = Modifier.size(16.dp))
            }
          }

          Text(
            text = "${item.quantity}",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 6.dp)
          )

          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
            modifier = Modifier
              .size(32.dp)
              .clickable { onQuantityChange(item.quantity + 1) }
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                Icons.Default.Add,
                contentDescription = "زيادة",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
              )
            }
          }

          Spacer(modifier = Modifier.width(6.dp))

          // حذف الصنف
          IconButton(onClick = onRemove, modifier = Modifier.size(30.dp)) {
            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // السطر السفلي: عرض الوحدة المعينة من الإعدادات وفئة التسعير والإجمالي
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
          ) {
            Text(
              text = "الوحدة: ${item.unitType}",
              fontSize = 10.5.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.5.dp)
            )
          }

          // تبديل فئة السعر للصنف (جملة / قطاعي)
          Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            FilterChip(
              selected = item.priceTier == PriceTier.WHOLESALE,
              onClick = { onTierChange(PriceTier.WHOLESALE) },
              label = { Text("جملة", fontSize = 10.sp) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = EmeraldPrimary.copy(alpha = 0.2f),
                selectedLabelColor = EmeraldPrimary
              ),
              modifier = Modifier.height(26.dp)
            )
            FilterChip(
              selected = item.priceTier == PriceTier.RETAIL,
              onClick = { onTierChange(PriceTier.RETAIL) },
              label = { Text("قطاعي", fontSize = 10.sp) },
              modifier = Modifier.height(26.dp)
            )
          }
        }

        Text(
          text = String.format(Locale.ENGLISH, "%.2f ج.م", item.totalPrice),
          fontWeight = FontWeight.ExtraBold,
          fontSize = 13.sp,
          color = MaterialTheme.colorScheme.primary
        )
      }
    }
  }
}

// -----------------------------------------------------------------------------
// نافذة البحث عن المنتجات (Product Search Sheet)
// يفرق نظام الجملة والقطاعي في السعر، مع إتاحة إضافة كرتونة أو قطعة في الحالتين
// -----------------------------------------------------------------------------
@Composable
fun ProductSearchAndPickerSheet(
  products: List<Product>,
  salesCart: List<CartItem>,
  isWholesalePriceMode: Boolean,
  defaultUnit: String = "كرتونة",
  onQuantityChange: (Product, String, Int) -> Unit,
  onOutOfStockAttempt: (Product, String) -> Unit,
  onAddNewProductDialog: () -> Unit,
  onClose: () -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("الكل") }

  val categories = remember(products) {
    listOf("الكل") + products.map { it.category }.distinct()
  }

  val filteredProducts = remember(products, searchQuery, selectedCategory) {
    products.filter { prod ->
      val matchSearch = prod.name.contains(searchQuery, ignoreCase = true) ||
          prod.barcode.contains(searchQuery, ignoreCase = true)
      val matchCat = selectedCategory == "الكل" || prod.category == selectedCategory
      matchSearch && matchCat
    }
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "البحث عن صنف وإضافته للفاتورة",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "النظام المطبق: ${if (isWholesalePriceMode) "سعر جملة" else "سعر قطاعي"}",
          fontSize = 11.sp,
          color = if (isWholesalePriceMode) EmeraldPrimary else MaterialTheme.colorScheme.primary,
          fontWeight = FontWeight.SemiBold
        )
      }
      IconButton(onClick = onClose) {
        Icon(Icons.Default.Close, contentDescription = "إغلاق")
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // شريط البحث المباشر مع علامة (✕) لمسح المكتوب فوراً
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      placeholder = { Text("اكتب اسم المنتج أو امسح الباركود...", fontSize = 13.sp) },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
      trailingIcon = {
        if (searchQuery.isNotEmpty()) {
          IconButton(onClick = { searchQuery = "" }) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "إلغاء المكتوب ومسح البحث",
              tint = MaterialTheme.colorScheme.error
            )
          }
        }
      },
      singleLine = true,
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp)
    )

    Spacer(modifier = Modifier.height(8.dp))

    // فلاتر الأقسام السريعة وزر إضافة صنف جديد
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "الأقسام:",
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Text(
        text = "+ صنف جديد غير مسجل",
        color = EmeraldPrimary,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        modifier = Modifier.clickable { onAddNewProductDialog() }
      )
    }

    Spacer(modifier = Modifier.height(4.dp))

    // قائمة فئات الأقسام
    LazyRow(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      items(categories) { cat ->
        FilterChip(
          selected = selectedCategory == cat,
          onClick = { selectedCategory = cat },
          label = { Text(cat, fontSize = 11.sp) }
        )
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // قائمة الأصناف المطابقة للبحث
    LazyColumn(
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(max = 420.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(filteredProducts, key = { it.id }) { product ->
        val cartonPrice = if (isWholesalePriceMode) {
          if (product.cartonWholesalePrice > 0.0) product.cartonWholesalePrice else (product.pieceRetailPrice * product.piecesPerCarton)
        } else {
          if (product.pieceRetailPrice > 0.0 && product.piecesPerCarton > 0) product.pieceRetailPrice * product.piecesPerCarton else product.cartonWholesalePrice
        }

        val piecePrice = if (isWholesalePriceMode) {
          if (product.pieceWholesalePrice > 0.0) product.pieceWholesalePrice else if (product.piecesPerCarton > 0 && product.cartonWholesalePrice > 0.0) product.cartonWholesalePrice / product.piecesPerCarton else product.pieceRetailPrice
        } else {
          if (product.pieceRetailPrice > 0.0) product.pieceRetailPrice else if (product.piecesPerCarton > 0) product.cartonWholesalePrice / product.piecesPerCarton else 0.0
        }

        val cartonQty = salesCart.find { it.product.id == product.id && it.unitType == "كرتونة" }?.quantity ?: 0
        val pieceQty = salesCart.find { it.product.id == product.id && (it.unitType == "قطعة" || it.unitType == "علبة") }?.quantity ?: 0
        val totalInCart = cartonQty + pieceQty
        val isInCart = totalInCart > 0

        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isInCart) EmeraldPrimary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
          ),
          border = if (isInCart) BorderStroke(1.5.dp, EmeraldPrimary.copy(alpha = 0.6f)) else null
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp)
          ) {
            // بيانات المنتج
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = product.name,
                fontWeight = FontWeight.Bold,
                fontSize = 13.5.sp,
                modifier = Modifier.weight(1f)
              )
              if (isInCart) {
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = EmeraldPrimary
                ) {
                  Text(
                    text = "بالفاتورة ✓: ${if (cartonQty > 0) "$cartonQty كرتونة " else ""}${if (pieceQty > 0) "$pieceQty علبة" else ""}",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "${product.category} • الكرتونة = ${product.piecesPerCarton} علبة",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              val isOutOfStock = product.totalPiecesInStock <= 0
              Surface(
                shape = RoundedCornerShape(4.dp),
                color = if (isOutOfStock) MaterialTheme.colorScheme.errorContainer else EmeraldPrimary.copy(alpha = 0.15f)
              ) {
                Text(
                  text = if (isOutOfStock) "⚠️ غير متوفر بالمخزن (0)" else "المخزن: ${product.stockDisplayString()}",
                  fontSize = 10.5.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = if (isOutOfStock) MaterialTheme.colorScheme.error else EmeraldPrimary,
                  modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "كرتونة: ${String.format(Locale.ENGLISH, "%.1f ج.م", cartonPrice)}",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                text = "علبة: ${String.format(Locale.ENGLISH, "%.1f ج.م", piecePrice)}",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
              )
            }

            HorizontalDivider(
              modifier = Modifier.padding(vertical = 8.dp),
              color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
            )

            // أسفل كل منتج: زر إضافة المنتج، وبعد إضافته يظهر علامة الـ (+) والـ (-) لزيادة ونقص الكمية
            if (!isInCart) {
              Button(
                onClick = {
                  if (product.totalPiecesInStock <= 0) {
                    onOutOfStockAttempt(product, defaultUnit)
                  } else {
                    onQuantityChange(product, defaultUnit, 1)
                  }
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(38.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
              ) {
                Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "إضافة المنتج للفاتورة +",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            } else {
              // بعد إضافته: علامات الـ (+) والـ (-) لزيادة ونقص الكمية أسفل المنتج مع خيار تبديل الوحدة
              val currentUnit = if (cartonQty > 0) "كرتونة" else "قطعة"
              val currentCount = if (currentUnit == "كرتونة") cartonQty else pieceQty

              Surface(
                shape = RoundedCornerShape(8.dp),
                color = EmeraldPrimary.copy(alpha = 0.12f),
                border = BorderStroke(1.dp, EmeraldPrimary)
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = "مضاف بالفاتورة ✓",
                      fontSize = 11.5.sp,
                      fontWeight = FontWeight.Bold,
                      color = EmeraldPrimary
                    )
                  }

                  // عداد الكمية (+ / -) بالوحدة المحددة من الخارج
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                  ) {
                    IconButton(
                      onClick = { onQuantityChange(product, defaultUnit, -1) },
                      modifier = Modifier.size(32.dp)
                    ) {
                      Icon(Icons.Default.Remove, contentDescription = "تقليل الكمية", tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                    }

                    val currentQty = salesCart.find { it.product.id == product.id && it.unitType == defaultUnit }?.quantity ?: (cartonQty + pieceQty)
                    Surface(
                      shape = RoundedCornerShape(6.dp),
                      color = EmeraldPrimary
                    ) {
                      Text(
                        text = "$currentQty $defaultUnit",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                      )
                    }

                    IconButton(
                      onClick = {
                        if (product.totalPiecesInStock <= 0) {
                          onOutOfStockAttempt(product, defaultUnit)
                        } else {
                          onQuantityChange(product, defaultUnit, 1)
                        }
                      },
                      modifier = Modifier.size(32.dp)
                    ) {
                      Icon(Icons.Default.Add, contentDescription = "زيادة الكمية", tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                    }
                  }
                }
              }
            }
          }
        }
      }

      if (filteredProducts.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(30.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("لا توجد أصناف تطابق هذا البحث", color = MaterialTheme.colorScheme.onSurfaceVariant)
              Spacer(modifier = Modifier.height(8.dp))
              OutlinedButton(onClick = onAddNewProductDialog) {
                Text("إضافة كصنف جديد الآن")
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))
    val totalQty = salesCart.sumOf { it.quantity }
    Button(
      onClick = onClose,
      modifier = Modifier
        .fillMaxWidth()
        .height(42.dp),
      shape = RoundedCornerShape(10.dp),
      colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
    ) {
      Text(
        text = if (totalQty > 0) "✓ تم الاختيار ($totalQty صنف بالفاتورة) • إغلاق" else "إغلاق نافذة الأصناف",
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp
      )
    }
  }
}

// -----------------------------------------------------------------------------
// نافذة تنبيه إذا كان المنتج غير متوفر في المخزن
// -----------------------------------------------------------------------------
@Composable
fun OutOfStockWarningDialog(
  product: Product,
  unitType: String,
  onDismiss: () -> Unit,
  onAddStockAndAddToCart: (Int) -> Unit,
  onAddAnyway: () -> Unit
) {
  var addQuantityText by remember { mutableStateOf("10") }
  var addUnitType by remember { mutableStateOf(unitType) }

  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        Icons.Default.Warning,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.error,
        modifier = Modifier.size(36.dp)
      )
    },
    title = {
      Text(
        text = "الصنف غير متوفر بالمخزن",
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp,
        textAlign = TextAlign.Center
      )
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Surface(
          color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(
              text = "الصنف: ${product.name}",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
            Text(
              text = "رصيد المخزن الحالي: 0 (غير متوفر)",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.error,
              fontWeight = FontWeight.SemiBold
            )
          }
        }

        Text(
          text = "هذا المنتج غير موجود أو نفد من المخزن. هل تريد إضافة المنتج وزيادة كميته في المخزن الآن؟",
          fontSize = 12.5.sp,
          color = MaterialTheme.colorScheme.onSurface
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = addQuantityText,
            onValueChange = { if (it.all { ch -> ch.isDigit() }) addQuantityText = it },
            label = { Text("الكمية المضافة للمخزن ($unitType)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(8.dp)
          )

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.primaryContainer
          ) {
            Text(
              text = "الوحدة: $unitType",
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onPrimaryContainer,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val qty = addQuantityText.toIntOrNull() ?: 1
          val piecesToAdd = if (unitType == "كرتونة") {
            qty * (if (product.piecesPerCarton > 0) product.piecesPerCarton else 1)
          } else {
            qty
          }
          onAddStockAndAddToCart(piecesToAdd)
        },
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
      ) {
        Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("نعم، زيادة المخزن والإضافة", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        OutlinedButton(onClick = onAddAnyway) {
          Text("إضافة بالسالب", fontSize = 11.sp)
        }
        TextButton(onClick = onDismiss) {
          Text("إلغاء", fontSize = 11.sp)
        }
      }
    }
  )
}

// -----------------------------------------------------------------------------
// نافذة إتمام البيع والسداد وتحديد طريقة الدفع (كاش / آجل / جزئي)
// -----------------------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimpleSalesCheckoutSheet(
  viewModel: WholesaleViewModel,
  cartItems: List<CartItem>,
  customers: List<Customer>,
  selectedCustomer: Customer?,
  discount: Double,
  paidAmount: Double?,
  paymentType: PaymentType,
  cartTotal: Double,
  previousBalance: Double,
  grandTotalDue: Double,
  isWholesalePriceMode: Boolean,
  onAddNewCustomer: () -> Unit,
  onClose: () -> Unit
) {
  val context = LocalContext.current
  val profile by viewModel.businessProfile.collectAsStateWithLifecycle()

  // 1. تاريخ الفاتورة المخصص (مع إمكانية التعديل)
  var customInvoiceTimestamp by remember { mutableStateOf<Long?>(null) }
  val activeTimestamp = customInvoiceTimestamp ?: System.currentTimeMillis()
  val dateDisplayFormat = remember { SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale("ar")) }

  // 2. حساب إجمالي الأصناف والخصم (نسبة أو مبلغ)
  val subtotal = remember(cartItems) { cartItems.sumOf { it.totalPrice } }
  var discountMode by remember { mutableStateOf(if (profile.salesDefaultDiscountType == "نسبة مئوية") "نسبة" else "مبلغ") }
  var discountInputText by remember {
    mutableStateOf(if (discount > 0) String.format(Locale.ENGLISH, "%.2f", discount) else "")
  }

  // 3. النقدية المستلمة وحساب الباقي وسداد أقل من الفاتورة
  var cashTenderedText by remember { mutableStateOf("") }
  var partialPaidText by remember { mutableStateOf(paidAmount?.toString() ?: "") }
  var invoiceNotesText by remember { mutableStateOf("") }
  var validationError by remember { mutableStateOf<String?>(null) }

  // صافي الفاتورة بعد الخصم المطبق
  val netInvoiceTotal = (subtotal - discount).coerceAtLeast(0.0)

  // النقدية المستلمة الفعلية عند الدفع كاش
  val tenderedCash = cashTenderedText.toDoubleOrNull()
  val isUnderpaidCash = paymentType == PaymentType.CASH && tenderedCash != null && tenderedCash < netInvoiceTotal
  val cashChangeDue = if (paymentType == PaymentType.CASH && tenderedCash != null && tenderedCash > netInvoiceTotal) {
    tenderedCash - netInvoiceTotal
  } else {
    0.0
  }

  // تحقق الخسارة (البيع أقل من التكلفة)
  val lossItems = remember(cartItems) { cartItems.filter { it.isSellingAtLoss } }
  val totalCost = remember(cartItems) { cartItems.sumOf { it.totalCost } }
  val isInvoiceLoss = remember(netInvoiceTotal, totalCost) { netInvoiceTotal < totalCost }
  val hasLossViolation = lossItems.isNotEmpty() || isInvoiceLoss
  val allowBelowCost = profile.salesAllowSellingBelowCost

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 16.dp, vertical = 10.dp)
  ) {
    // الرأس وزر الإغلاق
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "إتمام فاتورة المبيعات (${cartItems.size} صنف)",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "إجمالي السلة: ${String.format(Locale.ENGLISH, "%.2f ج.م", subtotal)}",
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
      IconButton(onClick = onClose) {
        Icon(Icons.Default.Close, contentDescription = "إغلاق")
      }
    }

    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

    // -------------------------------------------------------------------------
    // إعداد: تعديل تاريخ ووقت الفاتورة (حسب الإعدادات)
    // -------------------------------------------------------------------------
    if (profile.salesAllowCustomInvoiceDate) {
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.CalendarToday, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Column {
              Text("تاريخ الفاتورة:", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = dateDisplayFormat.format(Date(activeTimestamp)),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (customInvoiceTimestamp != null) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
              )
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedButton(
              onClick = {
                val cal = Calendar.getInstance().apply { timeInMillis = activeTimestamp }
                DatePickerDialog(
                  context,
                  { _, y, m, d ->
                    cal.set(Calendar.YEAR, y)
                    cal.set(Calendar.MONTH, m)
                    cal.set(Calendar.DAY_OF_MONTH, d)
                    TimePickerDialog(
                      context,
                      { _, h, min ->
                        cal.set(Calendar.HOUR_OF_DAY, h)
                        cal.set(Calendar.MINUTE, min)
                        customInvoiceTimestamp = cal.timeInMillis
                      },
                      cal.get(Calendar.HOUR_OF_DAY),
                      cal.get(Calendar.MINUTE),
                      false
                    ).show()
                  },
                  cal.get(Calendar.YEAR),
                  cal.get(Calendar.MONTH),
                  cal.get(Calendar.DAY_OF_MONTH)
                ).show()
              },
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.height(32.dp),
              contentPadding = PaddingValues(horizontal = 8.dp)
            ) {
              Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(13.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("تعديل التاريخ", fontSize = 11.sp)
            }

            if (customInvoiceTimestamp != null) {
              TextButton(
                onClick = { customInvoiceTimestamp = null },
                modifier = Modifier.height(32.dp),
                contentPadding = PaddingValues(horizontal = 6.dp)
              ) {
                Text("إعادة لـ الآن", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.error)
              }
            }
          }
        }
      }
      Spacer(modifier = Modifier.height(8.dp))
    }

    // -------------------------------------------------------------------------
    // طريقة الدفع (كاش / آجل / دفع جزئي)
    // -------------------------------------------------------------------------
    Text("طريقة سداد الفاتورة:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
    Spacer(modifier = Modifier.height(4.dp))

    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
      PaymentType.values().forEachIndexed { idx, type ->
        val label = when (type) {
          PaymentType.CASH -> "نقداً كاش"
          PaymentType.CREDIT -> "آجل (شكك)"
          PaymentType.PARTIAL -> "دفع جزئي"
        }
        SegmentedButton(
          selected = paymentType == type,
          onClick = {
            viewModel.setSalePaymentType(type)
            validationError = null
          },
          shape = SegmentedButtonDefaults.itemShape(index = idx, count = PaymentType.values().size)
        ) {
          Text(label, fontSize = 12.sp, fontWeight = if (paymentType == type) FontWeight.Bold else FontWeight.Normal)
        }
      }
    }

    // تنبيه بحالة الدفع
    Surface(
      shape = RoundedCornerShape(10.dp),
      color = when (paymentType) {
        PaymentType.CASH -> EmeraldPrimary.copy(alpha = 0.08f)
        PaymentType.CREDIT -> AmberPrimary.copy(alpha = 0.12f)
        PaymentType.PARTIAL -> Color(0xFF1976D2).copy(alpha = 0.08f)
      },
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 6.dp)
    ) {
      Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = if (paymentType == PaymentType.CREDIT && selectedCustomer == null) Icons.Default.Warning else Icons.Default.Info,
          contentDescription = null,
          tint = when (paymentType) {
            PaymentType.CASH -> EmeraldPrimary
            PaymentType.CREDIT -> if (selectedCustomer == null) MaterialTheme.colorScheme.error else AmberPrimary
            PaymentType.PARTIAL -> Color(0xFF1976D2)
          },
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
          when (paymentType) {
            PaymentType.CASH -> {
              Text(
                text = "دفع كاش: سيتم توريد المبلغ المحصل للخزينة فورياً.",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = EmeraldPrimary
              )
            }
            PaymentType.CREDIT -> {
              if (selectedCustomer == null) {
                Text(
                  text = "تنبيه: للبيع بالآجل، يجب اختيار عميل أو تسجيل عميل جديد لتقييد المبلغ كمديونية.",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.error
                )
              } else {
                Text(
                  text = "بيع آجل على حساب [${selectedCustomer.name}]. متبقي عليه: ${String.format(Locale.ENGLISH, "%.2f ج.م", netInvoiceTotal)}",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = AmberPrimary
                )
              }
            }
            PaymentType.PARTIAL -> {
              Text(
                text = "دفع جزئي: أدخل المبلغ المدفوع نقداً، والباقي سيُسجل كدين آجل على حساب العميل.",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1976D2)
              )
            }
          }
        }
      }
    }

    // -------------------------------------------------------------------------
    // إعداد: الخصومات (نسبة ومبلغ)
    // -------------------------------------------------------------------------
    if (profile.salesEnableDiscount) {
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("🏷️ خصم الفاتورة (مبلغ أو نسبة %):", fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              FilterChip(
                selected = discountMode == "مبلغ",
                onClick = {
                  discountMode = "مبلغ"
                  val amt = discountInputText.toDoubleOrNull() ?: 0.0
                  viewModel.setSaleDiscount(amt)
                },
                label = { Text("مبلغ ج.م", fontSize = 10.sp) },
                modifier = Modifier.height(28.dp)
              )
              FilterChip(
                selected = discountMode == "نسبة",
                onClick = {
                  discountMode = "نسبة"
                  val pct = discountInputText.toDoubleOrNull() ?: 0.0
                  val calcAmt = (subtotal * pct / 100.0).coerceAtLeast(0.0)
                  viewModel.setSaleDiscount(calcAmt)
                },
                label = { Text("نسبة %", fontSize = 10.sp) },
                modifier = Modifier.height(28.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(4.dp))

          OutlinedTextField(
            value = discountInputText,
            onValueChange = { input ->
              discountInputText = input
              val num = input.toDoubleOrNull() ?: 0.0
              if (discountMode == "نسبة") {
                val maxPct = profile.salesMaxDiscountPercent.coerceAtLeast(1.0)
                val safePct = if (num > maxPct) {
                  Toast.makeText(context, "الحد الأقصى للخصم المسموح به هو $maxPct%", Toast.LENGTH_SHORT).show()
                  maxPct
                } else {
                  num
                }
                val calcDiscount = (subtotal * safePct / 100.0).coerceIn(0.0, subtotal)
                viewModel.setSaleDiscount(calcDiscount)
              } else {
                val calcDiscount = num.coerceIn(0.0, subtotal)
                viewModel.setSaleDiscount(calcDiscount)
              }
            },
            label = {
              Text(
                if (discountMode == "نسبة") "نسبة الخصم % (الحد الأقصى: ${profile.salesMaxDiscountPercent}%)" else "مبلغ الخصم بالجنيه (ج.م)",
                fontSize = 11.sp
              )
            },
            trailingIcon = {
              if (discount > 0) {
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = EmeraldPrimary.copy(alpha = 0.15f)
                ) {
                  Text(
                    text = "خصم: ${String.format(Locale.ENGLISH, "%.2f ج.م", discount)}",
                    fontSize = 10.sp,
                    color = EmeraldPrimary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
          )
        }
      }
    }

    // -------------------------------------------------------------------------
    // إعداد: فئات النقدية السريعة + النقدية المستلمة + الباقي + البيع بأقل من الإجمالي
    // -------------------------------------------------------------------------
    if (paymentType == PaymentType.CASH) {
      if (profile.salesEnableQuickPaymentButtons) {
        Column(modifier = Modifier.padding(vertical = 4.dp)) {
          Text("💵 النقدية المستلمة من العميل وفئات الدفع السريع:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
          Spacer(modifier = Modifier.height(4.dp))

          LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            item {
              FilterChip(
                selected = cashTenderedText == String.format(Locale.ENGLISH, "%.0f", netInvoiceTotal),
                onClick = {
                  cashTenderedText = String.format(Locale.ENGLISH, "%.2f", netInvoiceTotal)
                  viewModel.setSalePaidAmount(netInvoiceTotal)
                },
                label = { Text("المضبوط (${String.format(Locale.ENGLISH, "%.0f", netInvoiceTotal)})", fontSize = 10.5.sp) }
              )
            }
            listOf(50.0, 100.0, 200.0, 500.0, 1000.0).forEach { bill ->
              if (bill >= netInvoiceTotal || profile.salesAllowSellingBelowInvoiceTotal) {
                item {
                  FilterChip(
                    selected = cashTenderedText == bill.toString(),
                    onClick = {
                      cashTenderedText = bill.toString()
                      if (bill < netInvoiceTotal) {
                        viewModel.setSalePaidAmount(bill)
                      } else {
                        viewModel.setSalePaidAmount(netInvoiceTotal)
                      }
                    },
                    label = { Text("${bill.toInt()} ج.م", fontSize = 10.5.sp) }
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(4.dp))

          OutlinedTextField(
            value = cashTenderedText,
            onValueChange = {
              cashTenderedText = it
              val t = it.toDoubleOrNull()
              if (t != null && t < netInvoiceTotal) {
                viewModel.setSalePaidAmount(t)
              } else {
                viewModel.setSalePaidAmount(netInvoiceTotal)
              }
            },
            label = { Text("النقدية المستلمة من يد العميل (ج.م)", fontSize = 11.sp) },
            placeholder = { Text(String.format(Locale.ENGLISH, "%.2f", netInvoiceTotal)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
          )

          // عرض الباقي أو تنبيه البيع بأقل من القيمة
          if (cashChangeDue > 0) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = EmeraldPrimary.copy(alpha = 0.15f),
              border = BorderStroke(1.dp, EmeraldPrimary),
              modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text("💵 الباقي المستحق للعميل (فكة):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = EmeraldPrimary)
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f ج.م", cashChangeDue),
                  fontWeight = FontWeight.ExtraBold,
                  fontSize = 15.sp,
                  color = EmeraldPrimary
                )
              }
            }
          } else if (isUnderpaidCash) {
            val shortage = netInvoiceTotal - (tenderedCash ?: 0.0)
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (profile.salesAllowSellingBelowInvoiceTotal) AmberPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.errorContainer,
              modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.Info,
                  contentDescription = null,
                  tint = if (profile.salesAllowSellingBelowInvoiceTotal) AmberPrimary else MaterialTheme.colorScheme.error,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (profile.salesAllowSellingBelowInvoiceTotal) {
                    "تم استلام (${String.format(Locale.ENGLISH, "%.2f", tenderedCash)}) بأقل من قيمة الفاتورة بمقدار (${String.format(Locale.ENGLISH, "%.2f ج.م", shortage)}) • مسموح به حسب إعدادات المبيعات."
                  } else {
                    "المبلغ أقل من الفاتورة بمقدار (${String.format(Locale.ENGLISH, "%.2f ج.م", shortage)})! إعدادات النظام لا تسمح بالبيع بأقل من الإجمالي نقداً."
                  },
                  fontSize = 10.5.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = if (profile.salesAllowSellingBelowInvoiceTotal) AmberPrimary else MaterialTheme.colorScheme.error
                )
              }
            }
          }
        }
      }
    }

    // -------------------------------------------------------------------------
    // الدفع الجزئي
    // -------------------------------------------------------------------------
    if (paymentType == PaymentType.PARTIAL) {
      OutlinedTextField(
        value = partialPaidText,
        onValueChange = {
          partialPaidText = it
          viewModel.setSalePaidAmount(it.toDoubleOrNull())
        },
        label = { Text("المبلغ المدفوع نقداً الآن (ج.م) *", fontSize = 11.sp) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp),
        shape = RoundedCornerShape(10.dp)
      )
    }

    // -------------------------------------------------------------------------
    // إعداد: ملاحظات الفاتورة (حسب الإعدادات)
    // -------------------------------------------------------------------------
    if (profile.salesEnableInvoiceNotes) {
      OutlinedTextField(
        value = invoiceNotesText,
        onValueChange = { invoiceNotesText = it },
        label = { Text("ملاحظات الفاتورة (اختياري)", fontSize = 11.sp) },
        placeholder = { Text("مثال: تسليم عند البوابة / خصم خاص لعميل دائم..", fontSize = 11.sp) },
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 2.dp),
        shape = RoundedCornerShape(10.dp)
      )
    }

    // -------------------------------------------------------------------------
    // إعداد: إظهار هامش الربح للكاشير (حسب الإعدادات)
    // -------------------------------------------------------------------------
    if (profile.salesShowProfitToCashier) {
      val profit = netInvoiceTotal - totalCost
      val marginPct = if (netInvoiceTotal > 0) (profit / netInvoiceTotal) * 100.0 else 0.0
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = EmeraldPrimary.copy(alpha = 0.08f),
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("هامش ربح الفاتورة للكاشير:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = "${String.format(Locale.ENGLISH, "%.2f ج.م", profit)} (${String.format(Locale.ENGLISH, "%.1f%%", marginPct)})",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (profit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
          )
        }
      }
    }

    // تنبيه البيع بأقل من سعر التكلفة
    if (hasLossViolation) {
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (allowBelowCost) AmberPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.errorContainer,
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
      ) {
        Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = if (allowBelowCost) Icons.Default.Info else Icons.Default.Warning,
            contentDescription = null,
            tint = if (allowBelowCost) AmberPrimary else MaterialTheme.colorScheme.error,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (allowBelowCost) {
              "⚠️ تنبيه: الفاتورة تباع بأقل من سعر التكلفة بمقدار (${String.format(Locale.ENGLISH, "%.2f ج.م", totalCost - netInvoiceTotal)}) • مسموح به في الإعدادات."
            } else {
              "⛔ تنبيه: لا يمكن البيع بسعر أقل من تكلفة الشراء! (يمنعها النظام لحماية الأرباح)."
            },
            color = if (allowBelowCost) AmberPrimary else MaterialTheme.colorScheme.error,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
          )
        }
      }
    }

    validationError?.let { err ->
      Text(
        text = err,
        color = MaterialTheme.colorScheme.error,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        modifier = Modifier.padding(vertical = 2.dp)
      )
    }

    // -------------------------------------------------------------------------
    // ملخص الحساب المالي (إجمالي المبيعات + رصيد العميل السابق = إجمالي المطلوب)
    // -------------------------------------------------------------------------
    Surface(
      shape = RoundedCornerShape(12.dp),
      color = MaterialTheme.colorScheme.surfaceVariant,
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 6.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("إجمالي السلة قبل الخصم:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.2f ج.م", subtotal),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }

        if (discount > 0) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("الخصم المطبق:", fontSize = 12.sp, color = EmeraldPrimary)
            Text(
              text = "- ${String.format(Locale.ENGLISH, "%.2f ج.م", discount)}",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = EmeraldPrimary
            )
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("صافي الفاتورة الحالية:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.2f ج.م", netInvoiceTotal),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("رصيد العميل السابق:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.2f ج.م", previousBalance),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (previousBalance > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
          )
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 3.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "إجمالي المطلوب النهائي:",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 13.sp
          )
          Text(
            text = String.format(Locale.ENGLISH, "%.2f ج.م", (previousBalance + netInvoiceTotal)),
            fontSize = 17.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if ((previousBalance + netInvoiceTotal) > 0) AmberPrimary else EmeraldPrimary
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // -------------------------------------------------------------------------
    // أزرار التحكم
    // -------------------------------------------------------------------------
    val canProceed = (!hasLossViolation || allowBelowCost) &&
        (!isUnderpaidCash || profile.salesAllowSellingBelowInvoiceTotal)

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      OutlinedButton(
        onClick = { viewModel.clearSalesCart() },
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.weight(1f)
      ) {
        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("مسح")
      }

      Button(
        onClick = {
          if (hasLossViolation && !allowBelowCost) {
            validationError = "غير مسموح بحفظ الفاتورة بسعر أقل من تكلفة الشراء!"
            return@Button
          }
          if (isUnderpaidCash && !profile.salesAllowSellingBelowInvoiceTotal) {
            validationError = "غير مسموح بالبيع بأقل من قيمة الفاتورة كاش حسب إعدادات النظام"
            return@Button
          }
          if ((paymentType == PaymentType.CREDIT || paymentType == PaymentType.PARTIAL) && selectedCustomer == null) {
            validationError = "برجاء اختيار عميل لتقييد المبلغ الآجل في حسابه"
            return@Button
          }
          validationError = null
          viewModel.completeSale(
            customTimestamp = customInvoiceTimestamp,
            invoiceNotes = invoiceNotesText.ifBlank { null },
            onSuccess = {
              onClose()
            },
            onError = { err ->
              validationError = err
            }
          )
        },
        enabled = canProceed,
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = if (!canProceed) Color.Gray else EmeraldPrimary,
          disabledContainerColor = Color.LightGray
        ),
        modifier = Modifier.weight(1.8f)
      ) {
        Icon(Icons.Default.Check, contentDescription = null)
        Spacer(modifier = Modifier.width(6.dp))
        Text("حفظ وإصدار الفاتورة 🖨️", fontWeight = FontWeight.Bold, fontSize = 13.sp)
      }
    }
  }
}

// -----------------------------------------------------------------------------
// سجل فواتير المبيعات السابقة
// -----------------------------------------------------------------------------
@Composable
fun SalesInvoicesHistoryView(
  viewModel: WholesaleViewModel,
  onEditInPos: ((Invoice) -> Unit)? = null
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val salesInvoices by viewModel.salesInvoices.collectAsStateWithLifecycle()
  val products by viewModel.products.collectAsStateWithLifecycle()
  val customers by viewModel.customers.collectAsStateWithLifecycle()
  val suppliers by viewModel.suppliers.collectAsStateWithLifecycle()

  var search by remember { mutableStateOf("") }
  var filterPaymentType by remember { mutableStateOf<PaymentType?>(null) }

  var inspectingInvoice by remember { mutableStateOf<Invoice?>(null) }
  var editingInvoiceData by remember { mutableStateOf<Pair<Invoice, List<InvoiceItem>>?>(null) }
  var deletingInvoice by remember { mutableStateOf<Invoice?>(null) }

  val filtered = remember(salesInvoices, search, filterPaymentType) {
    salesInvoices.filter { inv ->
      val matchesSearch = inv.partyName.contains(search, ignoreCase = true) ||
          inv.invoiceNumber.contains(search, ignoreCase = true)
      val matchesType = filterPaymentType == null || inv.paymentType == filterPaymentType
      matchesSearch && matchesType
    }
  }

  val totalSalesAmount = remember(salesInvoices) { salesInvoices.sumOf { it.totalAmount } }
  val totalPaidCash = remember(salesInvoices) { salesInvoices.sumOf { it.paidAmount } }
  val totalRemainingCredit = remember(salesInvoices) { salesInvoices.sumOf { it.remainingAmount } }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(14.dp)
  ) {
    // شريط إحصائي مالي
    Surface(
      shape = RoundedCornerShape(12.dp),
      color = MaterialTheme.colorScheme.surfaceVariant,
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 10.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("إجمالي المبيعات", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.1f ج.م", totalSalesAmount),
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.primary
          )
        }
        HorizontalDivider(modifier = Modifier.height(28.dp).width(1.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("المحصل كاش", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.1f ج.م", totalPaidCash),
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = EmeraldPrimary
          )
        }
        HorizontalDivider(modifier = Modifier.height(28.dp).width(1.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("الآجل المتبقي", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = String.format(Locale.ENGLISH, "%.1f ج.م", totalRemainingCredit),
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = if (totalRemainingCredit > 0) AmberPrimary else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    // مربع البحث
    OutlinedTextField(
      value = search,
      onValueChange = { search = it },
      placeholder = { Text("بحث باسم العميل أو رقم الفاتورة...", fontSize = 12.sp) },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
      trailingIcon = {
        if (search.isNotEmpty()) {
          IconButton(onClick = { search = "" }) {
            Icon(Icons.Default.Clear, contentDescription = "مسح", modifier = Modifier.size(16.dp))
          }
        }
      },
      modifier = Modifier.fillMaxWidth(),
      singleLine = true,
      shape = RoundedCornerShape(10.dp)
    )

    Spacer(modifier = Modifier.height(8.dp))

    // فلاتر الدفع
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      FilterChip(
        selected = filterPaymentType == null,
        onClick = { filterPaymentType = null },
        label = { Text("الكل (${salesInvoices.size})", fontSize = 11.sp) }
      )
      FilterChip(
        selected = filterPaymentType == PaymentType.CASH,
        onClick = { filterPaymentType = PaymentType.CASH },
        label = { Text("كاش", fontSize = 11.sp) }
      )
      FilterChip(
        selected = filterPaymentType == PaymentType.CREDIT,
        onClick = { filterPaymentType = PaymentType.CREDIT },
        label = { Text("آجل (شكك)", fontSize = 11.sp) }
      )
      FilterChip(
        selected = filterPaymentType == PaymentType.PARTIAL,
        onClick = { filterPaymentType = PaymentType.PARTIAL },
        label = { Text("جزئي", fontSize = 11.sp) }
      )
    }

    Spacer(modifier = Modifier.height(8.dp))

    // قائمة الفواتير
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      items(filtered, key = { it.id }) { invoice ->
        SalesInvoiceHistoryCard(
          invoice = invoice,
          onCardClick = { inspectingInvoice = invoice },
          onInspect = { inspectingInvoice = invoice },
          onEdit = {
            if (onEditInPos != null) {
              onEditInPos(invoice)
            } else {
              scope.launch {
                val items = viewModel.getInvoiceItems(invoice.id)
                editingInvoiceData = Pair(invoice, items)
              }
            }
          },
          onDelete = { deletingInvoice = invoice },
          onPrintReceipt = { viewModel.reopenInvoiceReceipt(invoice) }
        )
      }

      if (filtered.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(40.dp),
            contentAlignment = Alignment.Center
          ) {
            Text("لا توجد فواتير مبيعات مسجلة تطابق البحث", color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }
  }

  // Inspect invoice dialog
  inspectingInvoice?.let { inv ->
    InvoiceDetailsDialog(
      invoice = inv,
      onDismiss = { inspectingInvoice = null },
      onPrintReceipt = {
        viewModel.reopenInvoiceReceipt(inv)
      },
      onEditInvoice = { invoiceToEdit, itemsToEdit ->
        inspectingInvoice = null
        if (onEditInPos != null) {
          onEditInPos(invoiceToEdit)
        } else {
          editingInvoiceData = Pair(invoiceToEdit, itemsToEdit)
        }
      },
      onDeleteInvoice = { invoiceToDelete ->
        inspectingInvoice = null
        deletingInvoice = invoiceToDelete
      },
      loadItems = { id -> viewModel.getInvoiceItems(id) }
    )
  }

  // Edit invoice dialog
  editingInvoiceData?.let { (oldInv, items) ->
    EditInvoiceFullDialog(
      invoice = oldInv,
      initialItems = items,
      allProducts = products,
      allCustomers = customers,
      allSuppliers = suppliers,
      onDismiss = { editingInvoiceData = null },
      onSave = { updatedInvoice, newItems ->
        viewModel.updateInvoiceWithItems(oldInv, updatedInvoice, newItems) {
          Toast.makeText(context, "تم حفظ تعديلات الفاتورة وتحديث المخزن والحساب بنجاح", Toast.LENGTH_SHORT).show()
        }
        editingInvoiceData = null
      }
    )
  }

  // Delete invoice dialog
  deletingInvoice?.let { inv ->
    DeleteInvoiceConfirmDialog(
      invoice = inv,
      onConfirm = {
        viewModel.deleteInvoice(inv) {
          Toast.makeText(context, "تم حذف الفاتورة واسترجاع أرصدة المخزن والحساب بنجاح", Toast.LENGTH_SHORT).show()
        }
        deletingInvoice = null
      },
      onDismiss = { deletingInvoice = null }
    )
  }
}

@Composable
fun SalesInvoiceHistoryCard(
  invoice: Invoice,
  onCardClick: () -> Unit,
  onInspect: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  onPrintReceipt: () -> Unit
) {
  val isCash = invoice.paymentType == PaymentType.CASH
  val isCredit = invoice.paymentType == PaymentType.CREDIT
  val isPartial = invoice.paymentType == PaymentType.PARTIAL

  val timeFormatted = remember(invoice.timestamp) {
    SimpleDateFormat("yyyy-MM-dd  hh:mm a", Locale.ENGLISH).format(Date(invoice.timestamp))
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onCardClick() },
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), shape = CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Receipt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(text = invoice.partyName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(text = "${invoice.invoiceNumber} • $timeFormatted", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }

        Surface(
          shape = RoundedCornerShape(6.dp),
          color = when {
            isCash -> EmeraldPrimary.copy(alpha = 0.12f)
            isCredit -> AmberPrimary.copy(alpha = 0.12f)
            else -> Color(0xFF1976D2).copy(alpha = 0.12f)
          }
        ) {
          Text(
            text = when {
              isCash -> "كاش مسدد"
              isCredit -> "آجل على العميل"
              else -> "سداد جزئي"
            },
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = when {
              isCash -> EmeraldPrimary
              isCredit -> AmberPrimary
              else -> Color(0xFF1976D2)
            },
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
          )
        }
      }

      HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "قيمة الفاتورة: ${String.format(Locale.ENGLISH, "%.2f ج.م", invoice.totalAmount)}",
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp
        )
        if (invoice.remainingAmount > 0) {
          Text(
            text = "المتبقي دين: ${String.format(Locale.ENGLISH, "%.2f ج.م", invoice.remainingAmount)}",
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.error
          )
        } else {
          Text(
            text = "مسددة بالكامل",
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = EmeraldPrimary
          )
        }
      }

      val grandDue = if (invoice.grandTotalDue > 0) invoice.grandTotalDue else (invoice.previousBalance + invoice.remainingAmount)
      if (invoice.previousBalance > 0 || grandDue > 0) {
        Spacer(modifier = Modifier.height(4.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "رصيد العميل السابق: ${String.format(Locale.ENGLISH, "%.2f ج.م", invoice.previousBalance)}",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = "إجمالي الحساب المستحق: ${String.format(Locale.ENGLISH, "%.2f ج.م", grandDue)}",
            fontSize = 12.sp,
            fontWeight = FontWeight.ExtraBold,
            color = AmberPrimary
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Direct Action Buttons on Card: Inspect, Edit, Delete, Print
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Button(
          onClick = onInspect,
          modifier = Modifier.weight(1.1f),
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
          contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
        ) {
          Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("تفاصيل", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
          onClick = onEdit,
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
        ) {
          Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp), tint = AmberPrimary)
          Spacer(modifier = Modifier.width(4.dp))
          Text("تعديل", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AmberPrimary)
        }

        OutlinedButton(
          onClick = onDelete,
          modifier = Modifier.weight(0.9f),
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
        ) {
          Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.error)
          Spacer(modifier = Modifier.width(4.dp))
          Text("حذف", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
        }

        IconButton(
          onClick = onPrintReceipt,
          modifier = Modifier.size(34.dp)
        ) {
          Icon(Icons.Default.Print, contentDescription = "طباعة", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
        }
      }
    }
  }
}
