package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ai.GeminiSupermarketService
import com.example.ai.ParsedReceiptResult
import com.example.ai.ParsedTransactionResult
import com.example.ai.ReceiptExtractedItem
import kotlinx.coroutines.launch
import com.example.data.model.Customer
import com.example.data.model.PaymentType
import com.example.data.model.Product
import com.example.data.model.Supplier
import com.example.ui.PriceTier
import com.example.ui.WholesaleViewModel
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OrangePrimary

// ----------------------------------------------------
// 1. Voice / Text-to-Transaction Dialog
// ----------------------------------------------------
@Composable
fun VoiceToTransactionDialog(
  viewModel: WholesaleViewModel,
  products: List<Product>,
  customers: List<Customer>,
  suppliers: List<Supplier>,
  onDismiss: () -> Unit,
  onNavigateToTab: (Int) -> Unit
) {
  var commandText by remember { mutableStateOf("") }
  var isLoading by remember { mutableStateOf(false) }
  var parsedResult by remember { mutableStateOf<ParsedTransactionResult?>(null) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  val scope = rememberCoroutineScope()
  val focusManager = LocalFocusManager.current
  val keyboardController = LocalSoftwareKeyboardController.current
  val safeDismiss = {
    keyboardController?.hide()
    focusManager.clearFocus()
    onDismiss()
  }

  val sampleCommands = listOf(
    "بيع 2 كرتونة زيت عافية للعميل سامح على الحساب",
    "بيع 4 كرتونة مكرونة روجينا كاش",
    "شراء 5 كرتونة تونة من الشركة المتحدة كاش"
  )

  Dialog(
    onDismissRequest = safeDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .imePadding()
        .clip(RoundedCornerShape(20.dp)),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 8.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(40.dp)
                .background(OrangePrimary.copy(alpha = 0.15f), CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Mic, contentDescription = null, tint = OrangePrimary)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                "أمر صوتي ذكي (AI Voice/Text)",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
              )
              Text(
                "اكتب أو أملِ أمر البيع/الشراء وسيقوم الذكاء الاصطناعي بإعداد الفاتورة",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          IconButton(onClick = safeDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

        // Input Field
        OutlinedTextField(
          value = commandText,
          onValueChange = { commandText = it },
          placeholder = { Text("مثال: بيع 2 كرتونة زيت للعميل سامح على الحساب") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          trailingIcon = {
            if (commandText.isNotEmpty()) {
              IconButton(onClick = { commandText = "" }) {
                Icon(Icons.Default.Close, contentDescription = "مسح")
              }
            }
          }
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Quick Command Suggestions
        Text("أمثلة سريعة للأوامر:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          sampleCommands.forEach { sample ->
            OutlinedButton(
              onClick = {
                commandText = sample
              },
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 4.dp)
            ) {
              Text(sample.take(18) + "...", fontSize = 10.sp, maxLines = 1)
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Execute / Analyze Button
        Button(
          onClick = {
            if (commandText.isBlank()) return@Button
            isLoading = true
            errorMessage = null
            parsedResult = null
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).run {
              scope.launch {
                val result = GeminiSupermarketService.parseTransactionCommand(
                  commandText = commandText,
                  availableProducts = products.map { it.name },
                  availableCustomers = customers.map { it.name },
                  availableSuppliers = suppliers.map { it.name }
                )
                isLoading = false
                if (result != null) {
                  parsedResult = result
                } else {
                  errorMessage = "تعذر تحليل الأمر. تأكد من تفعيل مفتاح Gemini أو أعد صياغة الأمر."
                }
              }
            }
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
          enabled = commandText.isNotBlank() && !isLoading
        ) {
          if (isLoading) {
            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
            Spacer(modifier = Modifier.width(8.dp))
            Text("جاري معالجة الأمر بالذكاء الاصطناعي...")
          } else {
            Icon(Icons.Default.AutoAwesome, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("تحليل وتجهيز الفاتورة", fontWeight = FontWeight.Bold)
          }
        }

        // Error message if any
        if (errorMessage != null) {
          Spacer(modifier = Modifier.height(10.dp))
          Text(errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }

        // Parsed Result Card
        parsedResult?.let { res ->
          Spacer(modifier = Modifier.height(14.dp))
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(14.dp)
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text("نتيجة التحليل الذكي:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Box(
                  modifier = Modifier
                    .background(
                      if (res.type == "SALE") EmeraldPrimary else OrangePrimary,
                      RoundedCornerShape(6.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = if (res.type == "SALE") "فاتورة بيع" else "فاتورة توريد/شراء",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                  )
                }
              }

              Spacer(modifier = Modifier.height(8.dp))
              Text("الطرف: ${res.partyName}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
              Text(
                "طريقة الدفع: " + when (res.paymentType) {
                  PaymentType.CASH -> "نقداً (كاش)"
                  PaymentType.CREDIT -> "آجل (شكك)"
                  PaymentType.PARTIAL -> "سداد جزئي"
                },
                fontSize = 12.sp
              )

              Spacer(modifier = Modifier.height(8.dp))
              HorizontalDivider()
              Spacer(modifier = Modifier.height(8.dp))

              Text("الأصناف المستخرجة:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              res.items.forEach { item ->
                Text("• ${item.quantity} ${item.unitType} - ${item.productName}", fontSize = 12.sp)
              }

              Spacer(modifier = Modifier.height(14.dp))

              // Apply Button
              Button(
                onClick = {
                  // Find matched products and customers/suppliers
                  if (res.type == "SALE") {
                    viewModel.clearSalesCart()
                    // Match customer
                    val matchedCust = customers.find { it.name.contains(res.partyName, ignoreCase = true) || res.partyName.contains(it.name, ignoreCase = true) }
                    matchedCust?.let { viewModel.selectCustomer(it) }
                    viewModel.setSalePaymentType(res.paymentType)

                    // Match items
                    res.items.forEach { itm ->
                      val matchedProd = products.find { it.name.contains(itm.productName, ignoreCase = true) || itm.productName.contains(it.name, ignoreCase = true) }
                        ?: products.firstOrNull()
                      matchedProd?.let { prod ->
                        viewModel.addToSalesCart(prod, unitType = itm.unitType, tier = PriceTier.WHOLESALE)
                        if (itm.quantity > 1) {
                          val idx = viewModel.salesCart.value.indexOfLast { it.product.id == prod.id }
                          if (idx >= 0) {
                            viewModel.updateCartItemQuantity(idx, itm.quantity)
                          }
                        }
                      }
                    }
                    onDismiss()
                    onNavigateToTab(1) // Navigate to Sales
                  } else {
                    viewModel.clearPurchaseCart()
                    val matchedSup = suppliers.find { it.name.contains(res.partyName, ignoreCase = true) || res.partyName.contains(it.name, ignoreCase = true) }
                    matchedSup?.let { viewModel.selectSupplier(it) }
                    viewModel.setPurchasePaymentType(res.paymentType)

                    res.items.forEach { itm ->
                      val matchedProd = products.find { it.name.contains(itm.productName, ignoreCase = true) || itm.productName.contains(it.name, ignoreCase = true) }
                        ?: products.firstOrNull()
                      matchedProd?.let { prod ->
                        viewModel.addToPurchaseCart(prod, itm.unitType, prod.cartonCostPrice)
                        if (itm.quantity > 1) {
                          val idx = viewModel.purchaseCart.value.indexOfLast { it.product.id == prod.id }
                          if (idx >= 0) {
                            viewModel.updatePurchaseItemQuantity(idx, itm.quantity)
                          }
                        }
                      }
                    }
                    onDismiss()
                    onNavigateToTab(2) // Navigate to Purchases
                  }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                shape = RoundedCornerShape(10.dp)
              ) {
                Icon(Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("اعتماد ونقل لشاشة " + if (res.type == "SALE") "المبيعات" else "المشتريات", fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }
}

// ----------------------------------------------------
// 2. Receipt OCR Scanner Dialog
// ----------------------------------------------------
@Composable
fun ReceiptOcrDialog(
  viewModel: WholesaleViewModel,
  products: List<Product>,
  suppliers: List<Supplier>,
  onDismiss: () -> Unit,
  onNavigateToPurchases: () -> Unit
) {
  var rawInvoiceText by remember { mutableStateOf("") }
  var isLoading by remember { mutableStateOf(false) }
  var parsedReceipt by remember { mutableStateOf<ParsedReceiptResult?>(null) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  val scope = rememberCoroutineScope()
  val focusManager = LocalFocusManager.current
  val keyboardController = LocalSoftwareKeyboardController.current
  val safeDismiss = {
    keyboardController?.hide()
    focusManager.clearFocus()
    onDismiss()
  }

  val sampleReceipts = listOf(
    "فاتورة شركة عافية للزيوت:\n3 كرتونة زيت ذرة عافية 800 مل بسعر 720 ج.م\nالمجموع: 2160 ج.م",
    "فاتورة شركة روجينا الغذائية:\n5 كرتونة مكرونة مشكل 400 جم بسعر 320 ج.م\n2 كرتونة تونة صن شاين بسعر 960 ج.م"
  )

  Dialog(
    onDismissRequest = safeDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .imePadding()
        .clip(RoundedCornerShape(20.dp)),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 8.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(40.dp)
                .background(OrangePrimary.copy(alpha = 0.15f), CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.DocumentScanner, contentDescription = null, tint = OrangePrimary)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text("قراءة فواتير المشتريات (OCR AI)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
              Text("مسح وتفريغ فواتير الموردين الورقية تلقائياً للمخزن", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
          IconButton(onClick = safeDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

        Text("أدخل نص الفاتورة أو اختر نموذج فاتورة مورد:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(6.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          sampleReceipts.forEachIndexed { idx, sample ->
            OutlinedButton(
              onClick = { rawInvoiceText = sample },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(8.dp),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 4.dp)
            ) {
              Text("نموذج توريد ${idx + 1}", fontSize = 11.sp)
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = rawInvoiceText,
          onValueChange = { rawInvoiceText = it },
          placeholder = { Text("اكتب أو الصق نص الفاتورة الورقية هنا...") },
          modifier = Modifier
            .fillMaxWidth()
            .height(110.dp),
          shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Button(
          onClick = {
            if (rawInvoiceText.isBlank()) return@Button
            isLoading = true
            errorMessage = null
            parsedReceipt = null
            scope.launch {
              val result = GeminiSupermarketService.parseTransactionCommand(
                commandText = "فاتورة مشتريات وتوريد بضاعة: $rawInvoiceText",
                availableProducts = products.map { it.name },
                availableCustomers = emptyList(),
                availableSuppliers = suppliers.map { it.name }
              )
              isLoading = false
              if (result != null) {
                parsedReceipt = ParsedReceiptResult(
                  supplierName = result.partyName,
                  invoiceNumber = "PUR-${System.currentTimeMillis() % 10000}",
                  totalAmount = 0.0,
                  items = result.items.map {
                    ReceiptExtractedItem(
                      name = it.productName,
                      quantity = it.quantity,
                      unit = it.unitType,
                      costPrice = it.unitPrice ?: 0.0,
                      total = 0.0
                    )
                  }
                )
              } else {
                errorMessage = "تعذر قراءة الفاتورة، يرجى مراجعة النص أو الاتصال بالإنترنت."
              }
            }
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
          enabled = rawInvoiceText.isNotBlank() && !isLoading
        ) {
          if (isLoading) {
            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
            Spacer(modifier = Modifier.width(8.dp))
            Text("جاري استخراج بيانات الفاتورة...")
          } else {
            Icon(Icons.Default.AutoAwesome, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("استخراج الأصناف والأسعار", fontWeight = FontWeight.Bold)
          }
        }

        if (errorMessage != null) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }

        parsedReceipt?.let { rec ->
          Spacer(modifier = Modifier.height(14.dp))
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(12.dp)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text("المورد المستخرج: ${rec.supplierName}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
              Spacer(modifier = Modifier.height(6.dp))
              Text("الأصناف التي تم استخراجها وتفريغها:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
              rec.items.forEach { itm ->
                Text("• ${itm.quantity} ${itm.unit} - ${itm.name}", fontSize = 12.sp)
              }

              Spacer(modifier = Modifier.height(12.dp))

              Button(
                onClick = {
                  viewModel.clearPurchaseCart()
                  val matchedSup = suppliers.find { it.name.contains(rec.supplierName, ignoreCase = true) || rec.supplierName.contains(it.name, ignoreCase = true) }
                  matchedSup?.let { viewModel.selectSupplier(it) }

                  rec.items.forEach { itm ->
                    val matchedProd = products.find { it.name.contains(itm.name, ignoreCase = true) || itm.name.contains(it.name, ignoreCase = true) }
                      ?: products.firstOrNull()
                    matchedProd?.let { prod ->
                      val cost = if (itm.costPrice > 0) itm.costPrice else prod.cartonCostPrice
                      viewModel.addToPurchaseCart(prod, itm.unit, cost)
                      if (itm.quantity > 1) {
                        val idx = viewModel.purchaseCart.value.indexOfLast { it.product.id == prod.id }
                        if (idx >= 0) {
                          viewModel.updatePurchaseItemQuantity(idx, itm.quantity)
                        }
                      }
                    }
                  }
                  onDismiss()
                  onNavigateToPurchases()
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
              ) {
                Icon(Icons.Default.ShoppingCart, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("ترحيل فوراً إلى فاتورة المشتريات", fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }
}

// ----------------------------------------------------
// 3. AI Business Advisor Dialog
// ----------------------------------------------------
@Composable
fun AiAdvisorDialog(
  metricsSummary: String,
  onDismiss: () -> Unit
) {
  var adviceText by remember { mutableStateOf<String?>(null) }
  var isLoading by remember { mutableStateOf(true) }
  val scope = rememberCoroutineScope()

  LaunchedEffect(Unit) {
    scope.launch {
      adviceText = GeminiSupermarketService.getBusinessInsights(metricsSummary)
      isLoading = false
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .clip(RoundedCornerShape(20.dp)),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 8.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(40.dp)
                .background(OrangePrimary.copy(alpha = 0.15f), CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = OrangePrimary)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text("مساعد مالكي السوبرماركت الذكي", fontWeight = FontWeight.Bold, fontSize = 16.sp)
              Text("تحليلات ونصائح استراتيجية لزيادة الأرباح", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

        if (isLoading) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            CircularProgressIndicator(color = OrangePrimary)
            Spacer(modifier = Modifier.height(14.dp))
            Text("جاري استشارة الذكاء الاصطناعي وتحليل أرقام السوبرماركت...", fontSize = 13.sp)
          }
        } else {
          LazyColumn(
            modifier = Modifier
              .weight(1f, fill = false)
              .fillMaxWidth()
          ) {
            item {
              Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp)
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Text(
                    text = adviceText ?: "",
                    fontSize = 14.sp,
                    lineHeight = 22.sp,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
          onClick = onDismiss,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary)
        ) {
          Text("شكراً، تم الاطلاع", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
