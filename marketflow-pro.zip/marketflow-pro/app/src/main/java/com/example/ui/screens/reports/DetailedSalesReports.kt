package com.example.ui.screens.reports

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Straighten
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.ReportPeriodSelectorBar
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.platform.LocalContext
import com.example.utils.ReportExportHelper
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItem
import com.example.data.model.InvoiceType
import com.example.data.model.PaymentType
import com.example.data.model.Product
import com.example.ui.ReportPeriod
import com.example.ui.WholesaleViewModel
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldPrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * تقارير المبيعات الاحترافية متعددة الأبعاد:
 * - حسب المنتج (By Product)
 * - حسب الوحدة (By Unit: كرتونة / قطعة)
 * - حسب العميل (By Customer)
 * - حسب اليوم والتاريخ (By Day / Date)
 * - حسب التصنيف والقسم (By Category)
 * - حسب الموظف والكاشير (By Employee / Cashier)
 */
data class SalesDimensionItem(
  val id: Int,
  val title: String,
  val subtitle: String,
  val icon: androidx.compose.ui.graphics.vector.ImageVector,
  val iconColor: Color
)

@Composable
fun DetailedSalesReportsView(
  viewModel: WholesaleViewModel,
  salesInvoices: List<Invoice>,
  invoiceItems: List<InvoiceItem>,
  products: List<Product>,
  customers: List<Customer>,
  period: ReportPeriod,
  currency: String
) {
  var selectedDimension by remember { mutableIntStateOf(0) }
  var searchQuery by remember { mutableStateOf("") }
  var sortOrder by remember { mutableIntStateOf(0) } // 0: الأعلى إيراداً, 1: الأكثر كمية, 2: الأعلى ربحاً
  var isDimensionListExpanded by remember { mutableStateOf(false) }

  // قراءة فلاتر التاريخ واليوم المخصص والمدة المحددة
  val selectedPeriod by viewModel.selectedReportPeriod.collectAsStateWithLifecycle()
  val customDayTimestamp by viewModel.customDayTimestamp.collectAsStateWithLifecycle()
  val customDateRange by viewModel.customDateRange.collectAsStateWithLifecycle()

  val (startTimestamp, endTimestamp) = remember(selectedPeriod, customDayTimestamp, customDateRange) {
    viewModel.getPeriodDateRange(selectedPeriod, customDayTimestamp, customDateRange)
  }

  // تصفية الفواتير بالفترة الزمنية المحددة بدقة متناهية (اليوم المخصص أو المدة المعينة)
  val filteredInvoices = remember(salesInvoices, startTimestamp, endTimestamp) {
    salesInvoices.filter { it.type == InvoiceType.SALE && it.timestamp in startTimestamp..endTimestamp }
  }

  val validInvoiceIds = remember(filteredInvoices) {
    filteredInvoices.map { it.id }.toSet()
  }

  // بنود الفواتير المصفاة
  val filteredItems = remember(invoiceItems, validInvoiceIds) {
    invoiceItems.filter { it.invoiceId in validInvoiceIds }
  }

  // مؤشرات الإجمالي والأرباح للفترة المحددة
  val totalSalesRevenue = remember(filteredInvoices) { filteredInvoices.sumOf { it.totalAmount } }
  val totalSalesCost = remember(filteredInvoices) { filteredInvoices.sumOf { it.totalCost } }
  val totalSalesProfit = remember(filteredInvoices) { filteredInvoices.sumOf { it.totalProfit } }
  val totalInvoiceCount = filteredInvoices.size
  val averageTicket = if (totalInvoiceCount > 0) totalSalesRevenue / totalInvoiceCount else 0.0
  val profitMarginPercent = if (totalSalesRevenue > 0) (totalSalesProfit / totalSalesRevenue) * 100.0 else 0.0
  val cashSalesTotal = remember(filteredInvoices) { filteredInvoices.filter { it.paymentType == PaymentType.CASH }.sumOf { it.totalAmount } }
  val creditSalesTotal = remember(filteredInvoices) { filteredInvoices.filter { it.paymentType == PaymentType.CREDIT }.sumOf { it.totalAmount } }

  val dimensions = remember {
    listOf(
      SalesDimensionItem(0, "🏷️ حسب المنتج والأصناف", "تفصيل كميات المبيعات والأرباح والتكلفة لكل صنف", Icons.Default.ShoppingBag, EmeraldPrimary),
      SalesDimensionItem(1, "📦 حسب نوع الوحدة (كرتونة / قطعة)", "مبيعات الكراتين مقابل القطع الفردية وهامش ربحها", Icons.Default.Straighten, Color(0xFF2563EB)),
      SalesDimensionItem(2, "👥 حسب العميل", "أعلى العملاء شراءً وربحية وحجم فواتيرهم ومتبقياتهم", Icons.Default.Person, Color(0xFF7C3AED)),
      SalesDimensionItem(3, "📅 حسب اليوم والتاريخ", "حركة المبيعات والأرباح يوماً بيوم وتوزيع المبيعات", Icons.Default.CalendarToday, Color(0xFFD97706)),
      SalesDimensionItem(4, "🗂️ حسب التصنيف والقسم", "تحليل مبيعات الأقسام والمنتجات الأكثر مساهمة", Icons.Default.Category, Color(0xFF059669)),
      SalesDimensionItem(5, "👤 حسب الموظف والكاشير", "إنتاجية الموظفين والبائعين وقيمة مبيعاتهم", Icons.Default.Receipt, Color(0xFF4338CA)),
      SalesDimensionItem(6, "🧾 حسب الفاتورة", "كشف تفصيلي بفواتير المبيعات وهوامش ربحها ونوع السداد", Icons.Default.Description, Color(0xFFE11D48))
    )
  }

  val context = LocalContext.current
  val businessProfile by viewModel.businessProfile.collectAsStateWithLifecycle()
  val topProducts by viewModel.topSellingProducts.collectAsStateWithLifecycle()
  val expensesByCategory by viewModel.expensesByCategory.collectAsStateWithLifecycle()
  val profitReport by viewModel.profitReport.collectAsStateWithLifecycle()

  Column(modifier = Modifier.fillMaxSize()) {
    // 1. شريط فلترة الفترة واليوم المخصص والمدة المحددة
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 4.dp),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
      Column(modifier = Modifier.padding(10.dp)) {
        ReportPeriodSelectorBar(
          viewModel = viewModel,
          showLabel = true
        )
      }
    }

    // 2. بطاقة إحصائيات المبيعات والأرباح العلوية
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 4.dp),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // المبيعات
          Column(modifier = Modifier.weight(1f)) {
            Text("إجمالي المبيعات", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
              text = String.format(Locale.ENGLISH, "%.2f %s", totalSalesRevenue, currency),
              fontWeight = FontWeight.ExtraBold,
              fontSize = 15.sp,
              color = MaterialTheme.colorScheme.primary
            )
            Text(
              text = "$totalInvoiceCount فاتورة بيع",
              fontSize = 10.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          Box(
            modifier = Modifier
              .height(38.dp)
              .width(1.dp)
              .background(MaterialTheme.colorScheme.outlineVariant)
          )

          // أرباح المبيعات (Gross Profit)
          Column(modifier = Modifier.weight(1.2f).padding(horizontal = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.AttachMoney, contentDescription = null, modifier = Modifier.size(13.dp), tint = EmeraldPrimary)
              Text("أرباح المبيعات", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
            }
            Text(
              text = String.format(Locale.ENGLISH, "%.2f %s", totalSalesProfit, currency),
              fontWeight = FontWeight.ExtraBold,
              fontSize = 16.sp,
              color = EmeraldPrimary
            )
            Surface(
              shape = RoundedCornerShape(4.dp),
              color = EmeraldPrimary.copy(alpha = 0.15f)
            ) {
              Text(
                text = String.format(Locale.ENGLISH, " هامش الربح: %.1f%% ", profitMarginPercent),
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldPrimary,
                modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
              )
            }
          }

          Box(
            modifier = Modifier
              .height(38.dp)
              .width(1.dp)
              .background(MaterialTheme.colorScheme.outlineVariant)
          )

          // التكلفة ومتوسط الفاتورة
          Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
            Text("تكلفة البضاعة", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
              text = String.format(Locale.ENGLISH, "%.1f %s", totalSalesCost, currency),
              fontWeight = FontWeight.Bold,
              fontSize = 12.5.sp,
              color = Color(0xFFDC2626)
            )
            Text(
              text = String.format(Locale.ENGLISH, "متوسط: %.0f %s", averageTicket, currency),
              fontSize = 9.5.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }

    // شريط أزرار الطباعة والتصدير الشامل (Print, PDF, Image, Share)
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 2.dp),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedButton(
          onClick = {
            ReportExportHelper.printReportViaSystem(
              context = context,
              report = profitReport,
              period = selectedPeriod,
              businessName = businessProfile.businessName,
              phone = businessProfile.contactPhone,
              address = businessProfile.address,
              topProducts = topProducts,
              expensesByCategory = expensesByCategory,
              customTitle = "تقرير المبيعات - ${dimensions[selectedDimension].title}"
            )
          },
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(4.dp))
          Text("طباعة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Button(
          onClick = {
            val pdfFile = ReportExportHelper.generateFinancialReportPdf(
              context = context,
              report = profitReport,
              period = selectedPeriod,
              businessName = businessProfile.businessName,
              phone = businessProfile.contactPhone,
              address = businessProfile.address,
              topProducts = topProducts,
              expensesByCategory = expensesByCategory,
              customTitle = "تقرير المبيعات - ${dimensions[selectedDimension].title}"
            )
            ReportExportHelper.shareFile(
              context = context,
              file = pdfFile,
              mimeType = "application/pdf",
              title = "مشاركة تقرير المبيعات PDF"
            )
          },
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Button(
          onClick = {
            val imgFile = ReportExportHelper.generateFinancialReportImage(
              context = context,
              report = profitReport,
              period = selectedPeriod,
              businessName = businessProfile.businessName,
              topProducts = topProducts,
              customTitle = "تقرير المبيعات - ${dimensions[selectedDimension].title}"
            )
            ReportExportHelper.shareFile(
              context = context,
              file = imgFile,
              mimeType = "image/png",
              title = "مشاركة صورة تقرير المبيعات"
            )
          },
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("صورة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        IconButton(
          onClick = {
            val dateStr = SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH).format(Date())
            val txt = "📊 تقرير المبيعات (${businessProfile.businessName})\nالفترة: ${selectedPeriod.label} ($dateStr)\n• إجمالي المبيعات: ${String.format(Locale.ENGLISH, "%.2f", totalSalesRevenue)} $currency (${totalInvoiceCount} فاتورة)\n• تكلفة البضاعة: ${String.format(Locale.ENGLISH, "%.2f", totalSalesCost)} $currency\n• أرباح المبيعات: ${String.format(Locale.ENGLISH, "%.2f", totalSalesProfit)} $currency\n• هامش الربح: ${String.format(Locale.ENGLISH, "%.1f%%", profitMarginPercent)}"
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Sales Report", txt))
            Toast.makeText(context, "تم نسخ ملخص المبيعات للحافظة ✓", Toast.LENGTH_SHORT).show()
          },
          modifier = Modifier.size(32.dp)
        ) {
          Icon(Icons.Default.ContentCopy, contentDescription = "نسخ", modifier = Modifier.size(16.dp))
        }
      }
    }

    // 3. قائمة تصنيفات وأبعاد التقرير أسفل ملخص الأرباح والفترة
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 4.dp),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
      Column(modifier = Modifier.padding(10.dp)) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { isDimensionListExpanded = !isDimensionListExpanded }
            .padding(vertical = 2.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = dimensions[selectedDimension].iconColor.copy(alpha = 0.15f),
              modifier = Modifier.size(32.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  dimensions[selectedDimension].icon,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp),
                  tint = dimensions[selectedDimension].iconColor
                )
              }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text("عرض تقرير المبيعات حسب:", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = dimensions[selectedDimension].title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
            modifier = Modifier.clickable { isDimensionListExpanded = !isDimensionListExpanded }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = if (isDimensionListExpanded) "إغلاق القائمة ▲" else "تغيير التصنيف (${dimensions.size}) ▼",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
            }
          }
        }

        AnimatedVisibility(visible = isDimensionListExpanded) {
          Column(
            modifier = Modifier.padding(top = 10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            HorizontalDivider(modifier = Modifier.padding(bottom = 4.dp))
            dimensions.forEachIndexed { idx, dim ->
              val isSelected = selectedDimension == idx
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                border = if (isSelected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable {
                    selectedDimension = idx
                    searchQuery = ""
                    isDimensionListExpanded = false
                  }
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Surface(
                      shape = RoundedCornerShape(6.dp),
                      color = dim.iconColor.copy(alpha = 0.15f),
                      modifier = Modifier.size(28.dp)
                    ) {
                      Box(contentAlignment = Alignment.Center) {
                        Icon(dim.icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = dim.iconColor)
                      }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                      Text(
                        text = dim.title,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                      )
                      Text(
                        text = dim.subtitle,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                    }
                  }

                  if (isSelected) {
                    Icon(
                      Icons.Default.CheckCircle,
                      contentDescription = null,
                      modifier = Modifier.size(18.dp),
                      tint = MaterialTheme.colorScheme.primary
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    // 4. شريط البحث والترتيب السريع
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("بحث في نتائج التقرير...", fontSize = 12.sp) },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(Icons.Default.Clear, contentDescription = "مسح", modifier = Modifier.size(16.dp))
            }
          }
        },
        singleLine = true,
        modifier = Modifier.weight(1f).height(46.dp),
        shape = RoundedCornerShape(10.dp)
      )

      // خيارات الترتيب السريع
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.clickable {
          sortOrder = (sortOrder + 1) % 3
        }
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = when (sortOrder) {
              0 -> "الأعلى إيراداً ⬇"
              1 -> "الأكثر كمية ⬇"
              else -> "الأعلى ربحاً ⬇"
            },
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
        }
      }
    }

    // 4. محتوى التقرير حسب البعد المختار
    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
      when (selectedDimension) {
        0 -> SalesByProductSubReport(
          items = filteredItems,
          products = products,
          totalRevenue = totalSalesRevenue,
          searchQuery = searchQuery,
          sortOrder = sortOrder,
          currency = currency
        )
        1 -> SalesByUnitSubReport(
          items = filteredItems,
          totalRevenue = totalSalesRevenue,
          currency = currency
        )
        2 -> SalesByCustomerSubReport(
          invoices = filteredInvoices,
          customers = customers,
          totalRevenue = totalSalesRevenue,
          searchQuery = searchQuery,
          sortOrder = sortOrder,
          currency = currency
        )
        3 -> SalesByDaySubReport(
          invoices = filteredInvoices,
          searchQuery = searchQuery,
          currency = currency
        )
        4 -> SalesByCategorySubReport(
          items = filteredItems,
          products = products,
          totalRevenue = totalSalesRevenue,
          searchQuery = searchQuery,
          sortOrder = sortOrder,
          currency = currency
        )
        5 -> SalesByEmployeeSubReport(
          invoices = filteredInvoices,
          totalRevenue = totalSalesRevenue,
          searchQuery = searchQuery,
          currency = currency
        )
        6 -> SalesByInvoiceSubReport(
          invoices = filteredInvoices,
          searchQuery = searchQuery,
          sortOrder = sortOrder,
          currency = currency
        )
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 1. تقرير المبيعات حسب المنتج (Sales by Product)
// -----------------------------------------------------------------------------
data class ProductSalesRow(
  val productId: Long,
  val productName: String,
  val category: String,
  val cartonQuantity: Int,
  val pieceQuantity: Int,
  val totalPiecesSold: Int,
  val revenue: Double,
  val cost: Double,
  val profit: Double,
  val marginPercent: Double,
  val sharePercent: Double
)

@Composable
fun SalesByProductSubReport(
  items: List<InvoiceItem>,
  products: List<Product>,
  totalRevenue: Double,
  searchQuery: String,
  sortOrder: Int,
  currency: String
) {
  val prodMap = remember(products) { products.associateBy { it.id } }

  val rows = remember(items, prodMap, totalRevenue, searchQuery, sortOrder) {
    val grouped = items.groupBy { it.productId }
    val list = grouped.map { (pId, pItems) ->
      val prod = prodMap[pId]
      val name = prod?.name ?: pItems.firstOrNull()?.productName ?: "صنف"
      val cat = prod?.category ?: "عام"
      val cartons = pItems.filter { it.unitType == "كرتونة" }.sumOf { it.quantity }
      val pieces = pItems.filter { it.unitType != "كرتونة" }.sumOf { it.quantity }
      val totalPieces = pItems.sumOf { it.totalPieces }
      val rev = pItems.sumOf { it.totalPrice }
      val cost = pItems.sumOf { it.totalCost }
      val profit = pItems.sumOf { it.itemProfit }
      val margin = if (rev > 0) (profit / rev) * 100.0 else 0.0
      val share = if (totalRevenue > 0) (rev / totalRevenue) * 100.0 else 0.0

      ProductSalesRow(
        productId = pId,
        productName = name,
        category = cat,
        cartonQuantity = cartons,
        pieceQuantity = pieces,
        totalPiecesSold = totalPieces,
        revenue = rev,
        cost = cost,
        profit = profit,
        marginPercent = margin,
        sharePercent = share
      )
    }

    val filtered = if (searchQuery.isBlank()) list else list.filter {
      it.productName.contains(searchQuery, ignoreCase = true) ||
          it.category.contains(searchQuery, ignoreCase = true)
    }

    when (sortOrder) {
      0 -> filtered.sortedByDescending { it.revenue }
      1 -> filtered.sortedByDescending { it.totalPiecesSold }
      else -> filtered.sortedByDescending { it.profit }
    }
  }

  if (rows.isEmpty()) {
    EmptyReportView(message = "لا توجد مبيعات أصناف مسجلة في هذه الفترة")
  } else {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      item {
        Text(
          text = "إجمالي الأصناف المباعة: ${rows.size} صنف",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      items(rows, key = { it.productId }) { row ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(row.productName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                  text = "${row.category} • إجمالي القطع: ${row.totalPiecesSold}",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
              ) {
                Text(
                  text = String.format(Locale.ENGLISH, "حصة %.1f%%", row.sharePercent),
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // توزيع الوحدات: كراتين وقطع
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              if (row.cartonQuantity > 0) {
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                  Text(
                    text = "📦 كراتين: ${row.cartonQuantity}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                  )
                }
              }
              if (row.pieceQuantity > 0) {
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                  Text(
                    text = "🔘 قطع فردية: ${row.pieceQuantity}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(8.dp))

            // الإيراد والتكلفة والربح
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("إجمالي الإيراد", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f %s", row.revenue, currency),
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = MaterialTheme.colorScheme.primary
                )
              }
              Column {
                Text("التكلفة (COGS)", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f %s", row.cost, currency),
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 12.sp
                )
              }
              Column(horizontalAlignment = Alignment.End) {
                Text("صافي الربح", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "+%.2f %s (%.1f%%)", row.profit, currency, row.marginPercent),
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = EmeraldPrimary
                )
              }
            }
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 2. تقرير المبيعات حسب الوحدة (Sales by Unit: كرتونة vs قطعة)
// -----------------------------------------------------------------------------
@Composable
fun SalesByUnitSubReport(
  items: List<InvoiceItem>,
  totalRevenue: Double,
  currency: String
) {
  val cartonItems = remember(items) { items.filter { it.unitType == "كرتونة" } }
  val pieceItems = remember(items) { items.filter { it.unitType != "كرتونة" } }

  val cartonQuantity = remember(cartonItems) { cartonItems.sumOf { it.quantity } }
  val cartonRevenue = remember(cartonItems) { cartonItems.sumOf { it.totalPrice } }
  val cartonProfit = remember(cartonItems) { cartonItems.sumOf { it.itemProfit } }

  val pieceQuantity = remember(pieceItems) { pieceItems.sumOf { it.quantity } }
  val pieceRevenue = remember(pieceItems) { pieceItems.sumOf { it.totalPrice } }
  val pieceProfit = remember(pieceItems) { pieceItems.sumOf { it.itemProfit } }

  val totalCombined = cartonRevenue + pieceRevenue
  val cartonPct = if (totalCombined > 0) (cartonRevenue / totalCombined).toFloat() else 0f
  val piecePct = if (totalCombined > 0) (pieceRevenue / totalCombined).toFloat() else 0f

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(14.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Text(
        text = "مقارنة أداء مبيعات الكراتين (جملة) مقابل القطع (تجزئة)",
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp
      )
      Text(
        text = "يوضح حجم الإيراد والكمية والأرباح المحققة من كل وحدة بيع",
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    // شريط التوزيع المرئي بين الكرتونة والقطعة
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "📦 مبيعات الكراتين: " + String.format(Locale.ENGLISH, "%.1f%%", cartonPct * 100),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = EmeraldPrimary
            )
            Text(
              text = "🔘 مبيعات القطع: " + String.format(Locale.ENGLISH, "%.1f%%", piecePct * 100),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          LinearProgressIndicator(
            progress = { cartonPct },
            modifier = Modifier
              .fillMaxWidth()
              .height(10.dp),
            color = EmeraldPrimary,
            trackColor = MaterialTheme.colorScheme.primary
          )
        }
      }
    }

    // بطاقة تفصيل مبيعات الكراتين
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = EmeraldPrimary.copy(alpha = 0.08f)),
        border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.3f))
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .background(EmeraldPrimary.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Inventory2, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("مبيعات الكراتين (كرتونة)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("المعاملات بوحدة الجملة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            Surface(shape = RoundedCornerShape(6.dp), color = EmeraldPrimary) {
              Text(
                text = "$cartonQuantity كرتونة",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text("إجمالي الإيراد المحقق", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = String.format(Locale.ENGLISH, "%.2f %s", cartonRevenue, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp,
                color = EmeraldPrimary
              )
            }
            Column(horizontalAlignment = Alignment.End) {
              Text("صافي الأرباح", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = String.format(Locale.ENGLISH, "+%.2f %s", cartonProfit, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp,
                color = EmeraldPrimary
              )
            }
          }
        }
      }
    }

    // بطاقة تفصيل مبيعات القطع الفردية
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Straighten, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("مبيعات القطع الفردية (قطعة / علبة)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("المعاملات بوحدة التجزئة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.primary) {
              Text(
                text = "$pieceQuantity قطعة",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text("إجمالي الإيراد المحقق", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = String.format(Locale.ENGLISH, "%.2f %s", pieceRevenue, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary
              )
            }
            Column(horizontalAlignment = Alignment.End) {
              Text("صافي الأرباح", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = String.format(Locale.ENGLISH, "+%.2f %s", pieceProfit, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary
              )
            }
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 3. تقرير المبيعات حسب العميل (Sales by Customer)
// -----------------------------------------------------------------------------
data class CustomerSalesRow(
  val customerId: Long,
  val customerName: String,
  val phone: String,
  val invoiceCount: Int,
  val totalSales: Double,
  val totalPaid: Double,
  val totalRemaining: Double,
  val totalProfit: Double,
  val currentBalance: Double
)

@Composable
fun SalesByCustomerSubReport(
  invoices: List<Invoice>,
  customers: List<Customer>,
  totalRevenue: Double,
  searchQuery: String,
  sortOrder: Int,
  currency: String
) {
  val customerMap = remember(customers) { customers.associateBy { it.id } }

  val rows = remember(invoices, customerMap, searchQuery, sortOrder) {
    val grouped = invoices.groupBy { it.partyId }
    val list = grouped.map { (cId, cInvoices) ->
      val cust = customerMap[cId]
      val name = if (cId == 0L) "عميل نقدي (كاش عام)" else (cust?.name ?: cInvoices.firstOrNull()?.partyName ?: "عميل")
      val phone = cust?.phone ?: ""
      val count = cInvoices.size
      val total = cInvoices.sumOf { it.totalAmount }
      val paid = cInvoices.sumOf { it.paidAmount }
      val rem = cInvoices.sumOf { it.remainingAmount }
      val profit = cInvoices.sumOf { it.totalProfit }
      val balance = cust?.currentBalance ?: 0.0

      CustomerSalesRow(
        customerId = cId,
        customerName = name,
        phone = phone,
        invoiceCount = count,
        totalSales = total,
        totalPaid = paid,
        totalRemaining = rem,
        totalProfit = profit,
        currentBalance = balance
      )
    }

    val filtered = if (searchQuery.isBlank()) list else list.filter {
      it.customerName.contains(searchQuery, ignoreCase = true) ||
          it.phone.contains(searchQuery)
    }

    when (sortOrder) {
      0 -> filtered.sortedByDescending { it.totalSales }
      1 -> filtered.sortedByDescending { it.invoiceCount }
      else -> filtered.sortedByDescending { it.totalProfit }
    }
  }

  if (rows.isEmpty()) {
    EmptyReportView(message = "لا توجد مبيعات عملاء مسجلة في هذه الفترة")
  } else {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      item {
        Text(
          text = "إجمالي العملاء المتعاملين: ${rows.size} عميل",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      items(rows, key = { it.customerId }) { row ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(34.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(row.customerName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                  if (row.phone.isNotEmpty()) {
                    Text(row.phone, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
              }

              Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
              ) {
                Text(
                  text = "${row.invoiceCount} فاتورة",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text("إجمالي المسحوبات", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f %s", row.totalSales, currency),
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = MaterialTheme.colorScheme.primary
                )
              }
              Column {
                Text("المسدد كاش", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f %s", row.totalPaid, currency),
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 12.sp,
                  color = EmeraldPrimary
                )
              }
              Column(horizontalAlignment = Alignment.End) {
                Text("الربح من العميل", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "+%.2f %s", row.totalProfit, currency),
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = EmeraldPrimary
                )
              }
            }

            if (row.currentBalance > 0) {
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "⚠️ رصيد سابق متبقي على العميل: ${String.format(Locale.ENGLISH, "%.2f %s", row.currentBalance, currency)}",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.error
              )
            }
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 4. تقرير المبيعات حسب اليوم والتاريخ (Sales by Day / Date)
// -----------------------------------------------------------------------------
data class DaySalesRow(
  val dateString: String,
  val dayName: String,
  val invoiceCount: Int,
  val totalSales: Double,
  val totalProfit: Double,
  val cashAmount: Double,
  val creditAmount: Double,
  val averageInvoice: Double
)

@Composable
fun SalesByDaySubReport(
  invoices: List<Invoice>,
  searchQuery: String,
  currency: String
) {
  val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH) }
  val dayNameFormat = remember { SimpleDateFormat("EEEE", Locale("ar")) }

  val rows = remember(invoices, searchQuery) {
    val grouped = invoices.groupBy { dateFormat.format(Date(it.timestamp)) }
    val list = grouped.map { (dateStr, dayInvoices) ->
      val firstTs = dayInvoices.firstOrNull()?.timestamp ?: 0L
      val dayName = dayNameFormat.format(Date(firstTs))
      val count = dayInvoices.size
      val total = dayInvoices.sumOf { it.totalAmount }
      val profit = dayInvoices.sumOf { it.totalProfit }
      val cash = dayInvoices.sumOf { it.paidAmount }
      val credit = dayInvoices.sumOf { it.remainingAmount }
      val avg = if (count > 0) total / count else 0.0

      DaySalesRow(
        dateString = dateStr,
        dayName = dayName,
        invoiceCount = count,
        totalSales = total,
        totalProfit = profit,
        cashAmount = cash,
        creditAmount = credit,
        averageInvoice = avg
      )
    }.sortedByDescending { it.dateString }

    if (searchQuery.isBlank()) list else list.filter {
      it.dateString.contains(searchQuery) || it.dayName.contains(searchQuery)
    }
  }

  if (rows.isEmpty()) {
    EmptyReportView(message = "لا توجد مبيعات في هذه الفترة")
  } else {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(rows, key = { it.dateString }) { row ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(34.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.CalendarToday, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text("${row.dayName} (${row.dateString})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                  Text("${row.invoiceCount} فاتورة محررة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }

              Column(horizontalAlignment = Alignment.End) {
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f %s", row.totalSales, currency),
                  fontWeight = FontWeight.ExtraBold,
                  fontSize = 14.sp,
                  color = MaterialTheme.colorScheme.primary
                )
                Text(
                  text = String.format(Locale.ENGLISH, "ربح: +%.2f %s", row.totalProfit, currency),
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  color = EmeraldPrimary
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(6.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("المدفوع نقداً: ${String.format(Locale.ENGLISH, "%.1f", row.cashAmount)}", fontSize = 10.sp, color = EmeraldPrimary, fontWeight = FontWeight.SemiBold)
              Text("المتبقي آجل: ${String.format(Locale.ENGLISH, "%.1f", row.creditAmount)}", fontSize = 10.sp, color = if (row.creditAmount > 0) MaterialTheme.colorScheme.error else Color.Gray)
              Text("متوسط الفاتورة: ${String.format(Locale.ENGLISH, "%.1f", row.averageInvoice)}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 5. تقرير المبيعات حسب التصنيف / القسم (Sales by Category)
// -----------------------------------------------------------------------------
data class CategorySalesRow(
  val categoryName: String,
  val productCount: Int,
  val piecesSold: Int,
  val revenue: Double,
  val profit: Double,
  val sharePercent: Double
)

@Composable
fun SalesByCategorySubReport(
  items: List<InvoiceItem>,
  products: List<Product>,
  totalRevenue: Double,
  searchQuery: String,
  sortOrder: Int,
  currency: String
) {
  val prodMap = remember(products) { products.associateBy { it.id } }

  val rows = remember(items, prodMap, totalRevenue, searchQuery, sortOrder) {
    val grouped = items.groupBy { item ->
      prodMap[item.productId]?.category ?: "عام"
    }

    val list = grouped.map { (cat, catItems) ->
      val prodCount = catItems.map { it.productId }.distinct().size
      val pieces = catItems.sumOf { it.totalPieces }
      val rev = catItems.sumOf { it.totalPrice }
      val profit = catItems.sumOf { it.itemProfit }
      val share = if (totalRevenue > 0) (rev / totalRevenue) * 100.0 else 0.0

      CategorySalesRow(
        categoryName = cat,
        productCount = prodCount,
        piecesSold = pieces,
        revenue = rev,
        profit = profit,
        sharePercent = share
      )
    }

    val filtered = if (searchQuery.isBlank()) list else list.filter {
      it.categoryName.contains(searchQuery, ignoreCase = true)
    }

    when (sortOrder) {
      0 -> filtered.sortedByDescending { it.revenue }
      1 -> filtered.sortedByDescending { it.piecesSold }
      else -> filtered.sortedByDescending { it.profit }
    }
  }

  if (rows.isEmpty()) {
    EmptyReportView(message = "لا توجد مبيعات أقسام في هذه الفترة")
  } else {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(rows, key = { it.categoryName }) { row ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(34.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.Category, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(row.categoryName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                  Text("${row.productCount} صنف • ${row.piecesSold} قطعة مباعة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }

              Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
              ) {
                Text(
                  text = String.format(Locale.ENGLISH, "حصة %.1f%%", row.sharePercent),
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
              progress = { (row.sharePercent / 100f).toFloat().coerceIn(0f, 1f) },
              modifier = Modifier.fillMaxWidth().height(6.dp),
              color = MaterialTheme.colorScheme.primary,
              trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text("إجمالي الإيراد", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f %s", row.revenue, currency),
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = MaterialTheme.colorScheme.primary
                )
              }
              Column(horizontalAlignment = Alignment.End) {
                Text("أرباح القسم", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "+%.2f %s", row.profit, currency),
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = EmeraldPrimary
                )
              }
            }
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 6. تقرير المبيعات حسب الموظف / الكاشير (Sales by Employee / Cashier)
// -----------------------------------------------------------------------------
data class EmployeeSalesRow(
  val employeeName: String,
  val invoiceCount: Int,
  val totalSales: Double,
  val cashCollected: Double,
  val creditIssued: Double,
  val profit: Double
)

@Composable
fun SalesByEmployeeSubReport(
  invoices: List<Invoice>,
  totalRevenue: Double,
  searchQuery: String,
  currency: String
) {
  val rows = remember(invoices, searchQuery) {
    // تجميع الفواتير حسب اسم الكاشير أو الموظف (المسجل في الملاحظات أو الكاشير الافتراضي)
    val grouped = invoices.groupBy { inv ->
      val staffLine = inv.notes.lines().find { it.contains("موظف") || it.contains("كاشير") }
      staffLine ?: "كاشير 1 (الوردية الرئيسية)"
    }

    val list = grouped.map { (staff, staffInvoices) ->
      val count = staffInvoices.size
      val total = staffInvoices.sumOf { it.totalAmount }
      val cash = staffInvoices.sumOf { it.paidAmount }
      val credit = staffInvoices.sumOf { it.remainingAmount }
      val profit = staffInvoices.sumOf { it.totalProfit }

      EmployeeSalesRow(
        employeeName = staff,
        invoiceCount = count,
        totalSales = total,
        cashCollected = cash,
        creditIssued = credit,
        profit = profit
      )
    }.sortedByDescending { it.totalSales }

    if (searchQuery.isBlank()) list else list.filter {
      it.employeeName.contains(searchQuery, ignoreCase = true)
    }
  }

  if (rows.isEmpty()) {
    EmptyReportView(message = "لا توجد مبيعات موظفين مسجلة في هذه الفترة")
  } else {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(rows, key = { it.employeeName }) { row ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(34.dp)
                    .background(EmeraldPrimary.copy(alpha = 0.12f), CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.Person, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(row.employeeName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                  Text("${row.invoiceCount} فاتورة بيع صادرة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }

              Text(
                text = String.format(Locale.ENGLISH, "%.2f %s", row.totalSales, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.primary
              )
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(6.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text("المحصل نقداً في الدرج", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f %s", row.cashCollected, currency),
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp,
                  color = EmeraldPrimary
                )
              }
              Column {
                Text("الآجل المقيد", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "%.2f %s", row.creditIssued, currency),
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 12.sp,
                  color = if (row.creditIssued > 0) MaterialTheme.colorScheme.error else Color.Gray
                )
              }
              Column(horizontalAlignment = Alignment.End) {
                Text("الأرباح المحققة", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = String.format(Locale.ENGLISH, "+%.2f %s", row.profit, currency),
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp,
                  color = EmeraldPrimary
                )
              }
            }
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// عنصر عرض حالة عدم وجود نتائج (Empty State)
// -----------------------------------------------------------------------------
@Composable
fun EmptyReportView(message: String) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .padding(32.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Icon(
        Icons.Default.Receipt,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
        modifier = Modifier.size(48.dp)
      )
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = message,
        fontSize = 13.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontWeight = FontWeight.Medium
      )
    }
  }
}

// -----------------------------------------------------------------------------
// 7. تقرير المبيعات حسب الفاتورة (Sales by Invoice)
// -----------------------------------------------------------------------------
@Composable
fun SalesByInvoiceSubReport(
  invoices: List<Invoice>,
  searchQuery: String,
  sortOrder: Int,
  currency: String
) {
  val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.ENGLISH) }

  val filteredInvoices = remember(invoices, searchQuery, sortOrder) {
    invoices.filter {
      searchQuery.isBlank() || it.invoiceNumber.contains(searchQuery) || it.partyName.contains(searchQuery, ignoreCase = true)
    }.let { list ->
      when (sortOrder) {
        0 -> list.sortedByDescending { it.totalAmount }
        1 -> list.sortedByDescending { it.totalProfit }
        else -> list.sortedByDescending { if (it.totalAmount > 0) (it.totalProfit / it.totalAmount) * 100.0 else 0.0 }
      }
    }
  }

  if (filteredInvoices.isEmpty()) {
    EmptyReportView("لا توجد فواتير مبيعات مطابقة في هذه الفترة")
    return
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(14.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    items(filteredInvoices, key = { it.id }) { inv ->
      val margin = if (inv.totalAmount > 0) (inv.totalProfit / inv.totalAmount) * 100.0 else 0.0
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "فاتورة #${inv.invoiceNumber}",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = if (inv.paymentType == PaymentType.CASH) EmeraldPrimary.copy(alpha = 0.15f) else AmberPrimary.copy(alpha = 0.15f)
                ) {
                  Text(
                    text = if (inv.paymentType == PaymentType.CASH) "نقدي" else "آجل",
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (inv.paymentType == PaymentType.CASH) EmeraldPrimary else AmberPrimary,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                  )
                }
              }
              Text(
                text = "${inv.partyName} • ${dateFormat.format(Date(inv.timestamp))}",
                fontSize = 10.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = String.format(Locale.ENGLISH, "%.2f %s", inv.totalAmount, currency),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                text = String.format(Locale.ENGLISH, "ربح: %+.1f (%.1f%%)", inv.totalProfit, margin),
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                color = if (inv.totalProfit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))
          HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("المدفوع: ${String.format(Locale.ENGLISH, "%.2f", inv.paidAmount)}", fontSize = 10.5.sp, color = EmeraldPrimary)
            if (inv.remainingAmount > 0) {
              Text("المتبقي آجل: ${String.format(Locale.ENGLISH, "%.2f", inv.remainingAmount)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.error)
            }
            Text("التكلفة: ${String.format(Locale.ENGLISH, "%.2f", inv.totalCost)}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }
  }
}
