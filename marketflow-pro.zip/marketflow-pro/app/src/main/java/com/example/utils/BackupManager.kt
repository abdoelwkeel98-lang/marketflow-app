package com.example.utils

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import com.example.data.dao.AppDao
import com.example.data.model.Account
import com.example.data.model.Customer
import com.example.data.model.Expense
import com.example.data.model.Invoice
import com.example.data.model.InvoiceItem
import com.example.data.model.InvoiceType
import com.example.data.model.JournalEntry
import com.example.data.model.JournalLine
import com.example.data.model.PaymentTransaction
import com.example.data.model.PaymentType
import com.example.data.model.Product
import com.example.data.model.StockAudit
import com.example.data.model.StockAuditItem
import com.example.data.model.Supplier
import com.example.data.model.TransactionType
import com.example.data.settings.BusinessProfile
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

/**
 * مدير النسخ الاحتياطي الذكي لنظام سند للمحاسبة
 * - نسخ احتياطي تلقائي يومي
 * - حفظ في ذاكرة الهاتف في مجلد يحدده المستخدم أو مجلد النظام الافتراضي
 * - استبدال النسخة القديمة بالنسخة الحديثة لتبقى دائماً نسخة واحدة فقط على الهاتف
 * - استعادة بنقرة واحدة من القائمة المنبثقة دون الحاجة للتصفح اليدوي في الملفات
 */
object BackupManager {

  const val BACKUP_FILE_NAME = "SANAD_ERP_LATEST_BACKUP.sanad"

  data class BackupSummary(
    val timestamp: Long,
    val dateFormatted: String,
    val fileSizeBytes: Long,
    val fileSizeFormatted: String,
    val folderPath: String,
    val productsCount: Int,
    val customersCount: Int,
    val suppliersCount: Int,
    val invoicesCount: Int,
    val transactionsCount: Int,
    val expensesCount: Int,
    val journalEntriesCount: Int,
    val accountsCount: Int,
    val rawJson: String
  )

  data class BackupSaveResult(
    val success: Boolean,
    val filePathOrUri: String,
    val dateFormatted: String,
    val fileSizeFormatted: String,
    val summaryText: String,
    val errorMessage: String? = null
  )

  /**
   * إنشاء نص النسخة الاحتياطية المجمعة من قاعدة البيانات بالكامل
   */
  suspend fun createBackupPayload(dao: AppDao, profile: BusinessProfile): String {
    val now = System.currentTimeMillis()
    val dateStr = SimpleDateFormat("dd/MM/yyyy - hh:mm a", Locale("ar")).format(Date(now))

    val products = dao.getAllProductsSync()
    val customers = dao.getAllCustomersSync()
    val suppliers = dao.getAllSuppliersSync()
    val invoices = dao.getAllInvoicesSync()
    val invoiceItems = dao.getAllInvoiceItemsSync()
    val transactions = dao.getAllTransactionsSync()
    val expenses = dao.getAllExpensesSync()
    val stockAudits = dao.getAllStockAuditsSync()
    val stockAuditItems = dao.getAllStockAuditItemsSync()
    val accounts = dao.getAllAccountsSync()
    val journalEntries = dao.getAllJournalEntriesSync()
    val journalLines = dao.getAllJournalLinesSync()

    val root = JSONObject().apply {
      put("version", 2)
      put("appName", "الوكيل لتجارة المواد الغذائية")
      put("timestamp", now)
      put("dateFormatted", dateStr)

      // Summary Header for rapid instant reading without parsing all entities
      val summary = JSONObject().apply {
        put("productsCount", products.size)
        put("customersCount", customers.size)
        put("suppliersCount", suppliers.size)
        put("invoicesCount", invoices.size)
        put("transactionsCount", transactions.size)
        put("expensesCount", expenses.size)
        put("stockAuditsCount", stockAudits.size)
        put("accountsCount", accounts.size)
        put("journalEntriesCount", journalEntries.size)
      }
      put("summary", summary)

      // Profile
      val profileObj = JSONObject().apply {
        put("businessName", profile.businessName)
        put("businessType", profile.businessType)
        put("contactPhone", profile.contactPhone)
        put("currency", profile.currency)
        put("address", profile.address)
        put("taxNumber", profile.taxNumber)
        put("commercialRecord", profile.commercialRecord)
        put("selectedCashbox", profile.selectedCashbox)
        put("isDarkMode", profile.isDarkMode)
        put("autoBackupEnabled", profile.autoBackupEnabled)
      }
      put("profile", profileObj)

      // Products
      val productsArr = JSONArray()
      products.forEach { p ->
        productsArr.put(JSONObject().apply {
          put("id", p.id)
          put("name", p.name)
          put("barcode", p.barcode)
          put("category", p.category)
          put("unitName", p.unitName)
          put("cartonName", p.cartonName)
          put("piecesPerCarton", p.piecesPerCarton)
          put("cartonCostPrice", p.cartonCostPrice)
          put("cartonWholesalePrice", p.cartonWholesalePrice)
          put("cartonSemiWholesalePrice", p.cartonSemiWholesalePrice)
          put("pieceWholesalePrice", p.pieceWholesalePrice)
          put("pieceRetailPrice", p.pieceRetailPrice)
          put("totalPiecesInStock", p.totalPiecesInStock)
          put("minStockAlert", p.minStockAlert)
          put("createdAt", p.createdAt)
        })
      }
      put("products", productsArr)

      // Customers
      val customersArr = JSONArray()
      customers.forEach { c ->
        customersArr.put(JSONObject().apply {
          put("id", c.id)
          put("name", c.name)
          put("phone", c.phone)
          put("address", c.address)
          put("creditLimit", c.creditLimit)
          put("currentBalance", c.currentBalance)
          put("notes", c.notes)
          put("createdAt", c.createdAt)
        })
      }
      put("customers", customersArr)

      // Suppliers
      val suppliersArr = JSONArray()
      suppliers.forEach { s ->
        suppliersArr.put(JSONObject().apply {
          put("id", s.id)
          put("name", s.name)
          put("phone", s.phone)
          put("company", s.company)
          put("currentBalance", s.currentBalance)
          put("notes", s.notes)
          put("createdAt", s.createdAt)
        })
      }
      put("suppliers", suppliersArr)

      // Invoices
      val invoicesArr = JSONArray()
      invoices.forEach { inv ->
        invoicesArr.put(JSONObject().apply {
          put("id", inv.id)
          put("invoiceNumber", inv.invoiceNumber)
          put("type", inv.type.name)
          put("partyId", inv.partyId)
          put("partyName", inv.partyName)
          put("timestamp", inv.timestamp)
          put("subtotal", inv.subtotal)
          put("discount", inv.discount)
          put("totalAmount", inv.totalAmount)
          put("paidAmount", inv.paidAmount)
          put("remainingAmount", inv.remainingAmount)
          put("paymentType", inv.paymentType.name)
          put("totalCost", inv.totalCost)
          put("totalProfit", inv.totalProfit)
          put("previousBalance", inv.previousBalance)
          put("grandTotalDue", inv.grandTotalDue)
          put("notes", inv.notes)
        })
      }
      put("invoices", invoicesArr)

      // Invoice Items
      val itemsArr = JSONArray()
      invoiceItems.forEach { item ->
        itemsArr.put(JSONObject().apply {
          put("id", item.id)
          put("invoiceId", item.invoiceId)
          put("productId", item.productId)
          put("productName", item.productName)
          put("unitType", item.unitType)
          put("quantity", item.quantity)
          put("piecesPerCarton", item.piecesPerCarton)
          put("totalPieces", item.totalPieces)
          put("unitPrice", item.unitPrice)
          put("unitCost", item.unitCost)
          put("totalPrice", item.totalPrice)
          put("totalCost", item.totalCost)
          put("itemProfit", item.itemProfit)
        })
      }
      put("invoiceItems", itemsArr)

      // Transactions
      val txArr = JSONArray()
      transactions.forEach { tx ->
        txArr.put(JSONObject().apply {
          put("id", tx.id)
          put("type", tx.type.name)
          put("partyId", tx.partyId)
          put("partyName", tx.partyName)
          put("amount", tx.amount)
          put("notes", tx.notes)
          put("timestamp", tx.timestamp)
        })
      }
      put("transactions", txArr)

      // Expenses
      val expArr = JSONArray()
      expenses.forEach { e ->
        expArr.put(JSONObject().apply {
          put("id", e.id)
          put("category", e.category)
          put("amount", e.amount)
          put("recipient", e.recipient)
          put("notes", e.notes)
          put("timestamp", e.timestamp)
        })
      }
      put("expenses", expArr)

      // Stock Audits
      val auditsArr = JSONArray()
      stockAudits.forEach { a ->
        auditsArr.put(JSONObject().apply {
          put("id", a.id)
          put("auditDate", a.auditDate)
          put("title", a.title)
          put("totalDiscrepancyValue", a.totalDiscrepancyValue)
          put("notes", a.notes)
        })
      }
      put("stockAudits", auditsArr)

      // Stock Audit Items
      val auditItemsArr = JSONArray()
      stockAuditItems.forEach { ai ->
        auditItemsArr.put(JSONObject().apply {
          put("id", ai.id)
          put("auditId", ai.auditId)
          put("productId", ai.productId)
          put("productName", ai.productName)
          put("systemQuantity", ai.systemQuantity)
          put("actualQuantity", ai.actualQuantity)
          put("diffQuantity", ai.diffQuantity)
          put("unitPieceCost", ai.unitPieceCost)
          put("diffCostValue", ai.diffCostValue)
        })
      }
      put("stockAuditItems", auditItemsArr)

      // Accounts
      val accountsArr = JSONArray()
      accounts.forEach { acc ->
        accountsArr.put(JSONObject().apply {
          put("code", acc.code)
          put("name", acc.name)
          put("category", acc.category)
          put("normalBalance", acc.normalBalance)
          put("initialBalance", acc.initialBalance)
          put("description", acc.description)
        })
      }
      put("accounts", accountsArr)

      // Journal Entries
      val jeArr = JSONArray()
      journalEntries.forEach { je ->
        jeArr.put(JSONObject().apply {
          put("id", je.id)
          put("entryNumber", je.entryNumber)
          put("timestamp", je.timestamp)
          put("description", je.description)
          put("referenceType", je.referenceType)
          put("referenceId", je.referenceId)
          put("totalDebit", je.totalDebit)
          put("totalCredit", je.totalCredit)
          put("isBalanced", je.isBalanced)
        })
      }
      put("journalEntries", jeArr)

      // Journal Lines
      val jlArr = JSONArray()
      journalLines.forEach { jl ->
        jlArr.put(JSONObject().apply {
          put("id", jl.id)
          put("entryId", jl.entryId)
          put("accountCode", jl.accountCode)
          put("accountName", jl.accountName)
          put("debit", jl.debit)
          put("credit", jl.credit)
          put("notes", jl.notes)
        })
      }
      put("journalLines", jlArr)
    }

    return root.toString()
  }

  /**
   * حفظ النسخة الاحتياطية في ذاكرة الهاتف بالمكان المحدد من المستخدم.
   * في حال وجود نسخة سابقة يتم استبدالها فوراً لتبقى دائماً نسخة واحدة فقط على الهاتف.
   */
  fun saveBackup(
    context: Context,
    backupJson: String,
    folderUriString: String?
  ): BackupSaveResult {
    val dateStr = SimpleDateFormat("dd/MM/yyyy - hh:mm a", Locale("ar")).format(Date())
    val bytes = backupJson.toByteArray(Charsets.UTF_8)
    val sizeFormatted = formatFileSize(bytes.size.toLong())

    // 1. تجربة الحفظ في المجلد المحدد من قبل المستخدم عبر Storage Access Framework (SAF)
    if (!folderUriString.isNullOrBlank()) {
      try {
        val treeUri = Uri.parse(folderUriString)
        val parentDocId = DocumentsContract.getTreeDocumentId(treeUri)
        val parentDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, parentDocId)
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)

        // حذف النسخة القديمة إذا وجدت لضمان وجود نسخة واحدة فقط على الهاتف
        val projection = arrayOf(
          DocumentsContract.Document.COLUMN_DOCUMENT_ID,
          DocumentsContract.Document.COLUMN_DISPLAY_NAME
        )
        context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
          val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
          val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
          while (cursor.moveToNext()) {
            val name = cursor.getString(nameCol)
            if (name == BACKUP_FILE_NAME || name == "SANAD_ERP_LATEST_BACKUP.json") {
              val docId = cursor.getString(idCol)
              val existingDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
              try {
                DocumentsContract.deleteDocument(context.contentResolver, existingDocUri)
              } catch (_: Exception) {}
            }
          }
        }

        // إنشاء النسخة الجديدة وكتابة البيانات إليها
        val targetUri = DocumentsContract.createDocument(
          context.contentResolver,
          parentDocUri,
          "application/octet-stream",
          BACKUP_FILE_NAME
        )

        if (targetUri != null) {
          context.contentResolver.openOutputStream(targetUri, "wt")?.use { out ->
            out.write(bytes)
            out.flush()
          }

          // حفظ نسخة تكرار أمان محلية أيضاً في مجلد مستندات التطبيق
          saveToAppInternalDocuments(context, bytes)

          return BackupSaveResult(
            success = true,
            filePathOrUri = folderUriString,
            dateFormatted = dateStr,
            fileSizeFormatted = sizeFormatted,
            summaryText = "تم استبدال النسخة السابقة وحفظ النسخة الأحدث بنجاح في المجلد المحدد"
          )
        }
      } catch (_: Exception) {
        // Fallback to local storage if user revoked permission or folder unavailable
      }
    }

    // 2. الحفظ الافتراضي في ذاكرة الهاتف (مجلد Documents الخاص بالتطبيق)
    try {
      val localFile = saveToAppInternalDocuments(context, bytes)
      return BackupSaveResult(
        success = true,
        filePathOrUri = localFile.absolutePath,
        dateFormatted = dateStr,
        fileSizeFormatted = sizeFormatted,
        summaryText = "تم استبدال وحفظ النسخة في ذاكرة الهاتف (مجلد المستندات)"
      )
    } catch (e: Exception) {
      return BackupSaveResult(
        success = false,
        filePathOrUri = "",
        dateFormatted = dateStr,
        fileSizeFormatted = "0 بايت",
        summaryText = "فشل حفظ النسخة الاحتياطية",
        errorMessage = e.localizedMessage
      )
    }
  }

  private fun saveToAppInternalDocuments(context: Context, bytes: ByteArray): File {
    val backupDir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "SanadBackups")
    if (!backupDir.exists()) {
      backupDir.mkdirs()
    }
    val targetFile = File(backupDir, BACKUP_FILE_NAME)
    if (targetFile.exists()) {
      targetFile.delete() // استبدال وحذف النسخة القديمة
    }
    targetFile.writeBytes(bytes)
    return targetFile
  }

  /**
   * قراءة وفحص آخر نسخة احتياطية محفوظة على الهاتف لعرضها مباشرة في القائمة المنبثقة
   * دون الحاجة للدخول للملفات
   */
  fun getLatestBackupSummary(context: Context, folderUriString: String?): BackupSummary? {
    // 1. فحص مجلد المستخدم المحدد إن وجد
    if (!folderUriString.isNullOrBlank()) {
      try {
        val treeUri = Uri.parse(folderUriString)
        val parentDocId = DocumentsContract.getTreeDocumentId(treeUri)
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
        val projection = arrayOf(
          DocumentsContract.Document.COLUMN_DOCUMENT_ID,
          DocumentsContract.Document.COLUMN_DISPLAY_NAME
        )
        context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
          val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
          val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
          while (cursor.moveToNext()) {
            val name = cursor.getString(nameCol)
            if (name == BACKUP_FILE_NAME || name == "SANAD_ERP_LATEST_BACKUP.json") {
              val docId = cursor.getString(idCol)
              val fileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
              val jsonText = context.contentResolver.openInputStream(fileUri)?.bufferedReader()?.use { it.readText() }
              if (!jsonText.isNullOrBlank()) {
                val summary = parseBackupJsonSummary(jsonText, "المجلد المخصص على الهاتف")
                if (summary != null) return summary
              }
            }
          }
        }
      } catch (_: Exception) {}
    }

    // 2. فحص مجلد التطبيق الافتراضي على ذاكرة الهاتف
    try {
      val backupDir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "SanadBackups")
      val targetFile = File(backupDir, BACKUP_FILE_NAME)
      if (targetFile.exists() && targetFile.length() > 0) {
        val jsonText = targetFile.readText(Charsets.UTF_8)
        val summary = parseBackupJsonSummary(jsonText, targetFile.parent ?: "مستندات الهاتف")
        if (summary != null) return summary
      }
    } catch (_: Exception) {}

    return null
  }

  private fun parseBackupJsonSummary(jsonText: String, folderPath: String): BackupSummary? {
    return try {
      val root = JSONObject(jsonText)
      val timestamp = root.optLong("timestamp", System.currentTimeMillis())
      val dateFormatted = root.optString(
        "dateFormatted",
        SimpleDateFormat("dd/MM/yyyy - hh:mm a", Locale("ar")).format(Date(timestamp))
      )
      val summaryObj = root.optJSONObject("summary")

      val pCount = summaryObj?.optInt("productsCount") ?: root.optJSONArray("products")?.length() ?: 0
      val cCount = summaryObj?.optInt("customersCount") ?: root.optJSONArray("customers")?.length() ?: 0
      val sCount = summaryObj?.optInt("suppliersCount") ?: root.optJSONArray("suppliers")?.length() ?: 0
      val iCount = summaryObj?.optInt("invoicesCount") ?: root.optJSONArray("invoices")?.length() ?: 0
      val tCount = summaryObj?.optInt("transactionsCount") ?: root.optJSONArray("transactions")?.length() ?: 0
      val eCount = summaryObj?.optInt("expensesCount") ?: root.optJSONArray("expenses")?.length() ?: 0
      val jeCount = summaryObj?.optInt("journalEntriesCount") ?: root.optJSONArray("journalEntries")?.length() ?: 0
      val accCount = summaryObj?.optInt("accountsCount") ?: root.optJSONArray("accounts")?.length() ?: 0

      val bytesLen = jsonText.toByteArray(Charsets.UTF_8).size.toLong()
      BackupSummary(
        timestamp = timestamp,
        dateFormatted = dateFormatted,
        fileSizeBytes = bytesLen,
        fileSizeFormatted = formatFileSize(bytesLen),
        folderPath = folderPath,
        productsCount = pCount,
        customersCount = cCount,
        suppliersCount = sCount,
        invoicesCount = iCount,
        transactionsCount = tCount,
        expensesCount = eCount,
        journalEntriesCount = jeCount,
        accountsCount = accCount,
        rawJson = jsonText
      )
    } catch (_: Exception) {
      null
    }
  }

  /**
   * استعادة قاعدة البيانات بالكامل من نص النسخة الاحتياطية بنقرة واحدة داخل Transaction
   */
  suspend fun restoreFromBackupJson(dao: AppDao, jsonText: String): Boolean {
    return try {
      val root = JSONObject(jsonText)

      // Products
      val productsList = mutableListOf<Product>()
      val productsArr = root.optJSONArray("products")
      if (productsArr != null) {
        for (i in 0 until productsArr.length()) {
          val obj = productsArr.getJSONObject(i)
          productsList.add(
            Product(
              id = obj.optLong("id", 0),
              name = obj.optString("name"),
              barcode = obj.optString("barcode"),
              category = obj.optString("category", "عام"),
              unitName = obj.optString("unitName", "قطعة"),
              cartonName = obj.optString("cartonName", "كرتونة"),
              piecesPerCarton = obj.optInt("piecesPerCarton", 12),
              cartonCostPrice = obj.optDouble("cartonCostPrice", 0.0),
              cartonWholesalePrice = obj.optDouble("cartonWholesalePrice", 0.0),
              cartonSemiWholesalePrice = obj.optDouble("cartonSemiWholesalePrice", 0.0),
              pieceWholesalePrice = obj.optDouble("pieceWholesalePrice", 0.0),
              pieceRetailPrice = obj.optDouble("pieceRetailPrice", 0.0),
              totalPiecesInStock = obj.optInt("totalPiecesInStock", 0),
              minStockAlert = obj.optInt("minStockAlert", 24),
              createdAt = obj.optLong("createdAt", System.currentTimeMillis())
            )
          )
        }
      }

      // Customers
      val customersList = mutableListOf<Customer>()
      val customersArr = root.optJSONArray("customers")
      if (customersArr != null) {
        for (i in 0 until customersArr.length()) {
          val obj = customersArr.getJSONObject(i)
          customersList.add(
            Customer(
              id = obj.optLong("id", 0),
              name = obj.optString("name"),
              phone = obj.optString("phone"),
              address = obj.optString("address"),
              creditLimit = obj.optDouble("creditLimit", 0.0),
              currentBalance = obj.optDouble("currentBalance", 0.0),
              notes = obj.optString("notes"),
              createdAt = obj.optLong("createdAt", System.currentTimeMillis())
            )
          )
        }
      }

      // Suppliers
      val suppliersList = mutableListOf<Supplier>()
      val suppliersArr = root.optJSONArray("suppliers")
      if (suppliersArr != null) {
        for (i in 0 until suppliersArr.length()) {
          val obj = suppliersArr.getJSONObject(i)
          suppliersList.add(
            Supplier(
              id = obj.optLong("id", 0),
              name = obj.optString("name"),
              phone = obj.optString("phone"),
              company = obj.optString("company"),
              currentBalance = obj.optDouble("currentBalance", 0.0),
              notes = obj.optString("notes"),
              createdAt = obj.optLong("createdAt", System.currentTimeMillis())
            )
          )
        }
      }

      // Invoices
      val invoicesList = mutableListOf<Invoice>()
      val invoicesArr = root.optJSONArray("invoices")
      if (invoicesArr != null) {
        for (i in 0 until invoicesArr.length()) {
          val obj = invoicesArr.getJSONObject(i)
          val typeStr = obj.optString("type", InvoiceType.SALE.name)
          val type = try { InvoiceType.valueOf(typeStr) } catch (_: Exception) { InvoiceType.SALE }
          val payStr = obj.optString("paymentType", PaymentType.CASH.name)
          val payType = try { PaymentType.valueOf(payStr) } catch (_: Exception) { PaymentType.CASH }

          invoicesList.add(
            Invoice(
              id = obj.optLong("id", 0),
              invoiceNumber = obj.optString("invoiceNumber"),
              type = type,
              partyId = obj.optLong("partyId", 0L),
              partyName = obj.optString("partyName", "عميل نقدي"),
              timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
              subtotal = obj.optDouble("subtotal", 0.0),
              discount = obj.optDouble("discount", 0.0),
              totalAmount = obj.optDouble("totalAmount", 0.0),
              paidAmount = obj.optDouble("paidAmount", 0.0),
              remainingAmount = obj.optDouble("remainingAmount", 0.0),
              paymentType = payType,
              totalCost = obj.optDouble("totalCost", 0.0),
              totalProfit = obj.optDouble("totalProfit", 0.0),
              previousBalance = obj.optDouble("previousBalance", 0.0),
              grandTotalDue = obj.optDouble("grandTotalDue", 0.0),
              notes = obj.optString("notes")
            )
          )
        }
      }

      // Invoice Items
      val itemsList = mutableListOf<InvoiceItem>()
      val itemsArr = root.optJSONArray("invoiceItems")
      if (itemsArr != null) {
        for (i in 0 until itemsArr.length()) {
          val obj = itemsArr.getJSONObject(i)
          itemsList.add(
            InvoiceItem(
              id = obj.optLong("id", 0),
              invoiceId = obj.optLong("invoiceId", 0L),
              productId = obj.optLong("productId", 0L),
              productName = obj.optString("productName"),
              unitType = obj.optString("unitType", "قطعة"),
              quantity = obj.optInt("quantity", 1),
              piecesPerCarton = obj.optInt("piecesPerCarton", 1),
              totalPieces = obj.optInt("totalPieces", 1),
              unitPrice = obj.optDouble("unitPrice", 0.0),
              unitCost = obj.optDouble("unitCost", 0.0),
              totalPrice = obj.optDouble("totalPrice", 0.0),
              totalCost = obj.optDouble("totalCost", 0.0),
              itemProfit = obj.optDouble("itemProfit", 0.0)
            )
          )
        }
      }

      // Payment Transactions
      val txList = mutableListOf<PaymentTransaction>()
      val txArr = root.optJSONArray("transactions")
      if (txArr != null) {
        for (i in 0 until txArr.length()) {
          val obj = txArr.getJSONObject(i)
          val typeStr = obj.optString("type", TransactionType.CUSTOMER_PAYMENT.name)
          val type = try { TransactionType.valueOf(typeStr) } catch (_: Exception) { TransactionType.CUSTOMER_PAYMENT }

          txList.add(
            PaymentTransaction(
              id = obj.optLong("id", 0),
              type = type,
              partyId = obj.optLong("partyId", 0L),
              partyName = obj.optString("partyName"),
              amount = obj.optDouble("amount", 0.0),
              notes = obj.optString("notes"),
              timestamp = obj.optLong("timestamp", System.currentTimeMillis())
            )
          )
        }
      }

      // Expenses
      val expList = mutableListOf<Expense>()
      val expArr = root.optJSONArray("expenses")
      if (expArr != null) {
        for (i in 0 until expArr.length()) {
          val obj = expArr.getJSONObject(i)
          expList.add(
            Expense(
              id = obj.optLong("id", 0),
              category = obj.optString("category"),
              amount = obj.optDouble("amount", 0.0),
              recipient = obj.optString("recipient"),
              notes = obj.optString("notes"),
              timestamp = obj.optLong("timestamp", System.currentTimeMillis())
            )
          )
        }
      }

      // Stock Audits
      val auditList = mutableListOf<StockAudit>()
      val auditsArr = root.optJSONArray("stockAudits")
      if (auditsArr != null) {
        for (i in 0 until auditsArr.length()) {
          val obj = auditsArr.getJSONObject(i)
          auditList.add(
            StockAudit(
              id = obj.optLong("id", 0),
              auditDate = obj.optLong("auditDate", System.currentTimeMillis()),
              title = obj.optString("title", "جرد مخزني"),
              totalDiscrepancyValue = obj.optDouble("totalDiscrepancyValue", 0.0),
              notes = obj.optString("notes")
            )
          )
        }
      }

      // Stock Audit Items
      val auditItemsList = mutableListOf<StockAuditItem>()
      val auditItemsArr = root.optJSONArray("stockAuditItems")
      if (auditItemsArr != null) {
        for (i in 0 until auditItemsArr.length()) {
          val obj = auditItemsArr.getJSONObject(i)
          auditItemsList.add(
            StockAuditItem(
              id = obj.optLong("id", 0),
              auditId = obj.optLong("auditId", 0L),
              productId = obj.optLong("productId", 0L),
              productName = obj.optString("productName"),
              systemQuantity = obj.optInt("systemQuantity", 0),
              actualQuantity = obj.optInt("actualQuantity", 0),
              diffQuantity = obj.optInt("diffQuantity", 0),
              unitPieceCost = obj.optDouble("unitPieceCost", 0.0),
              diffCostValue = obj.optDouble("diffCostValue", 0.0)
            )
          )
        }
      }

      // Accounts
      val accountsList = mutableListOf<Account>()
      val accountsArr = root.optJSONArray("accounts")
      if (accountsArr != null) {
        for (i in 0 until accountsArr.length()) {
          val obj = accountsArr.getJSONObject(i)
          accountsList.add(
            Account(
              code = obj.optString("code"),
              name = obj.optString("name"),
              category = obj.optString("category", "أصول متداولة"),
              normalBalance = obj.optString("normalBalance", "DEBIT"),
              initialBalance = obj.optDouble("initialBalance", 0.0),
              description = obj.optString("description")
            )
          )
        }
      }

      // Journal Entries
      val jeList = mutableListOf<JournalEntry>()
      val jeArr = root.optJSONArray("journalEntries")
      if (jeArr != null) {
        for (i in 0 until jeArr.length()) {
          val obj = jeArr.getJSONObject(i)
          jeList.add(
            JournalEntry(
              id = obj.optLong("id", 0),
              entryNumber = obj.optString("entryNumber"),
              timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
              description = obj.optString("description"),
              referenceType = obj.optString("referenceType", "MANUAL"),
              referenceId = obj.optLong("referenceId", 0L),
              totalDebit = obj.optDouble("totalDebit", 0.0),
              totalCredit = obj.optDouble("totalCredit", 0.0),
              isBalanced = obj.optBoolean("isBalanced", true)
            )
          )
        }
      }

      // Journal Lines
      val jlList = mutableListOf<JournalLine>()
      val jlArr = root.optJSONArray("journalLines")
      if (jlArr != null) {
        for (i in 0 until jlArr.length()) {
          val obj = jlArr.getJSONObject(i)
          jlList.add(
            JournalLine(
              id = obj.optLong("id", 0),
              entryId = obj.optLong("entryId", 0L),
              accountCode = obj.optString("accountCode"),
              accountName = obj.optString("accountName"),
              debit = obj.optDouble("debit", 0.0),
              credit = obj.optDouble("credit", 0.0),
              notes = obj.optString("notes")
            )
          )
        }
      }

      // استعادة وتنفيذ الاستبدال الذري للبيانات داخل عملية واحدة
      dao.restoreDatabaseAll(
        products = productsList,
        customers = customersList,
        suppliers = suppliersList,
        invoices = invoicesList,
        invoiceItems = itemsList,
        transactions = txList,
        expenses = expList,
        stockAudits = auditList,
        stockAuditItems = auditItemsList,
        accounts = accountsList,
        journalEntries = jeList,
        journalLines = jlList
      )

      true
    } catch (e: Exception) {
      e.printStackTrace()
      false
    }
  }

  fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return "0 بايت"
    val kb = bytes / 1024.0
    if (kb < 1024.0) {
      return String.format(Locale.ENGLISH, "%.1f ك.ب", kb)
    }
    val mb = kb / 1024.0
    return String.format(Locale.ENGLISH, "%.2f م.ب", mb)
  }
}
