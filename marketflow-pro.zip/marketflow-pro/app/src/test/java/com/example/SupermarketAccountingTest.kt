package com.example

import com.example.data.model.Customer
import com.example.data.model.Expense
import com.example.data.model.PaymentType
import com.example.data.model.Product
import com.example.data.model.Supplier
import com.example.ui.CartItem
import com.example.ui.PriceTier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SupermarketAccountingTest {

  @Test
  fun productCartonToPieceCalculations_areAccurate() {
    val oilProduct = Product(
      id = 1,
      name = "زيت ذرة عافية 800 مل",
      cartonName = "كرتونة",
      unitName = "زجاجة",
      piecesPerCarton = 12,
      cartonCostPrice = 720.0,      // 60.0 per piece cost
      cartonWholesalePrice = 780.0, // 65.0 per piece wholesale
      cartonSemiWholesalePrice = 800.0,
      pieceWholesalePrice = 65.0,
      pieceRetailPrice = 72.0,      // 72.0 retail
      totalPiecesInStock = 120,     // 10 cartons
      minStockAlert = 24
    )

    assertEquals(60.0, oilProduct.pieceCostPrice, 0.001)
    assertEquals(65.0, oilProduct.pieceWholesalePrice, 0.001)
    assertEquals(10, oilProduct.cartonsInStock)
    assertEquals("10 كرتونة", oilProduct.stockDisplayString())
  }

  @Test
  fun salesCartItemCalculations_areAccurate() {
    val pastaProduct = Product(
      id = 2,
      name = "مكرونة روجينا 400 جم",
      piecesPerCarton = 20,
      cartonCostPrice = 300.0,      // 15.0 per piece cost
      cartonWholesalePrice = 340.0, // 17.0 per piece wholesale
      cartonSemiWholesalePrice = 350.0,
      pieceWholesalePrice = 17.0,
      pieceRetailPrice = 19.0,
      totalPiecesInStock = 100
    )

    val cartItemCarton = CartItem(
      product = pastaProduct,
      unitType = "كرتونة",
      priceTier = PriceTier.WHOLESALE,
      quantity = 3
    )

    assertEquals(60, cartItemCarton.totalPieces)
    assertEquals(340.0, cartItemCarton.unitPrice, 0.001)
    assertEquals(1020.0, cartItemCarton.totalPrice, 0.001)
    assertEquals(900.0, cartItemCarton.totalCost, 0.001)
    assertEquals(120.0, cartItemCarton.itemProfit, 0.001)
  }

  @Test
  fun creditSaleBalance_isCalculatedProperly() {
    val customer = Customer(
      id = 10,
      name = "سوبرماركت الأمل",
      currentBalance = 1500.0,
      creditLimit = 10000.0
    )

    val invoiceTotal = 3000.0
    val paidAmount = 1000.0
    val remainingDebt = invoiceTotal - paidAmount

    val updatedBalance = customer.currentBalance + remainingDebt
    assertEquals(3500.0, updatedBalance, 0.001)
    assertTrue(updatedBalance <= customer.creditLimit)
  }
}
